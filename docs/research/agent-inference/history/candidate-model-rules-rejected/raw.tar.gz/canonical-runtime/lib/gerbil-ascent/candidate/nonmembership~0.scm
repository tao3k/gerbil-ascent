(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/nonmembership::timestamp 1791687890)
  (begin
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
      (let ((__tmp37618 (list)) (__tmp37617 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'positive-nonmembership
         __tmp37618
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         __tmp37617
         '#f)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t)))
    (define gerbil-ascent/candidate/nonmembership#make-positive-nonmembership
      (lambda _%$args29685%_
        (apply make-instance
               gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
               _%$args29685%_)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#certificate-size-valid?
      (lambda (_%closure29669%_)
        (let ((_%relation-count29671%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                  _%closure29669%_
                  gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)))
              (_%rows29672%_ '0)
              (_%cells29673%_ '0))
          (if _%relation-count29671%_
              (let ((__tmp37619
                     (lambda (_%entry29675%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry29675%_
                                      '3))
                                   '3)
                           (let* ((_%row-list29677%_ (caddr _%entry29675%_))
                                  (_%count29679%_
                                   (let ((__tmp37620
                                          (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                             _%rows29672%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%row-list29677%_
                                      __tmp37620))))
                             (if _%count29679%_
                                 (if (begin
                                       (set! _%rows29672%_
                                             (+ _%rows29672%_ _%count29679%_))
                                       '#t)
                                     (let ((__tmp37621
                                            (lambda (_%row29681%_)
                                              (let ((_%width29683%_
                                                     (let ((__tmp37622
                                                            (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                            _%cells29673%_))))
               (declare (not safe))
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row29681%_
                __tmp37622))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%width29683%_
                                                    (begin
                                                      (set! _%cells29673%_
                                                            (+ _%cells29673%_
                                                               _%width29683%_))
                                                      '#t)
                                                    '#f)))))
                                       (declare (not safe))
                                       (andmap__0
                                        __tmp37621
                                        _%row-list29677%_))
                                     '#f)
                                 '#f))
                           '#f))))
                (declare (not safe))
                (andmap__0 __tmp37619 _%closure29669%_))
              '#f))))
    (define gerbil-ascent/candidate/nonmembership#ground-query?
      (lambda (_%query29665%_)
        (if (list? _%query29665%_)
            (if (pair? _%query29665%_)
                (let ((__tmp37624
                       (lambda (_%term29667%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term29667%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term29667%_))
                                 '#f
                                 (not (eq? _%term29667%_ '?_)))
                             '#f)))
                      (__tmp37623
                       (let () (declare (not safe)) (##cdr _%query29665%_))))
                  (declare (not safe))
                  (andmap__0 __tmp37624 __tmp37623))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/nonmembership#certificate-schema-of
      (lambda (_%snapshot29660%_ _%spec29661%_)
        (let ((__tmp37626
               (lambda (_%entry29663%_)
                 (list (car _%entry29663%_) (cdr _%entry29663%_))))
              (__tmp37625
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/funs#candidate-schema-of
                  _%snapshot29660%_
                  _%spec29661%_))))
          (declare (not safe))
          (##map __tmp37626 __tmp37625))))
    (define gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
      (lambda (_%snapshot29610%_
               _%spec29611%_
               _%candidate-digest29612%_
               _%native-status29613%_
               _%native-rows29614%_
               _%max-steps29615%_)
        (if (and (exact-integer? _%max-steps29615%_) (> _%max-steps29615%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership work budget" _%max-steps29615%_)))
        (let ((_%query29617%_
               (vector-ref
                (##structure-ref
                 _%spec29611%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29619%_
                    (lambda (_%status29657%_ _%closure29658%_)
                      (let ((__tmp37631
                             (##structure-ref
                              _%snapshot29610%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37630
                             (##structure-ref
                              _%snapshot29610%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37629
                             (##structure-ref
                              _%snapshot29610%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37628
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                                _%spec29611%_)))
                            (__tmp37627
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29617%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
                         _%status29657%_
                         __tmp37631
                         __tmp37630
                         __tmp37629
                         _%candidate-digest29612%_
                         __tmp37628
                         __tmp37627
                         _%max-steps29615%_
                         _%closure29658%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29610%_)))
                    (not (eq? _%native-status29613%_ 'complete))
                    (pair? _%native-rows29614%_)
                    (not (gerbil-ascent/candidate/nonmembership#ground-query?
                          _%query29617%_))
                    (not (let ((__tmp37632
                                (##structure-ref
                                 _%spec29611%_
                                 '3
                                 gerbil-ascent/candidate/types#reasoning-candidate::t
                                 '#f)))
                           (declare (not safe))
                           (andmap__0
                            gerbil-ascent/candidate/provenance#positive-rule-body?
                            __tmp37632))))
                (_%result29619%_ 'unsupported '())
                (if (> (let ((__tmp37633
                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                               _%snapshot29610%_
                               _%spec29611%_)))
                         (declare (not safe))
                         (##length __tmp37633))
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                    (_%result29619%_ 'bounded '())
                    (let* ((_%witness29633%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
                               _%snapshot29610%_
                               _%spec29611%_
                               _%candidate-digest29612%_
                               _%native-status29613%_
                               _%native-rows29614%_
                               _%max-steps29615%_)))
                           (_%status29635%_
                            (##structure-ref
                             _%witness29633%_
                             '1
                             gerbil-ascent/candidate/provenance#positive-proof::t
                             '#f))
                           (_%$e29638%_ _%status29635%_))
                      (if (eq? 'bounded _%$e29638%_)
                          (_%result29619%_ 'bounded '())
                          (if (eq? 'closed-absent _%$e29638%_)
                              (let ((_%grouped29641%_
                                     (let ()
                                       (declare (not safe))
                                       (make-hash-table-eq))))
                                (for-each
                                 (lambda (_%node29643%_)
                                   (let* ((_%name29645%_
                                           (##structure-ref
                                            _%node29643%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f))
                                          (__tmp37634
                                           (cons (##structure-ref
                                                  _%node29643%_
                                                  '4
                                                  gerbil-ascent/candidate/provenance#proof-node::t
                                                  '#f)
                                                 (let ((_%$e29647%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-get
                                                           _%grouped29641%_
                                                           _%name29645%_))))
                                                   (if _%$e29647%_
                                                       _%$e29647%_
                                                       '())))))
                                     (declare (not safe))
                                     (__hash-put!
                                      _%grouped29641%_
                                      _%name29645%_
                                      __tmp37634)))
                                 (##structure-ref
                                  _%witness29633%_
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))
                                (let ((_%closure29655%_
                                       (let ((__tmp37636
                                              (lambda (_%declaration29650%_)
                                                (list (car _%declaration29650%_)
                                                      (cadr _%declaration29650%_)
                                                      (let ((__tmp37637
                                                             (reverse (let ((_%$e29652%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     (let ((__tmp37638
                                            (car _%declaration29650%_)))
                                       (declare (not safe))
                                       (__hash-get
                                        _%grouped29641%_
                                        __tmp37638))))
                                (if _%$e29652%_ _%$e29652%_ '())))))
                (declare (not safe))
                (##map gerbil-ascent/candidate/datum#candidate-copy-pairs
                       __tmp37637)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (__tmp37635
                                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                                               _%snapshot29610%_
                                               _%spec29611%_)))
                                         (declare (not safe))
                                         (##map __tmp37636 __tmp37635))))
                                  (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                                       _%closure29655%_)
                                      (_%result29619%_
                                       'complete
                                       _%closure29655%_)
                                      (_%result29619%_ 'bounded '()))))
                              (_%result29619%_ 'unsupported '()))))))))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__%
      (lambda (_%terms29592%_ _%wildcards?29593%_)
        (map (lambda (_%term29595%_)
               (cons (if (and _%wildcards?29593%_ (eq? _%term29595%_ '?_))
                         'wildcard
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-variable?
                                _%term29595%_))
                             'variable
                             'literal))
                     _%term29595%_))
             _%terms29592%_)))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__0
      (lambda (_%terms29603%_)
        (let ((_%wildcards?29605%_ '#t))
          (gerbil-ascent/candidate/nonmembership#binding-patterns__%
           _%terms29603%_
           _%wildcards?29605%_))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns
      (lambda _g37639_
        (let ((_g37640_ (let () (declare (not safe)) (##length _g37639_))))
          (cond ((let () (declare (not safe)) (##fx= _g37640_ 1))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__0
                        _g37639_))
                ((let () (declare (not safe)) (##fx= _g37640_ 2))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__%
                        _g37639_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/nonmembership#binding-patterns
                  _g37639_))))))
    (define gerbil-ascent/candidate/nonmembership#head-row
      (lambda (_%head29586%_ _%bindings29587%_)
        (map (lambda (_%term29589%_)
               (if (eq? (car _%term29589%_) 'variable)
                   (cdr (assq (cdr _%term29589%_) _%bindings29587%_))
                   (cdr _%term29589%_)))
             _%head29586%_)))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
      (lambda (_%snapshot29411%_
               _%spec29412%_
               _%candidate-digest29413%_
               _%native-status29414%_
               _%native-rows29415%_
               _%certificate29416%_
               _%max-checks29417%_)
        (if (and (exact-integer? _%max-checks29417%_)
                 (> _%max-checks29417%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership verification budget"
                     _%max-checks29417%_)))
        (let* ((_%query29419%_
                (vector-ref
                 (##structure-ref
                  _%spec29412%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%schema29421%_
                (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                 _%snapshot29411%_
                 _%spec29412%_))
               (_%closure29423%_
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%certificate29416%_
                       'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%certificate29416%_
                       '9
                       '#f
                       '#f))
                    '#f))
               (_%preflight29431%_
                (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                     _%closure29423%_)
                    (if (= (length _%closure29423%_)
                           (let ()
                             (declare (not safe))
                             (##length _%schema29421%_)))
                        (if (let ((__tmp37641
                                   (lambda (_%entry29425%_)
                                     (and (list? _%entry29425%_)
                                          (= (let ()
                                               (declare (not safe))
                                               (##length _%entry29425%_))
                                             '3)
                                          (list? (caddr _%entry29425%_))))))
                              (declare (not safe))
                              (andmap__0 __tmp37641 _%closure29423%_))
                            (+ '1
                               (let ((__tmp37642
                                      (map (lambda (_%entry29427%_)
                                             (length (caddr _%entry29427%_)))
                                           _%closure29423%_)))
                                 (declare (not safe))
                                 (##apply + __tmp37642))
                               (let ((__tmp37643
                                      (map (lambda (_%entry29429%_)
                                             (length (caddr _%entry29429%_)))
                                           (##structure-ref
                                            _%snapshot29411%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f))))
                                 (declare (not safe))
                                 (##apply + __tmp37643))
                               (length (##structure-ref
                                        _%spec29412%_
                                        '2
                                        gerbil-ascent/candidate/types#reasoning-candidate::t
                                        '#f)))
                            '#f)
                        '#f)
                    '#f)))
          (if (and (let ()
                     (declare (not safe))
                     (##structure-instance-of?
                      _%certificate29416%_
                      'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                      _%snapshot29411%_))
                   (eq? (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%certificate29416%_
                           '1
                           '#f
                           '#f))
                        'complete)
                   (eq? _%native-status29414%_ 'complete)
                   (null? _%native-rows29415%_)
                   (gerbil-ascent/candidate/nonmembership#ground-query?
                    _%query29419%_)
                   (let ((__tmp37644
                          (##structure-ref
                           _%spec29412%_
                           '3
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)))
                     (declare (not safe))
                     (andmap__0
                      gerbil-ascent/candidate/provenance#positive-rule-body?
                      __tmp37644))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '2
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29411%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '3
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29411%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '4
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29411%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '5
                              '#f
                              '#f))
                           _%candidate-digest29413%_)
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '6
                              '#f
                              '#f))
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                              _%spec29412%_)))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29416%_
                              '7
                              '#f
                              '#f))
                           _%query29419%_)
                   _%preflight29431%_
                   (equal? (map (lambda (_%entry29434%_)
                                  (list (car _%entry29434%_)
                                        (cadr _%entry29434%_)))
                                _%closure29423%_)
                           _%schema29421%_))
              (if (> _%preflight29431%_ _%max-checks29417%_)
                  'bounded
                  (if (let ((__tmp37645
                             (lambda (_%entry29438%_)
                               (and (let ((__tmp37646 (caddr _%entry29438%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                       __tmp37646))
                                    (let ((__tmp37648
                                           (lambda (_%row29440%_)
                                             (and (list? _%row29440%_)
                                                  (= (let ()
                                                       (declare (not safe))
                                                       (##length _%row29440%_))
                                                     (cadr _%entry29438%_))
                                                  (let ()
                                                    (declare (not safe))
                                                    (andmap__0
                                                     gerbil-ascent/candidate/program#scalar?
                                                     _%row29440%_)))))
                                          (__tmp37647 (caddr _%entry29438%_)))
                                      (declare (not safe))
                                      (andmap__0 __tmp37648 __tmp37647))))))
                        (declare (not safe))
                        (andmap__0 __tmp37645 _%closure29423%_))
                      (let* ((_%steps29444%_ _%preflight29431%_)
                             (_%bounded?29446%_ '#f)
                             (_%invalid?29448%_ '#f)
                             (_%direct?29505%_
                              (let* ((_%$%closure2944929465%_ _%closure29423%_)
                                     (_%$%else2945329473%_ (lambda () '#f)))
                                (let ((_%$%K2946329502%_ (lambda () '#t))
                                      (_%$%K2946029492%_ (lambda () '#t))
                                      (_%$%K2945529478%_ (lambda () '#t)))
                                  (let ((_%$%try-match2945129498%_
                                         (lambda ()
                                           (if (pair? _%$%closure2944929465%_)
                                               (let ((_%$%tl2946229495%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%closure2944929465%_))))
                                                 (if (null? _%$%tl2946229495%_)
                                                     (_%$%K2946029492%_)
                                                     (if (pair? _%$%tl2946229495%_)
                                                         (let ((_%$%tl2945929484%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##cdr _%$%tl2946229495%_))))
                   (if (null? _%$%tl2945929484%_)
                       (_%$%K2945529478%_)
                       (_%$%else2945329473%_)))
                 (_%$%else2945329473%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%$%else2945329473%_)))))
                                    (if (null? _%$%closure2944929465%_)
                                        (_%$%K2946329502%_)
                                        (_%$%try-match2945129498%_))))))
                             (_%index29507%_
                              (if _%direct?29505%_
                                  '()
                                  (let ((__tmp37649 (length _%closure29423%_)))
                                    (declare (not safe))
                                    (make-hash-table-eq 'size: __tmp37649)))))
                        (letrec* ((_%relation-entry29510%_
                                   (lambda (_%name29582%_)
                                     (if _%direct?29505%_
                                         (let ((_%entry29584%_
                                                (assq _%name29582%_
                                                      _%index29507%_)))
                                           (if _%entry29584%_
                                               (cdr _%entry29584%_)
                                               '#f))
                                         (let ()
                                           (declare (not safe))
                                           (hash-get
                                            _%index29507%_
                                            _%name29582%_)))))
                                  (_g37650_
                                   (let ((_g37651_
                                          (for-each
                                           (lambda (_%entry29512%_)
                                             (let ((_%present29514%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (make-hash-table__%
                                                       '#f
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value))))
                                               (for-each
                                                (lambda (_%row29516%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%present29514%_
                                                     _%row29516%_
                                                     '#t)))
                                                (caddr _%entry29512%_))
                                               (if (_%relation-entry29510%_
                                                    (car _%entry29512%_))
                                                   '#!void
                                                   (let ((_%value29518%_
                                                          (cons (caddr _%entry29512%_)
                                                                _%present29514%_)))
                                                     (if _%direct?29505%_
                                                         (set! _%index29507%_
                                                               (cons (cons (car _%entry29512%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                   _%value29518%_)
                             _%index29507%_))
                 (let ((__tmp37653 (car _%entry29512%_)))
                   (declare (not safe))
                   (hash-put! _%index29507%_ __tmp37653 _%value29518%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           _%closure29423%_)))
                                     #!void
                                     _g37651_))
                                  (_%rows29519%_
                                   (lambda (_%name29578%_)
                                     (let ((_%entry29580%_
                                            (_%relation-entry29510%_
                                             _%name29578%_)))
                                       (if _%entry29580%_
                                           (car _%entry29580%_)
                                           '()))))
                                  (_%contains?29520%_
                                   (lambda (_%name29573%_ _%row29574%_)
                                     (let ((_%entry29576%_
                                            (_%relation-entry29510%_
                                             _%name29573%_)))
                                       (if _%entry29576%_
                                           (let ((__tmp37654
                                                  (cdr _%entry29576%_)))
                                             (declare (not safe))
                                             (hash-get
                                              __tmp37654
                                              _%row29574%_))
                                           '#f)))))
                          (begin
                            (if _%bounded?29446%_
                                '#!void
                                (for-each
                                 (lambda (_%entry29522%_)
                                   (for-each
                                    (lambda (_%row29524%_)
                                      (if (_%contains?29520%_
                                           (car _%entry29522%_)
                                           _%row29524%_)
                                          '#!void
                                          (set! _%invalid?29448%_ '#t)))
                                    (caddr _%entry29522%_)))
                                 (##structure-ref
                                  _%snapshot29411%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f)))
                            (if _%bounded?29446%_
                                '#!void
                                (for-each
                                 (lambda (_%fact29526%_)
                                   (if (_%contains?29520%_
                                        (vector-ref _%fact29526%_ '0)
                                        (vector-ref _%fact29526%_ '1))
                                       '#!void
                                       (set! _%invalid?29448%_ '#t)))
                                 (##structure-ref
                                  _%spec29412%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if (if _%bounded?29446%_
                                    '#f
                                    (_%contains?29520%_
                                     (car _%query29419%_)
                                     (cdr _%query29419%_)))
                                (set! _%invalid?29448%_ '#t)
                                '#!void)
                            (if (or _%bounded?29446%_ _%invalid?29448%_)
                                '#!void
                                (for-each
                                 (lambda (_%rule29531%_)
                                   (let* ((_%head29533%_
                                           (vector-ref _%rule29531%_ '0))
                                          (_%covered-head?29537%_
                                           (if (memq '?_ (cdr _%head29533%_))
                                               '#f
                                               (let ((__tmp37656
                                                      (lambda (_%clause29535%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                               _%clause29535%_))
                                                            '#f
                                                            (equal? _%head29533%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%clause29535%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp37655
                                                      (vector-ref
                                                       _%rule29531%_
                                                       '1)))
                                                 (declare (not safe))
                                                 (ormap__0
                                                  __tmp37656
                                                  __tmp37655))))
                                          (_%head-patterns29539%_
                                           (if _%covered-head?29537%_
                                               '()
                                               (gerbil-ascent/candidate/nonmembership#binding-patterns__%
                                                (cdr _%head29533%_)
                                                '#f)))
                                          (_%head-entry29541%_
                                           (if _%covered-head?29537%_
                                               '#f
                                               (_%relation-entry29510%_
                                                (car _%head29533%_))))
                                          (_%body29545%_
                                           (map (lambda (_%clause29543%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                         _%clause29543%_))
                                                      (vector '#t
                                                              _%clause29543%_
                                                              '())
                                                      (vector '#f
                                                              (gerbil-ascent/candidate/nonmembership#binding-patterns__0
                                                               (cdr _%clause29543%_))
                                                              (_%rows29519%_
                                                               (car _%clause29543%_)))))
                                                (vector-ref
                                                 _%rule29531%_
                                                 '1))))
                                     (letrec ((_%walk29548%_
                                               (lambda (_%remaining29550%_
                                                        _%bindings29551%_)
                                                 (if (or _%bounded?29446%_
                                                         _%invalid?29448%_)
                                                     '#!void
                                                     (if (null? _%remaining29550%_)
                                                         (if (or _%covered-head?29537%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (and _%head-entry29541%_
                              (let ((__tmp37658 (cdr _%head-entry29541%_))
                                    (__tmp37657
                                     (gerbil-ascent/candidate/nonmembership#head-row
                                      _%head-patterns29539%_
                                      _%bindings29551%_)))
                                (declare (not safe))
                                (hash-get __tmp37658 __tmp37657))))
                     '#!void
                     (set! _%invalid?29448%_ '#t))
                 (let ((_%clause29559%_ (car _%remaining29550%_)))
                   (if (vector-ref _%clause29559%_ '0)
                       (begin
                         (set! _%steps29444%_ (+ _%steps29444%_ '1))
                         (if (> _%steps29444%_ _%max-checks29417%_)
                             (set! _%bounded?29446%_ '#t)
                             (let ((_%next29561%_
                                    (let ((__tmp37659
                                           (vector-ref _%clause29559%_ '1)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                       __tmp37659
                                       _%bindings29551%_))))
                               (if _%next29561%_
                                   (_%walk29548%_
                                    (cdr _%remaining29550%_)
                                    _%next29561%_)
                                   '#!void))))
                       (for-each
                        (lambda (_%row29563%_)
                          (if (or _%bounded?29446%_ _%invalid?29448%_)
                              '#!void
                              (begin
                                (set! _%steps29444%_ (+ _%steps29444%_ '1))
                                (if (> _%steps29444%_ _%max-checks29417%_)
                                    (set! _%bounded?29446%_ '#t)
                                    (let ((_%next29568%_
                                           (let ((__tmp37660
                                                  (vector-ref
                                                   _%clause29559%_
                                                   '1)))
                                             (declare (not safe))
                                             (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                              __tmp37660
                                              _%row29563%_
                                              _%bindings29551%_))))
                                      (if _%next29568%_
                                          (_%walk29548%_
                                           (cdr _%remaining29550%_)
                                           _%next29568%_)
                                          '#!void))))))
                        (vector-ref _%clause29559%_ '2)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29548%_ _%body29545%_ '()))))
                                 (##structure-ref
                                  _%spec29412%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if _%invalid?29448%_
                                'invalid
                                (if _%bounded?29446%_ 'bounded 'valid)))))
                      'invalid))
              'invalid))))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership
      (lambda (_%snapshot29403%_
               _%spec29404%_
               _%candidate-digest29405%_
               _%native-status29406%_
               _%native-rows29407%_
               _%certificate29408%_
               _%max-checks29409%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29403%_))
            (gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
             _%snapshot29403%_
             _%spec29404%_
             _%candidate-digest29405%_
             _%native-status29406%_
             _%native-rows29407%_
             _%certificate29408%_
             _%max-checks29409%_)
            'invalid)))))
