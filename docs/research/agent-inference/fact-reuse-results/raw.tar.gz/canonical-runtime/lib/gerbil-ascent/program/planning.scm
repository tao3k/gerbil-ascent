(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/core/rule-semantics")
    (load-module "gerbil-ascent/core/positive-plan")
    (load-module "clan/poo/object"))
  (load-module "gerbil-ascent/program/planning~0"))
