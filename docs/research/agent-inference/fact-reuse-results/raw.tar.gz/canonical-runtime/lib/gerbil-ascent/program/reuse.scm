(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/activation")
    (load-module "std/func")
    (load-module "gerbil-ascent/program/result")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/core/rule-semantics")
    (load-module "gerbil-ascent/program/update-selection"))
  (load-module "gerbil-ascent/program/reuse~0"))
