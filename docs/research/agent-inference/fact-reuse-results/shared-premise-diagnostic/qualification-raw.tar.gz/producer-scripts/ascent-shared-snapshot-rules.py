import importlib.util,json,time
from pathlib import Path
p=Path.cwd()/'tools/research/candidate-model.py';spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=m.ROOT/'.cache/ascent/candidate-interaction/shared-premise-snapshot-qualification';out=base/'rules';out.mkdir(exist_ok=False)
results=[]
for label,mode in [('native',False),('full-gxi',True)]:
 d=out/label;d.mkdir();c=m.Consumer(d,mode)
 try:
  checks=[c.call(op='qualify',group=i) for i in range(8)]
  results.append({'mode':label,'checks':checks})
 finally:
  close=c.close();results[-1]['shutdown']=close;m.save(out/'receipt.json',{'results':results});assert close['clean']
 assert sum(x['checks'] for x in checks)==448
 assert checks[-1]['staleRejected'] and checks[-1]['boundedNotMatch']
 print(label,'448 RULE_CHECKS_OK',flush=True)
