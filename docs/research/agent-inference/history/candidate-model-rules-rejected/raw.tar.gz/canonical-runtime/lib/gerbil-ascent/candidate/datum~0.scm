(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/datum::timestamp 1791687861)
  (begin
    (define gerbil-ascent/candidate/datum#datum-frame::t
      (let ((__tmp33931 (list))
            (__tmp33930
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/datum#datum-frame::t
         'datum-frame
         __tmp33931
         '(pair depth tail?)
         __tmp33930
         '#f)))
    (define gerbil-ascent/candidate/datum#datum-frame?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/candidate/datum#datum-frame::t)))
    (define gerbil-ascent/candidate/datum#make-datum-frame
      (lambda _%$args26695%_
        (apply make-instance
               gerbil-ascent/candidate/datum#datum-frame::t
               _%$args26695%_)))
    (define gerbil-ascent/candidate/datum#datum-frame-pair
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#datum-frame-depth
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#datum-frame-tail?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#datum-frame-pair-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#datum-frame-depth-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#datum-frame-tail?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#&datum-frame-pair
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#&datum-frame-depth
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#&datum-frame-tail?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#&datum-frame-pair-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'pair)))
    (define gerbil-ascent/candidate/datum#&datum-frame-depth-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'depth)))
    (define gerbil-ascent/candidate/datum#&datum-frame-tail?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/datum#datum-frame::t
         'tail?)))
    (define gerbil-ascent/candidate/datum#candidate-datum-scalar?
      (lambda (_%value26684%_)
        (let ((_%$e26686%_ (exact-integer? _%value26684%_)))
          (if _%$e26686%_
              _%$e26686%_
              (let ((_%$e26689%_ (boolean? _%value26684%_)))
                (if _%$e26689%_
                    _%$e26689%_
                    (let ((_%$e26692%_ (symbol? _%value26684%_)))
                      (if _%$e26692%_
                          _%$e26692%_
                          (char? _%value26684%_)))))))))
    (define gerbil-ascent/candidate/datum#reasoning-bounded-data?
      (lambda (_%datum26549%_ _%max-nodes26550%_ _%max-depth26551%_)
        (let ((_%active26553%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (letrec ((_%activate26555%_
                    (lambda (_%prefix26673%_
                             _%depth26674%_
                             _%count26675%_
                             _%remaining26676%_
                             _%frames26677%_
                             _%step26678%_
                             _%stride26679%_)
                      (if (zero? _%count26675%_)
                          (_%visit26558%_
                           _%prefix26673%_
                           _%depth26674%_
                           _%remaining26676%_
                           _%frames26677%_)
                          (if (let ()
                                (declare (not safe))
                                (__hash-get _%active26553%_ _%prefix26673%_))
                              '#f
                              (let ()
                                (let ()
                                  (declare (not safe))
                                  (__hash-put!
                                   _%active26553%_
                                   _%prefix26673%_
                                   '#t))
                                (_%activate26555%_
                                 (_%step26678%_ _%prefix26673%_)
                                 (+ _%depth26674%_ _%stride26679%_)
                                 (- _%count26675%_ '1)
                                 _%remaining26676%_
                                 (cons (let ()
                                         (declare (not safe))
                                         (##structure
                                          gerbil-ascent/candidate/datum#datum-frame::t
                                          _%prefix26673%_
                                          _%depth26674%_
                                          '#t))
                                       _%frames26677%_)
                                 _%step26678%_
                                 _%stride26679%_))))))
                   (_%scan-spine26556%_
                    (lambda (_%start26636%_
                             _%depth26637%_
                             _%remaining26638%_
                             _%frames26639%_)
                      (let _%scan26641%_ ((_%cursor26643%_ _%start26636%_)
                                          (_%fast26644%_ _%start26636%_)
                                          (_%left26645%_ _%remaining26638%_)
                                          (_%count26646%_ '0))
                        (if (<= _%left26645%_ '0)
                            '#f
                            (if (pair? _%cursor26643%_)
                                (let ((_%head26650%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%cursor26643%_))))
                                  (if (pair? _%head26650%_)
                                      (_%activate26555%_
                                       _%start26636%_
                                       _%depth26637%_
                                       _%count26646%_
                                       _%left26645%_
                                       _%frames26639%_
                                       cdr
                                       '0)
                                      (if (or (<= _%left26645%_ '1)
                                              (not (or (null? _%head26650%_)
                                                       (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                                        _%head26650%_))))
                                          '#f
                                          (let* ((_%next26661%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (##cdr _%cursor26643%_)))
                                                 (_%next-fast26665%_
                                                  (if (pair? _%fast26644%_)
                                                      (let ((_%tail26663%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%fast26644%_))))
                (if (pair? _%tail26663%_)
                    (let () (declare (not safe)) (##cdr _%tail26663%_))
                    '#f))
              '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (and (pair? _%next26661%_)
                                                     (eq? _%next26661%_
                                                          _%next-fast26665%_))
                                                '#f
                                                (_%scan26641%_
                                                 _%next26661%_
                                                 _%next-fast26665%_
                                                 (- _%left26645%_ '2)
                                                 (+ _%count26646%_ '1)))))))
                                (if (or (null? _%cursor26643%_)
                                        (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                         _%cursor26643%_))
                                    (_%resume26559%_
                                     (- _%left26645%_ '1)
                                     _%frames26639%_)
                                    '#f))))))
                   (_%scan-nest26557%_
                    (lambda (_%start26605%_
                             _%depth26606%_
                             _%remaining26607%_
                             _%frames26608%_)
                      (let _%scan26610%_ ((_%cursor26612%_ _%start26605%_)
                                          (_%fast26613%_ _%start26605%_)
                                          (_%level26614%_ _%depth26606%_)
                                          (_%left26615%_ _%remaining26607%_)
                                          (_%count26616%_ '0))
                        (if (<= _%left26615%_ '0)
                            '#f
                            (if (pair? _%cursor26612%_)
                                (if (> _%level26614%_ _%max-depth26551%_)
                                    '#f
                                    (if (null? (let ()
                                                 (declare (not safe))
                                                 (##cdr _%cursor26612%_)))
                                        (if (<= _%left26615%_ '1)
                                            '#f
                                            (let* ((_%next26624%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%cursor26612%_)))
                                                   (_%next-fast26628%_
                                                    (if (pair? _%fast26613%_)
                                                        (let ((_%head26626%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (##car _%fast26613%_))))
                  (if (pair? _%head26626%_)
                      (let () (declare (not safe)) (##car _%head26626%_))
                      '#f))
                '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (if (and (pair? _%next26624%_)
                                                       (eq? _%next26624%_
                                                            _%next-fast26628%_))
                                                  '#f
                                                  (_%scan26610%_
                                                   _%next26624%_
                                                   _%next-fast26628%_
                                                   (+ _%level26614%_ '1)
                                                   (- _%left26615%_ '2)
                                                   (+ _%count26616%_ '1)))))
                                        (_%activate26555%_
                                         _%start26605%_
                                         _%depth26606%_
                                         _%count26616%_
                                         _%left26615%_
                                         _%frames26608%_
                                         car
                                         '1)))
                                (if (or (null? _%cursor26612%_)
                                        (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                         _%cursor26612%_))
                                    (_%resume26559%_
                                     (- _%left26615%_ '1)
                                     _%frames26608%_)
                                    '#f))))))
                   (_%visit26558%_
                    (lambda (_%value26588%_
                             _%depth26589%_
                             _%remaining26590%_
                             _%frames26591%_)
                      (if (<= _%remaining26590%_ '0)
                          '#f
                          (if (pair? _%value26588%_)
                              (if (or (> _%depth26589%_ _%max-depth26551%_)
                                      (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%active26553%_
                                         _%value26588%_)))
                                  '#f
                                  (let ((_%head26598%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%value26588%_))))
                                    (if (pair? _%head26598%_)
                                        (if (null? (let ()
                                                     (declare (not safe))
                                                     (##cdr _%value26588%_)))
                                            (_%scan-nest26557%_
                                             _%value26588%_
                                             _%depth26589%_
                                             _%remaining26590%_
                                             _%frames26591%_)
                                            (begin
                                              (let ()
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%active26553%_
                                                 _%value26588%_
                                                 '#t))
                                              (_%visit26558%_
                                               _%head26598%_
                                               (+ _%depth26589%_ '1)
                                               (- _%remaining26590%_ '1)
                                               (cons (let ()
                                                       (declare (not safe))
                                                       (##structure
                                                        gerbil-ascent/candidate/datum#datum-frame::t
                                                        _%value26588%_
                                                        _%depth26589%_
                                                        '#f))
                                                     _%frames26591%_))))
                                        (_%scan-spine26556%_
                                         _%value26588%_
                                         _%depth26589%_
                                         _%remaining26590%_
                                         _%frames26591%_))))
                              (if (or (null? _%value26588%_)
                                      (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                       _%value26588%_))
                                  (_%resume26559%_
                                   (- _%remaining26590%_ '1)
                                   _%frames26591%_)
                                  '#f)))))
                   (_%resume26559%_
                    (lambda (_%remaining26561%_ _%frames26562%_)
                      (if (null? _%frames26562%_)
                          '#t
                          (let* ((_%frame26564%_ (car _%frames26562%_))
                                 (_%frame26566%_ _%frame26564%_)
                                 (_%pair26577%_
                                  (let ()
                                    (declare (not safe))
                                    (##unchecked-structure-ref
                                     _%frame26566%_
                                     '1
                                     '#f
                                     '#f))))
                            (if (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%frame26566%_
                                   '3
                                   '#f
                                   '#f))
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%active26553%_
                                     _%pair26577%_
                                     '#f))
                                  (_%resume26559%_
                                   _%remaining26561%_
                                   (cdr _%frames26562%_)))
                                (let ((_%tail26579%_ (cdr _%pair26577%_)))
                                  (if (<= _%remaining26561%_ '0)
                                      '#f
                                      (if (pair? _%tail26579%_)
                                          (let ()
                                            (let ()
                                              (declare (not safe))
                                              (##unchecked-structure-set!
                                               _%frame26566%_
                                               '#t
                                               '3
                                               '#f
                                               '#f))
                                            (_%visit26558%_
                                             _%tail26579%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%frame26566%_
                                                '2
                                                '#f
                                                '#f))
                                             _%remaining26561%_
                                             _%frames26562%_))
                                          (if (or (null? _%tail26579%_)
                                                  (gerbil-ascent/candidate/datum#candidate-datum-scalar?
                                                   _%tail26579%_))
                                              (let ()
                                                (let ()
                                                  (declare (not safe))
                                                  (__hash-put!
                                                   _%active26553%_
                                                   _%pair26577%_
                                                   '#f))
                                                (_%resume26559%_
                                                 (- _%remaining26561%_ '1)
                                                 (cdr _%frames26562%_)))
                                              '#f))))))))))
            (_%visit26558%_ _%datum26549%_ '0 _%max-nodes26550%_ '())))))
    (define gerbil-ascent/candidate/datum#candidate-copy-pairs
      (lambda (_%datum26514%_)
        (let* ((_%$%datum2651526523%_ _%datum26514%_)
               (_%$%else2651726531%_ (lambda () _%datum26514%_))
               (_%$%K2651926537%_
                (lambda (_%tail26534%_ _%head26535%_)
                  (cons (gerbil-ascent/candidate/datum#candidate-copy-pairs
                         _%head26535%_)
                        (gerbil-ascent/candidate/datum#candidate-copy-pairs
                         _%tail26534%_)))))
          (if (pair? _%$%datum2651526523%_)
              (let ((_%$%hd2652026540%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%datum2651526523%_)))
                    (_%$%tl2652126542%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%datum2651526523%_))))
                (let* ((_%head26545%_ _%$%hd2652026540%_)
                       (_%tail26547%_ _%$%tl2652126542%_))
                  (_%$%K2651926537%_ _%tail26547%_ _%head26545%_)))
              (_%$%else2651726531%_)))))))
