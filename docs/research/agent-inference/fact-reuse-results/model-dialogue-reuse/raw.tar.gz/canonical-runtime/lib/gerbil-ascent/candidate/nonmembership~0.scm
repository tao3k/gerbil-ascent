(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/nonmembership::timestamp 1791693098)
  (begin
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
      (let ((__tmp34162 (list)) (__tmp34161 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'positive-nonmembership
         __tmp34162
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         __tmp34161
         '#f)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t)))
    (define gerbil-ascent/candidate/nonmembership#make-positive-nonmembership
      (lambda _%$args30019%_
        (apply make-instance
               gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
               _%$args30019%_)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#certificate-size-valid?
      (lambda (_%closure30003%_)
        (let ((_%relation-count30005%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                  _%closure30003%_
                  gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)))
              (_%rows30006%_ '0)
              (_%cells30007%_ '0))
          (if _%relation-count30005%_
              (let ((__tmp34163
                     (lambda (_%entry30009%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry30009%_
                                      '3))
                                   '3)
                           (let* ((_%row-list30011%_ (caddr _%entry30009%_))
                                  (_%count30013%_
                                   (let ((__tmp34164
                                          (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                             _%rows30006%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%row-list30011%_
                                      __tmp34164))))
                             (if _%count30013%_
                                 (if (begin
                                       (set! _%rows30006%_
                                             (+ _%rows30006%_ _%count30013%_))
                                       '#t)
                                     (let ((__tmp34165
                                            (lambda (_%row30015%_)
                                              (let ((_%width30017%_
                                                     (let ((__tmp34166
                                                            (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                            _%cells30007%_))))
               (declare (not safe))
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row30015%_
                __tmp34166))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%width30017%_
                                                    (begin
                                                      (set! _%cells30007%_
                                                            (+ _%cells30007%_
                                                               _%width30017%_))
                                                      '#t)
                                                    '#f)))))
                                       (declare (not safe))
                                       (andmap__0
                                        __tmp34165
                                        _%row-list30011%_))
                                     '#f)
                                 '#f))
                           '#f))))
                (declare (not safe))
                (andmap__0 __tmp34163 _%closure30003%_))
              '#f))))
    (define gerbil-ascent/candidate/nonmembership#ground-query?
      (lambda (_%query29999%_)
        (if (list? _%query29999%_)
            (if (pair? _%query29999%_)
                (let ((__tmp34168
                       (lambda (_%term30001%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term30001%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term30001%_))
                                 '#f
                                 (not (eq? _%term30001%_ '?_)))
                             '#f)))
                      (__tmp34167
                       (let () (declare (not safe)) (##cdr _%query29999%_))))
                  (declare (not safe))
                  (andmap__0 __tmp34168 __tmp34167))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/nonmembership#certificate-schema-of
      (lambda (_%snapshot29994%_ _%spec29995%_)
        (let ((__tmp34170
               (lambda (_%entry29997%_)
                 (list (car _%entry29997%_) (cdr _%entry29997%_))))
              (__tmp34169
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/funs#candidate-schema-of
                  _%snapshot29994%_
                  _%spec29995%_))))
          (declare (not safe))
          (##map __tmp34170 __tmp34169))))
    (define gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
      (lambda (_%snapshot29944%_
               _%spec29945%_
               _%candidate-digest29946%_
               _%native-status29947%_
               _%native-rows29948%_
               _%max-steps29949%_)
        (if (and (exact-integer? _%max-steps29949%_) (> _%max-steps29949%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership work budget" _%max-steps29949%_)))
        (let ((_%query29951%_
               (vector-ref
                (##structure-ref
                 _%spec29945%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29953%_
                    (lambda (_%status29991%_ _%closure29992%_)
                      (let ((__tmp34175
                             (##structure-ref
                              _%snapshot29944%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34174
                             (##structure-ref
                              _%snapshot29944%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34173
                             (##structure-ref
                              _%snapshot29944%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34172
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                                _%spec29945%_)))
                            (__tmp34171
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29951%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
                         _%status29991%_
                         __tmp34175
                         __tmp34174
                         __tmp34173
                         _%candidate-digest29946%_
                         __tmp34172
                         __tmp34171
                         _%max-steps29949%_
                         _%closure29992%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29944%_)))
                    (not (eq? _%native-status29947%_ 'complete))
                    (pair? _%native-rows29948%_)
                    (not (gerbil-ascent/candidate/nonmembership#ground-query?
                          _%query29951%_))
                    (not (let ((__tmp34176
                                (##structure-ref
                                 _%spec29945%_
                                 '3
                                 gerbil-ascent/candidate/types#reasoning-candidate::t
                                 '#f)))
                           (declare (not safe))
                           (andmap__0
                            gerbil-ascent/candidate/provenance#positive-rule-body?
                            __tmp34176))))
                (_%result29953%_ 'unsupported '())
                (if (> (let ((__tmp34177
                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                               _%snapshot29944%_
                               _%spec29945%_)))
                         (declare (not safe))
                         (##length __tmp34177))
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                    (_%result29953%_ 'bounded '())
                    (let* ((_%witness29967%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
                               _%snapshot29944%_
                               _%spec29945%_
                               _%candidate-digest29946%_
                               _%native-status29947%_
                               _%native-rows29948%_
                               _%max-steps29949%_)))
                           (_%status29969%_
                            (##structure-ref
                             _%witness29967%_
                             '1
                             gerbil-ascent/candidate/provenance#positive-proof::t
                             '#f))
                           (_%$e29972%_ _%status29969%_))
                      (if (eq? 'bounded _%$e29972%_)
                          (_%result29953%_ 'bounded '())
                          (if (eq? 'closed-absent _%$e29972%_)
                              (let ((_%grouped29975%_
                                     (let ()
                                       (declare (not safe))
                                       (make-hash-table-eq))))
                                (for-each
                                 (lambda (_%node29977%_)
                                   (let* ((_%name29979%_
                                           (##structure-ref
                                            _%node29977%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f))
                                          (__tmp34178
                                           (cons (##structure-ref
                                                  _%node29977%_
                                                  '4
                                                  gerbil-ascent/candidate/provenance#proof-node::t
                                                  '#f)
                                                 (let ((_%$e29981%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-get
                                                           _%grouped29975%_
                                                           _%name29979%_))))
                                                   (if _%$e29981%_
                                                       _%$e29981%_
                                                       '())))))
                                     (declare (not safe))
                                     (__hash-put!
                                      _%grouped29975%_
                                      _%name29979%_
                                      __tmp34178)))
                                 (##structure-ref
                                  _%witness29967%_
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))
                                (let ((_%closure29989%_
                                       (let ((__tmp34180
                                              (lambda (_%declaration29984%_)
                                                (list (car _%declaration29984%_)
                                                      (cadr _%declaration29984%_)
                                                      (let ((__tmp34181
                                                             (reverse (let ((_%$e29986%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     (let ((__tmp34182
                                            (car _%declaration29984%_)))
                                       (declare (not safe))
                                       (__hash-get
                                        _%grouped29975%_
                                        __tmp34182))))
                                (if _%$e29986%_ _%$e29986%_ '())))))
                (declare (not safe))
                (##map gerbil-ascent/candidate/datum#candidate-copy-pairs
                       __tmp34181)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (__tmp34179
                                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                                               _%snapshot29944%_
                                               _%spec29945%_)))
                                         (declare (not safe))
                                         (##map __tmp34180 __tmp34179))))
                                  (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                                       _%closure29989%_)
                                      (_%result29953%_
                                       'complete
                                       _%closure29989%_)
                                      (_%result29953%_ 'bounded '()))))
                              (_%result29953%_ 'unsupported '()))))))))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__%
      (lambda (_%terms29926%_ _%wildcards?29927%_)
        (map (lambda (_%term29929%_)
               (cons (if (and _%wildcards?29927%_ (eq? _%term29929%_ '?_))
                         'wildcard
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-variable?
                                _%term29929%_))
                             'variable
                             'literal))
                     _%term29929%_))
             _%terms29926%_)))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__0
      (lambda (_%terms29937%_)
        (let ((_%wildcards?29939%_ '#t))
          (gerbil-ascent/candidate/nonmembership#binding-patterns__%
           _%terms29937%_
           _%wildcards?29939%_))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns
      (lambda _g34183_
        (let ((_g34184_ (let () (declare (not safe)) (##length _g34183_))))
          (cond ((let () (declare (not safe)) (##fx= _g34184_ 1))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__0
                        _g34183_))
                ((let () (declare (not safe)) (##fx= _g34184_ 2))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__%
                        _g34183_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/nonmembership#binding-patterns
                  _g34183_))))))
    (define gerbil-ascent/candidate/nonmembership#head-row
      (lambda (_%head29920%_ _%bindings29921%_)
        (map (lambda (_%term29923%_)
               (if (eq? (car _%term29923%_) 'variable)
                   (cdr (assq (cdr _%term29923%_) _%bindings29921%_))
                   (cdr _%term29923%_)))
             _%head29920%_)))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
      (lambda (_%snapshot29745%_
               _%spec29746%_
               _%candidate-digest29747%_
               _%native-status29748%_
               _%native-rows29749%_
               _%certificate29750%_
               _%max-checks29751%_)
        (if (and (exact-integer? _%max-checks29751%_)
                 (> _%max-checks29751%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership verification budget"
                     _%max-checks29751%_)))
        (let* ((_%query29753%_
                (vector-ref
                 (##structure-ref
                  _%spec29746%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%schema29755%_
                (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                 _%snapshot29745%_
                 _%spec29746%_))
               (_%closure29757%_
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%certificate29750%_
                       'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%certificate29750%_
                       '9
                       '#f
                       '#f))
                    '#f))
               (_%preflight29765%_
                (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                     _%closure29757%_)
                    (if (= (length _%closure29757%_)
                           (let ()
                             (declare (not safe))
                             (##length _%schema29755%_)))
                        (if (let ((__tmp34185
                                   (lambda (_%entry29759%_)
                                     (and (list? _%entry29759%_)
                                          (= (let ()
                                               (declare (not safe))
                                               (##length _%entry29759%_))
                                             '3)
                                          (list? (caddr _%entry29759%_))))))
                              (declare (not safe))
                              (andmap__0 __tmp34185 _%closure29757%_))
                            (+ '1
                               (let ((__tmp34186
                                      (map (lambda (_%entry29761%_)
                                             (length (caddr _%entry29761%_)))
                                           _%closure29757%_)))
                                 (declare (not safe))
                                 (##apply + __tmp34186))
                               (let ((__tmp34187
                                      (map (lambda (_%entry29763%_)
                                             (length (caddr _%entry29763%_)))
                                           (##structure-ref
                                            _%snapshot29745%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f))))
                                 (declare (not safe))
                                 (##apply + __tmp34187))
                               (length (##structure-ref
                                        _%spec29746%_
                                        '2
                                        gerbil-ascent/candidate/types#reasoning-candidate::t
                                        '#f)))
                            '#f)
                        '#f)
                    '#f)))
          (if (and (let ()
                     (declare (not safe))
                     (##structure-instance-of?
                      _%certificate29750%_
                      'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                      _%snapshot29745%_))
                   (eq? (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%certificate29750%_
                           '1
                           '#f
                           '#f))
                        'complete)
                   (eq? _%native-status29748%_ 'complete)
                   (null? _%native-rows29749%_)
                   (gerbil-ascent/candidate/nonmembership#ground-query?
                    _%query29753%_)
                   (let ((__tmp34188
                          (##structure-ref
                           _%spec29746%_
                           '3
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)))
                     (declare (not safe))
                     (andmap__0
                      gerbil-ascent/candidate/provenance#positive-rule-body?
                      __tmp34188))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '2
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29745%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '3
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29745%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '4
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29745%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '5
                              '#f
                              '#f))
                           _%candidate-digest29747%_)
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '6
                              '#f
                              '#f))
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                              _%spec29746%_)))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29750%_
                              '7
                              '#f
                              '#f))
                           _%query29753%_)
                   _%preflight29765%_
                   (equal? (map (lambda (_%entry29768%_)
                                  (list (car _%entry29768%_)
                                        (cadr _%entry29768%_)))
                                _%closure29757%_)
                           _%schema29755%_))
              (if (> _%preflight29765%_ _%max-checks29751%_)
                  'bounded
                  (if (let ((__tmp34189
                             (lambda (_%entry29772%_)
                               (and (let ((__tmp34190 (caddr _%entry29772%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                       __tmp34190))
                                    (let ((__tmp34192
                                           (lambda (_%row29774%_)
                                             (and (list? _%row29774%_)
                                                  (= (let ()
                                                       (declare (not safe))
                                                       (##length _%row29774%_))
                                                     (cadr _%entry29772%_))
                                                  (let ()
                                                    (declare (not safe))
                                                    (andmap__0
                                                     gerbil-ascent/candidate/program#scalar?
                                                     _%row29774%_)))))
                                          (__tmp34191 (caddr _%entry29772%_)))
                                      (declare (not safe))
                                      (andmap__0 __tmp34192 __tmp34191))))))
                        (declare (not safe))
                        (andmap__0 __tmp34189 _%closure29757%_))
                      (let* ((_%steps29778%_ _%preflight29765%_)
                             (_%bounded?29780%_ '#f)
                             (_%invalid?29782%_ '#f)
                             (_%direct?29839%_
                              (let* ((_%$%closure2978329799%_ _%closure29757%_)
                                     (_%$%else2978729807%_ (lambda () '#f)))
                                (let ((_%$%K2979729836%_ (lambda () '#t))
                                      (_%$%K2979429826%_ (lambda () '#t))
                                      (_%$%K2978929812%_ (lambda () '#t)))
                                  (let ((_%$%try-match2978529832%_
                                         (lambda ()
                                           (if (pair? _%$%closure2978329799%_)
                                               (let ((_%$%tl2979629829%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%closure2978329799%_))))
                                                 (if (null? _%$%tl2979629829%_)
                                                     (_%$%K2979429826%_)
                                                     (if (pair? _%$%tl2979629829%_)
                                                         (let ((_%$%tl2979329818%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##cdr _%$%tl2979629829%_))))
                   (if (null? _%$%tl2979329818%_)
                       (_%$%K2978929812%_)
                       (_%$%else2978729807%_)))
                 (_%$%else2978729807%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%$%else2978729807%_)))))
                                    (if (null? _%$%closure2978329799%_)
                                        (_%$%K2979729836%_)
                                        (_%$%try-match2978529832%_))))))
                             (_%index29841%_
                              (if _%direct?29839%_
                                  '()
                                  (let ((__tmp34193 (length _%closure29757%_)))
                                    (declare (not safe))
                                    (make-hash-table-eq 'size: __tmp34193)))))
                        (letrec* ((_%relation-entry29844%_
                                   (lambda (_%name29916%_)
                                     (if _%direct?29839%_
                                         (let ((_%entry29918%_
                                                (assq _%name29916%_
                                                      _%index29841%_)))
                                           (if _%entry29918%_
                                               (cdr _%entry29918%_)
                                               '#f))
                                         (let ()
                                           (declare (not safe))
                                           (hash-get
                                            _%index29841%_
                                            _%name29916%_)))))
                                  (_g34194_
                                   (let ((_g34195_
                                          (for-each
                                           (lambda (_%entry29846%_)
                                             (let ((_%present29848%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (make-hash-table__%
                                                       '#f
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value))))
                                               (for-each
                                                (lambda (_%row29850%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%present29848%_
                                                     _%row29850%_
                                                     '#t)))
                                                (caddr _%entry29846%_))
                                               (if (_%relation-entry29844%_
                                                    (car _%entry29846%_))
                                                   '#!void
                                                   (let ((_%value29852%_
                                                          (cons (caddr _%entry29846%_)
                                                                _%present29848%_)))
                                                     (if _%direct?29839%_
                                                         (set! _%index29841%_
                                                               (cons (cons (car _%entry29846%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                   _%value29852%_)
                             _%index29841%_))
                 (let ((__tmp34197 (car _%entry29846%_)))
                   (declare (not safe))
                   (hash-put! _%index29841%_ __tmp34197 _%value29852%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           _%closure29757%_)))
                                     #!void
                                     _g34195_))
                                  (_%rows29853%_
                                   (lambda (_%name29912%_)
                                     (let ((_%entry29914%_
                                            (_%relation-entry29844%_
                                             _%name29912%_)))
                                       (if _%entry29914%_
                                           (car _%entry29914%_)
                                           '()))))
                                  (_%contains?29854%_
                                   (lambda (_%name29907%_ _%row29908%_)
                                     (let ((_%entry29910%_
                                            (_%relation-entry29844%_
                                             _%name29907%_)))
                                       (if _%entry29910%_
                                           (let ((__tmp34198
                                                  (cdr _%entry29910%_)))
                                             (declare (not safe))
                                             (hash-get
                                              __tmp34198
                                              _%row29908%_))
                                           '#f)))))
                          (begin
                            (if _%bounded?29780%_
                                '#!void
                                (for-each
                                 (lambda (_%entry29856%_)
                                   (for-each
                                    (lambda (_%row29858%_)
                                      (if (_%contains?29854%_
                                           (car _%entry29856%_)
                                           _%row29858%_)
                                          '#!void
                                          (set! _%invalid?29782%_ '#t)))
                                    (caddr _%entry29856%_)))
                                 (##structure-ref
                                  _%snapshot29745%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f)))
                            (if _%bounded?29780%_
                                '#!void
                                (for-each
                                 (lambda (_%fact29860%_)
                                   (if (_%contains?29854%_
                                        (vector-ref _%fact29860%_ '0)
                                        (vector-ref _%fact29860%_ '1))
                                       '#!void
                                       (set! _%invalid?29782%_ '#t)))
                                 (##structure-ref
                                  _%spec29746%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if (if _%bounded?29780%_
                                    '#f
                                    (_%contains?29854%_
                                     (car _%query29753%_)
                                     (cdr _%query29753%_)))
                                (set! _%invalid?29782%_ '#t)
                                '#!void)
                            (if (or _%bounded?29780%_ _%invalid?29782%_)
                                '#!void
                                (for-each
                                 (lambda (_%rule29865%_)
                                   (let* ((_%head29867%_
                                           (vector-ref _%rule29865%_ '0))
                                          (_%covered-head?29871%_
                                           (if (memq '?_ (cdr _%head29867%_))
                                               '#f
                                               (let ((__tmp34200
                                                      (lambda (_%clause29869%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                               _%clause29869%_))
                                                            '#f
                                                            (equal? _%head29867%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%clause29869%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp34199
                                                      (vector-ref
                                                       _%rule29865%_
                                                       '1)))
                                                 (declare (not safe))
                                                 (ormap__0
                                                  __tmp34200
                                                  __tmp34199))))
                                          (_%head-patterns29873%_
                                           (if _%covered-head?29871%_
                                               '()
                                               (gerbil-ascent/candidate/nonmembership#binding-patterns__%
                                                (cdr _%head29867%_)
                                                '#f)))
                                          (_%head-entry29875%_
                                           (if _%covered-head?29871%_
                                               '#f
                                               (_%relation-entry29844%_
                                                (car _%head29867%_))))
                                          (_%body29879%_
                                           (map (lambda (_%clause29877%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                         _%clause29877%_))
                                                      (vector '#t
                                                              _%clause29877%_
                                                              '())
                                                      (vector '#f
                                                              (gerbil-ascent/candidate/nonmembership#binding-patterns__0
                                                               (cdr _%clause29877%_))
                                                              (_%rows29853%_
                                                               (car _%clause29877%_)))))
                                                (vector-ref
                                                 _%rule29865%_
                                                 '1))))
                                     (letrec ((_%walk29882%_
                                               (lambda (_%remaining29884%_
                                                        _%bindings29885%_)
                                                 (if (or _%bounded?29780%_
                                                         _%invalid?29782%_)
                                                     '#!void
                                                     (if (null? _%remaining29884%_)
                                                         (if (or _%covered-head?29871%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (and _%head-entry29875%_
                              (let ((__tmp34202 (cdr _%head-entry29875%_))
                                    (__tmp34201
                                     (gerbil-ascent/candidate/nonmembership#head-row
                                      _%head-patterns29873%_
                                      _%bindings29885%_)))
                                (declare (not safe))
                                (hash-get __tmp34202 __tmp34201))))
                     '#!void
                     (set! _%invalid?29782%_ '#t))
                 (let ((_%clause29893%_ (car _%remaining29884%_)))
                   (if (vector-ref _%clause29893%_ '0)
                       (begin
                         (set! _%steps29778%_ (+ _%steps29778%_ '1))
                         (if (> _%steps29778%_ _%max-checks29751%_)
                             (set! _%bounded?29780%_ '#t)
                             (let ((_%next29895%_
                                    (let ((__tmp34203
                                           (vector-ref _%clause29893%_ '1)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                       __tmp34203
                                       _%bindings29885%_))))
                               (if _%next29895%_
                                   (_%walk29882%_
                                    (cdr _%remaining29884%_)
                                    _%next29895%_)
                                   '#!void))))
                       (for-each
                        (lambda (_%row29897%_)
                          (if (or _%bounded?29780%_ _%invalid?29782%_)
                              '#!void
                              (begin
                                (set! _%steps29778%_ (+ _%steps29778%_ '1))
                                (if (> _%steps29778%_ _%max-checks29751%_)
                                    (set! _%bounded?29780%_ '#t)
                                    (let ((_%next29902%_
                                           (let ((__tmp34204
                                                  (vector-ref
                                                   _%clause29893%_
                                                   '1)))
                                             (declare (not safe))
                                             (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                              __tmp34204
                                              _%row29897%_
                                              _%bindings29885%_))))
                                      (if _%next29902%_
                                          (_%walk29882%_
                                           (cdr _%remaining29884%_)
                                           _%next29902%_)
                                          '#!void))))))
                        (vector-ref _%clause29893%_ '2)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29882%_ _%body29879%_ '()))))
                                 (##structure-ref
                                  _%spec29746%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if _%invalid?29782%_
                                'invalid
                                (if _%bounded?29780%_ 'bounded 'valid)))))
                      'invalid))
              'invalid))))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership
      (lambda (_%snapshot29737%_
               _%spec29738%_
               _%candidate-digest29739%_
               _%native-status29740%_
               _%native-rows29741%_
               _%certificate29742%_
               _%max-checks29743%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29737%_))
            (gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
             _%snapshot29737%_
             _%spec29738%_
             _%candidate-digest29739%_
             _%native-status29740%_
             _%native-rows29741%_
             _%certificate29742%_
             _%max-checks29743%_)
            'invalid)))))
