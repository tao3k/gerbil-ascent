(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/expression-plan::timestamp 1791687872)
  (begin
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-call
      (lambda (_%procedure8203%_ _%slots8204%_)
        (let* ((_%$%slots82058239%_ _%slots8204%_)
               (_%$%else82118251%_
                (lambda ()
                  (lambda (_%frame8247%_)
                    (apply _%procedure8203%_
                           (map (lambda (_%slot8249%_)
                                  (vector-ref _%frame8247%_ _%slot8249%_))
                                _%slots8204%_))))))
          (let ((_%$%K82378441%_
                 (lambda () (lambda (_%frame8439%_) (_%procedure8203%_))))
                (_%$%K82348425%_
                 (lambda (_%one8415%_)
                   (lambda (_%frame8417%_)
                     (let* ((_%slot8419%_ _%one8415%_)
                            (_%next8421%_
                             (vector-ref _%frame8417%_ _%slot8419%_)))
                       (_%procedure8203%_ _%next8421%_)))))
                (_%$%K82298394%_
                 (lambda (_%two8377%_ _%one8378%_)
                   (lambda (_%frame8380%_)
                     (let* ((_%slot8382%_ _%one8378%_)
                            (_%next8384%_
                             (vector-ref _%frame8380%_ _%slot8382%_))
                            (_%slot8388%_ _%two8377%_)
                            (_%next8390%_
                             (vector-ref _%frame8380%_ _%slot8388%_)))
                       (_%procedure8203%_ _%next8384%_ _%next8390%_)))))
                (_%$%K82228349%_
                 (lambda (_%three8325%_ _%two8326%_ _%one8327%_)
                   (lambda (_%frame8329%_)
                     (let* ((_%slot8331%_ _%one8327%_)
                            (_%next8333%_
                             (vector-ref _%frame8329%_ _%slot8331%_))
                            (_%slot8337%_ _%two8326%_)
                            (_%next8339%_
                             (vector-ref _%frame8329%_ _%slot8337%_))
                            (_%slot8343%_ _%three8325%_)
                            (_%next8345%_
                             (vector-ref _%frame8329%_ _%slot8343%_)))
                       (_%procedure8203%_
                        _%next8333%_
                        _%next8339%_
                        _%next8345%_)))))
                (_%$%K82138290%_
                 (lambda (_%four8255%_ _%three8257%_ _%two8259%_ _%one8261%_)
                   (lambda (_%frame8264%_)
                     (let* ((_%slot8266%_ _%one8261%_)
                            (_%next8268%_
                             (vector-ref _%frame8264%_ _%slot8266%_))
                            (_%slot8272%_ _%two8259%_)
                            (_%next8274%_
                             (vector-ref _%frame8264%_ _%slot8272%_))
                            (_%slot8278%_ _%three8257%_)
                            (_%next8280%_
                             (vector-ref _%frame8264%_ _%slot8278%_))
                            (_%slot8284%_ _%four8255%_)
                            (_%next8286%_
                             (vector-ref _%frame8264%_ _%slot8284%_)))
                       (_%procedure8203%_
                        _%next8268%_
                        _%next8274%_
                        _%next8280%_
                        _%next8286%_))))))
            (let ((_%$%try-match82078435%_
                   (lambda ()
                     (if (pair? _%$%slots82058239%_)
                         (let ((_%$%tl82368430%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%slots82058239%_)))
                               (_%$%hd82358428%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%slots82058239%_))))
                           (if (null? _%$%tl82368430%_)
                               (let ((_%one8433%_ _%$%hd82358428%_))
                                 (_%$%K82348425%_ _%one8433%_))
                               (if (pair? _%$%tl82368430%_)
                                   (let ((_%$%tl82338406%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl82368430%_)))
                                         (_%$%hd82328404%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl82368430%_))))
                                     (if (null? _%$%tl82338406%_)
                                         (let ((_%one8402%_ _%$%hd82358428%_)
                                               (_%two8409%_ _%$%hd82328404%_))
                                           (_%$%K82298394%_
                                            _%two8409%_
                                            _%one8402%_))
                                         (if (pair? _%$%tl82338406%_)
                                             (let ((_%$%tl82288368%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl82338406%_)))
                                                   (_%$%hd82278366%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl82338406%_))))
                                               (if (null? _%$%tl82288368%_)
                                                   (let ((_%one8357%_
                                                          _%$%hd82358428%_)
                                                         (_%two8364%_
                                                          _%$%hd82328404%_)
                                                         (_%three8371%_
                                                          _%$%hd82278366%_))
                                                     (_%$%K82228349%_
                                                      _%three8371%_
                                                      _%two8364%_
                                                      _%one8357%_))
                                                   (if (pair? _%$%tl82288368%_)
                                                       (let ((_%$%tl82218316%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%$%tl82288368%_)))
                     (_%$%hd82208314%_
                      (let () (declare (not safe)) (##car _%$%tl82288368%_))))
                 (if (null? _%$%tl82218316%_)
                     (let ((_%one8298%_ _%$%hd82358428%_)
                           (_%two8305%_ _%$%hd82328404%_)
                           (_%three8312%_ _%$%hd82278366%_)
                           (_%four8319%_ _%$%hd82208314%_))
                       (_%$%K82138290%_
                        _%four8319%_
                        _%three8312%_
                        _%two8305%_
                        _%one8298%_))
                     (_%$%else82118251%_)))
               (_%$%else82118251%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%$%else82118251%_))))
                                   (_%$%else82118251%_))))
                         (_%$%else82118251%_)))))
              (if (null? _%$%slots82058239%_)
                  (_%$%K82378441%_)
                  (_%$%try-match82078435%_)))))))
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
      (lambda (_%actions8180%_)
        (if (null? _%actions8180%_)
            (lambda (_%_8182%_) '#t)
            (let* ((_%action8184%_ (car _%actions8180%_))
                   (_%next8186%_
                    (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
                     (cdr _%actions8180%_)))
                   (_%$e8189%_ (vector-ref _%action8184%_ '0)))
              (if (eq? 'guard _%$e8189%_)
                  (let ((_%call8192%_ (vector-ref _%action8184%_ '1)))
                    (lambda (_%frame8194%_)
                      (let ((_%pass?8196%_ (_%call8192%_ _%frame8194%_)))
                        (if (boolean? _%pass?8196%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT guard must return a boolean"
                                     _%pass?8196%_)))
                        (if _%pass?8196%_ (_%next8186%_ _%frame8194%_) '#f))))
                  (if (eq? 'binding _%$e8189%_)
                      (let ((_%slot8198%_ (vector-ref _%action8184%_ '1))
                            (_%call8199%_ (vector-ref _%action8184%_ '2)))
                        (lambda (_%frame8201%_)
                          (vector-set!
                           _%frame8201%_
                           _%slot8198%_
                           (_%call8199%_ _%frame8201%_))
                          (_%next8186%_ _%frame8201%_)))
                      '#!void))))))
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-input-guard
      (lambda (_%names8095%_)
        (let* ((_%$%names80968112%_ _%names8095%_)
               (_%$%else81008129%_
                (lambda ()
                  (let ((_%expected8120%_ (list->vector _%names8095%_)))
                    (lambda (_%current8122%_)
                      (let _%compare8124%_ ((_%remaining8126%_ _%current8122%_)
                                            (_%slot8127%_ '0))
                        (if (= _%slot8127%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-length _%expected8120%_)))
                            (null? _%remaining8126%_)
                            (if (pair? _%remaining8126%_)
                                (if (equal? (let ()
                                              (declare (not safe))
                                              (##car _%remaining8126%_))
                                            (vector-ref
                                             _%expected8120%_
                                             _%slot8127%_))
                                    (_%compare8124%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%remaining8126%_))
                                     (+ _%slot8127%_ '1))
                                    '#f)
                                '#f))))))))
          (let ((_%$%K81108177%_ (lambda () null?))
                (_%$%K81078163%_
                 (lambda (_%one8159%_)
                   (lambda (_%current8161%_)
                     (if (pair? _%current8161%_)
                         (if (eq? (let ()
                                    (declare (not safe))
                                    (##car _%current8161%_))
                                  _%one8159%_)
                             (null? (let ()
                                      (declare (not safe))
                                      (##cdr _%current8161%_)))
                             '#f)
                         '#f))))
                (_%$%K81028138%_
                 (lambda (_%two8133%_ _%one8134%_)
                   (lambda (_%current8136%_)
                     (if (pair? _%current8136%_)
                         (if (eq? (let ()
                                    (declare (not safe))
                                    (##car _%current8136%_))
                                  _%one8134%_)
                             (if (pair? (let ()
                                          (declare (not safe))
                                          (##cdr _%current8136%_)))
                                 (if (eq? (cadr _%current8136%_) _%two8133%_)
                                     (null? (cddr _%current8136%_))
                                     '#f)
                                 '#f)
                             '#f)
                         '#f)))))
            (let ((_%$%try-match80988173%_
                   (lambda ()
                     (if (pair? _%$%names80968112%_)
                         (let ((_%$%tl81098168%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%names80968112%_)))
                               (_%$%hd81088166%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%names80968112%_))))
                           (if (null? _%$%tl81098168%_)
                               (let ((_%one8171%_ _%$%hd81088166%_))
                                 (_%$%K81078163%_ _%one8171%_))
                               (if (pair? _%$%tl81098168%_)
                                   (let ((_%$%tl81068150%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl81098168%_)))
                                         (_%$%hd81058148%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl81098168%_))))
                                     (if (null? _%$%tl81068150%_)
                                         (let ((_%one8146%_ _%$%hd81088166%_)
                                               (_%two8153%_ _%$%hd81058148%_))
                                           (_%$%K81028138%_
                                            _%two8153%_
                                            _%one8146%_))
                                         (_%$%else81008129%_)))
                                   (_%$%else81008129%_))))
                         (_%$%else81008129%_)))))
              (if (null? _%$%names80968112%_)
                  (_%$%K81108177%_)
                  (_%$%try-match80988173%_)))))))))
