(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-query::timestamp 1791687882)
  (begin
    (define gerbil-ascent/program/scheme-query#relational-solution::t
      (let ((__tmp36215 (list)) (__tmp36214 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-query#relational-solution::t
         'relational-solution
         __tmp36215
         '(result)
         __tmp36214
         '#f)))
    (define gerbil-ascent/program/scheme-query#relational-solution?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-query#relational-solution::t)))
    (define gerbil-ascent/program/scheme-query#make-relational-solution
      (lambda _%$args20184%_
        (apply make-instance
               gerbil-ascent/program/scheme-query#relational-solution::t
               _%$args20184%_)))
    (define gerbil-ascent/program/scheme-query#relational-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-query#relational-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution::t
      (let ((__tmp36217 (list)) (__tmp36216 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-query#relational-program-solution::t
         'relational-program-solution
         __tmp36217
         '(result)
         __tmp36216
         '#f)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-query#relational-program-solution::t)))
    (define gerbil-ascent/program/scheme-query#make-relational-program-solution
      (lambda _%$args20181%_
        (apply make-instance
               gerbil-ascent/program/scheme-query#relational-program-solution::t
               _%$args20181%_)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#relational-program-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-program-solution-result
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#&relational-program-solution-result-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-query#relational-program-solution::t
         'result)))
    (define gerbil-ascent/program/scheme-query#copy-query-rows
      (lambda (_%rows20177%_)
        (map (lambda (_%row20179%_) (map identity _%row20179%_))
             _%rows20177%_)))
    (define gerbil-ascent/program/scheme-query#relational-result-rows
      (lambda (_%result20174%_ _%name20175%_)
        (if (let ()
              (declare (not safe))
              (clan/poo/object#.ref _%result20174%_ 'finished))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a completed result")))
        (gerbil-ascent/program/scheme-query#copy-query-rows
         ((let ()
            (declare (not safe))
            (clan/poo/object#.ref _%result20174%_ 'rows-of))
          _%name20175%_))))
    (define gerbil-ascent/program/scheme-query#relational-export
      (lambda (_%fragment20171%_ _%label20172%_)
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20171%_))
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%fragment20171%_ 'exports))
         _%label20172%_)))
    (define gerbil-ascent/program/scheme-query#checked-solution-result
      (lambda (_%solution20167%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%solution20167%_
               'gerbil-ascent/program/scheme-query#relational-solution::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a solved value"
                     _%solution20167%_)))
        (let ((_%result20169%_
               (##structure-ref
                _%solution20167%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (if (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%result20169%_ 'finished))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational query requires a completed result")))
          _%result20169%_)))
    (define gerbil-ascent/program/scheme-query#relational-prepare-query
      (lambda (_%fragment20158%_ _%label20159%_)
        (let ((_%name20161%_
               (gerbil-ascent/program/scheme-query#relational-export
                _%fragment20158%_
                _%label20159%_)))
          (lambda (_%solution20163%_)
            (let ((_%rows-of20165%_
                   (let ((__tmp36218
                          (gerbil-ascent/program/scheme-query#checked-solution-result
                           _%solution20163%_)))
                     (declare (not safe))
                     (clan/poo/object#.ref __tmp36218 'rows-of))))
              (gerbil-ascent/program/scheme-query#copy-query-rows
               (_%rows-of20165%_ _%name20161%_)))))))
    (define gerbil-ascent/program/scheme-query#relational-prepare-queries
      (lambda (_%fragment20141%_ _%labels20142%_)
        (if (and (list? _%labels20142%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%labels20142%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query view requires exported labels"
                     _%labels20142%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20141%_))
        (let* ((_%exports20144%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%fragment20141%_ 'exports)))
               (_%names20146%_ (map _%exports20144%_ _%labels20142%_)))
          (lambda (_%solution20149%_)
            (let* ((_%result20151%_
                    (gerbil-ascent/program/scheme-query#checked-solution-result
                     _%solution20149%_))
                   (_%rows-of20153%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%result20151%_ 'rows-of)))
                   (__tmp36219
                    (lambda (_%name20156%_)
                      (gerbil-ascent/program/scheme-query#copy-query-rows
                       (_%rows-of20153%_ _%name20156%_)))))
              (declare (not safe))
              (##map __tmp36219 _%names20146%_))))))
    (define gerbil-ascent/program/scheme-query#relational-query
      (lambda (_%solution20135%_ _%fragment20136%_ _%label20137%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%solution20135%_
               'gerbil-ascent/program/scheme-query#relational-solution::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational query requires a solved value"
                     _%solution20135%_)))
        (let ((_%result20139%_
               (##structure-ref
                _%solution20135%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20139%_
           (gerbil-ascent/program/scheme-query#relational-export
            _%fragment20136%_
            _%label20137%_)))))
    (define gerbil-ascent/program/scheme-query#relational-query-name
      (lambda (_%solution20130%_ _%name20131%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%solution20130%_
                    'gerbil-ascent/program/scheme-query#relational-solution::t))
                 (symbol? _%name20131%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational named query requires a solved value"
                     _%name20131%_)))
        (let ((_%result20133%_
               (##structure-ref
                _%solution20130%_
                '1
                gerbil-ascent/program/scheme-query#relational-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20133%_
           _%name20131%_))))
    (define gerbil-ascent/program/scheme-query#relational-program-query
      (lambda (_%solution20125%_ _%name20126%_)
        (if (and (let ()
                   (declare (not safe))
                   (##structure-instance-of?
                    _%solution20125%_
                    'gerbil-ascent/program/scheme-query#relational-program-solution::t))
                 (symbol? _%name20126%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational program query requires a named solution"
                     _%name20126%_)))
        (let ((_%result20128%_
               (##structure-ref
                _%solution20125%_
                '1
                gerbil-ascent/program/scheme-query#relational-program-solution::t
                '#f)))
          (gerbil-ascent/program/scheme-query#relational-result-rows
           _%result20128%_
           _%name20126%_))))))
