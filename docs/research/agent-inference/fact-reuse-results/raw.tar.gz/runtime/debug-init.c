#ifdef ___LINKER_INFO
; File: "debug-init.c", produced by Gambit v4.9.8
(
409008
(C)
"debug-init"
("debug-init")
()
(("debug-init"))
( #|*/"*/"symbols|#
"debug-init"
"debug-init#"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"__make-class-type"
"debug-init#"
"original-make-class-type"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"apply"
"car"
"current-error-port"
"display"
"force-output"
"newline"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "debug-init"
#define ___LINKER_ID ___LNK_debug_2d_init
#define ___MH_PROC ___H_debug_2d_init
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 2
#define ___GLOCOUNT 9
#define ___SUPCOUNT 3
#define ___SUBCOUNT 3
#define ___LBLCOUNT 13
#define ___MODDESCR ___REF_SUB(0)
#include "gambit.h"

___NEED_SYM(___S_debug_2d_init)
___NEED_SYM(___S_debug_2d_init_23_)

___NEED_GLO(___G_____make_2d_class_2d_type)
___NEED_GLO(___G_apply)
___NEED_GLO(___G_car)
___NEED_GLO(___G_current_2d_error_2d_port)
___NEED_GLO(___G_debug_2d_init_23_)
___NEED_GLO(___G_display)
___NEED_GLO(___G_force_2d_output)
___NEED_GLO(___G_newline)
___NEED_GLO(___G_original_2d_make_2d_class_2d_type)

___BEGIN_SYM
___DEF_SYM(0,___S_debug_2d_init,"debug-init")
___DEF_SYM(1,___S_debug_2d_init_23_,"debug-init#")
___END_SYM

#define ___SYM_debug_2d_init ___SYM(0,___S_debug_2d_init)
#define ___SYM_debug_2d_init_23_ ___SYM(1,___S_debug_2d_init_23_)

___BEGIN_GLO
___DEF_GLO(0,"__make-class-type")
___DEF_GLO(1,"debug-init#")
___DEF_GLO(2,"original-make-class-type")
___DEF_GLO(3,"apply")
___DEF_GLO(4,"car")
___DEF_GLO(5,"current-error-port")
___DEF_GLO(6,"display")
___DEF_GLO(7,"force-output")
___DEF_GLO(8,"newline")
___END_GLO

#define ___GLO_____make_2d_class_2d_type ___GLO(0,___G_____make_2d_class_2d_type)
#define ___PRM_____make_2d_class_2d_type ___PRM(0,___G_____make_2d_class_2d_type)
#define ___GLO_debug_2d_init_23_ ___GLO(1,___G_debug_2d_init_23_)
#define ___PRM_debug_2d_init_23_ ___PRM(1,___G_debug_2d_init_23_)
#define ___GLO_original_2d_make_2d_class_2d_type ___GLO(2,___G_original_2d_make_2d_class_2d_type)
#define ___PRM_original_2d_make_2d_class_2d_type ___PRM(2,___G_original_2d_make_2d_class_2d_type)
#define ___GLO_apply ___GLO(3,___G_apply)
#define ___PRM_apply ___PRM(3,___G_apply)
#define ___GLO_car ___GLO(4,___G_car)
#define ___PRM_car ___PRM(4,___G_car)
#define ___GLO_current_2d_error_2d_port ___GLO(5,___G_current_2d_error_2d_port)
#define ___PRM_current_2d_error_2d_port ___PRM(5,___G_current_2d_error_2d_port)
#define ___GLO_display ___GLO(6,___G_display)
#define ___PRM_display ___PRM(6,___G_display)
#define ___GLO_force_2d_output ___GLO(7,___G_force_2d_output)
#define ___PRM_force_2d_output ___PRM(7,___G_force_2d_output)
#define ___GLO_newline ___GLO(8,___G_newline)
#define ___PRM_newline ___PRM(8,___G_newline)

___DEF_SUB_VEC(___X0,6UL)
               ___VEC1(___REF_SUB(1))
               ___VEC1(___REF_SUB(2))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X1,1UL)
               ___VEC1(___REF_SYM(0,___S_debug_2d_init))
               ___VEC0
___DEF_SUB_VEC(___X2,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_debug_2d_init_23_)
___DEF_M_HLBL(___L1_debug_2d_init_23_)
___DEF_M_HLBL(___L2_debug_2d_init_23_)
___DEF_M_HLBL(___L3_debug_2d_init_23_)
___DEF_M_HLBL(___L4_debug_2d_init_23_)
___DEF_M_HLBL(___L5_debug_2d_init_23_)
___DEF_M_HLBL(___L6_debug_2d_init_23_)
___DEF_M_HLBL(___L7_debug_2d_init_23_)
___DEF_M_HLBL(___L8_debug_2d_init_23_)
___DEF_M_HLBL(___L9_debug_2d_init_23_)
___DEF_M_HLBL(___L10_debug_2d_init_23_)
___DEF_M_HLBL(___L11_debug_2d_init_23_)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_debug_2d_init_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_debug_2d_init_23_)
___DEF_P_HLBL(___L1_debug_2d_init_23_)
___DEF_P_HLBL(___L2_debug_2d_init_23_)
___DEF_P_HLBL(___L3_debug_2d_init_23_)
___DEF_P_HLBL(___L4_debug_2d_init_23_)
___DEF_P_HLBL(___L5_debug_2d_init_23_)
___DEF_P_HLBL(___L6_debug_2d_init_23_)
___DEF_P_HLBL(___L7_debug_2d_init_23_)
___DEF_P_HLBL(___L8_debug_2d_init_23_)
___DEF_P_HLBL(___L9_debug_2d_init_23_)
___DEF_P_HLBL(___L10_debug_2d_init_23_)
___DEF_P_HLBL(___L11_debug_2d_init_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_debug_2d_init_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_debug_2d_init_23_)
   ___SET_GLO(2,___G_original_2d_make_2d_class_2d_type,___GLO_____make_2d_class_2d_type)
   ___SET_GLO(0,___G_____make_2d_class_2d_type,___LBL(1))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___DEF_SLBL(1,___L1_debug_2d_init_23_)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(1,0,0,0)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___ADJFP(2)
   ___IF(___NOT(___EQP(___GLO_car,___PRM_car)))
   ___GOTO(___L13_debug_2d_init_23_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L13_debug_2d_init_23_)
   ___END_IF
   ___SET_R1(___CAR(___R1))
   ___GOTO(___L12_debug_2d_init_23_)
___DEF_SLBL(2,___L2_debug_2d_init_23_)
   ___ADJFP(-6)
___DEF_GLBL(___L12_debug_2d_init_23_)
   ___SET_STK(1,___R1)
   ___ADJFP(6)
   ___POLL(3)
___DEF_SLBL(3,___L3_debug_2d_init_23_)
   ___SET_R0(___LBL(4))
   ___JUMPGLOSAFE(___SET_NARGS(0),5,___G_current_2d_error_2d_port)
___DEF_SLBL(4,___L4_debug_2d_init_23_)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(5))
   ___JUMPGLOSAFE(___SET_NARGS(2),6,___G_display)
___DEF_SLBL(5,___L5_debug_2d_init_23_)
   ___SET_R0(___LBL(6))
   ___JUMPGLOSAFE(___SET_NARGS(0),5,___G_current_2d_error_2d_port)
___DEF_SLBL(6,___L6_debug_2d_init_23_)
   ___SET_R0(___LBL(7))
   ___JUMPGLOSAFE(___SET_NARGS(1),8,___G_newline)
___DEF_SLBL(7,___L7_debug_2d_init_23_)
   ___SET_R0(___LBL(8))
   ___JUMPGLOSAFE(___SET_NARGS(0),5,___G_current_2d_error_2d_port)
___DEF_SLBL(8,___L8_debug_2d_init_23_)
   ___SET_R0(___LBL(9))
   ___JUMPGLOSAFE(___SET_NARGS(1),7,___G_force_2d_output)
___DEF_SLBL(9,___L9_debug_2d_init_23_)
   ___SET_R2(___STK(-6))
   ___SET_R1(___GLO_original_2d_make_2d_class_2d_type)
   ___SET_R0(___STK(-7))
   ___POLL(10)
___DEF_SLBL(10,___L10_debug_2d_init_23_)
   ___ADJFP(-8)
   ___JUMPGLOSAFE(___SET_NARGS(2),3,___G_apply)
___DEF_GLBL(___L13_debug_2d_init_23_)
   ___SET_STK(0,___R1)
   ___SET_R1(___R1)
   ___ADJFP(6)
   ___POLL(11)
___DEF_SLBL(11,___L11_debug_2d_init_23_)
   ___SET_R0(___LBL(2))
   ___JUMPGLOSAFE(___SET_NARGS(1),4,___G_car)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_debug_2d_init_23_,___REF_SYM(1,___S_debug_2d_init_23_),___REF_FAL,12,0)
,___DEF_LBL_PROC(___H_debug_2d_init_23_,0,-1)
,___DEF_LBL_PROC(___H_debug_2d_init_23_,1,-1)
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_RET(___H_debug_2d_init_23_,___IFD(___RETI,8,0,0x3f03L))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(1,___G_debug_2d_init_23_,1)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(1,___G_debug_2d_init_23_,1)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_debug_2d_init,"debug-init")
___DEF_MOD_SYM(1,___S_debug_2d_init_23_,"debug-init#")
___END_MOD_SYM_KEY

#endif
