(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/actor-round::timestamp 1791689693)
  (begin
    (define gerbil-ascent/program/actor-round#gerbil-ascent-actor-round-eligible?
      (lambda (_%rules17788%_
               _%storages17789%_
               _%indexes17790%_
               _%joins17791%_
               _%fields17792%_)
        (if (let ((__tmp35735
                   (lambda (_%rule17794%_)
                     (let ((__tmp35736 (vector-ref _%rule17794%_ '5)))
                       (declare (not safe))
                       (gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
                        __tmp35736)))))
              (declare (not safe))
              (andmap__0 __tmp35735 _%rules17788%_))
            (if (let ((__tmp35738
                       (lambda (_%provider17796%_)
                         (or (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                _%provider17796%_))
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
                                _%provider17796%_)))))
                      (__tmp35737 (vector->list _%storages17789%_)))
                  (declare (not safe))
                  (andmap__0 __tmp35738 __tmp35737))
                (if (let ((__tmp35739 (vector->list _%indexes17790%_)))
                      (declare (not safe))
                      (andmap__0
                       gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                       __tmp35739))
                    (if (let ((__tmp35740 (vector->list _%joins17791%_)))
                          (declare (not safe))
                          (andmap__0 not __tmp35740))
                        (let ((__tmp35741 (vector->list _%fields17792%_)))
                          (declare (not safe))
                          (andmap__0 not __tmp35741))
                        '#f)
                    '#f)
                '#f)
            '#f)))
    (define gerbil-ascent/program/actor-round#run-task
      (lambda (_%owner17761%_ _%key17762%_ _%task17763%_ _%execute17764%_)
        (let ((__tmp35742
               (lambda (_%stop17766%_)
                 (let ((__tmp35744
                        (lambda (_%exception17768%_)
                          (_%stop17766%_ (cons 'failed _%exception17768%_))))
                       (__tmp35743
                        (lambda ()
                          (let ((_%batch17771%_ '())
                                (_%size17772%_ '0)
                                (_%ticks17773%_ '0))
                            (letrec ((_%request!17775%_
                                      (lambda (_%kind17785%_ _%payload17786%_)
                                        (thread-send
                                         _%owner17761%_
                                         (cons _%kind17785%_
                                               (cons _%key17762%_
                                                     (cons (current-thread)
                                                           (cons _%task17763%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (cons _%payload17786%_ '()))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (if (eq? (thread-receive) 'credit)
                                            '#!void
                                            (_%stop17766%_ 'stopped))))
                                     (_%flush!17776%_
                                      (lambda ()
                                        (if (zero? _%size17772%_)
                                            '#!void
                                            (begin
                                              (_%request!17775%_
                                               'batch
                                               (let ()
                                                 (declare (not safe))
                                                 (##reverse _%batch17771%_)))
                                              (set! _%ticks17773%_ '0)
                                              (set! _%batch17771%_ '())
                                              (set! _%size17772%_ '0)))))
                                     (_%emit!17777%_
                                      (lambda (_%atom17781%_ _%row17782%_)
                                        (set! _%batch17771%_
                                              (cons (cons _%atom17781%_
                                                          _%row17782%_)
                                                    _%batch17771%_))
                                        (set! _%size17772%_
                                              (+ _%size17772%_ '1))
                                        (if (= _%size17772%_ '32)
                                            (_%flush!17776%_)
                                            '#!void)))
                                     (_%checkpoint!17778%_
                                      (lambda ()
                                        (set! _%ticks17773%_
                                              (+ _%ticks17773%_ '1))
                                        (if (= _%ticks17773%_ '64)
                                            (begin
                                              (set! _%ticks17773%_ '0)
                                              (_%request!17775%_
                                               'checkpoint
                                               '#f))
                                            '#!void))))
                              (_%execute17764%_
                               _%task17763%_
                               _%emit!17777%_
                               _%checkpoint!17778%_)
                              (cons 'finished
                                    (let ()
                                      (declare (not safe))
                                      (##reverse _%batch17771%_))))))))
                   (declare (not safe))
                   (__with-exception-handler __tmp35744 __tmp35743)))))
          (declare (not safe))
          (##call-with-current-continuation __tmp35742))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
      (lambda (_%key17489%_
               _%tasks17490%_
               _%jobs17491%_
               _%execute17492%_
               _%merge17493%_
               _%canceled?17494%_
               _%ready?17495%_
               _%completed!17496%_)
        (if (and (exact-integer? _%jobs17491%_) (> _%jobs17491%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT worker capacity" _%jobs17491%_)))
        (let ((_%result17703%_
               (thread-join!
                (let ((__tmp35745
                       (lambda ()
                         (let ((__tmp35760
                                (lambda (_%exception17499%_)
                                  (cons 'failed _%exception17499%_)))
                               (__tmp35746
                                (lambda ()
                                  (let ((_%owner17502%_ (current-thread))
                                        (_%pending17503%_
                                         (cons '#f
                                               (map values _%tasks17490%_)))
                                        (_%assigned17504%_
                                         (let ()
                                           (declare (not safe))
                                           (make-hash-table-eq)))
                                        (_%active17505%_
                                         (let ()
                                           (declare (not safe))
                                           (make-hash-table-eq)))
                                        (_%active-count17506%_ '0)
                                        (_%workers17507%_ '())
                                        (_%idle17508%_ '())
                                        (_%awaiting17509%_ '#f)
                                        (_%failed?17510%_ '#f)
                                        (_%failure17511%_ '#f))
                                    (letrec ((_%stop!17513%_
                                              (lambda (_%exception17701%_)
                                                (if _%failed?17510%_
                                                    '#!void
                                                    (begin
                                                      (set! _%failure17511%_
                                                            _%exception17701%_)
                                                      (set! _%failed?17510%_
                                                            '#t)))
                                                (let ()
                                                  (declare (not safe))
                                                  (##set-cdr!
                                                   _%pending17503%_
                                                   '()))))
                                             (_%take-ready!17514%_
                                              (lambda ()
                                                (let _%scan17690%_ ((_%previous17692%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%pending17503%_)
                            (_%rest17693%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%pending17503%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (null? _%rest17693%_)
                                                      '#f
                                                      (if (let ((__tmp35747
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (car _%rest17693%_)))
                    (declare (not safe))
                    (__hash-get _%assigned17504%_ __tmp35747))
                  (let ()
                    (set-cdr! _%previous17692%_ (cdr _%rest17693%_))
                    (_%scan17690%_ _%previous17692%_ (cdr _%rest17693%_)))
                  (if (_%ready?17495%_ (car _%rest17693%_))
                      (let ((_%task17698%_ (car _%rest17693%_)))
                        (if _%task17698%_
                            (begin
                              (set-cdr! _%previous17692%_ (cdr _%rest17693%_))
                              (let ()
                                (declare (not safe))
                                (__hash-put!
                                 _%assigned17504%_
                                 _%task17698%_
                                 '#t)))
                            '#!void)
                        _%task17698%_)
                      (_%scan17690%_ _%rest17693%_ (cdr _%rest17693%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%make-worker!17515%_
                                              (lambda ()
                                                (let* ((_%worker17678%_
                                                        (let ((__tmp35748
                                                               (lambda ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let _%loop17631%_ ()
                           (let* ((_%$%g1763317644%_ (thread-receive))
                                  (_%$%E1763617648%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"No clause matching"
                                              _%$%g1763317644%_
                                              '(['task task])
                                              '('stop)))
                                     '#!void)))
                             (let ((_%$%K1763817663%_
                                    (lambda (_%task17659%_)
                                      (let* ((_%result17661%_
                                              (gerbil-ascent/program/actor-round#run-task
                                               _%owner17502%_
                                               _%key17489%_
                                               _%task17659%_
                                               _%execute17492%_))
                                             (__tmp35749
                                              (cons 'done
                                                    (cons _%key17489%_
                                                          (cons (current-thread)
                                                                (cons _%task17659%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (cons _%result17661%_ '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (declare (not safe))
                                        (##thread-send
                                         _%owner17502%_
                                         __tmp35749))
                                      (_%loop17631%_)))
                                   (_%$%K1763717653%_ (lambda () 'finished)))
                               (let ((_%$%try-match1763517656%_
                                      (lambda ()
                                        (if (let ()
                                              (declare (not safe))
                                              (##eq? _%$%g1763317644%_ 'stop))
                                            (_%$%K1763717653%_)
                                            (_%$%E1763617648%_)))))
                                 (if (pair? _%$%g1763317644%_)
                                     (let ((_%$%tl1764017668%_
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%$%g1763317644%_)))
                                           (_%$%hd1763917666%_
                                            (let ()
                                              (declare (not safe))
                                              (##car _%$%g1763317644%_))))
                                       (if (let ()
                                             (declare (not safe))
                                             (##eq? _%$%hd1763917666%_ 'task))
                                           (if (pair? _%$%tl1764017668%_)
                                               (let ((_%$%tl1764217673%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%tl1764017668%_)))
                                                     (_%$%hd1764117671%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##car _%$%tl1764017668%_))))
                                                 (if (null? _%$%tl1764217673%_)
                                                     (let ((_%task17676%_
                                                            _%$%hd1764117671%_))
                                                       (_%$%K1763817663%_
                                                        _%task17676%_))
                                                     (_%$%try-match1763517656%_)))
                                               (_%$%try-match1763517656%_))
                                           (_%$%try-match1763517656%_)))
                                     (_%$%try-match1763517656%_)))))))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-worker __tmp35748)))
               (_%monitor17686%_
                (let ((__tmp35750
                       (lambda ()
                         (let* ((_%result17684%_
                                 (let ((__tmp35752
                                        (lambda (_%exception17681%_)
                                          (cons 'failed _%exception17681%_)))
                                       (__tmp35751
                                        (lambda ()
                                          (thread-join! _%worker17678%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp35752 __tmp35751)))
                                (__tmp35753
                                 (cons 'exited
                                       (cons _%key17489%_
                                             (cons _%worker17678%_
                                                   (cons '#f
                                                         (cons _%result17684%_
                                                               '())))))))
                           (declare (not safe))
                           (##thread-send _%owner17502%_ __tmp35753)))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-monitor __tmp35750))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (set! _%workers17507%_
                                                        (cons (cons _%worker17678%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%monitor17686%_)
                      _%workers17507%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  _%worker17678%_)))
                                             (_%start!17516%_
                                              (lambda (_%task17623%_)
                                                (let ((_%worker17627%_
                                                       (if (pair? _%idle17508%_)
                                                           (let ((_%worker17625%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (car _%idle17508%_)))
                     (set! _%idle17508%_ (cdr _%idle17508%_))
                     _%worker17625%_)
                   (_%make-worker!17515%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%active17505%_
                                                     _%worker17627%_
                                                     _%task17623%_))
                                                  (set! _%active-count17506%_
                                                        (+ _%active-count17506%_
                                                           '1))
                                                  (thread-send
                                                   _%worker17627%_
                                                   (cons 'task
                                                         (cons _%task17623%_
                                                               '()))))))
                                             (_%run!17517%_
                                              (lambda ()
                                                (let ((__tmp35755
                                                       (lambda (_%exception17528%_)
                                                         (_%stop!17513%_
                                                          _%exception17528%_)
                                                         (if _%awaiting17509%_
                                                             (begin
                                                               (thread-send
                                                                _%awaiting17509%_
                                                                'stop)
                                                               (set! _%awaiting17509%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             '#f))
                     '#!void)
                 (_%run!17517%_)))
              (__tmp35754
               (lambda ()
                 (let _%loop17531%_ ()
                   (if _%failed?17510%_
                       '#!void
                       (begin
                         (if (_%canceled?17494%_)
                             (let ()
                               (declare (not safe))
                               (error '"ASCENT actor round canceled"))
                             '#!void)
                         (let _%admit17534%_ ()
                           (if (and (pair? (let ()
                                             (declare (not safe))
                                             (##cdr _%pending17503%_)))
                                    (< _%active-count17506%_ _%jobs17491%_))
                               (let ((_%task17537%_ (_%take-ready!17514%_)))
                                 (if _%task17537%_
                                     (begin
                                       (_%start!17516%_ _%task17537%_)
                                       (_%admit17534%_))
                                     '#!void))
                               '#!void))))
                   (if (zero? _%active-count17506%_)
                       '#!void
                       (begin
                         (let* ((_%$%g1753817554%_ (thread-receive))
                                (_%$%else1754017562%_ (lambda () '#!void))
                                (_%$%K1754217585%_
                                 (lambda (_%payload17565%_
                                          _%task17566%_
                                          _%worker17567%_
                                          _%received-key17568%_
                                          _%kind17569%_)
                                   (if (eq? _%received-key17568%_ _%key17489%_)
                                       (let ((_%assignment17571%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash-get
                                                 _%active17505%_
                                                 _%worker17567%_))))
                                         (if (eq? _%kind17569%_ 'exited)
                                             (let ()
                                               (if _%assignment17571%_
                                                   (begin
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-remove!
                                                        _%active17505%_
                                                        _%worker17567%_))
                                                     (set! _%active-count17506%_
                                                           (- _%active-count17506%_
                                                              '1)))
                                                   '#!void)
                                               (if (and (pair? _%payload17565%_)
                                                        (eq? (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%payload17565%_))
                     'failed))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (_%stop!17513%_
                                                    (cdr _%payload17565%_))
                                                   (let ()
                                                     (declare (not safe))
                                                     (error '"ASCENT worker exited before pool shutdown"))))
                                             (if (and _%assignment17571%_
                                                      (eq? _%task17566%_
                                                           _%assignment17571%_))
                                                 (let ((_%$e17575%_
                                                        _%kind17569%_))
                                                   (if (or (eq? 'batch
                                                                _%$e17575%_)
                                                           (eq? 'checkpoint
                                                                _%$e17575%_))
                                                       (begin
                                                         (set! _%awaiting17509%_
                                                               _%worker17567%_)
                                                         (if _%failed?17510%_
                                                             '#!void
                                                             (begin
                                                               (if (_%canceled?17494%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT actor round canceled"))
                           '#!void)
                       (if (eq? _%kind17569%_ 'batch)
                           (for-each
                            (lambda (_%candidate17581%_)
                              (_%merge17493%_
                               (car _%candidate17581%_)
                               (cdr _%candidate17581%_)))
                            _%payload17565%_)
                           '#!void)))
                 (thread-send
                  _%worker17567%_
                  (if _%failed?17510%_ 'stop 'credit))
                 (set! _%awaiting17509%_ '#f))
               (if (eq? 'done _%$e17575%_)
                   (begin
                     (let ()
                       (declare (not safe))
                       (__hash-remove! _%active17505%_ _%worker17567%_))
                     (set! _%active-count17506%_ (- _%active-count17506%_ '1))
                     (set! _%idle17508%_ (cons _%worker17567%_ _%idle17508%_))
                     (if (and (pair? _%payload17565%_)
                              (eq? (let ()
                                     (declare (not safe))
                                     (##car _%payload17565%_))
                                   'failed))
                         (_%stop!17513%_ (cdr _%payload17565%_))
                         (if _%failed?17510%_
                             '#!void
                             (begin
                               (if (and (pair? _%payload17565%_)
                                        (eq? (let ()
                                               (declare (not safe))
                                               (##car _%payload17565%_))
                                             'finished))
                                   (if (null? (cdr _%payload17565%_))
                                       '#!void
                                       (begin
                                         (if (_%canceled?17494%_)
                                             (let ()
                                               (declare (not safe))
                                               (error '"ASCENT actor round canceled"))
                                             '#!void)
                                         (for-each
                                          (lambda (_%candidate17583%_)
                                            (_%merge17493%_
                                             (car _%candidate17583%_)
                                             (cdr _%candidate17583%_)))
                                          (cdr _%payload17565%_))))
                                   '#!void)
                               (_%completed!17496%_ _%task17566%_)))))
                   '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '#!void)))
                                       '#!void))))
                           (if (pair? _%$%g1753817554%_)
                               (let ((_%$%hd1754317588%_
                                      (let ()
                                        (declare (not safe))
                                        (##car _%$%g1753817554%_)))
                                     (_%$%tl1754417590%_
                                      (let ()
                                        (declare (not safe))
                                        (##cdr _%$%g1753817554%_))))
                                 (let ((_%kind17593%_ _%$%hd1754317588%_))
                                   (if (pair? _%$%tl1754417590%_)
                                       (let ((_%$%hd1754517595%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%tl1754417590%_)))
                                             (_%$%tl1754617597%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl1754417590%_))))
                                         (let ((_%received-key17600%_
                                                _%$%hd1754517595%_))
                                           (if (pair? _%$%tl1754617597%_)
                                               (let ((_%$%hd1754717602%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##car _%$%tl1754617597%_)))
                                                     (_%$%tl1754817604%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%tl1754617597%_))))
                                                 (let ((_%worker17607%_
                                                        _%$%hd1754717602%_))
                                                   (if (pair? _%$%tl1754817604%_)
                                                       (let ((_%$%hd1754917609%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##car _%$%tl1754817604%_)))
                     (_%$%tl1755017611%_
                      (let ()
                        (declare (not safe))
                        (##cdr _%$%tl1754817604%_))))
                 (let ((_%task17614%_ _%$%hd1754917609%_))
                   (if (pair? _%$%tl1755017611%_)
                       (let ((_%$%hd1755117616%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%tl1755017611%_)))
                             (_%$%tl1755217618%_
                              (let ()
                                (declare (not safe))
                                (##cdr _%$%tl1755017611%_))))
                         (let ((_%payload17621%_ _%$%hd1755117616%_))
                           (if (null? _%$%tl1755217618%_)
                               (_%$%K1754217585%_
                                _%payload17621%_
                                _%task17614%_
                                _%worker17607%_
                                _%received-key17600%_
                                _%kind17593%_)
                               '#!void)))
                       '#!void)))
               '#!void)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               '#!void)))
                                       '#!void)))
                               '#!void))
                         (_%loop17531%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (__with-catch
                                                   __tmp35755
                                                   __tmp35754)))))
                                      (let ((__tmp35759
                                             (lambda ()
                                               (_%run!17517%_)
                                               (if _%failed?17510%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (raise _%failure17511%_))
                                                   (if (pair? (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%pending17503%_)))
               (let ()
                 (declare (not safe))
                 (error '"ASCENT ready task dependency deadlock"))
               '#!void))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp35756
                                             (lambda ()
                                               (let ((__tmp35757
                                                      (lambda (_%entry17523%_)
                                                        (thread-send
                                                         (car _%entry17523%_)
                                                         'stop))))
                                                 (declare (not safe))
                                                 (##for-each
                                                  __tmp35757
                                                  _%workers17507%_))
                                               (let ((__tmp35758
                                                      (lambda (_%entry17525%_)
                                                        (thread-join!
                                                         (cdr _%entry17525%_)))))
                                                 (declare (not safe))
                                                 (##for-each
                                                  __tmp35758
                                                  _%workers17507%_)))))
                                        (declare (not safe))
                                        (__with-unwind-protect
                                         __tmp35759
                                         __tmp35756)))))))
                           (declare (not safe))
                           (__with-catch __tmp35760 __tmp35746)))))
                  (declare (not safe))
                  (__spawn/name 'ascent-round-owner __tmp35745)))))
          (if (and (pair? _%result17703%_)
                   (eq? (let () (declare (not safe)) (##car _%result17703%_))
                        'failed))
              (let ((__tmp35761 (cdr _%result17703%_)))
                (declare (not safe))
                (raise __tmp35761))
              _%result17703%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__0
      (lambda (_%key17708%_
               _%tasks17709%_
               _%jobs17710%_
               _%execute17711%_
               _%merge17712%_)
        (let* ((_%canceled?17715%_ (lambda () '#f))
               (_%ready?17719%_ (lambda (_%_17717%_) '#t))
               (_%completed!17723%_ (lambda (_%_17721%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17708%_
           _%tasks17709%_
           _%jobs17710%_
           _%execute17711%_
           _%merge17712%_
           _%canceled?17715%_
           _%ready?17719%_
           _%completed!17723%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
      (lambda (_%key17725%_
               _%tasks17726%_
               _%jobs17727%_
               _%execute17728%_
               _%merge17729%_
               _%canceled?17730%_)
        (let* ((_%ready?17734%_ (lambda (_%_17732%_) '#t))
               (_%completed!17738%_ (lambda (_%_17736%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17725%_
           _%tasks17726%_
           _%jobs17727%_
           _%execute17728%_
           _%merge17729%_
           _%canceled?17730%_
           _%ready?17734%_
           _%completed!17738%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__2
      (lambda (_%key17740%_
               _%tasks17741%_
               _%jobs17742%_
               _%execute17743%_
               _%merge17744%_
               _%canceled?17745%_
               _%ready?17746%_)
        (let ((_%completed!17750%_ (lambda (_%_17748%_) '#!void)))
          (gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
           _%key17740%_
           _%tasks17741%_
           _%jobs17742%_
           _%execute17743%_
           _%merge17744%_
           _%canceled?17745%_
           _%ready?17746%_
           _%completed!17750%_))))
    (define gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!
      (lambda _g35762_
        (let ((_g35763_ (let () (declare (not safe)) (##length _g35762_))))
          (cond ((let () (declare (not safe)) (##fx= _g35763_ 5))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__0
                        _g35762_))
                ((let () (declare (not safe)) (##fx= _g35763_ 6))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__1
                        _g35762_))
                ((let () (declare (not safe)) (##fx= _g35763_ 7))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__2
                        _g35762_))
                ((let () (declare (not safe)) (##fx= _g35763_ 8))
                 (apply gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!__%
                        _g35762_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/actor-round#gerbil-ascent-run-actor-round!
                  _g35762_))))))))
