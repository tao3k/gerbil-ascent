(declare (block) (standard-bindings) (extended-bindings))
(begin (begin) (load-module "gerbil-ascent/table/funs~0"))
