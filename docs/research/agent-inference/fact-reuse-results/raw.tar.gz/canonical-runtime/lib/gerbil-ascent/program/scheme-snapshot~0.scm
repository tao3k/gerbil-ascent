(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-snapshot::timestamp 1791691018)
  (begin
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-term
      (lambda (_%term20241%_)
        (let ((_%$e20243%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%term20241%_ 'kind))))
          (if (eq? 'variable _%$e20243%_)
              (let ((__tmp36980
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term20241%_ 'value))))
                (declare (not safe))
                (gerbil-ascent/program/objects#gerbil-ascent-variable
                 __tmp36980))
              (if (eq? 'wildcard _%$e20243%_)
                  (let ()
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-wildcard))
                  (if (eq? 'literal _%$e20243%_)
                      (let ((_%value20246%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20241%_ 'value))))
                        (if (let ()
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-scalar?
                               _%value20246%_))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"non-scalar relational literal"
                                     _%value20246%_)))
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/program/objects#gerbil-ascent-literal
                           _%value20246%_)))
                      (let ((__tmp36981
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%term20241%_ 'kind))))
                        (declare (not safe))
                        (error '"unsupported relational term"
                               __tmp36981))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-atom
      (lambda (_%atom20239%_)
        (if (eq? (let ()
                   (declare (not safe))
                   (clan/poo/object#.ref _%atom20239%_ 'ascent-clause-kind))
                 'atom)
            '#!void
            (let ()
              (declare (not safe))
              (error '"unsupported relational clause")))
        (let ((__tmp36983
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%atom20239%_ 'relation)))
              (__tmp36982
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%atom20239%_ 'terms)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-atom
           __tmp36983
           __tmp36982))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-clause
      (lambda (_%clause20227%_)
        (let ((_%$e20229%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%clause20227%_ 'ascent-clause-kind))))
          (if (eq? 'atom _%$e20229%_)
              (gerbil-ascent/program/scheme-snapshot#relational-copy-atom
               _%clause20227%_)
              (if (eq? 'negation _%$e20229%_)
                  (let ((__tmp36985
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%clause20227%_ 'relation)))
                        (__tmp36984
                         (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%clause20227%_
                                 'terms)))))
                    (declare (not safe))
                    (gerbil-ascent/program/objects#gerbil-ascent-negation
                     __tmp36985
                     __tmp36984))
                  (if (eq? 'aggregate _%$e20229%_)
                      (let ((_%descriptor20232%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref
                                _%clause20227%_
                                'checked-operator)))
                            (_%terms20233%_
                             (let ()
                               (declare (not safe))
                               (clan/poo/object#.ref _%clause20227%_ 'terms))))
                        (if (and (vector? _%descriptor20232%_)
                                 (= (let ()
                                      (declare (not safe))
                                      (##vector-length _%descriptor20232%_))
                                    '6)
                                 (eq? (vector-ref _%descriptor20232%_ '0)
                                      'reduce)
                                 (eq? (vector-ref _%descriptor20232%_ '2)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'variable)))
                                 (eq? (vector-ref _%descriptor20232%_ '3)
                                      (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'relation)))
                                 (equal? (vector-ref _%descriptor20232%_ '4)
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%clause20227%_
                                            'variables)))
                                 (equal? (vector-ref _%descriptor20232%_ '5)
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/program/scheme-checked#relational-term-fingerprint
                                            _%terms20233%_)))
                                 (not (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause20227%_
                                         'output-pattern))))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"untrusted relational reduction")))
                        (let ((__tmp36990 (vector-ref _%descriptor20232%_ '2))
                              (__tmp36989 (vector-ref _%descriptor20232%_ '1))
                              (__tmp36988 (vector-ref _%descriptor20232%_ '4))
                              (__tmp36987 (vector-ref _%descriptor20232%_ '3))
                              (__tmp36986
                               (map gerbil-ascent/program/scheme-snapshot#relational-copy-term
                                    _%terms20233%_)))
                          (declare (not safe))
                          (gerbil-ascent/program/scheme-checked#relational-reducer
                           __tmp36990
                           __tmp36989
                           __tmp36988
                           __tmp36987
                           __tmp36986)))
                      (if (eq? 'guard _%$e20229%_)
                          (let ((_%descriptor20235%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%clause20227%_
                                    'checked-operator))))
                            (if (and (vector? _%descriptor20235%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##vector-length
                                           _%descriptor20235%_))
                                        '3)
                                     (eq? (vector-ref _%descriptor20235%_ '0)
                                          'where)
                                     (equal? (let ((__tmp36991
                                                    (vector-ref
                                                     _%descriptor20235%_
                                                     '2)))
                                               (declare (not safe))
                                               (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                __tmp36991))
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause20227%_
                                                'variables))))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"untrusted relational filter")))
                            (let ((__tmp36993
                                   (vector-ref _%descriptor20235%_ '1))
                                  (__tmp36992
                                   (vector-ref _%descriptor20235%_ '2)))
                              (declare (not safe))
                              (gerbil-ascent/program/scheme-checked#relational-where
                               __tmp36993
                               __tmp36992)))
                          (if (eq? 'binding _%$e20229%_)
                              (let ((_%descriptor20237%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20227%_
                                        'checked-operator))))
                                (if (and (vector? _%descriptor20237%_)
                                         (= (let ()
                                              (declare (not safe))
                                              (##vector-length
                                               _%descriptor20237%_))
                                            '4)
                                         (eq? (vector-ref
                                               _%descriptor20237%_
                                               '0)
                                              'compute)
                                         (equal? (let ((__tmp36994
                                                        (vector-ref
                                                         _%descriptor20237%_
                                                         '2)))
                                                   (declare (not safe))
                                                   (gerbil-ascent/program/scheme-checked#relational-operand-variables
                                                    __tmp36994))
                                                 (let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%clause20227%_
                                                    'variables)))
                                         (eq? (vector-ref
                                               _%descriptor20237%_
                                               '3)
                                              (let ()
                                                (declare (not safe))
                                                (clan/poo/object#.ref
                                                 _%clause20227%_
                                                 'variable))))
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"untrusted relational projection")))
                                (let ((__tmp36997
                                       (vector-ref _%descriptor20237%_ '3))
                                      (__tmp36996
                                       (vector-ref _%descriptor20237%_ '1))
                                      (__tmp36995
                                       (vector-ref _%descriptor20237%_ '2)))
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-compute
                                   __tmp36997
                                   __tmp36996
                                   __tmp36995)))
                              (let ((__tmp36998
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%clause20227%_
                                        'ascent-clause-kind))))
                                (declare (not safe))
                                (error '"unsupported relational clause"
                                       __tmp36998))))))))))
    (define gerbil-ascent/program/scheme-snapshot#relational-copy-rule
      (lambda (_%rule20225%_)
        (let ((__tmp37000
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-atom
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20225%_ 'heads))))
              (__tmp36999
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-clause
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%rule20225%_ 'body)))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-rule
           __tmp37000
           __tmp36999))))
    (define gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
      (lambda (_%program20205%_)
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentProgramContract
           _%program20205%_))
        (let ((__tmp37006
               (map (lambda (_%relation20207%_)
                      (let* ((_%domain20209%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'checked-domain)))
                             (_%domains20211%_
                              (if _%domain20209%_
                                  (begin
                                    (if (and (vector? _%domain20209%_)
                                             (= (let ()
                                                  (declare (not safe))
                                                  (##vector-length
                                                   _%domain20209%_))
                                                '2)
                                             (eq? (vector-ref
                                                   _%domain20209%_
                                                   '0)
                                                  'finite-domain))
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"untrusted finite domain descriptor")))
                                    (vector-ref _%domain20209%_ '1))
                                  '#f))
                             (_%name20213%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'name)))
                             (_%arity20215%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'arity)))
                             (_%rows20217%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'rows)))
                             (_%$e20220%_
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation20207%_
                                 'storage-kind))))
                        (if (eq? 'relation _%$e20220%_)
                            (if _%domain20209%_
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-finite-source
                                   _%name20213%_
                                   _%arity20215%_
                                   _%rows20217%_
                                   _%domains20211%_))
                                (let ()
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-source
                                   _%name20213%_
                                   _%arity20215%_
                                   _%rows20217%_)))
                            (if (eq? 'lattice _%$e20220%_)
                                (let ((_%descriptor20223%_
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation20207%_
                                          'checked-operator))))
                                  (if (and (vector? _%descriptor20223%_)
                                           (= (let ()
                                                (declare (not safe))
                                                (##vector-length
                                                 _%descriptor20223%_))
                                              '2)
                                           (eq? (vector-ref
                                                 _%descriptor20223%_
                                                 '0)
                                                'lattice))
                                      '#!void
                                      (let ()
                                        (declare (not safe))
                                        (error '"untrusted relational lattice")))
                                  (if _%domain20209%_
                                      (let ((__tmp37007
                                             (vector-ref
                                              _%descriptor20223%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-finite-lattice
                                         _%name20213%_
                                         _%arity20215%_
                                         _%rows20217%_
                                         __tmp37007
                                         _%domains20211%_))
                                      (let ((__tmp37008
                                             (vector-ref
                                              _%descriptor20223%_
                                              '1)))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-checked-lattice
                                         _%name20213%_
                                         _%arity20215%_
                                         _%rows20217%_
                                         __tmp37008))))
                                (let ()
                                  (declare (not safe))
                                  (error '"unsupported relational storage kind"))))))
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20205%_ 'relations))))
              (__tmp37005
               (map gerbil-ascent/program/scheme-snapshot#relational-copy-rule
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program20205%_ 'rules))))
              (__tmp37004
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-input-facts)))
              (__tmp37003
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-derived-facts)))
              (__tmp37002
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'max-output-facts)))
              (__tmp37001
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%program20205%_ 'source-handles))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           __tmp37006
           __tmp37005
           __tmp37004
           __tmp37003
           __tmp37002
           __tmp37001))))))
