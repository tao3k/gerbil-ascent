(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/relation-view[1]#_g33803_|
    (##structure
     gx#syntax-quote::t
     'relation-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33805_|
    (##structure
     gx#syntax-quote::t
     'make-relation-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33807_|
    (##structure
     gx#syntax-quote::t
     'relation-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33809_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33810_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33811_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33812_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33813_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33814_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33815_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33816_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33817_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33818_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33820_|
    (##structure
     gx#syntax-quote::t
     'relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33821_|
    (##structure
     gx#syntax-quote::t
     'relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33822_|
    (##structure
     gx#syntax-quote::t
     'relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33823_|
    (##structure
     gx#syntax-quote::t
     'relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33824_|
    (##structure
     gx#syntax-quote::t
     'relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33825_|
    (##structure
     gx#syntax-quote::t
     'relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33826_|
    (##structure
     gx#syntax-quote::t
     'relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33827_|
    (##structure
     gx#syntax-quote::t
     'relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33828_|
    (##structure
     gx#syntax-quote::t
     'relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33829_|
    (##structure
     gx#syntax-quote::t
     'relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33831_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33832_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33833_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33834_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33835_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33836_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33837_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33838_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33839_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33840_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33842_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33843_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33844_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-revision-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33845_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-lane-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33846_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33847_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-units-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33848_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-visit-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33849_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-contains-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33850_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-export-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33851_|
    (##structure
     gx#syntax-quote::t
     '&relation-view-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33853_|
    (##structure
     gx#syntax-quote::t
     'part-visitors::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33855_|
    (##structure
     gx#syntax-quote::t
     'make-part-visitors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33857_|
    (##structure
     gx#syntax-quote::t
     'part-visitors?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33859_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33860_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33862_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33863_|
    (##structure
     gx#syntax-quote::t
     'part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33865_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33866_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33868_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-checked-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33869_|
    (##structure
     gx#syntax-quote::t
     '&part-visitors-admitted-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33871_|
    (##structure
     gx#syntax-quote::t
     'row-stream::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33873_|
    (##structure
     gx#syntax-quote::t
     'make-row-stream
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33875_|
    (##structure
     gx#syntax-quote::t
     'row-stream?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33877_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33878_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33879_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33881_|
    (##structure
     gx#syntax-quote::t
     'row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33882_|
    (##structure
     gx#syntax-quote::t
     'row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33883_|
    (##structure
     gx#syntax-quote::t
     'row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33885_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33886_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33887_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33889_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33890_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33891_|
    (##structure
     gx#syntax-quote::t
     '&row-stream-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33893_|
    (##structure
     gx#syntax-quote::t
     'rectangle::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33895_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33897_|
    (##structure
     gx#syntax-quote::t
     'rectangle?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33899_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33900_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33901_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33903_|
    (##structure
     gx#syntax-quote::t
     'rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33904_|
    (##structure
     gx#syntax-quote::t
     'rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33905_|
    (##structure
     gx#syntax-quote::t
     'rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33907_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33908_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33909_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33911_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-prefix-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33912_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-left-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33913_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-right-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33915_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33917_|
    (##structure
     gx#syntax-quote::t
     'make-rectangle-bucket
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33919_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33921_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33922_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33923_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33924_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33926_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33927_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33928_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33929_|
    (##structure
     gx#syntax-quote::t
     'rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33931_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33932_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33933_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33934_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33936_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33937_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-blocks-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33938_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/relation-view[1]#_g33939_|
    (##structure
     gx#syntax-quote::t
     '&rectangle-bucket-plain-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/relation-view[:0:]#relation-view|
      (let ((__obj33551
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           'gerbil-ascent/core/relation-view#relation-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 'relation-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33551
           '(identity
             generation
             revision
             lane
             count
             units
             visit
             contains
             export
             parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '#f '13 '#f '#f))
        (let ((__tmp33802 |gerbil-ascent/core/relation-view[1]#_g33803_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33802 '4 '#f '#f))
        (let ((__tmp33804 |gerbil-ascent/core/relation-view[1]#_g33805_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33804 '14 '#f '#f))
        (let ((__tmp33806 |gerbil-ascent/core/relation-view[1]#_g33807_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33806 '15 '#f '#f))
        (let ((__tmp33808
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33809_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33810_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33811_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33812_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33813_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33814_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33815_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33816_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33817_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33818_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33808 '16 '#f '#f))
        (let ((__tmp33819
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33820_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33821_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33822_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33823_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33824_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33825_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33826_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33827_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33828_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33829_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33819 '17 '#f '#f))
        (let ((__tmp33830
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33831_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33832_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33833_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33834_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33835_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33836_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33837_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33838_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33839_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33840_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33830 '18 '#f '#f))
        (let ((__tmp33841
               (cons (cons 'identity
                           |gerbil-ascent/core/relation-view[1]#_g33842_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/core/relation-view[1]#_g33843_|)
                           (cons (cons 'revision
                                       |gerbil-ascent/core/relation-view[1]#_g33844_|)
                                 (cons (cons 'lane
                                             |gerbil-ascent/core/relation-view[1]#_g33845_|)
                                       (cons (cons 'count
                                                   |gerbil-ascent/core/relation-view[1]#_g33846_|)
                                             (cons (cons 'units
                                                         |gerbil-ascent/core/relation-view[1]#_g33847_|)
                                                   (cons (cons 'visit
                                                               |gerbil-ascent/core/relation-view[1]#_g33848_|)
                                                         (cons (cons 'contains
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/core/relation-view[1]#_g33849_|)
                       (cons (cons 'export
                                   |gerbil-ascent/core/relation-view[1]#_g33850_|)
                             (cons (cons 'parts
                                         |gerbil-ascent/core/relation-view[1]#_g33851_|)
                                   '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 __tmp33841 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33551 '() '21 '#f '#f))
        __obj33551))
    (define |gerbil-ascent/core/relation-view[:0:]#part-visitors|
      (let ((__obj33552
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33552
           'gerbil-ascent/core/relation-view#part-visitors::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 'part-visitors '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33552
           '(checked admitted)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33552
           '(checked admitted)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '#f '13 '#f '#f))
        (let ((__tmp33852 |gerbil-ascent/core/relation-view[1]#_g33853_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33852 '4 '#f '#f))
        (let ((__tmp33854 |gerbil-ascent/core/relation-view[1]#_g33855_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33854 '14 '#f '#f))
        (let ((__tmp33856 |gerbil-ascent/core/relation-view[1]#_g33857_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33856 '15 '#f '#f))
        (let ((__tmp33858
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33859_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33860_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33858 '16 '#f '#f))
        (let ((__tmp33861
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33862_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33863_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33861 '17 '#f '#f))
        (let ((__tmp33864
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33865_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33866_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33864 '18 '#f '#f))
        (let ((__tmp33867
               (cons (cons 'checked
                           |gerbil-ascent/core/relation-view[1]#_g33868_|)
                     (cons (cons 'admitted
                                 |gerbil-ascent/core/relation-view[1]#_g33869_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 __tmp33867 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33552 '() '21 '#f '#f))
        __obj33552))
    (define |gerbil-ascent/core/relation-view[:0:]#row-stream|
      (let ((__obj33553
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33553
           'gerbil-ascent/core/relation-view#row-stream::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 'row-stream '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33553
           '(view columns key)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33553
           '(view columns key)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '#f '13 '#f '#f))
        (let ((__tmp33870 |gerbil-ascent/core/relation-view[1]#_g33871_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33870 '4 '#f '#f))
        (let ((__tmp33872 |gerbil-ascent/core/relation-view[1]#_g33873_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33872 '14 '#f '#f))
        (let ((__tmp33874 |gerbil-ascent/core/relation-view[1]#_g33875_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33874 '15 '#f '#f))
        (let ((__tmp33876
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33877_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33878_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33879_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33876 '16 '#f '#f))
        (let ((__tmp33880
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33881_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33882_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33883_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33880 '17 '#f '#f))
        (let ((__tmp33884
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33885_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33886_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33887_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33884 '18 '#f '#f))
        (let ((__tmp33888
               (cons (cons 'view
                           |gerbil-ascent/core/relation-view[1]#_g33889_|)
                     (cons (cons 'columns
                                 |gerbil-ascent/core/relation-view[1]#_g33890_|)
                           (cons (cons 'key
                                       |gerbil-ascent/core/relation-view[1]#_g33891_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 __tmp33888 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33553 '() '21 '#f '#f))
        __obj33553))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle|
      (let ((__obj33554
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33554
           'gerbil-ascent/core/relation-view#rectangle::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 'rectangle '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33554
           '(prefix left right)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33554
           '(prefix left right)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '#f '13 '#f '#f))
        (let ((__tmp33892 |gerbil-ascent/core/relation-view[1]#_g33893_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33892 '4 '#f '#f))
        (let ((__tmp33894 |gerbil-ascent/core/relation-view[1]#_g33895_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33894 '14 '#f '#f))
        (let ((__tmp33896 |gerbil-ascent/core/relation-view[1]#_g33897_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33896 '15 '#f '#f))
        (let ((__tmp33898
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33899_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33900_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33901_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33898 '16 '#f '#f))
        (let ((__tmp33902
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33903_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33904_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33905_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33902 '17 '#f '#f))
        (let ((__tmp33906
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33907_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33908_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33909_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33906 '18 '#f '#f))
        (let ((__tmp33910
               (cons (cons 'prefix
                           |gerbil-ascent/core/relation-view[1]#_g33911_|)
                     (cons (cons 'left
                                 |gerbil-ascent/core/relation-view[1]#_g33912_|)
                           (cons (cons 'right
                                       |gerbil-ascent/core/relation-view[1]#_g33913_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 __tmp33910 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33554 '() '21 '#f '#f))
        __obj33554))
    (define |gerbil-ascent/core/relation-view[:0:]#rectangle-bucket|
      (let ((__obj33555
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33555
           'gerbil-ascent/core/relation-view#rectangle-bucket::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 'rectangle-bucket '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33555
           '(members blocks count plain)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33555
           '(members blocks count plain)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '#f '13 '#f '#f))
        (let ((__tmp33914 |gerbil-ascent/core/relation-view[1]#_g33915_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33914 '4 '#f '#f))
        (let ((__tmp33916 |gerbil-ascent/core/relation-view[1]#_g33917_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33916 '14 '#f '#f))
        (let ((__tmp33918 |gerbil-ascent/core/relation-view[1]#_g33919_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33918 '15 '#f '#f))
        (let ((__tmp33920
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33921_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33922_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33923_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33924_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33920 '16 '#f '#f))
        (let ((__tmp33925
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33926_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33927_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33928_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33929_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33925 '17 '#f '#f))
        (let ((__tmp33930
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33931_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33932_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33933_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33934_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33930 '18 '#f '#f))
        (let ((__tmp33935
               (cons (cons 'members
                           |gerbil-ascent/core/relation-view[1]#_g33936_|)
                     (cons (cons 'blocks
                                 |gerbil-ascent/core/relation-view[1]#_g33937_|)
                           (cons (cons 'count
                                       |gerbil-ascent/core/relation-view[1]#_g33938_|)
                                 (cons (cons 'plain
                                             |gerbil-ascent/core/relation-view[1]#_g33939_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 __tmp33935 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33555 '() '21 '#f '#f))
        __obj33555))))
