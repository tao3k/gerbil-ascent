# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Byte-level branch scheduling only. Native Scheme admits every state."""
import json

class BranchQueue:
    def __init__(self, stages, options):
        self.stages = stages
        self.options = options
        self.stack = [[]]
        self.tried = {}

    def next(self):
        while self.stack:
            parent = self.stack[-1]
            key = tuple(parent)
            remaining = [o['id'] for o in self.options if o['stage'] == len(parent)
                         and o['id'] not in self.tried.get(key, [])]
            if remaining:
                return list(parent), remaining
            self.stack.pop()
        return None

    def expand(self, parent, option, admissible):
        expected = self.next()
        if expected is None or expected[0] != parent or type(option) is not int or option not in expected[1]:
            raise ValueError('not an unvisited child of scheduled parent')
        self.tried.setdefault(tuple(parent), []).append(option)
        child = parent + [option]
        if admissible and len(child) < self.stages:
            self.stack.append(child)
        return child

def parse_expansion(terminal, allowed):
    calls = [x for x in terminal.get('output', []) if x.get('type') == 'function_call']
    if len(calls) != 1 or calls[0].get('name') != 'expand':
        raise ValueError('expected exactly one expand action')
    args = json.loads(calls[0]['arguments'])
    if set(args) != {'optionId'} or type(args['optionId']) is not int or args['optionId'] not in allowed:
        raise ValueError('invalid branch expansion')
    return args['optionId']
