(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/component-plan")
    (load-module "gerbil-ascent/program/index")
    (load-module "gerbil-ascent/core/positive-plan"))
  (load-module "gerbil-ascent/program/component-worker~0"))
