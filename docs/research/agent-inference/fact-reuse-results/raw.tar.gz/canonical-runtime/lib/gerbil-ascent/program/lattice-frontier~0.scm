(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/lattice-frontier::timestamp 1791690987)
  (begin
    (define gerbil-ascent/program/lattice-frontier#lattice-round::t
      (let ((__tmp34257 (list))
            (__tmp34256
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/lattice-frontier#lattice-round::t
         'lattice-round
         __tmp34257
         '(table changes sequence ordered?)
         __tmp34256
         '#f)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/lattice-frontier#lattice-round::t)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-round
      (lambda _%$args16320%_
        (apply make-instance
               gerbil-ascent/program/lattice-frontier#lattice-round::t
               _%$args16320%_)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-table
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-changes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-ordered?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-table-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-changes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-round-ordered?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-table
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-changes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-table-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'table)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-changes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'changes)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-round-ordered?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-round::t
         'ordered?)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change::t
      (let ((__tmp34259 (list))
            (__tmp34258
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/lattice-frontier#lattice-change::t
         'lattice-change
         __tmp34259
         '(row sequence)
         __tmp34258
         '#f)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/lattice-frontier#lattice-change::t)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-change
      (lambda _%$args16317%_
        (apply make-instance
               gerbil-ascent/program/lattice-frontier#lattice-change::t
               _%$args16317%_)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-row
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#lattice-change-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-row
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-sequence
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-row-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'row)))
    (define gerbil-ascent/program/lattice-frontier#&lattice-change-sequence-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/lattice-frontier#lattice-change::t
         'sequence)))
    (define gerbil-ascent/program/lattice-frontier#make-lattice-frontier
      (lambda ()
        (let ((__tmp34260
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/lattice-frontier#lattice-round::t
           __tmp34260
           '()
           '0
           '#t))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
      (lambda (_%frontier16287%_ _%key16288%_)
        (let* ((_%frontier16291%_ _%frontier16287%_)
               (_%$%node1629916301%_
                (let ((__tmp34261
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%frontier16291%_
                          '1
                          '#f
                          '#f))))
                  (declare (not safe))
                  (hash-get __tmp34261 _%key16288%_))))
          (if _%$%node1629916301%_
              (let* ((_%node16303%_ _%$%node1629916301%_)
                     (_%node16305%_ _%node16303%_))
                (declare (not safe))
                (##unchecked-structure-ref _%node16305%_ '1 '#f '#f))
              '#f))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-ref
      (lambda (_%frontier16274%_ _%key16275%_)
        (let ((_%frontier16278%_ _%frontier16274%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-ref
           _%frontier16278%_
           _%key16275%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
      (lambda (_%frontier16238%_ _%key16239%_ _%row16240%_)
        (let* ((_%frontier16243%_ _%frontier16238%_)
               (_%sequence16252%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%frontier16243%_ '3 '#f '#f))))
          (let ((__tmp34262 (+ _%sequence16252%_ '1)))
            (declare (not safe))
            (##unchecked-structure-set!
             _%frontier16243%_
             __tmp34262
             '3
             '#f
             '#f))
          (let ((_%$e16254%_
                 (let ((__tmp34263
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%frontier16243%_
                           '1
                           '#f
                           '#f))))
                   (declare (not safe))
                   (hash-get __tmp34263 _%key16239%_))))
            (if _%$e16254%_
                (let ()
                  (let ((_%node16259%_ _%$e16254%_))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-set!
                       _%node16259%_
                       _%row16240%_
                       '1
                       '#f
                       '#f))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-set!
                       _%node16259%_
                       _%sequence16252%_
                       '2
                       '#f
                       '#f)))
                  (if (eq? _%$e16254%_
                           (car (let ()
                                  (declare (not safe))
                                  (##unchecked-structure-ref
                                   _%frontier16243%_
                                   '2
                                   '#f
                                   '#f))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-set!
                         _%frontier16243%_
                         '#f
                         '4
                         '#f
                         '#f)))
                  '#f)
                (let ((_%node16272%_
                       (let ()
                         (declare (not safe))
                         (##structure
                          gerbil-ascent/program/lattice-frontier#lattice-change::t
                          _%row16240%_
                          _%sequence16252%_))))
                  (let ((__tmp34264
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%frontier16243%_
                            '1
                            '#f
                            '#f))))
                    (declare (not safe))
                    (hash-put! __tmp34264 _%key16239%_ _%node16272%_))
                  (let ((__tmp34265
                         (cons _%node16272%_
                               (let ()
                                 (declare (not safe))
                                 (##unchecked-structure-ref
                                  _%frontier16243%_
                                  '2
                                  '#f
                                  '#f)))))
                    (declare (not safe))
                    (##unchecked-structure-set!
                     _%frontier16243%_
                     __tmp34265
                     '2
                     '#f
                     '#f))
                  '#t))))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-stage!
      (lambda (_%frontier16224%_ _%key16225%_ _%row16226%_)
        (let ((_%frontier16229%_ _%frontier16224%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
           _%frontier16229%_
           _%key16225%_
           _%row16226%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
      (lambda (_%frontier16181%_)
        (let ((_%frontier16184%_ _%frontier16181%_))
          (map (lambda (_%node16193%_)
                 (let ((_%node16195%_ _%node16193%_))
                   (declare (not safe))
                   (##unchecked-structure-ref _%node16195%_ '1 '#f '#f)))
               (if (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%frontier16184%_ '4 '#f '#f))
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%frontier16184%_ '2 '#f '#f))
                   (list-sort
                    (lambda (_%a16205%_ _%b16206%_)
                      (let* ((_%a16208%_ _%a16205%_) (_%b16215%_ _%b16206%_))
                        (> (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%a16208%_ '2 '#f '#f))
                           (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%b16215%_
                              '2
                              '#f
                              '#f)))))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%frontier16184%_
                       '2
                       '#f
                       '#f))))))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-rows
      (lambda (_%frontier16169%_)
        (let ((_%frontier16172%_ _%frontier16169%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
           _%frontier16172%_))))
    (define gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
      (lambda (_%frontier16157%_)
        (let ((_%frontier16160%_ _%frontier16157%_))
          (let ((__tmp34266
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%frontier16160%_ '1 '#f '#f))))
            (declare (not safe))
            (hash-clear! __tmp34266))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16160%_ '() '2 '#f '#f))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16160%_ '0 '3 '#f '#f))
          (let ()
            (declare (not safe))
            (##unchecked-structure-set! _%frontier16160%_ '#t '4 '#f '#f)))))
    (define gerbil-ascent/program/lattice-frontier#lattice-frontier-clear!
      (lambda (_%frontier16145%_)
        (let ((_%frontier16148%_ _%frontier16145%_))
          (gerbil-ascent/program/lattice-frontier#__lattice-frontier-clear!
           _%frontier16148%_))))))
