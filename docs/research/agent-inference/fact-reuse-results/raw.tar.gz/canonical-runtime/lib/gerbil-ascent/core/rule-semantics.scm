(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/rule-bindings")
    (load-module "std/list/list")
    (load-module "std/list/list-builder")
    (load-module "gerbil-ascent/core/dependency-graph"))
  (load-module "gerbil-ascent/core/rule-semantics~0"))
