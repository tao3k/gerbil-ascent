(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/activation::timestamp 1791687856)
  (begin
    (define gerbil-ascent/program/activation#gerbil-ascent-activate-rule
      (lambda (_%rule11892%_)
        (let ((_%plan11894%_ (vector-ref _%rule11892%_ '5)))
          (vector (vector-ref _%rule11892%_ '0)
                  (vector-ref _%rule11892%_ '1)
                  (vector-ref _%rule11892%_ '2)
                  (vector-ref _%rule11892%_ '3)
                  (vector-ref _%rule11892%_ '4)
                  _%plan11894%_
                  (if _%plan11894%_
                      (make-vector (vector-ref _%plan11894%_ '2) '#f)
                      '#f)))))
    (define gerbil-ascent/program/activation#gerbil-ascent-activate-plans
      (lambda (_%plans11888%_)
        (vector-map
         (lambda (_%rules11890%_)
           (map gerbil-ascent/program/activation#gerbil-ascent-activate-rule
                _%rules11890%_))
         _%plans11888%_)))))
