(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/initialization::timestamp 1791691009)
  (begin
    (define gerbil-ascent/program/initialization#initial-source-state::t
      (let ((__tmp36293 (list))
            (__tmp36292
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/initialization#initial-source-state::t
         'initial-source-state
         __tmp36293
         '(all delta all-size delta-size storage-states seen lattice-rows)
         __tmp36292
         '#f)))
    (define gerbil-ascent/program/initialization#initial-source-state?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/initialization#initial-source-state::t)))
    (define gerbil-ascent/program/initialization#make-initial-source-state
      (lambda _%$args16907%_
        (apply make-instance
               gerbil-ascent/program/initialization#initial-source-state::t
               _%$args16907%_)))
    (define gerbil-ascent/program/initialization#initial-source-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-storage-states
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#initial-source-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#initial-source-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#initial-source-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#initial-source-state-storage-states-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#initial-source-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#initial-source-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-size
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-storage-states
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#&initial-source-state-seen
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#&initial-source-state-lattice-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta)))
    (define gerbil-ascent/program/initialization#&initial-source-state-all-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'all-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-delta-size-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'delta-size)))
    (define gerbil-ascent/program/initialization#&initial-source-state-storage-states-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'storage-states)))
    (define gerbil-ascent/program/initialization#&initial-source-state-seen-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'seen)))
    (define gerbil-ascent/program/initialization#&initial-source-state-lattice-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/initialization#initial-source-state::t
         'lattice-rows)))
    (define gerbil-ascent/program/initialization#gerbil-ascent-initialize-sources!
      (lambda (_%relations16746%_
               _%schema16747%_
               _%buffers16748%_
               _%input-limit16749%_
               _%output-limit16750%_)
        (let ((_%buffers16752%_ _%buffers16748%_))
          (let ((_%names16759%_ (vector-ref _%schema16747%_ '1))
                (_%arity16760%_ (vector-ref _%schema16747%_ '2))
                (_%field-checkers16761%_ (vector-ref _%schema16747%_ '3))
                (_%storage-extensions16762%_ (vector-ref _%schema16747%_ '6))
                (_%lattice-joins16763%_ (vector-ref _%schema16747%_ '7))
                (_%kinds16764%_ (vector-ref _%schema16747%_ '8))
                (_%storage-providers16765%_ (vector-ref _%schema16747%_ '9))
                (_%all16766%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '1 '#f '#f)))
                (_%delta16767%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '2 '#f '#f)))
                (_%all-size16768%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '3 '#f '#f)))
                (_%delta-size16769%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '4 '#f '#f)))
                (_%storage-states16770%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '5 '#f '#f)))
                (_%seen16771%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '6 '#f '#f)))
                (_%lattice-rows16772%_
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%buffers16752%_ '7 '#f '#f)))
                (_%source-count16773%_ '0)
                (_%source-materialized-count16774%_ '0))
            (let ((_%index16776%_ '0))
              (for-each
               (lambda (_%relation16778%_)
                 (let* ((_%name16780%_
                         (vector-ref _%names16759%_ _%index16776%_))
                        (_%width16782%_
                         (vector-ref _%arity16760%_ _%index16776%_))
                        (_%rows16784%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%relation16778%_ 'rows)))
                        (_%kind16786%_
                         (vector-ref _%kinds16764%_ _%index16776%_))
                        (_%check16788%_
                         (vector-ref _%field-checkers16761%_ _%index16776%_))
                        (_%provider16790%_
                         (vector-ref
                          _%storage-providers16765%_
                          _%index16776%_))
                        (_%set-storage?16792%_
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                            _%provider16790%_)))
                        (_%native-set?16794%_
                         (if (eq? _%kind16786%_ 'relation)
                             (if _%set-storage?16792%_
                                 (not _%check16788%_)
                                 '#f)
                             '#f))
                        (_%check-source!16801%_
                         (if _%native-set?16794%_
                             '#f
                             (lambda (_%row16796%_)
                               (if (and (list? _%row16796%_)
                                        (= (let ()
                                             (declare (not safe))
                                             (##length _%row16796%_))
                                           _%width16782%_))
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"invalid ASCENT relation row"
                                            _%name16780%_
                                            _%row16796%_)))
                               (if _%check16788%_
                                   (_%check16788%_ _%row16796%_)
                                   '#!void)
                               (set! _%source-count16773%_
                                     (+ _%source-count16773%_ '1))
                               (if (or (> _%source-count16773%_
                                          _%input-limit16749%_)
                                       (> _%source-count16773%_
                                          _%output-limit16750%_))
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT source fact budget exceeded"))
                                   '#!void))))
                        (_%native-view?16803%_
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
                                _%provider16790%_))
                             (let ((__tmp36294
                                    (vector-ref
                                     (vector-ref _%schema16747%_ '5)
                                     _%index16776%_)))
                               (declare (not safe))
                               (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                __tmp36294))
                             '#f))
                        (_%present16805%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value)))
                        (_%frontier16807%_ '#f))
                   (if (list? _%rows16784%_)
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"invalid ASCENT relation rows"
                                _%name16780%_
                                _%rows16784%_)))
                   (if (eq? _%kind16786%_ 'lattice)
                       (vector-set!
                        _%lattice-rows16772%_
                        _%index16776%_
                        (let ()
                          (declare (not safe))
                          (make-hash-table__%
                           '#f
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value
                           absent-value)))
                       '#!void)
                   (if (eq? _%kind16786%_ 'relation)
                       (vector-set!
                        _%storage-states16770%_
                        _%index16776%_
                        (let ((__tmp36295
                               (vector-ref
                                _%storage-providers16765%_
                                _%index16776%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-engine-state
                           __tmp36295)))
                       '#!void)
                   (if (eq? _%kind16786%_ 'lattice)
                       (for-each
                        (lambda (_%row16811%_)
                          (_%check-source!16801%_ _%row16811%_)
                          (let* ((_%key16813%_
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/core/rule-semantics#gerbil-ascent-lattice-key
                                     _%row16811%_)))
                                 (_%keyed16815%_
                                  (vector-ref
                                   _%lattice-rows16772%_
                                   _%index16776%_))
                                 (_%previous16817%_
                                  (let ()
                                    (declare (not safe))
                                    (hash-get _%keyed16815%_ _%key16813%_)))
                                 (_%merged16819%_
                                  (if _%previous16817%_
                                      (let ((__tmp36296
                                             ((vector-ref
                                               _%lattice-joins16763%_
                                               _%index16776%_)
                                              (last _%previous16817%_)
                                              (last _%row16811%_))))
                                        (declare (not safe))
                                        (gerbil-ascent/core/rule-semantics#gerbil-ascent-joined-row
                                         _%key16813%_
                                         __tmp36296))
                                      _%row16811%_)))
                            (if _%check16788%_
                                (_%check16788%_ _%merged16819%_)
                                '#!void)
                            (let ()
                              (declare (not safe))
                              (hash-put!
                               _%keyed16815%_
                               _%key16813%_
                               _%merged16819%_))
                            (if _%previous16817%_
                                '#!void
                                (set! _%source-materialized-count16774%_
                                      (+ _%source-materialized-count16774%_
                                         '1)))
                            (if _%frontier16807%_
                                '#!void
                                (set! _%frontier16807%_
                                      (let ()
                                        (declare (not safe))
                                        (gerbil-ascent/program/lattice-frontier#make-lattice-frontier))))
                            (let* ((_%frontier16822%_ _%frontier16807%_)
                                   (_%key16825%_ _%key16813%_)
                                   (_%row16828%_ _%merged16819%_)
                                   (_%frontier16832%_ _%frontier16822%_))
                              (declare (not safe))
                              (gerbil-ascent/program/lattice-frontier#__lattice-frontier-stage!
                               _%frontier16832%_
                               _%key16825%_
                               _%row16828%_))))
                        _%rows16784%_)
                       (if _%native-view?16803%_
                           (for-each
                            (lambda (_%row16869%_)
                              (_%check-source!16801%_ _%row16869%_)
                              (let ((_%frontier16871%_
                                     (let ((__tmp36298
                                            (vector-ref
                                             _%storage-states16770%_
                                             _%index16776%_))
                                           (__tmp36297
                                            (- _%output-limit16750%_
                                               _%source-materialized-count16774%_)))
                                       (declare (not safe))
                                       (gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
                                        __tmp36298
                                        _%row16869%_
                                        __tmp36297))))
                                (if _%check16788%_
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                       _%check16788%_
                                       _%frontier16871%_))
                                    '#!void)
                                (set! _%source-materialized-count16774%_
                                      (+ _%source-materialized-count16774%_
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                                            _%frontier16871%_))))
                                (let ((__tmp36299
                                       (vector-ref
                                        _%storage-states16770%_
                                        _%index16776%_)))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                   __tmp36299))))
                            _%rows16784%_)
                           (if _%set-storage?16792%_
                               (if _%check16788%_
                                   (for-each
                                    (lambda (_%row16874%_)
                                      (_%check-source!16801%_ _%row16874%_)
                                      (set! _%source-materialized-count16774%_
                                            (let ()
                                              (declare (not safe))
                                              (gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
                                               _%row16874%_
                                               _%width16782%_
                                               _%check16788%_
                                               _%present16805%_
                                               _%all16766%_
                                               _%index16776%_
                                               _%source-materialized-count16774%_
                                               _%output-limit16750%_))))
                                    _%rows16784%_)
                                   (let ((_%accepted16876%_
                                          (vector-ref
                                           _%all16766%_
                                           _%index16776%_)))
                                     (set! _%source-count16773%_
                                           (let ((__tmp36300
                                                  (lambda (_%row16878%_
                                                           _%source-count16879%_)
                                                    (if (and (list? _%row16878%_)
                                                             (= (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##length _%row16878%_))
                        _%width16782%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"invalid ASCENT relation row"
                         _%name16780%_
                         _%row16878%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%next-count16881%_
                                                           (+ _%source-count16879%_
                                                              '1)))
                                                      (if (or (> _%next-count16881%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%input-limit16749%_)
                      (> _%next-count16881%_ _%output-limit16750%_))
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT source fact budget exceeded"))
                  '#!void)
              (let ()
                (declare (not safe))
                (__hash-put! _%present16805%_ _%row16878%_ '#t))
              (set! _%source-materialized-count16774%_
                    (+ _%source-materialized-count16774%_ '1))
              (if (> _%source-materialized-count16774%_ _%output-limit16750%_)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT source fact budget exceeded"))
                  '#!void)
              (set! _%accepted16876%_ (cons _%row16878%_ _%accepted16876%_))
              _%next-count16881%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldl__0
                                              __tmp36300
                                              _%source-count16773%_
                                              _%rows16784%_)))
                                     (vector-set!
                                      _%all16766%_
                                      _%index16776%_
                                      _%accepted16876%_)))
                               (for-each
                                (lambda (_%row16888%_)
                                  (_%check-source!16801%_ _%row16888%_)
                                  (let ((_%materialized16890%_
                                         ((vector-ref
                                           _%storage-extensions16762%_
                                           _%index16776%_)
                                          (vector-ref
                                           _%storage-states16770%_
                                           _%index16776%_)
                                          (vector-ref
                                           _%all16766%_
                                           _%index16776%_)
                                          '()
                                          _%row16888%_
                                          (- _%output-limit16750%_
                                             _%source-materialized-count16774%_))))
                                    (if (list? _%materialized16890%_)
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"ASCENT storage provider returned non-list rows")))
                                    (for-each
                                     (lambda (_%stored16892%_)
                                       (set! _%source-materialized-count16774%_
                                             (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/program/admission#gerbil-ascent-initialize-source-row!
                                                _%stored16892%_
                                                _%width16782%_
                                                _%check16788%_
                                                _%present16805%_
                                                _%all16766%_
                                                _%index16776%_
                                                _%source-materialized-count16774%_
                                                _%output-limit16750%_))))
                                     _%materialized16890%_)
                                    (let ((__tmp36301
                                           (vector-ref
                                            _%storage-states16770%_
                                            _%index16776%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
                                       __tmp36301))))
                                _%rows16784%_))))
                   (if _%native-view?16803%_
                       (vector-set!
                        _%all16766%_
                        _%index16776%_
                        (let ((__tmp36302
                               (vector-ref
                                _%storage-states16770%_
                                _%index16776%_)))
                          (declare (not safe))
                          (gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
                           __tmp36302
                           '#f)))
                       '#!void)
                   (if (eq? _%kind16786%_ 'lattice)
                       (vector-set!
                        _%all16766%_
                        _%index16776%_
                        (if _%frontier16807%_
                            (let* ((_%frontier16894%_ _%frontier16807%_)
                                   (_%frontier16898%_ _%frontier16894%_))
                              (declare (not safe))
                              (gerbil-ascent/program/lattice-frontier#__lattice-frontier-rows
                               _%frontier16898%_))
                            '()))
                       '#!void)
                   (vector-set! _%seen16771%_ _%index16776%_ _%present16805%_)
                   (vector-set!
                    _%delta16767%_
                    _%index16776%_
                    (vector-ref _%all16766%_ _%index16776%_))
                   (vector-set!
                    _%all-size16768%_
                    _%index16776%_
                    (let ((__tmp36303
                           (vector-ref _%all16766%_ _%index16776%_)))
                      (declare (not safe))
                      (gerbil-ascent/core/relation-view#gerbil-ascent-row-count
                       __tmp36303)))
                   (vector-set!
                    _%delta-size16769%_
                    _%index16776%_
                    (vector-ref _%all-size16768%_ _%index16776%_))
                   (set! _%index16776%_ (+ _%index16776%_ '1))))
               _%relations16746%_))
            (values _%source-count16773%_
                    _%source-materialized-count16774%_)))))))
