# SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
"""Blinded, source-mapped annotation of externally returned model reasoning.

Label extraction is a separate measurement, not the native outcome judge.
"""
import json
from .crosspath_search_v3 import BASE, Native, canonical, sha, save, init, verify, provider, provider_key, charge_usage


def anchor(text, quote, occurrence):
    if not isinstance(quote,str) or not quote or type(occurrence) is not int or occurrence<0:
        raise ValueError('invalid quote/occurrence')
    start=0
    for _ in range(occurrence+1):
        pos=text.find(quote,start)
        if pos<0:raise ValueError('quote not present verbatim')
        start=pos+1
    return [pos,pos+len(quote)]


def validate_annotations(text, annotations, needs, source_edges, native_paths, native_ready):
    """Byte anchoring/schema checks; native admitted facts supply all truth values."""
    accepted=[];rejected=[]
    for index,a in enumerate(annotations):
        try:
            span=anchor(text,a['quote'],a['occurrence'])
            if accepted and span[0]<accepted[-1]['span'][0]:raise ValueError('out of chronological order')
            if a['kind'] not in ('derive','reuse','mention','conditional_recheck','uncertain'):raise ValueError('unknown kind')
            f=a['fragment'];paths=a['paths'];edges=a['premiseEdges']
            if f is not None and (type(f) is not int or not any(n[0]==f for n in needs)):raise ValueError('unknown fragment')
            if any(not isinstance(p,list) or len(p)!=2 or any(type(x) is not int for x in p) for p in paths+edges):raise ValueError('invalid endpoints')
            if any(e not in source_edges for e in edges):raise ValueError('support edge outside source')
            expected=next((n for n in needs if n[0]==f),None)
            identity_complete=expected is not None and sorted(paths)==sorted([expected[1:3],expected[3:5]]) and type(a['ready']) is bool
            truth_match=(identity_complete and a['ready']==(f in native_ready)) or (f is None and len(paths)==1 and paths[0] in native_paths and bool(edges))
            # Path-only positive claims can be anchored but are not counted as definite fragment repeats.
            prior=a['prior'];repeat=False;reject_reason=None
            key=(f,a['ready'],canonical(sorted(paths)),canonical(edges))
            if prior is not None:
                if type(prior) is not int or not 0<=prior<index:raise ValueError('invalid prior link')
                previous=next((x for x in accepted if x['index']==prior),None)
                if previous is None:raise ValueError('prior annotation was rejected')
                if a['kind']!='derive' or previous['kind']!='derive':raise ValueError('repeat link must connect derivations')
                if key!=tuple(previous['claimKey']):raise ValueError('different conclusion/premise context')
                if span[0]<previous['span'][1]:raise ValueError('overlapping self-repeat')
                repeat=bool(truth_match and previous['nativeTruthMatches'])
                if not repeat:reject_reason='repeat not admitted: incomplete fragment support or incorrect conclusion'
            accepted.append({**a,'index':index,'span':span,'textSha256':sha(text.encode()),'claimKey':list(key),
                             'nativeTruthMatches':bool(truth_match),'pathTruths':[p in native_paths for p in paths],
                             'definiteRepeatedDerivation':repeat,'repeatAdmissionNote':reject_reason})
        except (ValueError,KeyError,TypeError) as e:
            rejected.append({'index':index,'annotation':a,'failure':str(e)})
    return accepted,rejected


def annotate(plan):
    verify(plan);out=BASE/'annotations';out.mkdir(exist_ok=False)
    ledger=json.loads((BASE/'ledger.json').read_text());receipts=[]
    for row in ledger['phases']:
        c=next(c for c in plan['cases'] if c['id']==row['case'])
        folder=BASE/'paid'/f"{row['case']}-{row['arm']}-{row['phase']}"
        # Stable blinded ID contains no arm, case id, outcome or budget information.
        parts=[];segments=[]
        for call in row['calls']:
            text=(folder/f"{call['turn']}.thinking.txt").read_text()
            start=sum(len(p) for p in parts)
            marker=f"\n[call {call['turn']}]\n";parts.append(marker+text)
            segments.append({'turn':call['turn'],'start':start+len(marker),'end':start+len(marker)+len(text),
                             'thinkingSha256':call['thinkingSha256'],'providerOutcome':call['outcome']})
        text=''.join(parts);blind=sha(text.encode())[:20];dest=out/blind;dest.mkdir(exist_ok=False)
        (dest/'thinking.txt').write_text(text)
        measurement={'blindedId':blind,'phaseKey':str(folder.relative_to(BASE)),'textSha256':sha(text.encode()),'segments':segments,'failure':None,'accepted':[],'rejected':[]}
        if not any(x['end']>x['start'] for x in segments):
            measurement['failure']='no_returned_reasoning_text'
        else:
            request={'model':plan['model'],'input':[{'role':'user','content':canonical({'edges':c['edges'],'needs':c['needs'],'reasoningText':text})}],
                     'instructions':plan['annotationRubric'],'tools':[plan['annotatorTool']],'tool_choice':{'type':'function','name':'annotate'},
                     'reasoning':{'effort':'none'},'max_output_tokens':plan['annotationOutputCap'],'stream':True,'store':False}
            save(dest/'request.json',request);_,meta=provider(request,provider_key(),dest/'response.json');term=meta.get('terminal') or {}
            measurement['usage']=term.get('usage');measurement['providerSeconds']=meta['providerSeconds']
            try:measurement['measurementGrossTokens']=charge_usage(measurement['usage'])
            except ValueError as e:measurement['failure']=str(e)
            if term.get('status')!='completed' or meta.get('error'):measurement['failure']='annotation_provider_incomplete_or_error'
            if not measurement['failure']:
                try:
                    calls=[x for x in term.get('output',[]) if x.get('type')=='function_call' and x.get('name')=='annotate']
                    if len(calls)!=1:raise ValueError('expected exactly one annotation result')
                    a=json.loads(calls[0]['arguments'])['annotations']
                    native=Native()
                    try:
                        init(native,c,'fresh');raw,_=native.call(op='packet');cert=raw['certificate']
                    finally:native.close()
                    paths=next(x[2] for x in cert['finiteClosure'] if x[0]=='path');ready=next(x[2] for x in cert['finiteClosure'] if x[0]=='ready')
                    measurement['accepted'],measurement['rejected']=validate_annotations(text,a,c['needs'],c['edges'],paths,[x[0] for x in ready])
                    measurement['labelCoverage']='all returned text supplied; semantic extraction completeness unvalidated'
                except (ValueError,KeyError,TypeError,RuntimeError) as e:measurement['failure']='annotation_validation:'+str(e)
        save(dest/'receipt.json',measurement);receipts.append(measurement)
        save(BASE/'annotation-ledger.json',{'planSha256':sha((BASE/'frozen-plan.json').read_bytes()),'annotations':receipts})
        print('\nANNOTATED',blind,'episodes',len(measurement['accepted']),'repeats',sum(x['definiteRepeatedDerivation'] for x in measurement['accepted']),'failure',measurement['failure'],flush=True)
    verify(plan)
    print('CROSSPATH-ANNOTATION-OK',len(receipts),flush=True)

if __name__=='__main__':annotate(json.loads((BASE/'frozen-plan.json').read_text()))
