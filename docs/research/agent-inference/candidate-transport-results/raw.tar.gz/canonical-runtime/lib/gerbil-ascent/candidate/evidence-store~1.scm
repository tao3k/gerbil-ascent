(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34515_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34517_|
    (##structure
     gx#syntax-quote::t
     'make-evidence-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34519_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34521_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34522_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34523_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34524_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34526_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34527_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34528_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34529_|
    (##structure
     gx#syntax-quote::t
     'evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34531_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34532_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34533_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34534_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34536_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34537_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-candidate-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34538_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-receipt-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[1]#_g34539_|
    (##structure
     gx#syntax-quote::t
     '&evidence-entry-handle-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/evidence-store[:0:]#evidence-entry|
    (let ((__obj34426
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34426
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 'evidence-entry '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34426
         '(snapshot candidate receipt handle)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34426
         '(snapshot candidate receipt handle)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '#f '13 '#f '#f))
      (let ((__tmp34514 |gerbil-ascent/candidate/evidence-store[1]#_g34515_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34514 '4 '#f '#f))
      (let ((__tmp34516 |gerbil-ascent/candidate/evidence-store[1]#_g34517_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34516 '14 '#f '#f))
      (let ((__tmp34518 |gerbil-ascent/candidate/evidence-store[1]#_g34519_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34518 '15 '#f '#f))
      (let ((__tmp34520
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34521_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34522_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34523_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34524_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34520 '16 '#f '#f))
      (let ((__tmp34525
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34526_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34527_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34528_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34529_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34525 '17 '#f '#f))
      (let ((__tmp34530
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34531_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34532_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34533_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34534_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34530 '18 '#f '#f))
      (let ((__tmp34535
             (cons (cons 'snapshot
                         |gerbil-ascent/candidate/evidence-store[1]#_g34536_|)
                   (cons (cons 'candidate
                               |gerbil-ascent/candidate/evidence-store[1]#_g34537_|)
                         (cons (cons 'receipt
                                     |gerbil-ascent/candidate/evidence-store[1]#_g34538_|)
                               (cons (cons 'handle
                                           |gerbil-ascent/candidate/evidence-store[1]#_g34539_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 __tmp34535 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34426 '() '21 '#f '#f))
      __obj34426)))
