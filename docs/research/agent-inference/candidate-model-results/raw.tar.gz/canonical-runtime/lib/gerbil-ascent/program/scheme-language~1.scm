(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-language[1]#_g39072_|
    (##structure
     gx#syntax-quote::t
     'value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39083_|
    (##structure
     gx#syntax-quote::t
     'value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39096_|
    (##structure
     gx#syntax-quote::t
     'where
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39098_|
    (##structure
     gx#syntax-quote::t
     'compute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39100_|
    (##structure gx#syntax-quote::t 'not #f (gx#current-expander-context) '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39102_|
    (##structure
     gx#syntax-quote::t
     'reduce
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39126_|
    (##structure
     gx#syntax-quote::t
     'limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39128_|
    (##structure
     gx#syntax-quote::t
     'rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39130_|
    (##structure
     gx#syntax-quote::t
     'relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39135_|
    (##structure
     gx#syntax-quote::t
     'relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39140_|
    (##structure
     gx#syntax-quote::t
     'lattice
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39148_|
    (##structure
     gx#syntax-quote::t
     'import
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39152_|
    (##structure
     gx#syntax-quote::t
     'source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39158_|
    (##structure
     gx#syntax-quote::t
     'private
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39164_|
    (##structure
     gx#syntax-quote::t
     'export
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-language[1]#_g39170_|
    (##structure
     gx#syntax-quote::t
     'rule
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-term|
      (lambda (_%stx20476%_)
        (let* ((_%__stx3803138032%_ _%stx20476%_)
               (_%$%g2048120515%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3803138032%_)))))
          (let ((_%__kont3803438035%_
                 (lambda (_%$%g2048320669%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0
                            '#f
                            'relational-captured-value))
                         (cons _%$%g2048320669%_ '()))))
                (_%__kont3803638037%_
                 (lambda (_%$%g2049620595%_)
                   (let* ((_%datum20608%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax->datum _%$%g2049620595%_)))
                          (_%spelling20611%_ (symbol->string _%datum20608%_)))
                     (if (eq? _%datum20608%_ '?_)
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'gerbil-ascent-wildcard))
                               '())
                         (if (and (> (string-length _%spelling20611%_) '1)
                                  (let ((__tmp39070
                                         (string-ref _%spelling20611%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39070 '#\?)))
                             (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0
                                      '#f
                                      'gerbil-ascent-variable))
                                   (cons (cons (let ()
                                                 (declare (not safe))
                                                 (gx#datum->syntax__0
                                                  '#f
                                                  'quote))
                                               (cons _%$%g2049620595%_ '()))
                                         '()))
                             (let ()
                               (declare (not safe))
                               (gx#raise-syntax-error
                                '#f
                                '"relational term must be a ?variable or scalar literal"
                                _%$%g2049620595%_)))))))
                (_%__kont3803838039%_
                 (lambda (_%$%g2050320542%_)
                   (let ((_%datum20557%_
                          (let ()
                            (declare (not safe))
                            (gx#syntax->datum _%$%g2050320542%_))))
                     (if (or (exact-integer? _%datum20557%_)
                             (boolean? _%datum20557%_)
                             (char? _%datum20557%_))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'gerbil-ascent-literal))
                               (cons _%$%g2050320542%_ '()))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"relational term must be an immutable scalar literal"
                            _%$%g2050320542%_)))))))
            (let ((_%__match3808638087%_
                   (lambda (_%$%e2049720575%_
                            _%$%hd2049820579%_
                            _%$%tl2049920582%_
                            _%$%e2050020585%_
                            _%$%hd2050120589%_
                            _%$%tl2050220592%_)
                     (let ((_%$%g2049620595%_ _%$%hd2050120589%_))
                       (if (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2049620595%_))
                           (_%__kont3803638037%_ _%$%g2049620595%_)
                           (_%__kont3803838039%_ _%$%hd2050120589%_))))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3803138032%_))
                  (let ((_%$%e2048420629%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3803138032%_))))
                    (let ((_%$%tl2048620636%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2048420629%_)))
                          (_%$%hd2048520633%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2048420629%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2048620636%_))
                          (let ((_%$%e2048720639%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2048620636%_))))
                            (let ((_%$%tl2048920646%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2048720639%_)))
                                  (_%$%hd2048820643%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2048720639%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2048820643%_))
                                  (let ((_%$%e2049020649%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2048820643%_))))
                                    (let ((_%$%tl2049220656%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2049020649%_)))
                                          (_%$%hd2049120653%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2049020649%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#identifier?
                                             _%$%hd2049120653%_))
                                          (if (let ((__tmp39071
                                                     |gerbil-ascent/program/scheme-language[1]#_g39072_|))
                                                (declare (not safe))
                                                (gx#free-identifier=?
                                                 __tmp39071
                                                 _%$%hd2049120653%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl2049220656%_))
                                                  (let ((_%$%e2049320659%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl2049220656%_))))
                                                    (let ((_%$%tl2049520666%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2049320659%_)))
                                                          (_%$%hd2049420663%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2049320659%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2049520666%_))
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-null? _%$%tl2048920646%_))
                      (_%__kont3803438035%_ _%$%hd2049420663%_)
                      (let () (declare (not safe)) (_%$%g2048120515%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2048920646%_))
                      (_%__match3808638087%_
                       _%$%e2048420629%_
                       _%$%hd2048520633%_
                       _%$%tl2048620636%_
                       _%$%e2048720639%_
                       _%$%hd2048820643%_
                       _%$%tl2048920646%_)
                      (let () (declare (not safe)) (_%$%g2048120515%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2048920646%_))
                                                      (_%__match3808638087%_
                                                       _%$%e2048420629%_
                                                       _%$%hd2048520633%_
                                                       _%$%tl2048620636%_
                                                       _%$%e2048720639%_
                                                       _%$%hd2048820643%_
                                                       _%$%tl2048920646%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2048120515%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2048920646%_))
                                                  (_%__match3808638087%_
                                                   _%$%e2048420629%_
                                                   _%$%hd2048520633%_
                                                   _%$%tl2048620636%_
                                                   _%$%e2048720639%_
                                                   _%$%hd2048820643%_
                                                   _%$%tl2048920646%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g2048120515%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2048920646%_))
                                              (_%__match3808638087%_
                                               _%$%e2048420629%_
                                               _%$%hd2048520633%_
                                               _%$%tl2048620636%_
                                               _%$%e2048720639%_
                                               _%$%hd2048820643%_
                                               _%$%tl2048920646%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2048120515%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2048920646%_))
                                      (_%__match3808638087%_
                                       _%$%e2048420629%_
                                       _%$%hd2048520633%_
                                       _%$%tl2048620636%_
                                       _%$%e2048720639%_
                                       _%$%hd2048820643%_
                                       _%$%tl2048920646%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2048120515%_))))))
                          (let () (declare (not safe)) (_%$%g2048120515%_)))))
                  (let () (declare (not safe)) (_%$%g2048120515%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-atom|
      (lambda (_%stx20690%_)
        (let* ((_%__stx3810338104%_ _%stx20690%_)
               (_%$%g2069420728%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3810338104%_)))))
          (let ((_%__kont3810638107%_
                 (lambda (_%$%g2069620834%_ _%$%g2069720836%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-atom))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2069720836%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39073
                                                  (lambda (_%$%g2085420857%_
                                                           _%$%g2085520860%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2085420857%_ '()))
                  _%$%g2085520860%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39073
                                              '()
                                              _%$%g2069620834%_)))
                                     '())))))
                (_%__kont3811038111%_
                 (lambda (_%$%g2071620755%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational atom"
                      _%$%g2071620755%_)))))
            (let ((_%__match3813838139%_
                   (lambda (_%$%e2069820776%_
                            _%$%hd2069920780%_
                            _%$%tl2070020783%_
                            _%$%e2070120786%_
                            _%$%hd2070220790%_
                            _%$%tl2070320793%_
                            _%$%e2070420796%_
                            _%$%hd2070520800%_
                            _%$%tl2070620803%_
                            _%__splice3810838109%_
                            _%$%target2070720806%_
                            _%$%tl2070920809%_)
                     (letrec ((_%$%loop2071020812%_
                               (lambda (_%$%hd2070820816%_
                                        _%$%term2071420819%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2070820816%_))
                                     (let ((_%$%e2071120821%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2070820816%_))))
                                       (let ((_%$%lp-tl2071320828%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2071120821%_)))
                                             (_%$%lp-hd2071220825%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2071120821%_))))
                                         (_%$%loop2071020812%_
                                          _%$%lp-tl2071320828%_
                                          (cons _%$%lp-hd2071220825%_
                                                _%$%term2071420819%_))))
                                     (let ((_%$%term2071520831%_
                                            (reverse _%$%term2071420819%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2070320793%_))
                                           (let ((_%$%g2069620834%_
                                                  _%$%term2071520831%_)
                                                 (_%$%g2069720836%_
                                                  _%$%hd2070520800%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2069720836%_))
                                                 (_%__kont3810638107%_
                                                  _%$%g2069620834%_
                                                  _%$%g2069720836%_)
                                                 (_%__kont3811038111%_
                                                  _%$%hd2070220790%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2069420728%_))))))))
                       (_%$%loop2071020812%_ _%$%target2070720806%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3810338104%_))
                  (let ((_%$%e2069820776%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3810338104%_))))
                    (let ((_%$%tl2070020783%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2069820776%_)))
                          (_%$%hd2069920780%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2069820776%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2070020783%_))
                          (let ((_%$%e2070120786%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2070020783%_))))
                            (let ((_%$%tl2070320793%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2070120786%_)))
                                  (_%$%hd2070220790%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2070120786%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2070220790%_))
                                  (let ((_%$%e2070420796%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2070220790%_))))
                                    (let ((_%$%tl2070620803%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2070420796%_)))
                                          (_%$%hd2070520800%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2070420796%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2070620803%_))
                                          (let ((_%__splice3810838109%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2070620803%_
                                                    '0))))
                                            (let ((_%$%tl2070920809%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3810838109%_
                                                      '1)))
                                                  (_%$%target2070720806%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3810838109%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2070920809%_))
                                                  (_%__match3813838139%_
                                                   _%$%e2069820776%_
                                                   _%$%hd2069920780%_
                                                   _%$%tl2070020783%_
                                                   _%$%e2070120786%_
                                                   _%$%hd2070220790%_
                                                   _%$%tl2070320793%_
                                                   _%$%e2070420796%_
                                                   _%$%hd2070520800%_
                                                   _%$%tl2070620803%_
                                                   _%__splice3810838109%_
                                                   _%$%target2070720806%_
                                                   _%$%tl2070920809%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2070320793%_))
                                                      (_%__kont3811038111%_
                                                       _%$%hd2070220790%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2069420728%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2070320793%_))
                                              (_%__kont3811038111%_
                                               _%$%hd2070220790%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2069420728%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2070320793%_))
                                      (_%__kont3811038111%_ _%$%hd2070220790%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2069420728%_))))))
                          (let () (declare (not safe)) (_%$%g2069420728%_)))))
                  (let () (declare (not safe)) (_%$%g2069420728%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-atom/lexical|
      (lambda (_%stx20868%_)
        (let* ((_%__stx3815538156%_ _%stx20868%_)
               (_%$%g2087220906%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3815538156%_)))))
          (let ((_%__kont3815838159%_
                 (lambda (_%$%g2087421012%_ _%$%g2087521014%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-atom))
                         (cons _%$%g2087521014%_
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39074
                                                  (lambda (_%$%g2103221035%_
                                                           _%$%g2103321038%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2103221035%_ '()))
                  _%$%g2103321038%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39074
                                              '()
                                              _%$%g2087421012%_)))
                                     '())))))
                (_%__kont3816238163%_
                 (lambda (_%$%g2089420933%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational atom"
                      _%$%g2089420933%_)))))
            (let ((_%__match3819038191%_
                   (lambda (_%$%e2087620954%_
                            _%$%hd2087720958%_
                            _%$%tl2087820961%_
                            _%$%e2087920964%_
                            _%$%hd2088020968%_
                            _%$%tl2088120971%_
                            _%$%e2088220974%_
                            _%$%hd2088320978%_
                            _%$%tl2088420981%_
                            _%__splice3816038161%_
                            _%$%target2088520984%_
                            _%$%tl2088720987%_)
                     (letrec ((_%$%loop2088820990%_
                               (lambda (_%$%hd2088620994%_
                                        _%$%term2089220997%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2088620994%_))
                                     (let ((_%$%e2088920999%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2088620994%_))))
                                       (let ((_%$%lp-tl2089121006%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2088920999%_)))
                                             (_%$%lp-hd2089021003%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2088920999%_))))
                                         (_%$%loop2088820990%_
                                          _%$%lp-tl2089121006%_
                                          (cons _%$%lp-hd2089021003%_
                                                _%$%term2089220997%_))))
                                     (let ((_%$%term2089321009%_
                                            (reverse _%$%term2089220997%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2088120971%_))
                                           (let ((_%$%g2087421012%_
                                                  _%$%term2089321009%_)
                                                 (_%$%g2087521014%_
                                                  _%$%hd2088320978%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2087521014%_))
                                                 (_%__kont3815838159%_
                                                  _%$%g2087421012%_
                                                  _%$%g2087521014%_)
                                                 (_%__kont3816238163%_
                                                  _%$%hd2088020968%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2087220906%_))))))))
                       (_%$%loop2088820990%_ _%$%target2088520984%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3815538156%_))
                  (let ((_%$%e2087620954%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3815538156%_))))
                    (let ((_%$%tl2087820961%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2087620954%_)))
                          (_%$%hd2087720958%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2087620954%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2087820961%_))
                          (let ((_%$%e2087920964%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2087820961%_))))
                            (let ((_%$%tl2088120971%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2087920964%_)))
                                  (_%$%hd2088020968%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2087920964%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2088020968%_))
                                  (let ((_%$%e2088220974%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2088020968%_))))
                                    (let ((_%$%tl2088420981%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2088220974%_)))
                                          (_%$%hd2088320978%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2088220974%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2088420981%_))
                                          (let ((_%__splice3816038161%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2088420981%_
                                                    '0))))
                                            (let ((_%$%tl2088720987%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3816038161%_
                                                      '1)))
                                                  (_%$%target2088520984%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3816038161%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2088720987%_))
                                                  (_%__match3819038191%_
                                                   _%$%e2087620954%_
                                                   _%$%hd2087720958%_
                                                   _%$%tl2087820961%_
                                                   _%$%e2087920964%_
                                                   _%$%hd2088020968%_
                                                   _%$%tl2088120971%_
                                                   _%$%e2088220974%_
                                                   _%$%hd2088320978%_
                                                   _%$%tl2088420981%_
                                                   _%__splice3816038161%_
                                                   _%$%target2088520984%_
                                                   _%$%tl2088720987%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2088120971%_))
                                                      (_%__kont3816238163%_
                                                       _%$%hd2088020968%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2087220906%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2088120971%_))
                                              (_%__kont3816238163%_
                                               _%$%hd2088020968%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2087220906%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2088120971%_))
                                      (_%__kont3816238163%_ _%$%hd2088020968%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2087220906%_))))))
                          (let () (declare (not safe)) (_%$%g2087220906%_)))))
                  (let () (declare (not safe)) (_%$%g2087220906%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-negation|
      (lambda (_%stx21046%_)
        (let* ((_%__stx3820738208%_ _%stx21046%_)
               (_%$%g2105021084%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3820738208%_)))))
          (let ((_%__kont3821038211%_
                 (lambda (_%$%g2105221190%_ _%$%g2105321192%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-negation))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2105321192%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39075
                                                  (lambda (_%$%g2121021213%_
                                                           _%$%g2121121216%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2121021213%_ '()))
                  _%$%g2121121216%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39075
                                              '()
                                              _%$%g2105221190%_)))
                                     '())))))
                (_%__kont3821438215%_
                 (lambda (_%$%g2107221111%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational negation atom"
                      _%$%g2107221111%_)))))
            (let ((_%__match3824238243%_
                   (lambda (_%$%e2105421132%_
                            _%$%hd2105521136%_
                            _%$%tl2105621139%_
                            _%$%e2105721142%_
                            _%$%hd2105821146%_
                            _%$%tl2105921149%_
                            _%$%e2106021152%_
                            _%$%hd2106121156%_
                            _%$%tl2106221159%_
                            _%__splice3821238213%_
                            _%$%target2106321162%_
                            _%$%tl2106521165%_)
                     (letrec ((_%$%loop2106621168%_
                               (lambda (_%$%hd2106421172%_
                                        _%$%term2107021175%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2106421172%_))
                                     (let ((_%$%e2106721177%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2106421172%_))))
                                       (let ((_%$%lp-tl2106921184%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2106721177%_)))
                                             (_%$%lp-hd2106821181%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2106721177%_))))
                                         (_%$%loop2106621168%_
                                          _%$%lp-tl2106921184%_
                                          (cons _%$%lp-hd2106821181%_
                                                _%$%term2107021175%_))))
                                     (let ((_%$%term2107121187%_
                                            (reverse _%$%term2107021175%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2105921149%_))
                                           (let ((_%$%g2105221190%_
                                                  _%$%term2107121187%_)
                                                 (_%$%g2105321192%_
                                                  _%$%hd2106121156%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2105321192%_))
                                                 (_%__kont3821038211%_
                                                  _%$%g2105221190%_
                                                  _%$%g2105321192%_)
                                                 (_%__kont3821438215%_
                                                  _%$%hd2105821146%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2105021084%_))))))))
                       (_%$%loop2106621168%_ _%$%target2106321162%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3820738208%_))
                  (let ((_%$%e2105421132%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3820738208%_))))
                    (let ((_%$%tl2105621139%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2105421132%_)))
                          (_%$%hd2105521136%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2105421132%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2105621139%_))
                          (let ((_%$%e2105721142%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2105621139%_))))
                            (let ((_%$%tl2105921149%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2105721142%_)))
                                  (_%$%hd2105821146%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2105721142%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2105821146%_))
                                  (let ((_%$%e2106021152%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2105821146%_))))
                                    (let ((_%$%tl2106221159%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2106021152%_)))
                                          (_%$%hd2106121156%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2106021152%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2106221159%_))
                                          (let ((_%__splice3821238213%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2106221159%_
                                                    '0))))
                                            (let ((_%$%tl2106521165%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3821238213%_
                                                      '1)))
                                                  (_%$%target2106321162%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3821238213%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2106521165%_))
                                                  (_%__match3824238243%_
                                                   _%$%e2105421132%_
                                                   _%$%hd2105521136%_
                                                   _%$%tl2105621139%_
                                                   _%$%e2105721142%_
                                                   _%$%hd2105821146%_
                                                   _%$%tl2105921149%_
                                                   _%$%e2106021152%_
                                                   _%$%hd2106121156%_
                                                   _%$%tl2106221159%_
                                                   _%__splice3821238213%_
                                                   _%$%target2106321162%_
                                                   _%$%tl2106521165%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2105921149%_))
                                                      (_%__kont3821438215%_
                                                       _%$%hd2105821146%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2105021084%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2105921149%_))
                                              (_%__kont3821438215%_
                                               _%$%hd2105821146%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2105021084%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2105921149%_))
                                      (_%__kont3821438215%_ _%$%hd2105821146%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2105021084%_))))))
                          (let () (declare (not safe)) (_%$%g2105021084%_)))))
                  (let () (declare (not safe)) (_%$%g2105021084%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-negation/lexical|
      (lambda (_%stx21224%_)
        (let* ((_%__stx3825938260%_ _%stx21224%_)
               (_%$%g2122821262%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3825938260%_)))))
          (let ((_%__kont3826238263%_
                 (lambda (_%$%g2123021368%_ _%$%g2123121370%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'gerbil-ascent-negation))
                         (cons _%$%g2123121370%_
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'list))
                                           (let ((__tmp39076
                                                  (lambda (_%$%g2138821391%_
                                                           _%$%g2138921394%_)
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-term))
                        (cons _%$%g2138821391%_ '()))
                  _%$%g2138921394%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp39076
                                              '()
                                              _%$%g2123021368%_)))
                                     '())))))
                (_%__kont3826638267%_
                 (lambda (_%$%g2125021289%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected a relational negation atom"
                      _%$%g2125021289%_)))))
            (let ((_%__match3829438295%_
                   (lambda (_%$%e2123221310%_
                            _%$%hd2123321314%_
                            _%$%tl2123421317%_
                            _%$%e2123521320%_
                            _%$%hd2123621324%_
                            _%$%tl2123721327%_
                            _%$%e2123821330%_
                            _%$%hd2123921334%_
                            _%$%tl2124021337%_
                            _%__splice3826438265%_
                            _%$%target2124121340%_
                            _%$%tl2124321343%_)
                     (letrec ((_%$%loop2124421346%_
                               (lambda (_%$%hd2124221350%_
                                        _%$%term2124821353%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (gx#stx-pair? _%$%hd2124221350%_))
                                     (let ((_%$%e2124521355%_
                                            (let ()
                                              (declare (not safe))
                                              (gx#syntax-e
                                               _%$%hd2124221350%_))))
                                       (let ((_%$%lp-tl2124721362%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%e2124521355%_)))
                                             (_%$%lp-hd2124621359%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%e2124521355%_))))
                                         (_%$%loop2124421346%_
                                          _%$%lp-tl2124721362%_
                                          (cons _%$%lp-hd2124621359%_
                                                _%$%term2124821353%_))))
                                     (let ((_%$%term2124921365%_
                                            (reverse _%$%term2124821353%_)))
                                       (if (let ()
                                             (declare (not safe))
                                             (gx#stx-null? _%$%tl2123721327%_))
                                           (let ((_%$%g2123021368%_
                                                  _%$%term2124921365%_)
                                                 (_%$%g2123121370%_
                                                  _%$%hd2123921334%_))
                                             (if (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2123121370%_))
                                                 (_%__kont3826238263%_
                                                  _%$%g2123021368%_
                                                  _%$%g2123121370%_)
                                                 (_%__kont3826638267%_
                                                  _%$%hd2123621324%_)))
                                           (let ()
                                             (declare (not safe))
                                             (_%$%g2122821262%_))))))))
                       (_%$%loop2124421346%_ _%$%target2124121340%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3825938260%_))
                  (let ((_%$%e2123221310%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3825938260%_))))
                    (let ((_%$%tl2123421317%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2123221310%_)))
                          (_%$%hd2123321314%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2123221310%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2123421317%_))
                          (let ((_%$%e2123521320%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2123421317%_))))
                            (let ((_%$%tl2123721327%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2123521320%_)))
                                  (_%$%hd2123621324%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2123521320%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2123621324%_))
                                  (let ((_%$%e2123821330%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2123621324%_))))
                                    (let ((_%$%tl2124021337%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2123821330%_)))
                                          (_%$%hd2123921334%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2123821330%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%tl2124021337%_))
                                          (let ((_%__splice3826438265%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%tl2124021337%_
                                                    '0))))
                                            (let ((_%$%tl2124321343%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3826438265%_
                                                      '1)))
                                                  (_%$%target2124121340%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3826438265%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2124321343%_))
                                                  (_%__match3829438295%_
                                                   _%$%e2123221310%_
                                                   _%$%hd2123321314%_
                                                   _%$%tl2123421317%_
                                                   _%$%e2123521320%_
                                                   _%$%hd2123621324%_
                                                   _%$%tl2123721327%_
                                                   _%$%e2123821330%_
                                                   _%$%hd2123921334%_
                                                   _%$%tl2124021337%_
                                                   _%__splice3826438265%_
                                                   _%$%target2124121340%_
                                                   _%$%tl2124321343%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2123721327%_))
                                                      (_%__kont3826638267%_
                                                       _%$%hd2123621324%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2122821262%_))))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2123721327%_))
                                              (_%__kont3826638267%_
                                               _%$%hd2123621324%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2122821262%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2123721327%_))
                                      (_%__kont3826638267%_ _%$%hd2123621324%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2122821262%_))))))
                          (let () (declare (not safe)) (_%$%g2122821262%_)))))
                  (let () (declare (not safe)) (_%$%g2122821262%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-reduce|
      (lambda (_%stx21402%_)
        (let* ((_%__stx3831138312%_ _%stx21402%_)
               (_%$%g2140621467%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3831138312%_)))))
          (let ((_%__kont3831438315%_
                 (lambda (_%$%g2140821651%_
                          _%$%g2140921653%_
                          _%$%g2141021654%_
                          _%$%g2141121655%_
                          _%$%g2141221656%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-reducer))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2141221656%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons _%$%g2141121655%_ '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons (let ((__tmp39077
                                                              (lambda (_%$%g2168721692%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2168821695%_)
                        (cons _%$%g2168721692%_ _%$%g2168821695%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39077 '() _%$%g2141021654%_))
               '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'quote))
                                                       (cons _%$%g2140921653%_
                                                             '()))
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39078
                            (lambda (_%$%g2168921698%_ _%$%g2169021701%_)
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'relational-term))
                                          (cons _%$%g2168921698%_ '()))
                                    _%$%g2169021701%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39078 '() _%$%g2140821651%_)))
               '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                (_%__kont3832038321%_
                 (lambda (_%$%g2144921512%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected checked reduction"
                      _%stx21402%_)))))
            (let* ((_%__match3837038371%_
                    (lambda (_%$%e2145021474%_
                             _%$%hd2145121478%_
                             _%$%tl2145221481%_
                             _%__splice3832238323%_
                             _%$%target2145321484%_
                             _%$%tl2145521487%_)
                      (letrec ((_%$%loop2145621490%_
                                (lambda (_%$%hd2145421494%_
                                         _%$%bad2146021497%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2145421494%_))
                                      (let ((_%$%e2145721499%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2145421494%_))))
                                        (let ((_%$%lp-tl2145921506%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2145721499%_)))
                                              (_%$%lp-hd2145821503%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2145721499%_))))
                                          (_%$%loop2145621490%_
                                           _%$%lp-tl2145921506%_
                                           (cons _%$%lp-hd2145821503%_
                                                 _%$%bad2146021497%_))))
                                      (let ((_%$%bad2146121509%_
                                             (reverse _%$%bad2146021497%_)))
                                        (_%__kont3832038321%_
                                         _%$%bad2146121509%_))))))
                        (_%$%loop2145621490%_ _%$%target2145321484%_ '()))))
                   (_%__match3836238363%_
                    (lambda (_%$%e2145021474%_
                             _%$%hd2145121478%_
                             _%$%tl2145221481%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl2145221481%_))
                          (let ((_%__splice3832238323%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl2145221481%_
                                    '0))))
                            (let ((_%$%tl2145521487%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3832238323%_ '1)))
                                  (_%$%target2145321484%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3832238323%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl2145521487%_))
                                  (_%__match3837038371%_
                                   _%$%e2145021474%_
                                   _%$%hd2145121478%_
                                   _%$%tl2145221481%_
                                   _%__splice3832238323%_
                                   _%$%target2145321484%_
                                   _%$%tl2145521487%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2140621467%_)))))
                          (let () (declare (not safe)) (_%$%g2140621467%_)))))
                   (_%__match3835638357%_
                    (lambda (_%$%e2141321535%_
                             _%$%hd2141421539%_
                             _%$%tl2141521542%_
                             _%$%e2141621545%_
                             _%$%hd2141721549%_
                             _%$%tl2141821552%_
                             _%$%e2141921555%_
                             _%$%hd2142021559%_
                             _%$%tl2142121562%_
                             _%$%e2142221565%_
                             _%$%hd2142321569%_
                             _%$%tl2142421572%_
                             _%__splice3831638317%_
                             _%$%target2142521575%_
                             _%$%tl2142721578%_)
                      (letrec ((_%$%loop2142821581%_
                                (lambda (_%$%hd2142621585%_
                                         _%$%input2143221588%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2142621585%_))
                                      (let ((_%$%e2142921590%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2142621585%_))))
                                        (let ((_%$%lp-tl2143121597%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2142921590%_)))
                                              (_%$%lp-hd2143021594%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2142921590%_))))
                                          (_%$%loop2142821581%_
                                           _%$%lp-tl2143121597%_
                                           (cons _%$%lp-hd2143021594%_
                                                 _%$%input2143221588%_))))
                                      (let ((_%$%input2143321600%_
                                             (reverse _%$%input2143221588%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2142421572%_))
                                            (let ((_%$%e2143421603%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2142421572%_))))
                                              (let ((_%$%tl2143621610%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2143421603%_)))
                                                    (_%$%hd2143521607%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2143421603%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2143521607%_))
                                                    (let ((_%$%e2143721613%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2143521607%_))))
                                                      (let ((_%$%tl2143921620%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2143721613%_)))
                    (_%$%hd2143821617%_
                     (let () (declare (not safe)) (##car _%$%e2143721613%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2143921620%_))
                    (let ((_%__splice3831838319%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2143921620%_
                              '0))))
                      (let ((_%$%tl2144221626%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3831838319%_ '1)))
                            (_%$%target2144021623%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3831838319%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2144221626%_))
                            (letrec ((_%$%loop2144321629%_
                                      (lambda (_%$%hd2144121633%_
                                               _%$%term2144721636%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2144121633%_))
                                            (let ((_%$%e2144421638%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2144121633%_))))
                                              (let ((_%$%lp-tl2144621645%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2144421638%_)))
                                                    (_%$%lp-hd2144521642%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2144421638%_))))
                                                (_%$%loop2144321629%_
                                                 _%$%lp-tl2144621645%_
                                                 (cons _%$%lp-hd2144521642%_
                                                       _%$%term2144721636%_))))
                                            (let ((_%$%term2144821648%_
                                                   (reverse _%$%term2144721636%_)))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2143621610%_))
                                                  (let ((_%$%g2140821651%_
                                                         _%$%term2144821648%_)
                                                        (_%$%g2140921653%_
                                                         _%$%hd2143821617%_)
                                                        (_%$%g2141021654%_
                                                         _%$%input2143321600%_)
                                                        (_%$%g2141121655%_
                                                         _%$%hd2142021559%_)
                                                        (_%$%g2141221656%_
                                                         _%$%hd2141721549%_))
                                                    (if (and (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2140921653%_))
                     (let ()
                       (declare (not safe))
                       (gx#identifier? _%$%g2141121655%_)))
                (_%__kont3831438315%_
                 _%$%g2140821651%_
                 _%$%g2140921653%_
                 _%$%g2141021654%_
                 _%$%g2141121655%_
                 _%$%g2141221656%_)
                (_%__match3836238363%_
                 _%$%e2141321535%_
                 _%$%hd2141421539%_
                 _%$%tl2141521542%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3836238363%_
                                                   _%$%e2141321535%_
                                                   _%$%hd2141421539%_
                                                   _%$%tl2141521542%_)))))))
                              (_%$%loop2144321629%_
                               _%$%target2144021623%_
                               '()))
                            (_%__match3836238363%_
                             _%$%e2141321535%_
                             _%$%hd2141421539%_
                             _%$%tl2141521542%_))))
                    (_%__match3836238363%_
                     _%$%e2141321535%_
                     _%$%hd2141421539%_
                     _%$%tl2141521542%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3836238363%_
                                                     _%$%e2141321535%_
                                                     _%$%hd2141421539%_
                                                     _%$%tl2141521542%_))))
                                            (_%__match3836238363%_
                                             _%$%e2141321535%_
                                             _%$%hd2141421539%_
                                             _%$%tl2141521542%_)))))))
                        (_%$%loop2142821581%_ _%$%target2142521575%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3831138312%_))
                  (let ((_%$%e2141321535%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3831138312%_))))
                    (let ((_%$%tl2141521542%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2141321535%_)))
                          (_%$%hd2141421539%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2141321535%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2141521542%_))
                          (let ((_%$%e2141621545%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2141521542%_))))
                            (let ((_%$%tl2141821552%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2141621545%_)))
                                  (_%$%hd2141721549%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2141621545%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2141821552%_))
                                  (let ((_%$%e2141921555%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2141821552%_))))
                                    (let ((_%$%tl2142121562%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2141921555%_)))
                                          (_%$%hd2142021559%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2141921555%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2142121562%_))
                                          (let ((_%$%e2142221565%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2142121562%_))))
                                            (let ((_%$%tl2142421572%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2142221565%_)))
                                                  (_%$%hd2142321569%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2142221565%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%hd2142321569%_))
                                                  (let ((_%__splice3831638317%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%hd2142321569%_
                                                            '0))))
                                                    (let ((_%$%tl2142721578%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3831638317%_
                                                              '1)))
                                                          (_%$%target2142521575%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3831638317%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2142721578%_))
                                                          (_%__match3835638357%_
                                                           _%$%e2141321535%_
                                                           _%$%hd2141421539%_
                                                           _%$%tl2141521542%_
                                                           _%$%e2141621545%_
                                                           _%$%hd2141721549%_
                                                           _%$%tl2141821552%_
                                                           _%$%e2141921555%_
                                                           _%$%hd2142021559%_
                                                           _%$%tl2142121562%_
                                                           _%$%e2142221565%_
                                                           _%$%hd2142321569%_
                                                           _%$%tl2142421572%_
                                                           _%__splice3831638317%_
                                                           _%$%target2142521575%_
                                                           _%$%tl2142721578%_)
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-pair/null? _%$%tl2141521542%_))
                      (let ((_%__splice3832238323%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2141521542%_
                                '0))))
                        (let ((_%$%tl2145521487%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3832238323%_ '1)))
                              (_%$%target2145321484%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3832238323%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2145521487%_))
                              (_%__match3837038371%_
                               _%$%e2141321535%_
                               _%$%hd2141421539%_
                               _%$%tl2141521542%_
                               _%__splice3832238323%_
                               _%$%target2145321484%_
                               _%$%tl2145521487%_)
                              (let ()
                                (declare (not safe))
                                (_%$%g2140621467%_)))))
                      (let () (declare (not safe)) (_%$%g2140621467%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2141521542%_))
                                                      (let ((_%__splice3832238323%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice->vector
                        _%$%tl2141521542%_
                        '0))))
                (let ((_%$%tl2145521487%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3832238323%_ '1)))
                      (_%$%target2145321484%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3832238323%_ '0))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2145521487%_))
                      (_%__match3837038371%_
                       _%$%e2141321535%_
                       _%$%hd2141421539%_
                       _%$%tl2141521542%_
                       _%__splice3832238323%_
                       _%$%target2145321484%_
                       _%$%tl2145521487%_)
                      (let () (declare (not safe)) (_%$%g2140621467%_)))))
              (let () (declare (not safe)) (_%$%g2140621467%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2141521542%_))
                                              (let ((_%__splice3832238323%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice->vector
                                                        _%$%tl2141521542%_
                                                        '0))))
                                                (let ((_%$%tl2145521487%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3832238323%_
                                                          '1)))
                                                      (_%$%target2145321484%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3832238323%_
                                                          '0))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2145521487%_))
                                                      (_%__match3837038371%_
                                                       _%$%e2141321535%_
                                                       _%$%hd2141421539%_
                                                       _%$%tl2141521542%_
                                                       _%__splice3832238323%_
                                                       _%$%target2145321484%_
                                                       _%$%tl2145521487%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2140621467%_)))))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2140621467%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair/null? _%$%tl2141521542%_))
                                      (let ((_%__splice3832238323%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-split-splice->vector
                                                _%$%tl2141521542%_
                                                '0))))
                                        (let ((_%$%tl2145521487%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3832238323%_
                                                  '1)))
                                              (_%$%target2145321484%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3832238323%_
                                                  '0))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2145521487%_))
                                              (_%__match3837038371%_
                                               _%$%e2141321535%_
                                               _%$%hd2141421539%_
                                               _%$%tl2141521542%_
                                               _%__splice3832238323%_
                                               _%$%target2145321484%_
                                               _%$%tl2145521487%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2140621467%_)))))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2140621467%_))))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2141521542%_))
                              (let ((_%__splice3832238323%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl2141521542%_
                                        '0))))
                                (let ((_%$%tl2145521487%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3832238323%_
                                          '1)))
                                      (_%$%target2145321484%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3832238323%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2145521487%_))
                                      (_%__match3837038371%_
                                       _%$%e2141321535%_
                                       _%$%hd2141421539%_
                                       _%$%tl2141521542%_
                                       _%__splice3832238323%_
                                       _%$%target2145321484%_
                                       _%$%tl2145521487%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2140621467%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g2140621467%_))))))
                  (let () (declare (not safe)) (_%$%g2140621467%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-reduce/lexical|
      (lambda (_%stx21711%_)
        (let* ((_%__stx3837338374%_ _%stx21711%_)
               (_%$%g2171521776%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3837338374%_)))))
          (let ((_%__kont3837638377%_
                 (lambda (_%$%g2171721960%_
                          _%$%g2171821962%_
                          _%$%g2171921963%_
                          _%$%g2172021964%_
                          _%$%g2172121965%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-reducer))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'quote))
                                     (cons _%$%g2172121965%_ '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons _%$%g2172021964%_ '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons (let ((__tmp39079
                                                              (lambda (_%$%g2199622001%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2199722004%_)
                        (cons _%$%g2199622001%_ _%$%g2199722004%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39079 '() _%$%g2171921963%_))
               '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           (cons _%$%g2171821962%_
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39080
                            (lambda (_%$%g2199822007%_ _%$%g2199922010%_)
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'relational-term))
                                          (cons _%$%g2199822007%_ '()))
                                    _%$%g2199922010%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39080 '() _%$%g2171721960%_)))
               '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                (_%__kont3838238383%_
                 (lambda (_%$%g2175821821%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected checked reduction"
                      _%stx21711%_)))))
            (let* ((_%__match3843238433%_
                    (lambda (_%$%e2175921783%_
                             _%$%hd2176021787%_
                             _%$%tl2176121790%_
                             _%__splice3838438385%_
                             _%$%target2176221793%_
                             _%$%tl2176421796%_)
                      (letrec ((_%$%loop2176521799%_
                                (lambda (_%$%hd2176321803%_
                                         _%$%bad2176921806%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2176321803%_))
                                      (let ((_%$%e2176621808%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2176321803%_))))
                                        (let ((_%$%lp-tl2176821815%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2176621808%_)))
                                              (_%$%lp-hd2176721812%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2176621808%_))))
                                          (_%$%loop2176521799%_
                                           _%$%lp-tl2176821815%_
                                           (cons _%$%lp-hd2176721812%_
                                                 _%$%bad2176921806%_))))
                                      (let ((_%$%bad2177021818%_
                                             (reverse _%$%bad2176921806%_)))
                                        (_%__kont3838238383%_
                                         _%$%bad2177021818%_))))))
                        (_%$%loop2176521799%_ _%$%target2176221793%_ '()))))
                   (_%__match3842438425%_
                    (lambda (_%$%e2175921783%_
                             _%$%hd2176021787%_
                             _%$%tl2176121790%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl2176121790%_))
                          (let ((_%__splice3838438385%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl2176121790%_
                                    '0))))
                            (let ((_%$%tl2176421796%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3838438385%_ '1)))
                                  (_%$%target2176221793%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3838438385%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl2176421796%_))
                                  (_%__match3843238433%_
                                   _%$%e2175921783%_
                                   _%$%hd2176021787%_
                                   _%$%tl2176121790%_
                                   _%__splice3838438385%_
                                   _%$%target2176221793%_
                                   _%$%tl2176421796%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2171521776%_)))))
                          (let () (declare (not safe)) (_%$%g2171521776%_)))))
                   (_%__match3841838419%_
                    (lambda (_%$%e2172221844%_
                             _%$%hd2172321848%_
                             _%$%tl2172421851%_
                             _%$%e2172521854%_
                             _%$%hd2172621858%_
                             _%$%tl2172721861%_
                             _%$%e2172821864%_
                             _%$%hd2172921868%_
                             _%$%tl2173021871%_
                             _%$%e2173121874%_
                             _%$%hd2173221878%_
                             _%$%tl2173321881%_
                             _%__splice3837838379%_
                             _%$%target2173421884%_
                             _%$%tl2173621887%_)
                      (letrec ((_%$%loop2173721890%_
                                (lambda (_%$%hd2173521894%_
                                         _%$%input2174121897%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2173521894%_))
                                      (let ((_%$%e2173821899%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2173521894%_))))
                                        (let ((_%$%lp-tl2174021906%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2173821899%_)))
                                              (_%$%lp-hd2173921903%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2173821899%_))))
                                          (_%$%loop2173721890%_
                                           _%$%lp-tl2174021906%_
                                           (cons _%$%lp-hd2173921903%_
                                                 _%$%input2174121897%_))))
                                      (let ((_%$%input2174221909%_
                                             (reverse _%$%input2174121897%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2173321881%_))
                                            (let ((_%$%e2174321912%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2173321881%_))))
                                              (let ((_%$%tl2174521919%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2174321912%_)))
                                                    (_%$%hd2174421916%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2174321912%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2174421916%_))
                                                    (let ((_%$%e2174621922%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2174421916%_))))
                                                      (let ((_%$%tl2174821929%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2174621922%_)))
                    (_%$%hd2174721926%_
                     (let () (declare (not safe)) (##car _%$%e2174621922%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2174821929%_))
                    (let ((_%__splice3838038381%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2174821929%_
                              '0))))
                      (let ((_%$%tl2175121935%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3838038381%_ '1)))
                            (_%$%target2174921932%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3838038381%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2175121935%_))
                            (letrec ((_%$%loop2175221938%_
                                      (lambda (_%$%hd2175021942%_
                                               _%$%term2175621945%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2175021942%_))
                                            (let ((_%$%e2175321947%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2175021942%_))))
                                              (let ((_%$%lp-tl2175521954%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2175321947%_)))
                                                    (_%$%lp-hd2175421951%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2175321947%_))))
                                                (_%$%loop2175221938%_
                                                 _%$%lp-tl2175521954%_
                                                 (cons _%$%lp-hd2175421951%_
                                                       _%$%term2175621945%_))))
                                            (let ((_%$%term2175721957%_
                                                   (reverse _%$%term2175621945%_)))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2174521919%_))
                                                  (let ((_%$%g2171721960%_
                                                         _%$%term2175721957%_)
                                                        (_%$%g2171821962%_
                                                         _%$%hd2174721926%_)
                                                        (_%$%g2171921963%_
                                                         _%$%input2174221909%_)
                                                        (_%$%g2172021964%_
                                                         _%$%hd2172921868%_)
                                                        (_%$%g2172121965%_
                                                         _%$%hd2172621858%_))
                                                    (if (and (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2171821962%_))
                     (let ()
                       (declare (not safe))
                       (gx#identifier? _%$%g2172021964%_)))
                (_%__kont3837638377%_
                 _%$%g2171721960%_
                 _%$%g2171821962%_
                 _%$%g2171921963%_
                 _%$%g2172021964%_
                 _%$%g2172121965%_)
                (_%__match3842438425%_
                 _%$%e2172221844%_
                 _%$%hd2172321848%_
                 _%$%tl2172421851%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3842438425%_
                                                   _%$%e2172221844%_
                                                   _%$%hd2172321848%_
                                                   _%$%tl2172421851%_)))))))
                              (_%$%loop2175221938%_
                               _%$%target2174921932%_
                               '()))
                            (_%__match3842438425%_
                             _%$%e2172221844%_
                             _%$%hd2172321848%_
                             _%$%tl2172421851%_))))
                    (_%__match3842438425%_
                     _%$%e2172221844%_
                     _%$%hd2172321848%_
                     _%$%tl2172421851%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3842438425%_
                                                     _%$%e2172221844%_
                                                     _%$%hd2172321848%_
                                                     _%$%tl2172421851%_))))
                                            (_%__match3842438425%_
                                             _%$%e2172221844%_
                                             _%$%hd2172321848%_
                                             _%$%tl2172421851%_)))))))
                        (_%$%loop2173721890%_ _%$%target2173421884%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3837338374%_))
                  (let ((_%$%e2172221844%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3837338374%_))))
                    (let ((_%$%tl2172421851%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2172221844%_)))
                          (_%$%hd2172321848%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2172221844%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2172421851%_))
                          (let ((_%$%e2172521854%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2172421851%_))))
                            (let ((_%$%tl2172721861%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2172521854%_)))
                                  (_%$%hd2172621858%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2172521854%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2172721861%_))
                                  (let ((_%$%e2172821864%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2172721861%_))))
                                    (let ((_%$%tl2173021871%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2172821864%_)))
                                          (_%$%hd2172921868%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2172821864%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2173021871%_))
                                          (let ((_%$%e2173121874%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2173021871%_))))
                                            (let ((_%$%tl2173321881%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2173121874%_)))
                                                  (_%$%hd2173221878%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2173121874%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%hd2173221878%_))
                                                  (let ((_%__splice3837838379%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%hd2173221878%_
                                                            '0))))
                                                    (let ((_%$%tl2173621887%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3837838379%_
                                                              '1)))
                                                          (_%$%target2173421884%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3837838379%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2173621887%_))
                                                          (_%__match3841838419%_
                                                           _%$%e2172221844%_
                                                           _%$%hd2172321848%_
                                                           _%$%tl2172421851%_
                                                           _%$%e2172521854%_
                                                           _%$%hd2172621858%_
                                                           _%$%tl2172721861%_
                                                           _%$%e2172821864%_
                                                           _%$%hd2172921868%_
                                                           _%$%tl2173021871%_
                                                           _%$%e2173121874%_
                                                           _%$%hd2173221878%_
                                                           _%$%tl2173321881%_
                                                           _%__splice3837838379%_
                                                           _%$%target2173421884%_
                                                           _%$%tl2173621887%_)
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-pair/null? _%$%tl2172421851%_))
                      (let ((_%__splice3838438385%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2172421851%_
                                '0))))
                        (let ((_%$%tl2176421796%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3838438385%_ '1)))
                              (_%$%target2176221793%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3838438385%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2176421796%_))
                              (_%__match3843238433%_
                               _%$%e2172221844%_
                               _%$%hd2172321848%_
                               _%$%tl2172421851%_
                               _%__splice3838438385%_
                               _%$%target2176221793%_
                               _%$%tl2176421796%_)
                              (let ()
                                (declare (not safe))
                                (_%$%g2171521776%_)))))
                      (let () (declare (not safe)) (_%$%g2171521776%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2172421851%_))
                                                      (let ((_%__splice3838438385%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice->vector
                        _%$%tl2172421851%_
                        '0))))
                (let ((_%$%tl2176421796%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3838438385%_ '1)))
                      (_%$%target2176221793%_
                       (let ()
                         (declare (not safe))
                         (##vector-ref _%__splice3838438385%_ '0))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2176421796%_))
                      (_%__match3843238433%_
                       _%$%e2172221844%_
                       _%$%hd2172321848%_
                       _%$%tl2172421851%_
                       _%__splice3838438385%_
                       _%$%target2176221793%_
                       _%$%tl2176421796%_)
                      (let () (declare (not safe)) (_%$%g2171521776%_)))))
              (let () (declare (not safe)) (_%$%g2171521776%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2172421851%_))
                                              (let ((_%__splice3838438385%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice->vector
                                                        _%$%tl2172421851%_
                                                        '0))))
                                                (let ((_%$%tl2176421796%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3838438385%_
                                                          '1)))
                                                      (_%$%target2176221793%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##vector-ref
                                                          _%__splice3838438385%_
                                                          '0))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2176421796%_))
                                                      (_%__match3843238433%_
                                                       _%$%e2172221844%_
                                                       _%$%hd2172321848%_
                                                       _%$%tl2172421851%_
                                                       _%__splice3838438385%_
                                                       _%$%target2176221793%_
                                                       _%$%tl2176421796%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2171521776%_)))))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2171521776%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair/null? _%$%tl2172421851%_))
                                      (let ((_%__splice3838438385%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-split-splice->vector
                                                _%$%tl2172421851%_
                                                '0))))
                                        (let ((_%$%tl2176421796%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3838438385%_
                                                  '1)))
                                              (_%$%target2176221793%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector-ref
                                                  _%__splice3838438385%_
                                                  '0))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2176421796%_))
                                              (_%__match3843238433%_
                                               _%$%e2172221844%_
                                               _%$%hd2172321848%_
                                               _%$%tl2172421851%_
                                               _%__splice3838438385%_
                                               _%$%target2176221793%_
                                               _%$%tl2176421796%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2171521776%_)))))
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2171521776%_))))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2172421851%_))
                              (let ((_%__splice3838438385%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice->vector
                                        _%$%tl2172421851%_
                                        '0))))
                                (let ((_%$%tl2176421796%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3838438385%_
                                          '1)))
                                      (_%$%target2176221793%_
                                       (let ()
                                         (declare (not safe))
                                         (##vector-ref
                                          _%__splice3838438385%_
                                          '0))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2176421796%_))
                                      (_%__match3843238433%_
                                       _%$%e2172221844%_
                                       _%$%hd2172321848%_
                                       _%$%tl2172421851%_
                                       _%__splice3838438385%_
                                       _%$%target2176221793%_
                                       _%$%tl2176421796%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2171521776%_)))))
                              (let ()
                                (declare (not safe))
                                (_%$%g2171521776%_))))))
                  (let () (declare (not safe)) (_%$%g2171521776%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-operator-input|
      (lambda (_%stx22020%_)
        (let* ((_%__stx3843538436%_ _%stx22020%_)
               (_%$%g2202522059%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3843538436%_)))))
          (let ((_%__kont3843838439%_
                 (lambda (_%$%g2202722206%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0
                            '#f
                            'relational-operator-literal))
                         (cons _%$%g2202722206%_ '()))))
                (_%__kont3844038441%_
                 (lambda (_%$%g2204022138%_)
                   (let* ((_%datum22151%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax->datum _%$%g2204022138%_)))
                          (_%spelling22154%_ (symbol->string _%datum22151%_)))
                     (if (if (eq? _%datum22151%_ '?_)
                             '#f
                             (and (> (string-length _%spelling22154%_) '1)
                                  (let ((__tmp39081
                                         (string-ref _%spelling22154%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39081 '#\?))))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0 '#f 'vector))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'quote))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'variable))
                                                 '()))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'quote))
                                                 (cons _%$%g2204022138%_ '()))
                                           '())))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"operator input must be a ?variable or scalar literal"
                            _%$%g2204022138%_))))))
                (_%__kont3844238443%_
                 (lambda (_%$%g2204722086%_)
                   (let ((_%datum22100%_
                          (let ()
                            (declare (not safe))
                            (gx#syntax->datum _%$%g2204722086%_))))
                     (if (or (exact-integer? _%datum22100%_)
                             (boolean? _%datum22100%_)
                             (char? _%datum22100%_))
                         (cons (let ()
                                 (declare (not safe))
                                 (gx#datum->syntax__0
                                  '#f
                                  'relational-operator-literal))
                               (cons _%$%g2204722086%_ '()))
                         (let ()
                           (declare (not safe))
                           (gx#raise-syntax-error
                            '#f
                            '"operator input must be an immutable scalar literal"
                            _%$%g2204722086%_)))))))
            (let ((_%__match3849038491%_
                   (lambda (_%$%e2204122118%_
                            _%$%hd2204222122%_
                            _%$%tl2204322125%_
                            _%$%e2204422128%_
                            _%$%hd2204522132%_
                            _%$%tl2204622135%_)
                     (let ((_%$%g2204022138%_ _%$%hd2204522132%_))
                       (if (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2204022138%_))
                           (_%__kont3844038441%_ _%$%g2204022138%_)
                           (_%__kont3844238443%_ _%$%hd2204522132%_))))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3843538436%_))
                  (let ((_%$%e2202822166%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3843538436%_))))
                    (let ((_%$%tl2203022173%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2202822166%_)))
                          (_%$%hd2202922170%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2202822166%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2203022173%_))
                          (let ((_%$%e2203122176%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2203022173%_))))
                            (let ((_%$%tl2203322183%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2203122176%_)))
                                  (_%$%hd2203222180%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2203122176%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2203222180%_))
                                  (let ((_%$%e2203422186%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2203222180%_))))
                                    (let ((_%$%tl2203622193%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2203422186%_)))
                                          (_%$%hd2203522190%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2203422186%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#identifier?
                                             _%$%hd2203522190%_))
                                          (if (let ((__tmp39082
                                                     |gerbil-ascent/program/scheme-language[1]#_g39083_|))
                                                (declare (not safe))
                                                (gx#free-identifier=?
                                                 __tmp39082
                                                 _%$%hd2203522190%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%tl2203622193%_))
                                                  (let ((_%$%e2203722196%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%tl2203622193%_))))
                                                    (let ((_%$%tl2203922203%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2203722196%_)))
                                                          (_%$%hd2203822200%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2203722196%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2203922203%_))
                                                          (if (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#stx-null? _%$%tl2203322183%_))
                      (_%__kont3843838439%_ _%$%hd2203822200%_)
                      (let () (declare (not safe)) (_%$%g2202522059%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl2203322183%_))
                      (_%__match3849038491%_
                       _%$%e2202822166%_
                       _%$%hd2202922170%_
                       _%$%tl2203022173%_
                       _%$%e2203122176%_
                       _%$%hd2203222180%_
                       _%$%tl2203322183%_)
                      (let () (declare (not safe)) (_%$%g2202522059%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2203322183%_))
                                                      (_%__match3849038491%_
                                                       _%$%e2202822166%_
                                                       _%$%hd2202922170%_
                                                       _%$%tl2203022173%_
                                                       _%$%e2203122176%_
                                                       _%$%hd2203222180%_
                                                       _%$%tl2203322183%_)
                                                      (let ()
                                                        (declare (not safe))
                                                        (_%$%g2202522059%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2203322183%_))
                                                  (_%__match3849038491%_
                                                   _%$%e2202822166%_
                                                   _%$%hd2202922170%_
                                                   _%$%tl2203022173%_
                                                   _%$%e2203122176%_
                                                   _%$%hd2203222180%_
                                                   _%$%tl2203322183%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (_%$%g2202522059%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2203322183%_))
                                              (_%__match3849038491%_
                                               _%$%e2202822166%_
                                               _%$%hd2202922170%_
                                               _%$%tl2203022173%_
                                               _%$%e2203122176%_
                                               _%$%hd2203222180%_
                                               _%$%tl2203322183%_)
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2202522059%_))))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-null? _%$%tl2203322183%_))
                                      (_%__match3849038491%_
                                       _%$%e2202822166%_
                                       _%$%hd2202922170%_
                                       _%$%tl2203022173%_
                                       _%$%e2203122176%_
                                       _%$%hd2203222180%_
                                       _%$%tl2203322183%_)
                                      (let ()
                                        (declare (not safe))
                                        (_%$%g2202522059%_))))))
                          (let () (declare (not safe)) (_%$%g2202522059%_)))))
                  (let () (declare (not safe)) (_%$%g2202522059%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-checked-clause|
      (lambda (_%stx22227%_)
        (letrec ((_%logic-variable?22230%_
                  (lambda (_%input23441%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#identifier? _%input23441%_))
                        (let* ((_%datum23444%_
                                (let ()
                                  (declare (not safe))
                                  (gx#syntax->datum _%input23441%_)))
                               (_%spelling23447%_
                                (symbol->string _%datum23444%_)))
                          (if (eq? _%datum23444%_ '?_)
                              '#f
                              (if (> (string-length _%spelling23447%_) '1)
                                  (let ((__tmp39084
                                         (string-ref _%spelling23447%_ '0)))
                                    (declare (not safe))
                                    (##char=? __tmp39084 '#\?))
                                  '#f)))
                        '#f))))
          (let* ((_%__stx3850738508%_ _%stx22227%_)
                 (_%$%g2223822473%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (gx#raise-syntax-error
                       '#f
                       '"Bad syntax; invalid match target"
                       _%__stx3850738508%_)))))
            (let ((_%__kont3851038511%_
                   (lambda (_%$%g2224023392%_
                            _%$%g2224123394%_
                            _%$%g2224223395%_
                            _%$%g2224323396%_
                            _%$%g2224423397%_)
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-where))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2224123394%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'list))
                                             (let ((__tmp39085
                                                    (lambda (_%$%g2342823431%_
                                                             _%$%g2342923434%_)
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0
                             '#f
                             'relational-operator-input))
                          (cons _%$%g2342823431%_ '()))
                    _%$%g2342923434%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (declare (not safe))
                                               (foldr__0
                                                __tmp39085
                                                '()
                                                _%$%g2224023392%_)))
                                       '())))))
                  (_%__kont3851438515%_
                   (lambda (_%$%g2227823228%_
                            _%$%g2227923230%_
                            _%$%g2228023231%_
                            _%$%g2228123232%_
                            _%$%g2228223233%_
                            _%$%g2228323234%_)
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-compute))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2228023231%_ '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0
                                                '#f
                                                'quote))
                                             (cons _%$%g2227923230%_ '()))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'list))
                                                   (let ((__tmp39086
                                                          (lambda (_%$%g2326823271%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%$%g2326923274%_)
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0
                                   '#f
                                   'relational-operator-input))
                                (cons _%$%g2326823271%_ '()))
                          _%$%g2326923274%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (foldr__0
                                                      __tmp39086
                                                      '()
                                                      _%$%g2227823228%_)))
                                             '()))))))
                  (_%__kont3851838519%_
                   (lambda (_%$%g2232023058%_
                            _%$%g2232123060%_
                            _%$%g2232223061%_
                            _%$%g2232323062%_
                            _%$%g2232423063%_)
                     (cons _%$%g2232323062%_
                           (cons (cons _%$%g2232123060%_
                                       (let ((__tmp39087
                                              (lambda (_%$%g2309423097%_
                                                       _%$%g2309523100%_)
                                                (cons _%$%g2309423097%_
                                                      _%$%g2309523100%_))))
                                         (declare (not safe))
                                         (foldr__0
                                          __tmp39087
                                          '()
                                          _%$%g2232023058%_)))
                                 '()))))
                  (_%__kont3852238523%_
                   (lambda (_%$%g2235822866%_
                            _%$%g2235922868%_
                            _%$%g2236022869%_
                            _%$%g2236122870%_
                            _%$%g2236222871%_
                            _%$%g2236322872%_
                            _%$%g2236422873%_
                            _%$%g2236522874%_)
                     (cons _%$%g2236322872%_
                           (cons _%$%g2236222871%_
                                 (cons _%$%g2236122870%_
                                       (cons (let ((__tmp39088
                                                    (lambda (_%$%g2292622931%_
                                                             _%$%g2292722934%_)
                                                      (cons _%$%g2292622931%_
                                                            _%$%g2292722934%_))))
                                               (declare (not safe))
                                               (foldr__0
                                                __tmp39088
                                                '()
                                                _%$%g2236022869%_))
                                             (cons (cons _%$%g2235922868%_
                                                         (let ((__tmp39089
                                                                (lambda (_%$%g2292822937%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%$%g2292922940%_)
                          (cons _%$%g2292822937%_ _%$%g2292922940%_))))
                   (declare (not safe))
                   (foldr__0 __tmp39089 '() _%$%g2235822866%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   '())))))))
                  (_%__kont3852838529%_
                   (lambda (_%$%g2241722652%_
                            _%$%g2241822654%_
                            _%$%g2241922655%_
                            _%$%g2242022656%_
                            _%$%g2242122657%_)
                     (cons _%$%g2242122657%_
                           (cons (cons _%$%g2241822654%_
                                       (let ((__tmp39090
                                              (lambda (_%$%g2268422687%_
                                                       _%$%g2268522690%_)
                                                (cons _%$%g2268422687%_
                                                      _%$%g2268522690%_))))
                                         (declare (not safe))
                                         (foldr__0
                                          __tmp39090
                                          '()
                                          _%$%g2241722652%_)))
                                 '()))))
                  (_%__kont3853238533%_
                   (lambda (_%$%g2244922530%_
                            _%$%g2245022532%_
                            _%$%g2245122533%_
                            _%$%g2245222534%_)
                     (let ()
                       (declare (not safe))
                       (gx#raise-syntax-error
                        '#f
                        '"expected atom, not, reduce, where, or compute clause"
                        _%$%g2244922530%_)))))
              (let* ((_%__match3883038831%_
                      (lambda (_%$%e2242222564%_
                               _%$%hd2242322568%_
                               _%$%tl2242422571%_
                               _%$%e2242522574%_
                               _%$%hd2242622578%_
                               _%$%tl2242722581%_
                               _%$%e2242822584%_
                               _%$%hd2242922588%_
                               _%$%tl2243022591%_
                               _%$%e2243122594%_
                               _%$%hd2243222598%_
                               _%$%tl2243322601%_
                               _%$%e2243422604%_
                               _%$%hd2243522608%_
                               _%$%tl2243622611%_
                               _%$%e2243722614%_
                               _%$%hd2243822618%_
                               _%$%tl2243922621%_
                               _%__splice3853038531%_
                               _%$%target2244022624%_
                               _%$%tl2244222627%_)
                        (letrec ((_%$%loop2244322630%_
                                  (lambda (_%$%hd2244122634%_
                                           _%$%term2244722637%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2244122634%_))
                                        (let ((_%$%e2244422639%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2244122634%_))))
                                          (let ((_%$%lp-tl2244622646%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2244422639%_)))
                                                (_%$%lp-hd2244522643%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2244422639%_))))
                                            (_%$%loop2244322630%_
                                             _%$%lp-tl2244622646%_
                                             (cons _%$%lp-hd2244522643%_
                                                   _%$%term2244722637%_))))
                                        (let ((_%$%term2244822649%_
                                               (reverse _%$%term2244722637%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2243622611%_))
                                              (let ((_%$%g2241722652%_
                                                     _%$%term2244822649%_)
                                                    (_%$%g2241822654%_
                                                     _%$%hd2243822618%_)
                                                    (_%$%g2241922655%_
                                                     _%$%hd2243222598%_)
                                                    (_%$%g2242022656%_
                                                     _%$%hd2242922588%_)
                                                    (_%$%g2242122657%_
                                                     _%$%hd2242622578%_))
                                                (if (and (let ()
                                                           (declare (not safe))
                                                           (gx#identifier?
                                                            _%$%g2242122657%_))
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#identifier?
                                                            _%$%g2241822654%_))
                                                         (not (let ((__tmp39091
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (let ()
                               (declare (not safe))
                               (gx#syntax->datum _%$%g2241822654%_))))
                        (declare (not safe))
                        (##memq __tmp39091 '(where compute not reduce)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__kont3852838529%_
                                                     _%$%g2241722652%_
                                                     _%$%g2241822654%_
                                                     _%$%g2241922655%_
                                                     _%$%g2242022656%_
                                                     _%$%g2242122657%_)
                                                    (_%__kont3853238533%_
                                                     _%$%hd2243522608%_
                                                     _%$%hd2243222598%_
                                                     _%$%hd2242922588%_
                                                     _%$%hd2242622578%_)))
                                              (let ()
                                                (declare (not safe))
                                                (_%$%g2223822473%_))))))))
                          (_%$%loop2244322630%_ _%$%target2244022624%_ '()))))
                     (_%__match3882238823%_
                      (lambda (_%$%e2242222564%_
                               _%$%hd2242322568%_
                               _%$%tl2242422571%_
                               _%$%e2242522574%_
                               _%$%hd2242622578%_
                               _%$%tl2242722581%_
                               _%$%e2242822584%_
                               _%$%hd2242922588%_
                               _%$%tl2243022591%_
                               _%$%e2243122594%_
                               _%$%hd2243222598%_
                               _%$%tl2243322601%_
                               _%$%e2243422604%_
                               _%$%hd2243522608%_
                               _%$%tl2243622611%_
                               _%$%e2243722614%_
                               _%$%hd2243822618%_
                               _%$%tl2243922621%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2243922621%_))
                            (let ((_%__splice3853038531%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2243922621%_
                                      '0))))
                              (let ((_%$%tl2244222627%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '1)))
                                    (_%$%target2244022624%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2244222627%_))
                                    (_%__match3883038831%_
                                     _%$%e2242222564%_
                                     _%$%hd2242322568%_
                                     _%$%tl2242422571%_
                                     _%$%e2242522574%_
                                     _%$%hd2242622578%_
                                     _%$%tl2242722581%_
                                     _%$%e2242822584%_
                                     _%$%hd2242922588%_
                                     _%$%tl2243022591%_
                                     _%$%e2243122594%_
                                     _%$%hd2243222598%_
                                     _%$%tl2243322601%_
                                     _%$%e2243422604%_
                                     _%$%hd2243522608%_
                                     _%$%tl2243622611%_
                                     _%$%e2243722614%_
                                     _%$%hd2243822618%_
                                     _%$%tl2243922621%_
                                     _%__splice3853038531%_
                                     _%$%target2244022624%_
                                     _%$%tl2244222627%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2243622611%_))
                                        (_%__kont3853238533%_
                                         _%$%hd2243522608%_
                                         _%$%hd2243222598%_
                                         _%$%hd2242922588%_
                                         _%$%hd2242622578%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2223822473%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2243622611%_))
                                (_%__kont3853238533%_
                                 _%$%hd2243522608%_
                                 _%$%hd2243222598%_
                                 _%$%hd2242922588%_
                                 _%$%hd2242622578%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2223822473%_))))))
                     (_%__match3878638787%_
                      (lambda (_%$%e2236622700%_
                               _%$%hd2236722704%_
                               _%$%tl2236822707%_
                               _%$%e2236922710%_
                               _%$%hd2237022714%_
                               _%$%tl2237122717%_
                               _%$%e2237222720%_
                               _%$%hd2237322724%_
                               _%$%tl2237422727%_
                               _%$%e2237522730%_
                               _%$%hd2237622734%_
                               _%$%tl2237722737%_
                               _%$%e2237822740%_
                               _%$%hd2237922744%_
                               _%$%tl2238022747%_
                               _%$%e2238122750%_
                               _%$%hd2238222754%_
                               _%$%tl2238322757%_
                               _%$%e2238422760%_
                               _%$%hd2238522764%_
                               _%$%tl2238622767%_
                               _%$%e2238722770%_
                               _%$%hd2238822774%_
                               _%$%tl2238922777%_
                               _%$%e2239022780%_
                               _%$%hd2239122784%_
                               _%$%tl2239222787%_
                               _%__splice3852438525%_
                               _%$%target2239322790%_
                               _%$%tl2239522793%_)
                        (letrec ((_%$%loop2239622796%_
                                  (lambda (_%$%hd2239422800%_
                                           _%$%input2240022803%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2239422800%_))
                                        (let ((_%$%e2239722805%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2239422800%_))))
                                          (let ((_%$%lp-tl2239922812%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2239722805%_)))
                                                (_%$%lp-hd2239822809%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2239722805%_))))
                                            (_%$%loop2239622796%_
                                             _%$%lp-tl2239922812%_
                                             (cons _%$%lp-hd2239822809%_
                                                   _%$%input2240022803%_))))
                                        (let ((_%$%input2240122815%_
                                               (reverse _%$%input2240022803%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl2238922777%_))
                                              (let ((_%$%e2240222818%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl2238922777%_))))
                                                (let ((_%$%tl2240422825%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2240222818%_)))
                                                      (_%$%hd2240322822%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2240222818%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%hd2240322822%_))
                                                      (let ((_%$%e2240522828%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%hd2240322822%_))))
                (let ((_%$%tl2240722835%_
                       (let () (declare (not safe)) (##cdr _%$%e2240522828%_)))
                      (_%$%hd2240622832%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%e2240522828%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair/null? _%$%tl2240722835%_))
                      (let ((_%__splice3852638527%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice->vector
                                _%$%tl2240722835%_
                                '0))))
                        (let ((_%$%tl2241022841%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3852638527%_ '1)))
                              (_%$%target2240822838%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-ref _%__splice3852638527%_ '0))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl2241022841%_))
                              (letrec ((_%$%loop2241122844%_
                                        (lambda (_%$%hd2240922848%_
                                                 _%$%term2241522851%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd2240922848%_))
                                              (let ((_%$%e2241222853%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd2240922848%_))))
                                                (let ((_%$%lp-tl2241422860%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2241222853%_)))
                                                      (_%$%lp-hd2241322857%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2241222853%_))))
                                                  (_%$%loop2241122844%_
                                                   _%$%lp-tl2241422860%_
                                                   (cons _%$%lp-hd2241322857%_
                                                         _%$%term2241522851%_))))
                                              (let ((_%$%term2241622863%_
                                                     (reverse _%$%term2241522851%_)))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2240422825%_))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2238022747%_))
                                                        (let ((_%$%g2235822866%_
                                                               _%$%term2241622863%_)
                                                              (_%$%g2235922868%_
                                                               _%$%hd2240622832%_)
                                                              (_%$%g2236022869%_
                                                               _%$%input2240122815%_)
                                                              (_%$%g2236122870%_
                                                               _%$%hd2239122784%_)
                                                              (_%$%g2236222871%_
                                                               _%$%hd2238522764%_)
                                                              (_%$%g2236322872%_
                                                               _%$%hd2237622734%_)
                                                              (_%$%g2236422873%_
                                                               _%$%hd2237322724%_)
                                                              (_%$%g2236522874%_
                                                               _%$%hd2237022714%_))
                                                          (if (and (_%logic-variable?22230%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g2236222871%_)
                           (let ()
                             (declare (not safe))
                             (gx#identifier? _%$%g2236122870%_))
                           (let ((__tmp39092
                                  (let ((__tmp39093
                                         (let ((__tmp39094
                                                (lambda (_%$%g2291822921%_
                                                         _%$%g2291922924%_)
                                                  (cons _%$%g2291822921%_
                                                        _%$%g2291922924%_))))
                                           (declare (not safe))
                                           (foldr__0
                                            __tmp39094
                                            '()
                                            _%$%g2236022869%_))))
                                    (declare (not safe))
                                    (gx#syntax->list __tmp39093))))
                             (declare (not safe))
                             (andmap__0 _%logic-variable?22230%_ __tmp39092)))
                      (_%__kont3852238523%_
                       _%$%g2235822866%_
                       _%$%g2235922868%_
                       _%$%g2236022869%_
                       _%$%g2236122870%_
                       _%$%g2236222871%_
                       _%$%g2236322872%_
                       _%$%g2236422873%_
                       _%$%g2236522874%_)
                      (_%__match3882238823%_
                       _%$%e2236622700%_
                       _%$%hd2236722704%_
                       _%$%tl2236822707%_
                       _%$%e2236922710%_
                       _%$%hd2237022714%_
                       _%$%tl2237122717%_
                       _%$%e2237222720%_
                       _%$%hd2237322724%_
                       _%$%tl2237422727%_
                       _%$%e2237522730%_
                       _%$%hd2237622734%_
                       _%$%tl2237722737%_
                       _%$%e2237822740%_
                       _%$%hd2237922744%_
                       _%$%tl2238022747%_
                       _%$%e2238122750%_
                       _%$%hd2238222754%_
                       _%$%tl2238322757%_)))
                (_%__match3882238823%_
                 _%$%e2236622700%_
                 _%$%hd2236722704%_
                 _%$%tl2236822707%_
                 _%$%e2236922710%_
                 _%$%hd2237022714%_
                 _%$%tl2237122717%_
                 _%$%e2237222720%_
                 _%$%hd2237322724%_
                 _%$%tl2237422727%_
                 _%$%e2237522730%_
                 _%$%hd2237622734%_
                 _%$%tl2237722737%_
                 _%$%e2237822740%_
                 _%$%hd2237922744%_
                 _%$%tl2238022747%_
                 _%$%e2238122750%_
                 _%$%hd2238222754%_
                 _%$%tl2238322757%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3882238823%_
                                                     _%$%e2236622700%_
                                                     _%$%hd2236722704%_
                                                     _%$%tl2236822707%_
                                                     _%$%e2236922710%_
                                                     _%$%hd2237022714%_
                                                     _%$%tl2237122717%_
                                                     _%$%e2237222720%_
                                                     _%$%hd2237322724%_
                                                     _%$%tl2237422727%_
                                                     _%$%e2237522730%_
                                                     _%$%hd2237622734%_
                                                     _%$%tl2237722737%_
                                                     _%$%e2237822740%_
                                                     _%$%hd2237922744%_
                                                     _%$%tl2238022747%_
                                                     _%$%e2238122750%_
                                                     _%$%hd2238222754%_
                                                     _%$%tl2238322757%_)))))))
                                (_%$%loop2241122844%_
                                 _%$%target2240822838%_
                                 '()))
                              (_%__match3882238823%_
                               _%$%e2236622700%_
                               _%$%hd2236722704%_
                               _%$%tl2236822707%_
                               _%$%e2236922710%_
                               _%$%hd2237022714%_
                               _%$%tl2237122717%_
                               _%$%e2237222720%_
                               _%$%hd2237322724%_
                               _%$%tl2237422727%_
                               _%$%e2237522730%_
                               _%$%hd2237622734%_
                               _%$%tl2237722737%_
                               _%$%e2237822740%_
                               _%$%hd2237922744%_
                               _%$%tl2238022747%_
                               _%$%e2238122750%_
                               _%$%hd2238222754%_
                               _%$%tl2238322757%_))))
                      (_%__match3882238823%_
                       _%$%e2236622700%_
                       _%$%hd2236722704%_
                       _%$%tl2236822707%_
                       _%$%e2236922710%_
                       _%$%hd2237022714%_
                       _%$%tl2237122717%_
                       _%$%e2237222720%_
                       _%$%hd2237322724%_
                       _%$%tl2237422727%_
                       _%$%e2237522730%_
                       _%$%hd2237622734%_
                       _%$%tl2237722737%_
                       _%$%e2237822740%_
                       _%$%hd2237922744%_
                       _%$%tl2238022747%_
                       _%$%e2238122750%_
                       _%$%hd2238222754%_
                       _%$%tl2238322757%_))))
              (_%__match3882238823%_
               _%$%e2236622700%_
               _%$%hd2236722704%_
               _%$%tl2236822707%_
               _%$%e2236922710%_
               _%$%hd2237022714%_
               _%$%tl2237122717%_
               _%$%e2237222720%_
               _%$%hd2237322724%_
               _%$%tl2237422727%_
               _%$%e2237522730%_
               _%$%hd2237622734%_
               _%$%tl2237722737%_
               _%$%e2237822740%_
               _%$%hd2237922744%_
               _%$%tl2238022747%_
               _%$%e2238122750%_
               _%$%hd2238222754%_
               _%$%tl2238322757%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%__match3882238823%_
                                               _%$%e2236622700%_
                                               _%$%hd2236722704%_
                                               _%$%tl2236822707%_
                                               _%$%e2236922710%_
                                               _%$%hd2237022714%_
                                               _%$%tl2237122717%_
                                               _%$%e2237222720%_
                                               _%$%hd2237322724%_
                                               _%$%tl2237422727%_
                                               _%$%e2237522730%_
                                               _%$%hd2237622734%_
                                               _%$%tl2237722737%_
                                               _%$%e2237822740%_
                                               _%$%hd2237922744%_
                                               _%$%tl2238022747%_
                                               _%$%e2238122750%_
                                               _%$%hd2238222754%_
                                               _%$%tl2238322757%_)))))))
                          (_%$%loop2239622796%_ _%$%target2239322790%_ '()))))
                     (_%__match3872038721%_
                      (lambda (_%$%e2232522950%_
                               _%$%hd2232622954%_
                               _%$%tl2232722957%_
                               _%$%e2232822960%_
                               _%$%hd2232922964%_
                               _%$%tl2233022967%_
                               _%$%e2233122970%_
                               _%$%hd2233222974%_
                               _%$%tl2233322977%_
                               _%$%e2233422980%_
                               _%$%hd2233522984%_
                               _%$%tl2233622987%_
                               _%$%e2233722990%_
                               _%$%hd2233822994%_
                               _%$%tl2233922997%_
                               _%$%e2234023000%_
                               _%$%hd2234123004%_
                               _%$%tl2234223007%_
                               _%$%e2234323010%_
                               _%$%hd2234423014%_
                               _%$%tl2234523017%_
                               _%$%e2234623020%_
                               _%$%hd2234723024%_
                               _%$%tl2234823027%_
                               _%__splice3852038521%_
                               _%$%target2234923030%_
                               _%$%tl2235123033%_)
                        (letrec ((_%$%loop2235223036%_
                                  (lambda (_%$%hd2235023040%_
                                           _%$%term2235623043%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2235023040%_))
                                        (let ((_%$%e2235323045%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2235023040%_))))
                                          (let ((_%$%lp-tl2235523052%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2235323045%_)))
                                                (_%$%lp-hd2235423049%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2235323045%_))))
                                            (_%$%loop2235223036%_
                                             _%$%lp-tl2235523052%_
                                             (cons _%$%lp-hd2235423049%_
                                                   _%$%term2235623043%_))))
                                        (let ((_%$%term2235723055%_
                                               (reverse _%$%term2235623043%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2234523017%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2233922997%_))
                                                  (_%__kont3851838519%_
                                                   _%$%term2235723055%_
                                                   _%$%hd2234723024%_
                                                   _%$%hd2233522984%_
                                                   _%$%hd2233222974%_
                                                   _%$%hd2232922964%_)
                                                  (_%__match3882238823%_
                                                   _%$%e2232522950%_
                                                   _%$%hd2232622954%_
                                                   _%$%tl2232722957%_
                                                   _%$%e2232822960%_
                                                   _%$%hd2232922964%_
                                                   _%$%tl2233022967%_
                                                   _%$%e2233122970%_
                                                   _%$%hd2233222974%_
                                                   _%$%tl2233322977%_
                                                   _%$%e2233422980%_
                                                   _%$%hd2233522984%_
                                                   _%$%tl2233622987%_
                                                   _%$%e2233722990%_
                                                   _%$%hd2233822994%_
                                                   _%$%tl2233922997%_
                                                   _%$%e2234023000%_
                                                   _%$%hd2234123004%_
                                                   _%$%tl2234223007%_))
                                              (_%__match3882238823%_
                                               _%$%e2232522950%_
                                               _%$%hd2232622954%_
                                               _%$%tl2232722957%_
                                               _%$%e2232822960%_
                                               _%$%hd2232922964%_
                                               _%$%tl2233022967%_
                                               _%$%e2233122970%_
                                               _%$%hd2233222974%_
                                               _%$%tl2233322977%_
                                               _%$%e2233422980%_
                                               _%$%hd2233522984%_
                                               _%$%tl2233622987%_
                                               _%$%e2233722990%_
                                               _%$%hd2233822994%_
                                               _%$%tl2233922997%_
                                               _%$%e2234023000%_
                                               _%$%hd2234123004%_
                                               _%$%tl2234223007%_)))))))
                          (_%$%loop2235223036%_ _%$%target2234923030%_ '()))))
                     (_%__match3866038661%_
                      (lambda (_%$%e2228423110%_
                               _%$%hd2228523114%_
                               _%$%tl2228623117%_
                               _%$%e2228723120%_
                               _%$%hd2228823124%_
                               _%$%tl2228923127%_
                               _%$%e2229023130%_
                               _%$%hd2229123134%_
                               _%$%tl2229223137%_
                               _%$%e2229323140%_
                               _%$%hd2229423144%_
                               _%$%tl2229523147%_
                               _%$%e2229623150%_
                               _%$%hd2229723154%_
                               _%$%tl2229823157%_
                               _%$%e2229923160%_
                               _%$%hd2230023164%_
                               _%$%tl2230123167%_
                               _%$%e2230223170%_
                               _%$%hd2230323174%_
                               _%$%tl2230423177%_
                               _%$%e2230523180%_
                               _%$%hd2230623184%_
                               _%$%tl2230723187%_
                               _%$%e2230823190%_
                               _%$%hd2230923194%_
                               _%$%tl2231023197%_
                               _%__splice3851638517%_
                               _%$%target2231123200%_
                               _%$%tl2231323203%_)
                        (letrec ((_%$%loop2231423206%_
                                  (lambda (_%$%hd2231223210%_
                                           _%$%input2231823213%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2231223210%_))
                                        (let ((_%$%e2231523215%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2231223210%_))))
                                          (let ((_%$%lp-tl2231723222%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2231523215%_)))
                                                (_%$%lp-hd2231623219%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2231523215%_))))
                                            (_%$%loop2231423206%_
                                             _%$%lp-tl2231723222%_
                                             (cons _%$%lp-hd2231623219%_
                                                   _%$%input2231823213%_))))
                                        (let ((_%$%input2231923225%_
                                               (reverse _%$%input2231823213%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2230723187%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2229823157%_))
                                                  (let ((_%$%g2227823228%_
                                                         _%$%input2231923225%_)
                                                        (_%$%g2227923230%_
                                                         _%$%hd2230923194%_)
                                                        (_%$%g2228023231%_
                                                         _%$%hd2230323174%_)
                                                        (_%$%g2228123232%_
                                                         _%$%hd2229423144%_)
                                                        (_%$%g2228223233%_
                                                         _%$%hd2229123134%_)
                                                        (_%$%g2228323234%_
                                                         _%$%hd2228823124%_))
                                                    (if (and (_%logic-variable?22230%_
                                                              _%$%g2228023231%_)
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#identifier? _%$%g2227923230%_)))
                (_%__kont3851438515%_
                 _%$%g2227823228%_
                 _%$%g2227923230%_
                 _%$%g2228023231%_
                 _%$%g2228123232%_
                 _%$%g2228223233%_
                 _%$%g2228323234%_)
                (_%__match3882238823%_
                 _%$%e2228423110%_
                 _%$%hd2228523114%_
                 _%$%tl2228623117%_
                 _%$%e2228723120%_
                 _%$%hd2228823124%_
                 _%$%tl2228923127%_
                 _%$%e2229023130%_
                 _%$%hd2229123134%_
                 _%$%tl2229223137%_
                 _%$%e2229323140%_
                 _%$%hd2229423144%_
                 _%$%tl2229523147%_
                 _%$%e2229623150%_
                 _%$%hd2229723154%_
                 _%$%tl2229823157%_
                 _%$%e2229923160%_
                 _%$%hd2230023164%_
                 _%$%tl2230123167%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3882238823%_
                                                   _%$%e2228423110%_
                                                   _%$%hd2228523114%_
                                                   _%$%tl2228623117%_
                                                   _%$%e2228723120%_
                                                   _%$%hd2228823124%_
                                                   _%$%tl2228923127%_
                                                   _%$%e2229023130%_
                                                   _%$%hd2229123134%_
                                                   _%$%tl2229223137%_
                                                   _%$%e2229323140%_
                                                   _%$%hd2229423144%_
                                                   _%$%tl2229523147%_
                                                   _%$%e2229623150%_
                                                   _%$%hd2229723154%_
                                                   _%$%tl2229823157%_
                                                   _%$%e2229923160%_
                                                   _%$%hd2230023164%_
                                                   _%$%tl2230123167%_))
                                              (_%__match3882238823%_
                                               _%$%e2228423110%_
                                               _%$%hd2228523114%_
                                               _%$%tl2228623117%_
                                               _%$%e2228723120%_
                                               _%$%hd2228823124%_
                                               _%$%tl2228923127%_
                                               _%$%e2229023130%_
                                               _%$%hd2229123134%_
                                               _%$%tl2229223137%_
                                               _%$%e2229323140%_
                                               _%$%hd2229423144%_
                                               _%$%tl2229523147%_
                                               _%$%e2229623150%_
                                               _%$%hd2229723154%_
                                               _%$%tl2229823157%_
                                               _%$%e2229923160%_
                                               _%$%hd2230023164%_
                                               _%$%tl2230123167%_)))))))
                          (_%$%loop2231423206%_ _%$%target2231123200%_ '()))))
                     (_%__match3859438595%_
                      (lambda (_%$%e2224523284%_
                               _%$%hd2224623288%_
                               _%$%tl2224723291%_
                               _%$%e2224823294%_
                               _%$%hd2224923298%_
                               _%$%tl2225023301%_
                               _%$%e2225123304%_
                               _%$%hd2225223308%_
                               _%$%tl2225323311%_
                               _%$%e2225423314%_
                               _%$%hd2225523318%_
                               _%$%tl2225623321%_
                               _%$%e2225723324%_
                               _%$%hd2225823328%_
                               _%$%tl2225923331%_
                               _%$%e2226023334%_
                               _%$%hd2226123338%_
                               _%$%tl2226223341%_
                               _%$%e2226323344%_
                               _%$%hd2226423348%_
                               _%$%tl2226523351%_
                               _%$%e2226623354%_
                               _%$%hd2226723358%_
                               _%$%tl2226823361%_
                               _%__splice3851238513%_
                               _%$%target2226923364%_
                               _%$%tl2227123367%_)
                        (letrec ((_%$%loop2227223370%_
                                  (lambda (_%$%hd2227023374%_
                                           _%$%input2227623377%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2227023374%_))
                                        (let ((_%$%e2227323379%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2227023374%_))))
                                          (let ((_%$%lp-tl2227523386%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2227323379%_)))
                                                (_%$%lp-hd2227423383%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2227323379%_))))
                                            (_%$%loop2227223370%_
                                             _%$%lp-tl2227523386%_
                                             (cons _%$%lp-hd2227423383%_
                                                   _%$%input2227623377%_))))
                                        (let ((_%$%input2227723389%_
                                               (reverse _%$%input2227623377%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-null?
                                                 _%$%tl2226523351%_))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2225923331%_))
                                                  (let ((_%$%g2224023392%_
                                                         _%$%input2227723389%_)
                                                        (_%$%g2224123394%_
                                                         _%$%hd2226723358%_)
                                                        (_%$%g2224223395%_
                                                         _%$%hd2225523318%_)
                                                        (_%$%g2224323396%_
                                                         _%$%hd2225223308%_)
                                                        (_%$%g2224423397%_
                                                         _%$%hd2224923298%_))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#identifier?
                                                           _%$%g2224123394%_))
                                                        (_%__kont3851038511%_
                                                         _%$%g2224023392%_
                                                         _%$%g2224123394%_
                                                         _%$%g2224223395%_
                                                         _%$%g2224323396%_
                                                         _%$%g2224423397%_)
                                                        (_%__match3882238823%_
                                                         _%$%e2224523284%_
                                                         _%$%hd2224623288%_
                                                         _%$%tl2224723291%_
                                                         _%$%e2224823294%_
                                                         _%$%hd2224923298%_
                                                         _%$%tl2225023301%_
                                                         _%$%e2225123304%_
                                                         _%$%hd2225223308%_
                                                         _%$%tl2225323311%_
                                                         _%$%e2225423314%_
                                                         _%$%hd2225523318%_
                                                         _%$%tl2225623321%_
                                                         _%$%e2225723324%_
                                                         _%$%hd2225823328%_
                                                         _%$%tl2225923331%_
                                                         _%$%e2226023334%_
                                                         _%$%hd2226123338%_
                                                         _%$%tl2226223341%_)))
                                                  (_%__match3882238823%_
                                                   _%$%e2224523284%_
                                                   _%$%hd2224623288%_
                                                   _%$%tl2224723291%_
                                                   _%$%e2224823294%_
                                                   _%$%hd2224923298%_
                                                   _%$%tl2225023301%_
                                                   _%$%e2225123304%_
                                                   _%$%hd2225223308%_
                                                   _%$%tl2225323311%_
                                                   _%$%e2225423314%_
                                                   _%$%hd2225523318%_
                                                   _%$%tl2225623321%_
                                                   _%$%e2225723324%_
                                                   _%$%hd2225823328%_
                                                   _%$%tl2225923331%_
                                                   _%$%e2226023334%_
                                                   _%$%hd2226123338%_
                                                   _%$%tl2226223341%_))
                                              (_%__match3882238823%_
                                               _%$%e2224523284%_
                                               _%$%hd2224623288%_
                                               _%$%tl2224723291%_
                                               _%$%e2224823294%_
                                               _%$%hd2224923298%_
                                               _%$%tl2225023301%_
                                               _%$%e2225123304%_
                                               _%$%hd2225223308%_
                                               _%$%tl2225323311%_
                                               _%$%e2225423314%_
                                               _%$%hd2225523318%_
                                               _%$%tl2225623321%_
                                               _%$%e2225723324%_
                                               _%$%hd2225823328%_
                                               _%$%tl2225923331%_
                                               _%$%e2226023334%_
                                               _%$%hd2226123338%_
                                               _%$%tl2226223341%_)))))))
                          (_%$%loop2227223370%_ _%$%target2226923364%_ '())))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%__stx3850738508%_))
                    (let ((_%$%e2224523284%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%__stx3850738508%_))))
                      (let ((_%$%tl2224723291%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2224523284%_)))
                            (_%$%hd2224623288%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2224523284%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%tl2224723291%_))
                            (let ((_%$%e2224823294%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%tl2224723291%_))))
                              (let ((_%$%tl2225023301%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e2224823294%_)))
                                    (_%$%hd2224923298%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e2224823294%_))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl2225023301%_))
                                    (let ((_%$%e2225123304%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%tl2225023301%_))))
                                      (let ((_%$%tl2225323311%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2225123304%_)))
                                            (_%$%hd2225223308%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2225123304%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2225323311%_))
                                            (let ((_%$%e2225423314%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2225323311%_))))
                                              (let ((_%$%tl2225623321%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2225423314%_)))
                                                    (_%$%hd2225523318%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2225423314%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%tl2225623321%_))
                                                    (let ((_%$%e2225723324%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%tl2225623321%_))))
                                                      (let ((_%$%tl2225923331%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2225723324%_)))
                    (_%$%hd2225823328%_
                     (let () (declare (not safe)) (##car _%$%e2225723324%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair? _%$%hd2225823328%_))
                    (let ((_%$%e2226023334%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2225823328%_))))
                      (let ((_%$%tl2226223341%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2226023334%_)))
                            (_%$%hd2226123338%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2226023334%_))))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%hd2226123338%_))
                            (if (let ((__tmp39095
                                       |gerbil-ascent/program/scheme-language[1]#_g39096_|))
                                  (declare (not safe))
                                  (gx#free-identifier=?
                                   __tmp39095
                                   _%$%hd2226123338%_))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%tl2226223341%_))
                                    (let ((_%$%e2226323344%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%tl2226223341%_))))
                                      (let ((_%$%tl2226523351%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2226323344%_)))
                                            (_%$%hd2226423348%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2226323344%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%hd2226423348%_))
                                            (let ((_%$%e2226623354%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%hd2226423348%_))))
                                              (let ((_%$%tl2226823361%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2226623354%_)))
                                                    (_%$%hd2226723358%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2226623354%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2226823361%_))
                                                    (let ((_%__splice3851238513%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2226823361%_
                                                              '0))))
                                                      (let ((_%$%tl2227123367%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3851238513%_ '1)))
                    (_%$%target2226923364%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3851238513%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2227123367%_))
                    (_%__match3859438595%_
                     _%$%e2224523284%_
                     _%$%hd2224623288%_
                     _%$%tl2224723291%_
                     _%$%e2224823294%_
                     _%$%hd2224923298%_
                     _%$%tl2225023301%_
                     _%$%e2225123304%_
                     _%$%hd2225223308%_
                     _%$%tl2225323311%_
                     _%$%e2225423314%_
                     _%$%hd2225523318%_
                     _%$%tl2225623321%_
                     _%$%e2225723324%_
                     _%$%hd2225823328%_
                     _%$%tl2225923331%_
                     _%$%e2226023334%_
                     _%$%hd2226123338%_
                     _%$%tl2226223341%_
                     _%$%e2226323344%_
                     _%$%hd2226423348%_
                     _%$%tl2226523351%_
                     _%$%e2226623354%_
                     _%$%hd2226723358%_
                     _%$%tl2226823361%_
                     _%__splice3851238513%_
                     _%$%target2226923364%_
                     _%$%tl2227123367%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2226223341%_))
                        (let ((_%__splice3853038531%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2226223341%_
                                  '0))))
                          (let ((_%$%tl2244222627%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3853038531%_ '1)))
                                (_%$%target2244022624%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3853038531%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2244222627%_))
                                (_%__match3883038831%_
                                 _%$%e2224523284%_
                                 _%$%hd2224623288%_
                                 _%$%tl2224723291%_
                                 _%$%e2224823294%_
                                 _%$%hd2224923298%_
                                 _%$%tl2225023301%_
                                 _%$%e2225123304%_
                                 _%$%hd2225223308%_
                                 _%$%tl2225323311%_
                                 _%$%e2225423314%_
                                 _%$%hd2225523318%_
                                 _%$%tl2225623321%_
                                 _%$%e2225723324%_
                                 _%$%hd2225823328%_
                                 _%$%tl2225923331%_
                                 _%$%e2226023334%_
                                 _%$%hd2226123338%_
                                 _%$%tl2226223341%_
                                 _%__splice3853038531%_
                                 _%$%target2244022624%_
                                 _%$%tl2244222627%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2225923331%_))
                                    (_%__kont3853238533%_
                                     _%$%hd2225823328%_
                                     _%$%hd2225523318%_
                                     _%$%hd2225223308%_
                                     _%$%hd2224923298%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2223822473%_))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2225923331%_))
                            (_%__kont3853238533%_
                             _%$%hd2225823328%_
                             _%$%hd2225523318%_
                             _%$%hd2225223308%_
                             _%$%hd2224923298%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%tl2226223341%_))
                                                        (let ((_%__splice3853038531%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice->vector
                          _%$%tl2226223341%_
                          '0))))
                  (let ((_%$%tl2244222627%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3853038531%_ '1)))
                        (_%$%target2244022624%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3853038531%_ '0))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2244222627%_))
                        (_%__match3883038831%_
                         _%$%e2224523284%_
                         _%$%hd2224623288%_
                         _%$%tl2224723291%_
                         _%$%e2224823294%_
                         _%$%hd2224923298%_
                         _%$%tl2225023301%_
                         _%$%e2225123304%_
                         _%$%hd2225223308%_
                         _%$%tl2225323311%_
                         _%$%e2225423314%_
                         _%$%hd2225523318%_
                         _%$%tl2225623321%_
                         _%$%e2225723324%_
                         _%$%hd2225823328%_
                         _%$%tl2225923331%_
                         _%$%e2226023334%_
                         _%$%hd2226123338%_
                         _%$%tl2226223341%_
                         _%__splice3853038531%_
                         _%$%target2244022624%_
                         _%$%tl2244222627%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2225923331%_))
                            (_%__kont3853238533%_
                             _%$%hd2225823328%_
                             _%$%hd2225523318%_
                             _%$%hd2225223308%_
                             _%$%hd2224923298%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2223822473%_))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2225923331%_))
                    (_%__kont3853238533%_
                     _%$%hd2225823328%_
                     _%$%hd2225523318%_
                     _%$%hd2225223308%_
                     _%$%hd2224923298%_)
                    (let () (declare (not safe)) (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2226223341%_))
                                                (let ((_%__splice3853038531%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2226223341%_
                                                          '0))))
                                                  (let ((_%$%tl2244222627%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '1)))
                                                        (_%$%target2244022624%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2244222627%_))
                                                        (_%__match3883038831%_
                                                         _%$%e2224523284%_
                                                         _%$%hd2224623288%_
                                                         _%$%tl2224723291%_
                                                         _%$%e2224823294%_
                                                         _%$%hd2224923298%_
                                                         _%$%tl2225023301%_
                                                         _%$%e2225123304%_
                                                         _%$%hd2225223308%_
                                                         _%$%tl2225323311%_
                                                         _%$%e2225423314%_
                                                         _%$%hd2225523318%_
                                                         _%$%tl2225623321%_
                                                         _%$%e2225723324%_
                                                         _%$%hd2225823328%_
                                                         _%$%tl2225923331%_
                                                         _%$%e2226023334%_
                                                         _%$%hd2226123338%_
                                                         _%$%tl2226223341%_
                                                         _%__splice3853038531%_
                                                         _%$%target2244022624%_
                                                         _%$%tl2244222627%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2225923331%_))
                                                            (_%__kont3853238533%_
                                                             _%$%hd2225823328%_
                                                             _%$%hd2225523318%_
                                                             _%$%hd2225223308%_
                                                             _%$%hd2224923298%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2223822473%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2225923331%_))
                                                    (_%__kont3853238533%_
                                                     _%$%hd2225823328%_
                                                     _%$%hd2225523318%_
                                                     _%$%hd2225223308%_
                                                     _%$%hd2224923298%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2223822473%_)))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%tl2226223341%_))
                                        (let ((_%__splice3853038531%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice->vector
                                                  _%$%tl2226223341%_
                                                  '0))))
                                          (let ((_%$%tl2244222627%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##vector-ref
                                                    _%__splice3853038531%_
                                                    '1)))
                                                (_%$%target2244022624%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##vector-ref
                                                    _%__splice3853038531%_
                                                    '0))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2244222627%_))
                                                (_%__match3883038831%_
                                                 _%$%e2224523284%_
                                                 _%$%hd2224623288%_
                                                 _%$%tl2224723291%_
                                                 _%$%e2224823294%_
                                                 _%$%hd2224923298%_
                                                 _%$%tl2225023301%_
                                                 _%$%e2225123304%_
                                                 _%$%hd2225223308%_
                                                 _%$%tl2225323311%_
                                                 _%$%e2225423314%_
                                                 _%$%hd2225523318%_
                                                 _%$%tl2225623321%_
                                                 _%$%e2225723324%_
                                                 _%$%hd2225823328%_
                                                 _%$%tl2225923331%_
                                                 _%$%e2226023334%_
                                                 _%$%hd2226123338%_
                                                 _%$%tl2226223341%_
                                                 _%__splice3853038531%_
                                                 _%$%target2244022624%_
                                                 _%$%tl2244222627%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2225923331%_))
                                                    (_%__kont3853238533%_
                                                     _%$%hd2225823328%_
                                                     _%$%hd2225523318%_
                                                     _%$%hd2225223308%_
                                                     _%$%hd2224923298%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2223822473%_))))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2225923331%_))
                                            (_%__kont3853238533%_
                                             _%$%hd2225823328%_
                                             _%$%hd2225523318%_
                                             _%$%hd2225223308%_
                                             _%$%hd2224923298%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2223822473%_)))))
                                (if (let ((__tmp39097
                                           |gerbil-ascent/program/scheme-language[1]#_g39098_|))
                                      (declare (not safe))
                                      (gx#free-identifier=?
                                       __tmp39097
                                       _%$%hd2226123338%_))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl2226223341%_))
                                        (let ((_%$%e2230223170%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl2226223341%_))))
                                          (let ((_%$%tl2230423177%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2230223170%_)))
                                                (_%$%hd2230323174%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2230223170%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2230423177%_))
                                                (let ((_%$%e2230523180%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2230423177%_))))
                                                  (let ((_%$%tl2230723187%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2230523180%_)))
                                                        (_%$%hd2230623184%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2230523180%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2230623184%_))
                                                        (let ((_%$%e2230823190%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2230623184%_))))
                  (let ((_%$%tl2231023197%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2230823190%_)))
                        (_%$%hd2230923194%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2230823190%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2231023197%_))
                        (let ((_%__splice3851638517%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2231023197%_
                                  '0))))
                          (let ((_%$%tl2231323203%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3851638517%_ '1)))
                                (_%$%target2231123200%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3851638517%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2231323203%_))
                                (_%__match3866038661%_
                                 _%$%e2224523284%_
                                 _%$%hd2224623288%_
                                 _%$%tl2224723291%_
                                 _%$%e2224823294%_
                                 _%$%hd2224923298%_
                                 _%$%tl2225023301%_
                                 _%$%e2225123304%_
                                 _%$%hd2225223308%_
                                 _%$%tl2225323311%_
                                 _%$%e2225423314%_
                                 _%$%hd2225523318%_
                                 _%$%tl2225623321%_
                                 _%$%e2225723324%_
                                 _%$%hd2225823328%_
                                 _%$%tl2225923331%_
                                 _%$%e2226023334%_
                                 _%$%hd2226123338%_
                                 _%$%tl2226223341%_
                                 _%$%e2230223170%_
                                 _%$%hd2230323174%_
                                 _%$%tl2230423177%_
                                 _%$%e2230523180%_
                                 _%$%hd2230623184%_
                                 _%$%tl2230723187%_
                                 _%$%e2230823190%_
                                 _%$%hd2230923194%_
                                 _%$%tl2231023197%_
                                 _%__splice3851638517%_
                                 _%$%target2231123200%_
                                 _%$%tl2231323203%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2226223341%_))
                                    (let ((_%__splice3853038531%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2226223341%_
                                              '0))))
                                      (let ((_%$%tl2244222627%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3853038531%_
                                                '1)))
                                            (_%$%target2244022624%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3853038531%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2244222627%_))
                                            (_%__match3883038831%_
                                             _%$%e2224523284%_
                                             _%$%hd2224623288%_
                                             _%$%tl2224723291%_
                                             _%$%e2224823294%_
                                             _%$%hd2224923298%_
                                             _%$%tl2225023301%_
                                             _%$%e2225123304%_
                                             _%$%hd2225223308%_
                                             _%$%tl2225323311%_
                                             _%$%e2225423314%_
                                             _%$%hd2225523318%_
                                             _%$%tl2225623321%_
                                             _%$%e2225723324%_
                                             _%$%hd2225823328%_
                                             _%$%tl2225923331%_
                                             _%$%e2226023334%_
                                             _%$%hd2226123338%_
                                             _%$%tl2226223341%_
                                             _%__splice3853038531%_
                                             _%$%target2244022624%_
                                             _%$%tl2244222627%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2225923331%_))
                                                (_%__kont3853238533%_
                                                 _%$%hd2225823328%_
                                                 _%$%hd2225523318%_
                                                 _%$%hd2225223308%_
                                                 _%$%hd2224923298%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2223822473%_))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2225923331%_))
                                        (_%__kont3853238533%_
                                         _%$%hd2225823328%_
                                         _%$%hd2225523318%_
                                         _%$%hd2225223308%_
                                         _%$%hd2224923298%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2223822473%_)))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2226223341%_))
                            (let ((_%__splice3853038531%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2226223341%_
                                      '0))))
                              (let ((_%$%tl2244222627%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '1)))
                                    (_%$%target2244022624%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2244222627%_))
                                    (_%__match3883038831%_
                                     _%$%e2224523284%_
                                     _%$%hd2224623288%_
                                     _%$%tl2224723291%_
                                     _%$%e2224823294%_
                                     _%$%hd2224923298%_
                                     _%$%tl2225023301%_
                                     _%$%e2225123304%_
                                     _%$%hd2225223308%_
                                     _%$%tl2225323311%_
                                     _%$%e2225423314%_
                                     _%$%hd2225523318%_
                                     _%$%tl2225623321%_
                                     _%$%e2225723324%_
                                     _%$%hd2225823328%_
                                     _%$%tl2225923331%_
                                     _%$%e2226023334%_
                                     _%$%hd2226123338%_
                                     _%$%tl2226223341%_
                                     _%__splice3853038531%_
                                     _%$%target2244022624%_
                                     _%$%tl2244222627%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2225923331%_))
                                        (_%__kont3853238533%_
                                         _%$%hd2225823328%_
                                         _%$%hd2225523318%_
                                         _%$%hd2225223308%_
                                         _%$%hd2224923298%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2223822473%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2225923331%_))
                                (_%__kont3853238533%_
                                 _%$%hd2225823328%_
                                 _%$%hd2225523318%_
                                 _%$%hd2225223308%_
                                 _%$%hd2224923298%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2223822473%_)))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2226223341%_))
                    (let ((_%__splice3853038531%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2226223341%_
                              '0))))
                      (let ((_%$%tl2244222627%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3853038531%_ '1)))
                            (_%$%target2244022624%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3853038531%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2244222627%_))
                            (_%__match3883038831%_
                             _%$%e2224523284%_
                             _%$%hd2224623288%_
                             _%$%tl2224723291%_
                             _%$%e2224823294%_
                             _%$%hd2224923298%_
                             _%$%tl2225023301%_
                             _%$%e2225123304%_
                             _%$%hd2225223308%_
                             _%$%tl2225323311%_
                             _%$%e2225423314%_
                             _%$%hd2225523318%_
                             _%$%tl2225623321%_
                             _%$%e2225723324%_
                             _%$%hd2225823328%_
                             _%$%tl2225923331%_
                             _%$%e2226023334%_
                             _%$%hd2226123338%_
                             _%$%tl2226223341%_
                             _%__splice3853038531%_
                             _%$%target2244022624%_
                             _%$%tl2244222627%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2225923331%_))
                                (_%__kont3853238533%_
                                 _%$%hd2225823328%_
                                 _%$%hd2225523318%_
                                 _%$%hd2225223308%_
                                 _%$%hd2224923298%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2223822473%_))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2225923331%_))
                        (_%__kont3853238533%_
                         _%$%hd2225823328%_
                         _%$%hd2225523318%_
                         _%$%hd2225223308%_
                         _%$%hd2224923298%_)
                        (let () (declare (not safe)) (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2226223341%_))
                                                    (let ((_%__splice3853038531%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2226223341%_
                                                              '0))))
                                                      (let ((_%$%tl2244222627%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3853038531%_ '1)))
                    (_%$%target2244022624%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3853038531%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2244222627%_))
                    (_%__match3883038831%_
                     _%$%e2224523284%_
                     _%$%hd2224623288%_
                     _%$%tl2224723291%_
                     _%$%e2224823294%_
                     _%$%hd2224923298%_
                     _%$%tl2225023301%_
                     _%$%e2225123304%_
                     _%$%hd2225223308%_
                     _%$%tl2225323311%_
                     _%$%e2225423314%_
                     _%$%hd2225523318%_
                     _%$%tl2225623321%_
                     _%$%e2225723324%_
                     _%$%hd2225823328%_
                     _%$%tl2225923331%_
                     _%$%e2226023334%_
                     _%$%hd2226123338%_
                     _%$%tl2226223341%_
                     _%__splice3853038531%_
                     _%$%target2244022624%_
                     _%$%tl2244222627%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2225923331%_))
                        (_%__kont3853238533%_
                         _%$%hd2225823328%_
                         _%$%hd2225523318%_
                         _%$%hd2225223308%_
                         _%$%hd2224923298%_)
                        (let () (declare (not safe)) (_%$%g2223822473%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2225923331%_))
                                                        (_%__kont3853238533%_
                                                         _%$%hd2225823328%_
                                                         _%$%hd2225523318%_
                                                         _%$%hd2225223308%_
                                                         _%$%hd2224923298%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2223822473%_)))))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2226223341%_))
                                            (let ((_%__splice3853038531%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2226223341%_
                                                      '0))))
                                              (let ((_%$%tl2244222627%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3853038531%_
                                                        '1)))
                                                    (_%$%target2244022624%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3853038531%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2244222627%_))
                                                    (_%__match3883038831%_
                                                     _%$%e2224523284%_
                                                     _%$%hd2224623288%_
                                                     _%$%tl2224723291%_
                                                     _%$%e2224823294%_
                                                     _%$%hd2224923298%_
                                                     _%$%tl2225023301%_
                                                     _%$%e2225123304%_
                                                     _%$%hd2225223308%_
                                                     _%$%tl2225323311%_
                                                     _%$%e2225423314%_
                                                     _%$%hd2225523318%_
                                                     _%$%tl2225623321%_
                                                     _%$%e2225723324%_
                                                     _%$%hd2225823328%_
                                                     _%$%tl2225923331%_
                                                     _%$%e2226023334%_
                                                     _%$%hd2226123338%_
                                                     _%$%tl2226223341%_
                                                     _%__splice3853038531%_
                                                     _%$%target2244022624%_
                                                     _%$%tl2244222627%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2225923331%_))
                                                        (_%__kont3853238533%_
                                                         _%$%hd2225823328%_
                                                         _%$%hd2225523318%_
                                                         _%$%hd2225223308%_
                                                         _%$%hd2224923298%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2223822473%_))))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2225923331%_))
                                                (_%__kont3853238533%_
                                                 _%$%hd2225823328%_
                                                 _%$%hd2225523318%_
                                                 _%$%hd2225223308%_
                                                 _%$%hd2224923298%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2223822473%_)))))
                                    (if (let ((__tmp39099
                                               |gerbil-ascent/program/scheme-language[1]#_g39100_|))
                                          (declare (not safe))
                                          (gx#free-identifier=?
                                           __tmp39099
                                           _%$%hd2226123338%_))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2226223341%_))
                                            (let ((_%$%e2234323010%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2226223341%_))))
                                              (let ((_%$%tl2234523017%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2234323010%_)))
                                                    (_%$%hd2234423014%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2234323010%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd2234423014%_))
                                                    (let ((_%$%e2234623020%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd2234423014%_))))
                                                      (let ((_%$%tl2234823027%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##cdr _%$%e2234623020%_)))
                    (_%$%hd2234723024%_
                     (let () (declare (not safe)) (##car _%$%e2234623020%_))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2234823027%_))
                    (let ((_%__splice3852038521%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2234823027%_
                              '0))))
                      (let ((_%$%tl2235123033%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3852038521%_ '1)))
                            (_%$%target2234923030%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3852038521%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2235123033%_))
                            (_%__match3872038721%_
                             _%$%e2224523284%_
                             _%$%hd2224623288%_
                             _%$%tl2224723291%_
                             _%$%e2224823294%_
                             _%$%hd2224923298%_
                             _%$%tl2225023301%_
                             _%$%e2225123304%_
                             _%$%hd2225223308%_
                             _%$%tl2225323311%_
                             _%$%e2225423314%_
                             _%$%hd2225523318%_
                             _%$%tl2225623321%_
                             _%$%e2225723324%_
                             _%$%hd2225823328%_
                             _%$%tl2225923331%_
                             _%$%e2226023334%_
                             _%$%hd2226123338%_
                             _%$%tl2226223341%_
                             _%$%e2234323010%_
                             _%$%hd2234423014%_
                             _%$%tl2234523017%_
                             _%$%e2234623020%_
                             _%$%hd2234723024%_
                             _%$%tl2234823027%_
                             _%__splice3852038521%_
                             _%$%target2234923030%_
                             _%$%tl2235123033%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2226223341%_))
                                (let ((_%__splice3853038531%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2226223341%_
                                          '0))))
                                  (let ((_%$%tl2244222627%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3853038531%_
                                            '1)))
                                        (_%$%target2244022624%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3853038531%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2244222627%_))
                                        (_%__match3883038831%_
                                         _%$%e2224523284%_
                                         _%$%hd2224623288%_
                                         _%$%tl2224723291%_
                                         _%$%e2224823294%_
                                         _%$%hd2224923298%_
                                         _%$%tl2225023301%_
                                         _%$%e2225123304%_
                                         _%$%hd2225223308%_
                                         _%$%tl2225323311%_
                                         _%$%e2225423314%_
                                         _%$%hd2225523318%_
                                         _%$%tl2225623321%_
                                         _%$%e2225723324%_
                                         _%$%hd2225823328%_
                                         _%$%tl2225923331%_
                                         _%$%e2226023334%_
                                         _%$%hd2226123338%_
                                         _%$%tl2226223341%_
                                         _%__splice3853038531%_
                                         _%$%target2244022624%_
                                         _%$%tl2244222627%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2225923331%_))
                                            (_%__kont3853238533%_
                                             _%$%hd2225823328%_
                                             _%$%hd2225523318%_
                                             _%$%hd2225223308%_
                                             _%$%hd2224923298%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2223822473%_))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2225923331%_))
                                    (_%__kont3853238533%_
                                     _%$%hd2225823328%_
                                     _%$%hd2225523318%_
                                     _%$%hd2225223308%_
                                     _%$%hd2224923298%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2223822473%_)))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2226223341%_))
                        (let ((_%__splice3853038531%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2226223341%_
                                  '0))))
                          (let ((_%$%tl2244222627%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3853038531%_ '1)))
                                (_%$%target2244022624%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3853038531%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2244222627%_))
                                (_%__match3883038831%_
                                 _%$%e2224523284%_
                                 _%$%hd2224623288%_
                                 _%$%tl2224723291%_
                                 _%$%e2224823294%_
                                 _%$%hd2224923298%_
                                 _%$%tl2225023301%_
                                 _%$%e2225123304%_
                                 _%$%hd2225223308%_
                                 _%$%tl2225323311%_
                                 _%$%e2225423314%_
                                 _%$%hd2225523318%_
                                 _%$%tl2225623321%_
                                 _%$%e2225723324%_
                                 _%$%hd2225823328%_
                                 _%$%tl2225923331%_
                                 _%$%e2226023334%_
                                 _%$%hd2226123338%_
                                 _%$%tl2226223341%_
                                 _%__splice3853038531%_
                                 _%$%target2244022624%_
                                 _%$%tl2244222627%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2225923331%_))
                                    (_%__kont3853238533%_
                                     _%$%hd2225823328%_
                                     _%$%hd2225523318%_
                                     _%$%hd2225223308%_
                                     _%$%hd2224923298%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2223822473%_))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2225923331%_))
                            (_%__kont3853238533%_
                             _%$%hd2225823328%_
                             _%$%hd2225523318%_
                             _%$%hd2225223308%_
                             _%$%hd2224923298%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%tl2226223341%_))
                                                        (let ((_%__splice3853038531%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice->vector
                          _%$%tl2226223341%_
                          '0))))
                  (let ((_%$%tl2244222627%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3853038531%_ '1)))
                        (_%$%target2244022624%_
                         (let ()
                           (declare (not safe))
                           (##vector-ref _%__splice3853038531%_ '0))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2244222627%_))
                        (_%__match3883038831%_
                         _%$%e2224523284%_
                         _%$%hd2224623288%_
                         _%$%tl2224723291%_
                         _%$%e2224823294%_
                         _%$%hd2224923298%_
                         _%$%tl2225023301%_
                         _%$%e2225123304%_
                         _%$%hd2225223308%_
                         _%$%tl2225323311%_
                         _%$%e2225423314%_
                         _%$%hd2225523318%_
                         _%$%tl2225623321%_
                         _%$%e2225723324%_
                         _%$%hd2225823328%_
                         _%$%tl2225923331%_
                         _%$%e2226023334%_
                         _%$%hd2226123338%_
                         _%$%tl2226223341%_
                         _%__splice3853038531%_
                         _%$%target2244022624%_
                         _%$%tl2244222627%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2225923331%_))
                            (_%__kont3853238533%_
                             _%$%hd2225823328%_
                             _%$%hd2225523318%_
                             _%$%hd2225223308%_
                             _%$%hd2224923298%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g2223822473%_))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2225923331%_))
                    (_%__kont3853238533%_
                     _%$%hd2225823328%_
                     _%$%hd2225523318%_
                     _%$%hd2225223308%_
                     _%$%hd2224923298%_)
                    (let () (declare (not safe)) (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2226223341%_))
                                                (let ((_%__splice3853038531%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2226223341%_
                                                          '0))))
                                                  (let ((_%$%tl2244222627%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '1)))
                                                        (_%$%target2244022624%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2244222627%_))
                                                        (_%__match3883038831%_
                                                         _%$%e2224523284%_
                                                         _%$%hd2224623288%_
                                                         _%$%tl2224723291%_
                                                         _%$%e2224823294%_
                                                         _%$%hd2224923298%_
                                                         _%$%tl2225023301%_
                                                         _%$%e2225123304%_
                                                         _%$%hd2225223308%_
                                                         _%$%tl2225323311%_
                                                         _%$%e2225423314%_
                                                         _%$%hd2225523318%_
                                                         _%$%tl2225623321%_
                                                         _%$%e2225723324%_
                                                         _%$%hd2225823328%_
                                                         _%$%tl2225923331%_
                                                         _%$%e2226023334%_
                                                         _%$%hd2226123338%_
                                                         _%$%tl2226223341%_
                                                         _%__splice3853038531%_
                                                         _%$%target2244022624%_
                                                         _%$%tl2244222627%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2225923331%_))
                                                            (_%__kont3853238533%_
                                                             _%$%hd2225823328%_
                                                             _%$%hd2225523318%_
                                                             _%$%hd2225223308%_
                                                             _%$%hd2224923298%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2223822473%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2225923331%_))
                                                    (_%__kont3853238533%_
                                                     _%$%hd2225823328%_
                                                     _%$%hd2225523318%_
                                                     _%$%hd2225223308%_
                                                     _%$%hd2224923298%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2223822473%_)))))
                                        (if (let ((__tmp39101
                                                   |gerbil-ascent/program/scheme-language[1]#_g39102_|))
                                              (declare (not safe))
                                              (gx#free-identifier=?
                                               __tmp39101
                                               _%$%hd2226123338%_))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2226223341%_))
                                                (let ((_%$%e2238422760%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2226223341%_))))
                                                  (let ((_%$%tl2238622767%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2238422760%_)))
                                                        (_%$%hd2238522764%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2238422760%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%tl2238622767%_))
                                                        (let ((_%$%e2238722770%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%tl2238622767%_))))
                  (let ((_%$%tl2238922777%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2238722770%_)))
                        (_%$%hd2238822774%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2238722770%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%hd2238822774%_))
                        (let ((_%$%e2239022780%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%hd2238822774%_))))
                          (let ((_%$%tl2239222787%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2239022780%_)))
                                (_%$%hd2239122784%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2239022780%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2239222787%_))
                                (let ((_%__splice3852438525%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2239222787%_
                                          '0))))
                                  (let ((_%$%tl2239522793%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3852438525%_
                                            '1)))
                                        (_%$%target2239322790%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3852438525%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2239522793%_))
                                        (_%__match3878638787%_
                                         _%$%e2224523284%_
                                         _%$%hd2224623288%_
                                         _%$%tl2224723291%_
                                         _%$%e2224823294%_
                                         _%$%hd2224923298%_
                                         _%$%tl2225023301%_
                                         _%$%e2225123304%_
                                         _%$%hd2225223308%_
                                         _%$%tl2225323311%_
                                         _%$%e2225423314%_
                                         _%$%hd2225523318%_
                                         _%$%tl2225623321%_
                                         _%$%e2225723324%_
                                         _%$%hd2225823328%_
                                         _%$%tl2225923331%_
                                         _%$%e2226023334%_
                                         _%$%hd2226123338%_
                                         _%$%tl2226223341%_
                                         _%$%e2238422760%_
                                         _%$%hd2238522764%_
                                         _%$%tl2238622767%_
                                         _%$%e2238722770%_
                                         _%$%hd2238822774%_
                                         _%$%tl2238922777%_
                                         _%$%e2239022780%_
                                         _%$%hd2239122784%_
                                         _%$%tl2239222787%_
                                         _%__splice3852438525%_
                                         _%$%target2239322790%_
                                         _%$%tl2239522793%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2226223341%_))
                                            (let ((_%__splice3853038531%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2226223341%_
                                                      '0))))
                                              (let ((_%$%tl2244222627%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3853038531%_
                                                        '1)))
                                                    (_%$%target2244022624%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3853038531%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2244222627%_))
                                                    (_%__match3883038831%_
                                                     _%$%e2224523284%_
                                                     _%$%hd2224623288%_
                                                     _%$%tl2224723291%_
                                                     _%$%e2224823294%_
                                                     _%$%hd2224923298%_
                                                     _%$%tl2225023301%_
                                                     _%$%e2225123304%_
                                                     _%$%hd2225223308%_
                                                     _%$%tl2225323311%_
                                                     _%$%e2225423314%_
                                                     _%$%hd2225523318%_
                                                     _%$%tl2225623321%_
                                                     _%$%e2225723324%_
                                                     _%$%hd2225823328%_
                                                     _%$%tl2225923331%_
                                                     _%$%e2226023334%_
                                                     _%$%hd2226123338%_
                                                     _%$%tl2226223341%_
                                                     _%__splice3853038531%_
                                                     _%$%target2244022624%_
                                                     _%$%tl2244222627%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2225923331%_))
                                                        (_%__kont3853238533%_
                                                         _%$%hd2225823328%_
                                                         _%$%hd2225523318%_
                                                         _%$%hd2225223308%_
                                                         _%$%hd2224923298%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2223822473%_))))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2225923331%_))
                                                (_%__kont3853238533%_
                                                 _%$%hd2225823328%_
                                                 _%$%hd2225523318%_
                                                 _%$%hd2225223308%_
                                                 _%$%hd2224923298%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2223822473%_)))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2226223341%_))
                                    (let ((_%__splice3853038531%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2226223341%_
                                              '0))))
                                      (let ((_%$%tl2244222627%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3853038531%_
                                                '1)))
                                            (_%$%target2244022624%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3853038531%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2244222627%_))
                                            (_%__match3883038831%_
                                             _%$%e2224523284%_
                                             _%$%hd2224623288%_
                                             _%$%tl2224723291%_
                                             _%$%e2224823294%_
                                             _%$%hd2224923298%_
                                             _%$%tl2225023301%_
                                             _%$%e2225123304%_
                                             _%$%hd2225223308%_
                                             _%$%tl2225323311%_
                                             _%$%e2225423314%_
                                             _%$%hd2225523318%_
                                             _%$%tl2225623321%_
                                             _%$%e2225723324%_
                                             _%$%hd2225823328%_
                                             _%$%tl2225923331%_
                                             _%$%e2226023334%_
                                             _%$%hd2226123338%_
                                             _%$%tl2226223341%_
                                             _%__splice3853038531%_
                                             _%$%target2244022624%_
                                             _%$%tl2244222627%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2225923331%_))
                                                (_%__kont3853238533%_
                                                 _%$%hd2225823328%_
                                                 _%$%hd2225523318%_
                                                 _%$%hd2225223308%_
                                                 _%$%hd2224923298%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (_%$%g2223822473%_))))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2225923331%_))
                                        (_%__kont3853238533%_
                                         _%$%hd2225823328%_
                                         _%$%hd2225523318%_
                                         _%$%hd2225223308%_
                                         _%$%hd2224923298%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2223822473%_)))))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair/null? _%$%tl2226223341%_))
                            (let ((_%__splice3853038531%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-split-splice->vector
                                      _%$%tl2226223341%_
                                      '0))))
                              (let ((_%$%tl2244222627%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '1)))
                                    (_%$%target2244022624%_
                                     (let ()
                                       (declare (not safe))
                                       (##vector-ref
                                        _%__splice3853038531%_
                                        '0))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2244222627%_))
                                    (_%__match3883038831%_
                                     _%$%e2224523284%_
                                     _%$%hd2224623288%_
                                     _%$%tl2224723291%_
                                     _%$%e2224823294%_
                                     _%$%hd2224923298%_
                                     _%$%tl2225023301%_
                                     _%$%e2225123304%_
                                     _%$%hd2225223308%_
                                     _%$%tl2225323311%_
                                     _%$%e2225423314%_
                                     _%$%hd2225523318%_
                                     _%$%tl2225623321%_
                                     _%$%e2225723324%_
                                     _%$%hd2225823328%_
                                     _%$%tl2225923331%_
                                     _%$%e2226023334%_
                                     _%$%hd2226123338%_
                                     _%$%tl2226223341%_
                                     _%__splice3853038531%_
                                     _%$%target2244022624%_
                                     _%$%tl2244222627%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2225923331%_))
                                        (_%__kont3853238533%_
                                         _%$%hd2225823328%_
                                         _%$%hd2225523318%_
                                         _%$%hd2225223308%_
                                         _%$%hd2224923298%_)
                                        (let ()
                                          (declare (not safe))
                                          (_%$%g2223822473%_))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2225923331%_))
                                (_%__kont3853238533%_
                                 _%$%hd2225823328%_
                                 _%$%hd2225523318%_
                                 _%$%hd2225223308%_
                                 _%$%hd2224923298%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2223822473%_)))))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-pair/null? _%$%tl2226223341%_))
                    (let ((_%__splice3853038531%_
                           (let ()
                             (declare (not safe))
                             (gx#syntax-split-splice->vector
                              _%$%tl2226223341%_
                              '0))))
                      (let ((_%$%tl2244222627%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3853038531%_ '1)))
                            (_%$%target2244022624%_
                             (let ()
                               (declare (not safe))
                               (##vector-ref _%__splice3853038531%_ '0))))
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-null? _%$%tl2244222627%_))
                            (_%__match3883038831%_
                             _%$%e2224523284%_
                             _%$%hd2224623288%_
                             _%$%tl2224723291%_
                             _%$%e2224823294%_
                             _%$%hd2224923298%_
                             _%$%tl2225023301%_
                             _%$%e2225123304%_
                             _%$%hd2225223308%_
                             _%$%tl2225323311%_
                             _%$%e2225423314%_
                             _%$%hd2225523318%_
                             _%$%tl2225623321%_
                             _%$%e2225723324%_
                             _%$%hd2225823328%_
                             _%$%tl2225923331%_
                             _%$%e2226023334%_
                             _%$%hd2226123338%_
                             _%$%tl2226223341%_
                             _%__splice3853038531%_
                             _%$%target2244022624%_
                             _%$%tl2244222627%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2225923331%_))
                                (_%__kont3853238533%_
                                 _%$%hd2225823328%_
                                 _%$%hd2225523318%_
                                 _%$%hd2225223308%_
                                 _%$%hd2224923298%_)
                                (let ()
                                  (declare (not safe))
                                  (_%$%g2223822473%_))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2225923331%_))
                        (_%__kont3853238533%_
                         _%$%hd2225823328%_
                         _%$%hd2225523318%_
                         _%$%hd2225223308%_
                         _%$%hd2224923298%_)
                        (let () (declare (not safe)) (_%$%g2223822473%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2226223341%_))
                                                    (let ((_%__splice3853038531%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2226223341%_
                                                              '0))))
                                                      (let ((_%$%tl2244222627%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3853038531%_ '1)))
                    (_%$%target2244022624%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3853038531%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2244222627%_))
                    (_%__match3883038831%_
                     _%$%e2224523284%_
                     _%$%hd2224623288%_
                     _%$%tl2224723291%_
                     _%$%e2224823294%_
                     _%$%hd2224923298%_
                     _%$%tl2225023301%_
                     _%$%e2225123304%_
                     _%$%hd2225223308%_
                     _%$%tl2225323311%_
                     _%$%e2225423314%_
                     _%$%hd2225523318%_
                     _%$%tl2225623321%_
                     _%$%e2225723324%_
                     _%$%hd2225823328%_
                     _%$%tl2225923331%_
                     _%$%e2226023334%_
                     _%$%hd2226123338%_
                     _%$%tl2226223341%_
                     _%__splice3853038531%_
                     _%$%target2244022624%_
                     _%$%tl2244222627%_)
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2225923331%_))
                        (_%__kont3853238533%_
                         _%$%hd2225823328%_
                         _%$%hd2225523318%_
                         _%$%hd2225223308%_
                         _%$%hd2224923298%_)
                        (let () (declare (not safe)) (_%$%g2223822473%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2225923331%_))
                                                        (_%__kont3853238533%_
                                                         _%$%hd2225823328%_
                                                         _%$%hd2225523318%_
                                                         _%$%hd2225223308%_
                                                         _%$%hd2224923298%_)
                                                        (let ()
                                                          (declare (not safe))
                                                          (_%$%g2223822473%_)))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair/null?
                                                   _%$%tl2226223341%_))
                                                (let ((_%__splice3853038531%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-split-splice->vector
                                                          _%$%tl2226223341%_
                                                          '0))))
                                                  (let ((_%$%tl2244222627%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '1)))
                                                        (_%$%target2244022624%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##vector-ref
                                                            _%__splice3853038531%_
                                                            '0))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2244222627%_))
                                                        (_%__match3883038831%_
                                                         _%$%e2224523284%_
                                                         _%$%hd2224623288%_
                                                         _%$%tl2224723291%_
                                                         _%$%e2224823294%_
                                                         _%$%hd2224923298%_
                                                         _%$%tl2225023301%_
                                                         _%$%e2225123304%_
                                                         _%$%hd2225223308%_
                                                         _%$%tl2225323311%_
                                                         _%$%e2225423314%_
                                                         _%$%hd2225523318%_
                                                         _%$%tl2225623321%_
                                                         _%$%e2225723324%_
                                                         _%$%hd2225823328%_
                                                         _%$%tl2225923331%_
                                                         _%$%e2226023334%_
                                                         _%$%hd2226123338%_
                                                         _%$%tl2226223341%_
                                                         _%__splice3853038531%_
                                                         _%$%target2244022624%_
                                                         _%$%tl2244222627%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-null?
                                                               _%$%tl2225923331%_))
                                                            (_%__kont3853238533%_
                                                             _%$%hd2225823328%_
                                                             _%$%hd2225523318%_
                                                             _%$%hd2225223308%_
                                                             _%$%hd2224923298%_)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (_%$%g2223822473%_))))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2225923331%_))
                                                    (_%__kont3853238533%_
                                                     _%$%hd2225823328%_
                                                     _%$%hd2225523318%_
                                                     _%$%hd2225223308%_
                                                     _%$%hd2224923298%_)
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2223822473%_))))))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2226223341%_))
                                (let ((_%__splice3853038531%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice->vector
                                          _%$%tl2226223341%_
                                          '0))))
                                  (let ((_%$%tl2244222627%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3853038531%_
                                            '1)))
                                        (_%$%target2244022624%_
                                         (let ()
                                           (declare (not safe))
                                           (##vector-ref
                                            _%__splice3853038531%_
                                            '0))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2244222627%_))
                                        (_%__match3883038831%_
                                         _%$%e2224523284%_
                                         _%$%hd2224623288%_
                                         _%$%tl2224723291%_
                                         _%$%e2224823294%_
                                         _%$%hd2224923298%_
                                         _%$%tl2225023301%_
                                         _%$%e2225123304%_
                                         _%$%hd2225223308%_
                                         _%$%tl2225323311%_
                                         _%$%e2225423314%_
                                         _%$%hd2225523318%_
                                         _%$%tl2225623321%_
                                         _%$%e2225723324%_
                                         _%$%hd2225823328%_
                                         _%$%tl2225923331%_
                                         _%$%e2226023334%_
                                         _%$%hd2226123338%_
                                         _%$%tl2226223341%_
                                         _%__splice3853038531%_
                                         _%$%target2244022624%_
                                         _%$%tl2244222627%_)
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2225923331%_))
                                            (_%__kont3853238533%_
                                             _%$%hd2225823328%_
                                             _%$%hd2225523318%_
                                             _%$%hd2225223308%_
                                             _%$%hd2224923298%_)
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2223822473%_))))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl2225923331%_))
                                    (_%__kont3853238533%_
                                     _%$%hd2225823328%_
                                     _%$%hd2225523318%_
                                     _%$%hd2225223308%_
                                     _%$%hd2224923298%_)
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2223822473%_)))))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2225923331%_))
                        (_%__kont3853238533%_
                         _%$%hd2225823328%_
                         _%$%hd2225523318%_
                         _%$%hd2225223308%_
                         _%$%hd2224923298%_)
                        (let () (declare (not safe)) (_%$%g2223822473%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2223822473%_)))))
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2223822473%_)))))
                                    (let ()
                                      (declare (not safe))
                                      (_%$%g2223822473%_)))))
                            (let ()
                              (declare (not safe))
                              (_%$%g2223822473%_)))))
                    (let () (declare (not safe)) (_%$%g2223822473%_)))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-collect|
      (lambda (_%stx23458%_)
        (let* ((_%__stx3886538866%_ _%stx23458%_)
               (_%$%g2346723850%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3886538866%_)))))
          (let ((_%__kont3886838869%_
                 (lambda (_%$%g2346925366%_
                          _%$%g2347025368%_
                          _%$%g2347125369%_
                          _%$%g2347225370%_
                          _%$%g2347325371%_
                          _%$%g2347425372%_
                          _%$%g2347525373%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39105
                                      (lambda (_%$%g2542825437%_
                                               _%$%g2542925440%_)
                                        (cons _%$%g2542825437%_
                                              _%$%g2542925440%_)))
                                     (__tmp39103
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-checked-lattice))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2347325371%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39104
                                                     (lambda (_%$%g2543025443%_
                                                              _%$%g2543125446%_)
                                                       (cons _%$%g2543025443%_
                                                             _%$%g2543125446%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39104
                                                 '()
                                                 _%$%g2347225370%_))
                                              '()))
                                  '()))
                      (cons _%$%g2347125369%_
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons _%$%g2347025368%_ '()))
                                  '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39105
                                  __tmp39103
                                  _%$%g2347525373%_))
                               (cons (let ((__tmp39106
                                            (lambda (_%$%g2543225449%_
                                                     _%$%g2543325452%_)
                                              (cons _%$%g2543225449%_
                                                    _%$%g2543325452%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39106
                                        '()
                                        _%$%g2347425372%_))
                                     (let ((__tmp39107
                                            (lambda (_%$%g2543425455%_
                                                     _%$%g2543525458%_)
                                              (cons _%$%g2543425455%_
                                                    _%$%g2543525458%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39107
                                        '()
                                        _%$%g2346925366%_)))))))
                (_%__kont3887838879%_
                 (lambda (_%$%g2353925066%_
                          _%$%g2354025068%_
                          _%$%g2354125069%_
                          _%$%g2354225070%_
                          _%$%g2354325071%_
                          _%$%g2354425072%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39110
                                      (lambda (_%$%g2512425133%_
                                               _%$%g2512525136%_)
                                        (cons _%$%g2512425133%_
                                              _%$%g2512525136%_)))
                                     (__tmp39108
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-source))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2354225070%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39109
                                                     (lambda (_%$%g2512625139%_
                                                              _%$%g2512725142%_)
                                                       (cons _%$%g2512625139%_
                                                             _%$%g2512725142%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39109
                                                 '()
                                                 _%$%g2354125069%_))
                                              '()))
                                  '()))
                      (cons _%$%g2354025068%_ '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39110
                                  __tmp39108
                                  _%$%g2354425072%_))
                               (cons (let ((__tmp39111
                                            (lambda (_%$%g2512825145%_
                                                     _%$%g2512925148%_)
                                              (cons _%$%g2512825145%_
                                                    _%$%g2512925148%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39111
                                        '()
                                        _%$%g2354325071%_))
                                     (let ((__tmp39112
                                            (lambda (_%$%g2513025151%_
                                                     _%$%g2513125154%_)
                                              (cons _%$%g2513025151%_
                                                    _%$%g2513125154%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39112
                                        '()
                                        _%$%g2353925066%_)))))))
                (_%__kont3888838889%_
                 (lambda (_%$%g2360524780%_
                          _%$%g2360624782%_
                          _%$%g2360724783%_
                          _%$%g2360824784%_
                          _%$%g2360924785%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39115
                                      (lambda (_%$%g2483424843%_
                                               _%$%g2483524846%_)
                                        (cons _%$%g2483424843%_
                                              _%$%g2483524846%_)))
                                     (__tmp39113
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'relational-source))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'quote))
                      (cons _%$%g2360724783%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'length))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'quote))
                                        (cons (let ((__tmp39114
                                                     (lambda (_%$%g2483624849%_
                                                              _%$%g2483724852%_)
                                                       (cons _%$%g2483624849%_
                                                             _%$%g2483724852%_))))
                                                (declare (not safe))
                                                (foldr__0
                                                 __tmp39114
                                                 '()
                                                 _%$%g2360624782%_))
                                              '()))
                                  '()))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f '@list))
                                  '())
                            '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                                 (declare (not safe))
                                 (foldr__0
                                  __tmp39115
                                  __tmp39113
                                  _%$%g2360924785%_))
                               (cons (let ((__tmp39116
                                            (lambda (_%$%g2483824855%_
                                                     _%$%g2483924858%_)
                                              (cons _%$%g2483824855%_
                                                    _%$%g2483924858%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39116
                                        '()
                                        _%$%g2360824784%_))
                                     (let ((__tmp39117
                                            (lambda (_%$%g2484024861%_
                                                     _%$%g2484124864%_)
                                              (cons _%$%g2484024861%_
                                                    _%$%g2484124864%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39117
                                        '()
                                        _%$%g2360524780%_)))))))
                (_%__kont3889838899%_
                 (lambda (_%$%g2366724514%_
                          _%$%g2366824516%_
                          _%$%g2366924517%_
                          _%$%g2367024518%_
                          _%$%g2367124519%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'relational-collect))
                         (cons (let ((__tmp39118
                                      (lambda (_%$%g2455824567%_
                                               _%$%g2455924570%_)
                                        (cons _%$%g2455824567%_
                                              _%$%g2455924570%_))))
                                 (declare (not safe))
                                 (foldr__0 __tmp39118 '() _%$%g2367124519%_))
                               (cons (let ((__tmp39121
                                            (lambda (_%$%g2456024573%_
                                                     _%$%g2456124576%_)
                                              (cons _%$%g2456024573%_
                                                    _%$%g2456124576%_)))
                                           (__tmp39119
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'gerbil-ascent-rule))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'list))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0
                                           '#f
                                           'relational-atom))
                                        (cons _%$%g2366924517%_ '()))
                                  '()))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'list))
                                  (let ((__tmp39120
                                         (lambda (_%$%g2456224579%_
                                                  _%$%g2456324582%_)
                                           (cons (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'relational-checked-clause))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'relational-atom))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'relational-negation))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0
                                    '#f
                                    'relational-reduce))
                                 (cons _%$%g2456224579%_ '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 _%$%g2456324582%_))))
                                    (declare (not safe))
                                    (foldr__0
                                     __tmp39120
                                     '()
                                     _%$%g2366824516%_)))
                            '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39121
                                        __tmp39119
                                        _%$%g2367024518%_))
                                     (let ((__tmp39122
                                            (lambda (_%$%g2456424585%_
                                                     _%$%g2456524588%_)
                                              (cons _%$%g2456424585%_
                                                    _%$%g2456524588%_))))
                                       (declare (not safe))
                                       (foldr__0
                                        __tmp39122
                                        '()
                                        _%$%g2366724514%_)))))))
                (_%__kont3890838909%_
                 (lambda (_%$%g2372624278%_
                          _%$%g2372724280%_
                          _%$%g2372824281%_
                          _%$%g2372924282%_
                          _%$%g2373024283%_)
                   (cons (let ()
                           (declare (not safe))
                           (gx#datum->syntax__0 '#f 'let))
                         (cons (cons (let ()
                                       (declare (not safe))
                                       (gx#datum->syntax__0 '#f 'relations))
                                     (cons (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'list))
                                                 (let ((__tmp39123
                                                        (lambda (_%$%g2431824323%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g2431924326%_)
                  (cons _%$%g2431824323%_ _%$%g2431924326%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__0
                                                    __tmp39123
                                                    '()
                                                    _%$%g2373024283%_)))
                                           '()))
                               (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'gerbil-ascent-program))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'relations))
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'list))
                     (let ((__tmp39124
                            (lambda (_%$%g2432024329%_ _%$%g2432124332%_)
                              (cons _%$%g2432024329%_ _%$%g2432124332%_))))
                       (declare (not safe))
                       (foldr__0 __tmp39124 '() _%$%g2372924282%_)))
               (cons _%$%g2372824281%_
                     (cons _%$%g2372724280%_
                           (cons _%$%g2372624278%_
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'map))
                                             (cons (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'lambda))
                                                         (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (declare (not safe))
                               (gx#datum->syntax__0 '#f 'relation))
                             '())
                       (cons (cons (let ()
                                     (declare (not safe))
                                     (gx#datum->syntax__0 '#f '.ref))
                                   (cons (let ()
                                           (declare (not safe))
                                           (gx#datum->syntax__0 '#f 'relation))
                                         (cons (cons (let ()
                                                       (declare (not safe))
                                                       (gx#datum->syntax__0
                                                        '#f
                                                        'quote))
                                                     (cons (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#datum->syntax__0
                                                              '#f
                                                              'name))
                                                           '()))
                                               '())))
                             '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (cons (let ()
                                                           (declare (not safe))
                                                           (gx#datum->syntax__0
                                                            '#f
                                                            'relations))
                                                         '())))
                                       '())))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3891438915%_
                 (lambda (_%$%g2377324100%_
                          _%$%g2377424102%_
                          _%$%g2377524103%_
                          _%$%g2377624104%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"expected relation, rule, or final limits clause"
                      _%$%g2377424102%_))))
                (_%__kont3892238923%_
                 (lambda (_%$%g2381623943%_ _%$%g2381723945%_)
                   (let ()
                     (declare (not safe))
                     (gx#raise-syntax-error
                      '#f
                      '"relational-program requires a final limits clause"
                      _%stx23458%_)))))
            (let* ((_%__match3906839069%_
                    (lambda (_%$%e2381823857%_
                             _%$%hd2381923861%_
                             _%$%tl2382023864%_
                             _%$%e2382123867%_
                             _%$%hd2382223871%_
                             _%$%tl2382323874%_
                             _%__splice3892438925%_
                             _%$%target2382423877%_
                             _%$%tl2382623880%_)
                      (letrec ((_%$%loop2382723883%_
                                (lambda (_%$%hd2382523887%_
                                         _%$%declared2383123890%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2382523887%_))
                                      (let ((_%$%e2382823892%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2382523887%_))))
                                        (let ((_%$%lp-tl2383023899%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2382823892%_)))
                                              (_%$%lp-hd2382923896%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2382823892%_))))
                                          (_%$%loop2382723883%_
                                           _%$%lp-tl2383023899%_
                                           (cons _%$%lp-hd2382923896%_
                                                 _%$%declared2383123890%_))))
                                      (let ((_%$%declared2383223902%_
                                             (reverse _%$%declared2383123890%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2382323874%_))
                                            (let ((_%$%e2383323905%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2382323874%_))))
                                              (let ((_%$%tl2383523912%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2383323905%_)))
                                                    (_%$%hd2383423909%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2383323905%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2383423909%_))
                                                    (let ((_%__splice3892638927%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2383423909%_
                                                              '0))))
                                                      (let ((_%$%tl2383823918%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3892638927%_ '1)))
                    (_%$%target2383623915%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3892638927%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2383823918%_))
                    (letrec ((_%$%loop2383923921%_
                              (lambda (_%$%hd2383723925%_
                                       _%$%lowered2384323928%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2383723925%_))
                                    (let ((_%$%e2384023930%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2383723925%_))))
                                      (let ((_%$%lp-tl2384223937%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2384023930%_)))
                                            (_%$%lp-hd2384123934%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2384023930%_))))
                                        (_%$%loop2383923921%_
                                         _%$%lp-tl2384223937%_
                                         (cons _%$%lp-hd2384123934%_
                                               _%$%lowered2384323928%_))))
                                    (let ((_%$%lowered2384423940%_
                                           (reverse _%$%lowered2384323928%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2383523912%_))
                                          (_%__kont3892238923%_
                                           _%$%lowered2384423940%_
                                           _%$%declared2383223902%_)
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g2346723850%_))))))))
                      (_%$%loop2383923921%_ _%$%target2383623915%_ '()))
                    (let () (declare (not safe)) (_%$%g2346723850%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ()
                                                      (declare (not safe))
                                                      (_%$%g2346723850%_)))))
                                            (let ()
                                              (declare (not safe))
                                              (_%$%g2346723850%_))))))))
                        (_%$%loop2382723883%_ _%$%target2382423877%_ '()))))
                   (_%__match3904839049%_
                    (lambda (_%$%e2377723976%_
                             _%$%hd2377823980%_
                             _%$%tl2377923983%_
                             _%$%e2378023986%_
                             _%$%hd2378123990%_
                             _%$%tl2378223993%_
                             _%__splice3891638917%_
                             _%$%target2378323996%_
                             _%$%tl2378523999%_)
                      (letrec ((_%$%loop2378624002%_
                                (lambda (_%$%hd2378424006%_
                                         _%$%declared2379024009%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2378424006%_))
                                      (let ((_%$%e2378724011%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2378424006%_))))
                                        (let ((_%$%lp-tl2378924018%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2378724011%_)))
                                              (_%$%lp-hd2378824015%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2378724011%_))))
                                          (_%$%loop2378624002%_
                                           _%$%lp-tl2378924018%_
                                           (cons _%$%lp-hd2378824015%_
                                                 _%$%declared2379024009%_))))
                                      (let ((_%$%declared2379124021%_
                                             (reverse _%$%declared2379024009%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2378223993%_))
                                            (let ((_%$%e2379224024%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2378223993%_))))
                                              (let ((_%$%tl2379424031%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2379224024%_)))
                                                    (_%$%hd2379324028%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2379224024%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2379324028%_))
                                                    (let ((_%__splice3891838919%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2379324028%_
                                                              '0))))
                                                      (let ((_%$%tl2379724037%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3891838919%_ '1)))
                    (_%$%target2379524034%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3891838919%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2379724037%_))
                    (letrec ((_%$%loop2379824040%_
                              (lambda (_%$%hd2379624044%_
                                       _%$%lowered2380224047%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2379624044%_))
                                    (let ((_%$%e2379924049%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2379624044%_))))
                                      (let ((_%$%lp-tl2380124056%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2379924049%_)))
                                            (_%$%lp-hd2380024053%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2379924049%_))))
                                        (_%$%loop2379824040%_
                                         _%$%lp-tl2380124056%_
                                         (cons _%$%lp-hd2380024053%_
                                               _%$%lowered2380224047%_))))
                                    (let ((_%$%lowered2380324059%_
                                           (reverse _%$%lowered2380224047%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2379424031%_))
                                          (let ((_%$%e2380424062%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2379424031%_))))
                                            (let ((_%$%tl2380624069%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2380424062%_)))
                                                  (_%$%hd2380524066%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2380424062%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair/null?
                                                     _%$%tl2380624069%_))
                                                  (let ((_%__splice3892038921%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-split-splice->vector
                                                            _%$%tl2380624069%_
                                                            '0))))
                                                    (let ((_%$%tl2380924075%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3892038921%_
                                                              '1)))
                                                          (_%$%target2380724072%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##vector-ref
                                                              _%__splice3892038921%_
                                                              '0))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-null?
                                                             _%$%tl2380924075%_))
                                                          (letrec ((_%$%loop2381024078%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (lambda (_%$%hd2380824082%_ _%$%rest2381424085%_)
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%hd2380824082%_))
                                  (let ((_%$%e2381124087%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%hd2380824082%_))))
                                    (let ((_%$%lp-tl2381324094%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2381124087%_)))
                                          (_%$%lp-hd2381224091%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2381124087%_))))
                                      (_%$%loop2381024078%_
                                       _%$%lp-tl2381324094%_
                                       (cons _%$%lp-hd2381224091%_
                                             _%$%rest2381424085%_))))
                                  (let ((_%$%rest2381524097%_
                                         (reverse _%$%rest2381424085%_)))
                                    (_%__kont3891438915%_
                                     _%$%rest2381524097%_
                                     _%$%hd2380524066%_
                                     _%$%lowered2380324059%_
                                     _%$%declared2379124021%_))))))
                    (_%$%loop2381024078%_ _%$%target2380724072%_ '()))
                  (_%__match3906839069%_
                   _%$%e2377723976%_
                   _%$%hd2377823980%_
                   _%$%tl2377923983%_
                   _%$%e2378023986%_
                   _%$%hd2378123990%_
                   _%$%tl2378223993%_
                   _%__splice3891638917%_
                   _%$%target2378323996%_
                   _%$%tl2378523999%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3906839069%_
                                                   _%$%e2377723976%_
                                                   _%$%hd2377823980%_
                                                   _%$%tl2377923983%_
                                                   _%$%e2378023986%_
                                                   _%$%hd2378123990%_
                                                   _%$%tl2378223993%_
                                                   _%__splice3891638917%_
                                                   _%$%target2378323996%_
                                                   _%$%tl2378523999%_))))
                                          (_%__match3906839069%_
                                           _%$%e2377723976%_
                                           _%$%hd2377823980%_
                                           _%$%tl2377923983%_
                                           _%$%e2378023986%_
                                           _%$%hd2378123990%_
                                           _%$%tl2378223993%_
                                           _%__splice3891638917%_
                                           _%$%target2378323996%_
                                           _%$%tl2378523999%_)))))))
                      (_%$%loop2379824040%_ _%$%target2379524034%_ '()))
                    (_%__match3906839069%_
                     _%$%e2377723976%_
                     _%$%hd2377823980%_
                     _%$%tl2377923983%_
                     _%$%e2378023986%_
                     _%$%hd2378123990%_
                     _%$%tl2378223993%_
                     _%__splice3891638917%_
                     _%$%target2378323996%_
                     _%$%tl2378523999%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3906839069%_
                                                     _%$%e2377723976%_
                                                     _%$%hd2377823980%_
                                                     _%$%tl2377923983%_
                                                     _%$%e2378023986%_
                                                     _%$%hd2378123990%_
                                                     _%$%tl2378223993%_
                                                     _%__splice3891638917%_
                                                     _%$%target2378323996%_
                                                     _%$%tl2378523999%_))))
                                            (_%__match3906839069%_
                                             _%$%e2377723976%_
                                             _%$%hd2377823980%_
                                             _%$%tl2377923983%_
                                             _%$%e2378023986%_
                                             _%$%hd2378123990%_
                                             _%$%tl2378223993%_
                                             _%__splice3891638917%_
                                             _%$%target2378323996%_
                                             _%$%tl2378523999%_)))))))
                        (_%$%loop2378624002%_ _%$%target2378323996%_ '()))))
                   (_%__match3902839029%_
                    (lambda (_%$%e2373124142%_
                             _%$%hd2373224146%_
                             _%$%tl2373324149%_
                             _%$%e2373424152%_
                             _%$%hd2373524156%_
                             _%$%tl2373624159%_
                             _%__splice3891038911%_
                             _%$%target2373724162%_
                             _%$%tl2373924165%_)
                      (letrec ((_%$%loop2374024168%_
                                (lambda (_%$%hd2373824172%_
                                         _%$%declared2374424175%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2373824172%_))
                                      (let ((_%$%e2374124177%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2373824172%_))))
                                        (let ((_%$%lp-tl2374324184%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2374124177%_)))
                                              (_%$%lp-hd2374224181%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2374124177%_))))
                                          (_%$%loop2374024168%_
                                           _%$%lp-tl2374324184%_
                                           (cons _%$%lp-hd2374224181%_
                                                 _%$%declared2374424175%_))))
                                      (let ((_%$%declared2374524187%_
                                             (reverse _%$%declared2374424175%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2373624159%_))
                                            (let ((_%$%e2374624190%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2373624159%_))))
                                              (let ((_%$%tl2374824197%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2374624190%_)))
                                                    (_%$%hd2374724194%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2374624190%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2374724194%_))
                                                    (let ((_%__splice3891238913%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2374724194%_
                                                              '0))))
                                                      (let ((_%$%tl2375124203%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3891238913%_ '1)))
                    (_%$%target2374924200%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3891238913%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2375124203%_))
                    (letrec ((_%$%loop2375224206%_
                              (lambda (_%$%hd2375024210%_
                                       _%$%lowered2375624213%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2375024210%_))
                                    (let ((_%$%e2375324215%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2375024210%_))))
                                      (let ((_%$%lp-tl2375524222%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2375324215%_)))
                                            (_%$%lp-hd2375424219%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2375324215%_))))
                                        (_%$%loop2375224206%_
                                         _%$%lp-tl2375524222%_
                                         (cons _%$%lp-hd2375424219%_
                                               _%$%lowered2375624213%_))))
                                    (let ((_%$%lowered2375724225%_
                                           (reverse _%$%lowered2375624213%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2374824197%_))
                                          (let ((_%$%e2375824228%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2374824197%_))))
                                            (let ((_%$%tl2376024235%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2375824228%_)))
                                                  (_%$%hd2375924232%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2375824228%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2375924232%_))
                                                  (let ((_%$%e2376124238%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2375924232%_))))
                                                    (let ((_%$%tl2376324245%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2376124238%_)))
                                                          (_%$%hd2376224242%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2376124238%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2376224242%_))
                                                          (if (let ((__tmp39125
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39126_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39125 _%$%hd2376224242%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2376324245%_))
                          (let ((_%$%e2376424248%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2376324245%_))))
                            (let ((_%$%tl2376624255%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2376424248%_)))
                                  (_%$%hd2376524252%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2376424248%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2376624255%_))
                                  (let ((_%$%e2376724258%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2376624255%_))))
                                    (let ((_%$%tl2376924265%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2376724258%_)))
                                          (_%$%hd2376824262%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2376724258%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2376924265%_))
                                          (let ((_%$%e2377024268%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2376924265%_))))
                                            (let ((_%$%tl2377224275%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2377024268%_)))
                                                  (_%$%hd2377124272%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2377024268%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2377224275%_))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-null?
                                                         _%$%tl2376024235%_))
                                                      (_%__kont3890838909%_
                                                       _%$%hd2377124272%_
                                                       _%$%hd2376824262%_
                                                       _%$%hd2376524252%_
                                                       _%$%lowered2375724225%_
                                                       _%$%declared2374524187%_)
                                                      (_%__match3904839049%_
                                                       _%$%e2373124142%_
                                                       _%$%hd2373224146%_
                                                       _%$%tl2373324149%_
                                                       _%$%e2373424152%_
                                                       _%$%hd2373524156%_
                                                       _%$%tl2373624159%_
                                                       _%__splice3891038911%_
                                                       _%$%target2373724162%_
                                                       _%$%tl2373924165%_))
                                                  (_%__match3904839049%_
                                                   _%$%e2373124142%_
                                                   _%$%hd2373224146%_
                                                   _%$%tl2373324149%_
                                                   _%$%e2373424152%_
                                                   _%$%hd2373524156%_
                                                   _%$%tl2373624159%_
                                                   _%__splice3891038911%_
                                                   _%$%target2373724162%_
                                                   _%$%tl2373924165%_))))
                                          (_%__match3904839049%_
                                           _%$%e2373124142%_
                                           _%$%hd2373224146%_
                                           _%$%tl2373324149%_
                                           _%$%e2373424152%_
                                           _%$%hd2373524156%_
                                           _%$%tl2373624159%_
                                           _%__splice3891038911%_
                                           _%$%target2373724162%_
                                           _%$%tl2373924165%_))))
                                  (_%__match3904839049%_
                                   _%$%e2373124142%_
                                   _%$%hd2373224146%_
                                   _%$%tl2373324149%_
                                   _%$%e2373424152%_
                                   _%$%hd2373524156%_
                                   _%$%tl2373624159%_
                                   _%__splice3891038911%_
                                   _%$%target2373724162%_
                                   _%$%tl2373924165%_))))
                          (_%__match3904839049%_
                           _%$%e2373124142%_
                           _%$%hd2373224146%_
                           _%$%tl2373324149%_
                           _%$%e2373424152%_
                           _%$%hd2373524156%_
                           _%$%tl2373624159%_
                           _%__splice3891038911%_
                           _%$%target2373724162%_
                           _%$%tl2373924165%_))
                      (_%__match3904839049%_
                       _%$%e2373124142%_
                       _%$%hd2373224146%_
                       _%$%tl2373324149%_
                       _%$%e2373424152%_
                       _%$%hd2373524156%_
                       _%$%tl2373624159%_
                       _%__splice3891038911%_
                       _%$%target2373724162%_
                       _%$%tl2373924165%_))
                  (_%__match3904839049%_
                   _%$%e2373124142%_
                   _%$%hd2373224146%_
                   _%$%tl2373324149%_
                   _%$%e2373424152%_
                   _%$%hd2373524156%_
                   _%$%tl2373624159%_
                   _%__splice3891038911%_
                   _%$%target2373724162%_
                   _%$%tl2373924165%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3904839049%_
                                                   _%$%e2373124142%_
                                                   _%$%hd2373224146%_
                                                   _%$%tl2373324149%_
                                                   _%$%e2373424152%_
                                                   _%$%hd2373524156%_
                                                   _%$%tl2373624159%_
                                                   _%__splice3891038911%_
                                                   _%$%target2373724162%_
                                                   _%$%tl2373924165%_))))
                                          (_%__match3904839049%_
                                           _%$%e2373124142%_
                                           _%$%hd2373224146%_
                                           _%$%tl2373324149%_
                                           _%$%e2373424152%_
                                           _%$%hd2373524156%_
                                           _%$%tl2373624159%_
                                           _%__splice3891038911%_
                                           _%$%target2373724162%_
                                           _%$%tl2373924165%_)))))))
                      (_%$%loop2375224206%_ _%$%target2374924200%_ '()))
                    (_%__match3904839049%_
                     _%$%e2373124142%_
                     _%$%hd2373224146%_
                     _%$%tl2373324149%_
                     _%$%e2373424152%_
                     _%$%hd2373524156%_
                     _%$%tl2373624159%_
                     _%__splice3891038911%_
                     _%$%target2373724162%_
                     _%$%tl2373924165%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3904839049%_
                                                     _%$%e2373124142%_
                                                     _%$%hd2373224146%_
                                                     _%$%tl2373324149%_
                                                     _%$%e2373424152%_
                                                     _%$%hd2373524156%_
                                                     _%$%tl2373624159%_
                                                     _%__splice3891038911%_
                                                     _%$%target2373724162%_
                                                     _%$%tl2373924165%_))))
                                            (_%__match3904839049%_
                                             _%$%e2373124142%_
                                             _%$%hd2373224146%_
                                             _%$%tl2373324149%_
                                             _%$%e2373424152%_
                                             _%$%hd2373524156%_
                                             _%$%tl2373624159%_
                                             _%__splice3891038911%_
                                             _%$%target2373724162%_
                                             _%$%tl2373924165%_)))))))
                        (_%$%loop2374024168%_ _%$%target2373724162%_ '()))))
                   (_%__match3900839009%_
                    (lambda (_%$%e2367224342%_
                             _%$%hd2367324346%_
                             _%$%tl2367424349%_
                             _%$%e2367524352%_
                             _%$%hd2367624356%_
                             _%$%tl2367724359%_
                             _%__splice3890038901%_
                             _%$%target2367824362%_
                             _%$%tl2368024365%_)
                      (letrec ((_%$%loop2368124368%_
                                (lambda (_%$%hd2367924372%_
                                         _%$%declared2368524375%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2367924372%_))
                                      (let ((_%$%e2368224377%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2367924372%_))))
                                        (let ((_%$%lp-tl2368424384%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2368224377%_)))
                                              (_%$%lp-hd2368324381%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2368224377%_))))
                                          (_%$%loop2368124368%_
                                           _%$%lp-tl2368424384%_
                                           (cons _%$%lp-hd2368324381%_
                                                 _%$%declared2368524375%_))))
                                      (let ((_%$%declared2368624387%_
                                             (reverse _%$%declared2368524375%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2367724359%_))
                                            (let ((_%$%e2368724390%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2367724359%_))))
                                              (let ((_%$%tl2368924397%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2368724390%_)))
                                                    (_%$%hd2368824394%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2368724390%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2368824394%_))
                                                    (let ((_%__splice3890238903%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2368824394%_
                                                              '0))))
                                                      (let ((_%$%tl2369224403%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3890238903%_ '1)))
                    (_%$%target2369024400%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3890238903%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2369224403%_))
                    (letrec ((_%$%loop2369324406%_
                              (lambda (_%$%hd2369124410%_
                                       _%$%lowered2369724413%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2369124410%_))
                                    (let ((_%$%e2369424415%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2369124410%_))))
                                      (let ((_%$%lp-tl2369624422%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2369424415%_)))
                                            (_%$%lp-hd2369524419%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2369424415%_))))
                                        (_%$%loop2369324406%_
                                         _%$%lp-tl2369624422%_
                                         (cons _%$%lp-hd2369524419%_
                                               _%$%lowered2369724413%_))))
                                    (let ((_%$%lowered2369824425%_
                                           (reverse _%$%lowered2369724413%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2368924397%_))
                                          (let ((_%$%e2369924428%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2368924397%_))))
                                            (let ((_%$%tl2370124435%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2369924428%_)))
                                                  (_%$%hd2370024432%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2369924428%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2370024432%_))
                                                  (let ((_%$%e2370224438%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2370024432%_))))
                                                    (let ((_%$%tl2370424445%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2370224438%_)))
                                                          (_%$%hd2370324442%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2370224438%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2370324442%_))
                                                          (if (let ((__tmp39127
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39128_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39127 _%$%hd2370324442%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2370424445%_))
                          (let ((_%$%e2370524448%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2370424445%_))))
                            (let ((_%$%tl2370724455%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2370524448%_)))
                                  (_%$%hd2370624452%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2370524448%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%tl2370724455%_))
                                  (let ((_%__splice3890438905%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice->vector
                                            _%$%tl2370724455%_
                                            '0))))
                                    (let ((_%$%tl2371024461%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3890438905%_
                                              '1)))
                                          (_%$%target2370824458%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3890438905%_
                                              '0))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2371024461%_))
                                          (letrec ((_%$%loop2371124464%_
                                                    (lambda (_%$%hd2370924468%_
                                                             _%$%body2371524471%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd2370924468%_))
                                                          (let ((_%$%e2371224473%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd2370924468%_))))
                    (let ((_%$%lp-tl2371424480%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2371224473%_)))
                          (_%$%lp-hd2371324477%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2371224473%_))))
                      (_%$%loop2371124464%_
                       _%$%lp-tl2371424480%_
                       (cons _%$%lp-hd2371324477%_ _%$%body2371524471%_))))
                  (let ((_%$%body2371624483%_ (reverse _%$%body2371524471%_)))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair/null? _%$%tl2370124435%_))
                        (let ((_%__splice3890638907%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-split-splice->vector
                                  _%$%tl2370124435%_
                                  '0))))
                          (let ((_%$%tl2371924489%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3890638907%_ '1)))
                                (_%$%target2371724486%_
                                 (let ()
                                   (declare (not safe))
                                   (##vector-ref _%__splice3890638907%_ '0))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2371924489%_))
                                (letrec ((_%$%loop2372024492%_
                                          (lambda (_%$%hd2371824496%_
                                                   _%$%rest2372424499%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%hd2371824496%_))
                                                (let ((_%$%e2372124501%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%hd2371824496%_))))
                                                  (let ((_%$%lp-tl2372324508%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2372124501%_)))
                                                        (_%$%lp-hd2372224505%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2372124501%_))))
                                                    (_%$%loop2372024492%_
                                                     _%$%lp-tl2372324508%_
                                                     (cons _%$%lp-hd2372224505%_
                                                           _%$%rest2372424499%_))))
                                                (let ((_%$%rest2372524511%_
                                                       (reverse _%$%rest2372424499%_)))
                                                  (_%__kont3889838899%_
                                                   _%$%rest2372524511%_
                                                   _%$%body2371624483%_
                                                   _%$%hd2370624452%_
                                                   _%$%lowered2369824425%_
                                                   _%$%declared2368624387%_))))))
                                  (_%$%loop2372024492%_
                                   _%$%target2371724486%_
                                   '()))
                                (_%__match3902839029%_
                                 _%$%e2367224342%_
                                 _%$%hd2367324346%_
                                 _%$%tl2367424349%_
                                 _%$%e2367524352%_
                                 _%$%hd2367624356%_
                                 _%$%tl2367724359%_
                                 _%__splice3890038901%_
                                 _%$%target2367824362%_
                                 _%$%tl2368024365%_))))
                        (_%__match3902839029%_
                         _%$%e2367224342%_
                         _%$%hd2367324346%_
                         _%$%tl2367424349%_
                         _%$%e2367524352%_
                         _%$%hd2367624356%_
                         _%$%tl2367724359%_
                         _%__splice3890038901%_
                         _%$%target2367824362%_
                         _%$%tl2368024365%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (_%$%loop2371124464%_
                                             _%$%target2370824458%_
                                             '()))
                                          (_%__match3902839029%_
                                           _%$%e2367224342%_
                                           _%$%hd2367324346%_
                                           _%$%tl2367424349%_
                                           _%$%e2367524352%_
                                           _%$%hd2367624356%_
                                           _%$%tl2367724359%_
                                           _%__splice3890038901%_
                                           _%$%target2367824362%_
                                           _%$%tl2368024365%_))))
                                  (_%__match3902839029%_
                                   _%$%e2367224342%_
                                   _%$%hd2367324346%_
                                   _%$%tl2367424349%_
                                   _%$%e2367524352%_
                                   _%$%hd2367624356%_
                                   _%$%tl2367724359%_
                                   _%__splice3890038901%_
                                   _%$%target2367824362%_
                                   _%$%tl2368024365%_))))
                          (_%__match3902839029%_
                           _%$%e2367224342%_
                           _%$%hd2367324346%_
                           _%$%tl2367424349%_
                           _%$%e2367524352%_
                           _%$%hd2367624356%_
                           _%$%tl2367724359%_
                           _%__splice3890038901%_
                           _%$%target2367824362%_
                           _%$%tl2368024365%_))
                      (_%__match3902839029%_
                       _%$%e2367224342%_
                       _%$%hd2367324346%_
                       _%$%tl2367424349%_
                       _%$%e2367524352%_
                       _%$%hd2367624356%_
                       _%$%tl2367724359%_
                       _%__splice3890038901%_
                       _%$%target2367824362%_
                       _%$%tl2368024365%_))
                  (_%__match3902839029%_
                   _%$%e2367224342%_
                   _%$%hd2367324346%_
                   _%$%tl2367424349%_
                   _%$%e2367524352%_
                   _%$%hd2367624356%_
                   _%$%tl2367724359%_
                   _%__splice3890038901%_
                   _%$%target2367824362%_
                   _%$%tl2368024365%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3902839029%_
                                                   _%$%e2367224342%_
                                                   _%$%hd2367324346%_
                                                   _%$%tl2367424349%_
                                                   _%$%e2367524352%_
                                                   _%$%hd2367624356%_
                                                   _%$%tl2367724359%_
                                                   _%__splice3890038901%_
                                                   _%$%target2367824362%_
                                                   _%$%tl2368024365%_))))
                                          (_%__match3902839029%_
                                           _%$%e2367224342%_
                                           _%$%hd2367324346%_
                                           _%$%tl2367424349%_
                                           _%$%e2367524352%_
                                           _%$%hd2367624356%_
                                           _%$%tl2367724359%_
                                           _%__splice3890038901%_
                                           _%$%target2367824362%_
                                           _%$%tl2368024365%_)))))))
                      (_%$%loop2369324406%_ _%$%target2369024400%_ '()))
                    (_%__match3902839029%_
                     _%$%e2367224342%_
                     _%$%hd2367324346%_
                     _%$%tl2367424349%_
                     _%$%e2367524352%_
                     _%$%hd2367624356%_
                     _%$%tl2367724359%_
                     _%__splice3890038901%_
                     _%$%target2367824362%_
                     _%$%tl2368024365%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3902839029%_
                                                     _%$%e2367224342%_
                                                     _%$%hd2367324346%_
                                                     _%$%tl2367424349%_
                                                     _%$%e2367524352%_
                                                     _%$%hd2367624356%_
                                                     _%$%tl2367724359%_
                                                     _%__splice3890038901%_
                                                     _%$%target2367824362%_
                                                     _%$%tl2368024365%_))))
                                            (_%__match3902839029%_
                                             _%$%e2367224342%_
                                             _%$%hd2367324346%_
                                             _%$%tl2367424349%_
                                             _%$%e2367524352%_
                                             _%$%hd2367624356%_
                                             _%$%tl2367724359%_
                                             _%__splice3890038901%_
                                             _%$%target2367824362%_
                                             _%$%tl2368024365%_)))))))
                        (_%$%loop2368124368%_ _%$%target2367824362%_ '()))))
                   (_%__match3898838989%_
                    (lambda (_%$%e2361024598%_
                             _%$%hd2361124602%_
                             _%$%tl2361224605%_
                             _%$%e2361324608%_
                             _%$%hd2361424612%_
                             _%$%tl2361524615%_
                             _%__splice3889038891%_
                             _%$%target2361624618%_
                             _%$%tl2361824621%_)
                      (letrec ((_%$%loop2361924624%_
                                (lambda (_%$%hd2361724628%_
                                         _%$%declared2362324631%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2361724628%_))
                                      (let ((_%$%e2362024633%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2361724628%_))))
                                        (let ((_%$%lp-tl2362224640%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2362024633%_)))
                                              (_%$%lp-hd2362124637%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2362024633%_))))
                                          (_%$%loop2361924624%_
                                           _%$%lp-tl2362224640%_
                                           (cons _%$%lp-hd2362124637%_
                                                 _%$%declared2362324631%_))))
                                      (let ((_%$%declared2362424643%_
                                             (reverse _%$%declared2362324631%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2361524615%_))
                                            (let ((_%$%e2362524646%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2361524615%_))))
                                              (let ((_%$%tl2362724653%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2362524646%_)))
                                                    (_%$%hd2362624650%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2362524646%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2362624650%_))
                                                    (let ((_%__splice3889238893%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2362624650%_
                                                              '0))))
                                                      (let ((_%$%tl2363024659%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3889238893%_ '1)))
                    (_%$%target2362824656%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3889238893%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2363024659%_))
                    (letrec ((_%$%loop2363124662%_
                              (lambda (_%$%hd2362924666%_
                                       _%$%lowered2363524669%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2362924666%_))
                                    (let ((_%$%e2363224671%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2362924666%_))))
                                      (let ((_%$%lp-tl2363424678%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2363224671%_)))
                                            (_%$%lp-hd2363324675%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2363224671%_))))
                                        (_%$%loop2363124662%_
                                         _%$%lp-tl2363424678%_
                                         (cons _%$%lp-hd2363324675%_
                                               _%$%lowered2363524669%_))))
                                    (let ((_%$%lowered2363624681%_
                                           (reverse _%$%lowered2363524669%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2362724653%_))
                                          (let ((_%$%e2363724684%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2362724653%_))))
                                            (let ((_%$%tl2363924691%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2363724684%_)))
                                                  (_%$%hd2363824688%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2363724684%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2363824688%_))
                                                  (let ((_%$%e2364024694%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2363824688%_))))
                                                    (let ((_%$%tl2364224701%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2364024694%_)))
                                                          (_%$%hd2364124698%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2364024694%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2364124698%_))
                                                          (if (let ((__tmp39129
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39130_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39129 _%$%hd2364124698%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2364224701%_))
                          (let ((_%$%e2364324704%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2364224701%_))))
                            (let ((_%$%tl2364524711%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2364324704%_)))
                                  (_%$%hd2364424708%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2364324704%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2364524711%_))
                                  (let ((_%$%e2364624714%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2364524711%_))))
                                    (let ((_%$%tl2364824721%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2364624714%_)))
                                          (_%$%hd2364724718%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2364624714%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2364724718%_))
                                          (let ((_%__splice3889438895%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2364724718%_
                                                    '0))))
                                            (let ((_%$%tl2365124727%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3889438895%_
                                                      '1)))
                                                  (_%$%target2364924724%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3889438895%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2365124727%_))
                                                  (letrec ((_%$%loop2365224730%_
                                                            (lambda (_%$%hd2365024734%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2365624737%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2365024734%_))
                          (let ((_%$%e2365324739%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2365024734%_))))
                            (let ((_%$%lp-tl2365524746%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2365324739%_)))
                                  (_%$%lp-hd2365424743%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2365324739%_))))
                              (_%$%loop2365224730%_
                               _%$%lp-tl2365524746%_
                               (cons _%$%lp-hd2365424743%_
                                     _%$%column2365624737%_))))
                          (let ((_%$%column2365724749%_
                                 (reverse _%$%column2365624737%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2364824721%_))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair/null? _%$%tl2363924691%_))
                                    (let ((_%__splice3889638897%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-split-splice->vector
                                              _%$%tl2363924691%_
                                              '0))))
                                      (let ((_%$%tl2366024755%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3889638897%_
                                                '1)))
                                            (_%$%target2365824752%_
                                             (let ()
                                               (declare (not safe))
                                               (##vector-ref
                                                _%__splice3889638897%_
                                                '0))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2366024755%_))
                                            (letrec ((_%$%loop2366124758%_
                                                      (lambda (_%$%hd2365924762%_
                                                               _%$%rest2366524765%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd2365924762%_))
                                                            (let ((_%$%e2366224767%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2365924762%_))))
                      (let ((_%$%lp-tl2366424774%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2366224767%_)))
                            (_%$%lp-hd2366324771%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2366224767%_))))
                        (_%$%loop2366124758%_
                         _%$%lp-tl2366424774%_
                         (cons _%$%lp-hd2366324771%_ _%$%rest2366524765%_))))
                    (let ((_%$%rest2366624777%_
                           (reverse _%$%rest2366524765%_)))
                      (let ((_%$%g2360524780%_ _%$%rest2366624777%_)
                            (_%$%g2360624782%_ _%$%column2365724749%_)
                            (_%$%g2360724783%_ _%$%hd2364424708%_)
                            (_%$%g2360824784%_ _%$%lowered2363624681%_)
                            (_%$%g2360924785%_ _%$%declared2362424643%_))
                        (if (and (let ()
                                   (declare (not safe))
                                   (gx#identifier? _%$%g2360724783%_))
                                 (let ((__tmp39131
                                        (let ((__tmp39132
                                               (let ((__tmp39133
                                                      (lambda (_%$%g2482624829%_
                                                               _%$%g2482724832%_)
                                                        (cons _%$%g2482624829%_
                                                              _%$%g2482724832%_))))
                                                 (declare (not safe))
                                                 (foldr__0
                                                  __tmp39133
                                                  '()
                                                  _%$%g2360624782%_))))
                                          (declare (not safe))
                                          (gx#syntax->list __tmp39132))))
                                   (declare (not safe))
                                   (andmap__0 gx#identifier? __tmp39131)))
                            (_%__kont3888838889%_
                             _%$%g2360524780%_
                             _%$%g2360624782%_
                             _%$%g2360724783%_
                             _%$%g2360824784%_
                             _%$%g2360924785%_)
                            (_%__match3900839009%_
                             _%$%e2361024598%_
                             _%$%hd2361124602%_
                             _%$%tl2361224605%_
                             _%$%e2361324608%_
                             _%$%hd2361424612%_
                             _%$%tl2361524615%_
                             _%__splice3889038891%_
                             _%$%target2361624618%_
                             _%$%tl2361824621%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop2366124758%_
                                               _%$%target2365824752%_
                                               '()))
                                            (_%__match3900839009%_
                                             _%$%e2361024598%_
                                             _%$%hd2361124602%_
                                             _%$%tl2361224605%_
                                             _%$%e2361324608%_
                                             _%$%hd2361424612%_
                                             _%$%tl2361524615%_
                                             _%__splice3889038891%_
                                             _%$%target2361624618%_
                                             _%$%tl2361824621%_))))
                                    (_%__match3900839009%_
                                     _%$%e2361024598%_
                                     _%$%hd2361124602%_
                                     _%$%tl2361224605%_
                                     _%$%e2361324608%_
                                     _%$%hd2361424612%_
                                     _%$%tl2361524615%_
                                     _%__splice3889038891%_
                                     _%$%target2361624618%_
                                     _%$%tl2361824621%_))
                                (_%__match3900839009%_
                                 _%$%e2361024598%_
                                 _%$%hd2361124602%_
                                 _%$%tl2361224605%_
                                 _%$%e2361324608%_
                                 _%$%hd2361424612%_
                                 _%$%tl2361524615%_
                                 _%__splice3889038891%_
                                 _%$%target2361624618%_
                                 _%$%tl2361824621%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2365224730%_
                                                     _%$%target2364924724%_
                                                     '()))
                                                  (_%__match3900839009%_
                                                   _%$%e2361024598%_
                                                   _%$%hd2361124602%_
                                                   _%$%tl2361224605%_
                                                   _%$%e2361324608%_
                                                   _%$%hd2361424612%_
                                                   _%$%tl2361524615%_
                                                   _%__splice3889038891%_
                                                   _%$%target2361624618%_
                                                   _%$%tl2361824621%_))))
                                          (_%__match3900839009%_
                                           _%$%e2361024598%_
                                           _%$%hd2361124602%_
                                           _%$%tl2361224605%_
                                           _%$%e2361324608%_
                                           _%$%hd2361424612%_
                                           _%$%tl2361524615%_
                                           _%__splice3889038891%_
                                           _%$%target2361624618%_
                                           _%$%tl2361824621%_))))
                                  (_%__match3900839009%_
                                   _%$%e2361024598%_
                                   _%$%hd2361124602%_
                                   _%$%tl2361224605%_
                                   _%$%e2361324608%_
                                   _%$%hd2361424612%_
                                   _%$%tl2361524615%_
                                   _%__splice3889038891%_
                                   _%$%target2361624618%_
                                   _%$%tl2361824621%_))))
                          (_%__match3900839009%_
                           _%$%e2361024598%_
                           _%$%hd2361124602%_
                           _%$%tl2361224605%_
                           _%$%e2361324608%_
                           _%$%hd2361424612%_
                           _%$%tl2361524615%_
                           _%__splice3889038891%_
                           _%$%target2361624618%_
                           _%$%tl2361824621%_))
                      (_%__match3900839009%_
                       _%$%e2361024598%_
                       _%$%hd2361124602%_
                       _%$%tl2361224605%_
                       _%$%e2361324608%_
                       _%$%hd2361424612%_
                       _%$%tl2361524615%_
                       _%__splice3889038891%_
                       _%$%target2361624618%_
                       _%$%tl2361824621%_))
                  (_%__match3900839009%_
                   _%$%e2361024598%_
                   _%$%hd2361124602%_
                   _%$%tl2361224605%_
                   _%$%e2361324608%_
                   _%$%hd2361424612%_
                   _%$%tl2361524615%_
                   _%__splice3889038891%_
                   _%$%target2361624618%_
                   _%$%tl2361824621%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3900839009%_
                                                   _%$%e2361024598%_
                                                   _%$%hd2361124602%_
                                                   _%$%tl2361224605%_
                                                   _%$%e2361324608%_
                                                   _%$%hd2361424612%_
                                                   _%$%tl2361524615%_
                                                   _%__splice3889038891%_
                                                   _%$%target2361624618%_
                                                   _%$%tl2361824621%_))))
                                          (_%__match3900839009%_
                                           _%$%e2361024598%_
                                           _%$%hd2361124602%_
                                           _%$%tl2361224605%_
                                           _%$%e2361324608%_
                                           _%$%hd2361424612%_
                                           _%$%tl2361524615%_
                                           _%__splice3889038891%_
                                           _%$%target2361624618%_
                                           _%$%tl2361824621%_)))))))
                      (_%$%loop2363124662%_ _%$%target2362824656%_ '()))
                    (_%__match3900839009%_
                     _%$%e2361024598%_
                     _%$%hd2361124602%_
                     _%$%tl2361224605%_
                     _%$%e2361324608%_
                     _%$%hd2361424612%_
                     _%$%tl2361524615%_
                     _%__splice3889038891%_
                     _%$%target2361624618%_
                     _%$%tl2361824621%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3900839009%_
                                                     _%$%e2361024598%_
                                                     _%$%hd2361124602%_
                                                     _%$%tl2361224605%_
                                                     _%$%e2361324608%_
                                                     _%$%hd2361424612%_
                                                     _%$%tl2361524615%_
                                                     _%__splice3889038891%_
                                                     _%$%target2361624618%_
                                                     _%$%tl2361824621%_))))
                                            (_%__match3900839009%_
                                             _%$%e2361024598%_
                                             _%$%hd2361124602%_
                                             _%$%tl2361224605%_
                                             _%$%e2361324608%_
                                             _%$%hd2361424612%_
                                             _%$%tl2361524615%_
                                             _%__splice3889038891%_
                                             _%$%target2361624618%_
                                             _%$%tl2361824621%_)))))))
                        (_%$%loop2361924624%_ _%$%target2361624618%_ '()))))
                   (_%__match3896838969%_
                    (lambda (_%$%e2354524874%_
                             _%$%hd2354624878%_
                             _%$%tl2354724881%_
                             _%$%e2354824884%_
                             _%$%hd2354924888%_
                             _%$%tl2355024891%_
                             _%__splice3888038881%_
                             _%$%target2355124894%_
                             _%$%tl2355324897%_)
                      (letrec ((_%$%loop2355424900%_
                                (lambda (_%$%hd2355224904%_
                                         _%$%declared2355824907%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2355224904%_))
                                      (let ((_%$%e2355524909%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2355224904%_))))
                                        (let ((_%$%lp-tl2355724916%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2355524909%_)))
                                              (_%$%lp-hd2355624913%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2355524909%_))))
                                          (_%$%loop2355424900%_
                                           _%$%lp-tl2355724916%_
                                           (cons _%$%lp-hd2355624913%_
                                                 _%$%declared2355824907%_))))
                                      (let ((_%$%declared2355924919%_
                                             (reverse _%$%declared2355824907%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2355024891%_))
                                            (let ((_%$%e2356024922%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2355024891%_))))
                                              (let ((_%$%tl2356224929%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2356024922%_)))
                                                    (_%$%hd2356124926%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2356024922%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2356124926%_))
                                                    (let ((_%__splice3888238883%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2356124926%_
                                                              '0))))
                                                      (let ((_%$%tl2356524935%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3888238883%_ '1)))
                    (_%$%target2356324932%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3888238883%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2356524935%_))
                    (letrec ((_%$%loop2356624938%_
                              (lambda (_%$%hd2356424942%_
                                       _%$%lowered2357024945%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2356424942%_))
                                    (let ((_%$%e2356724947%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2356424942%_))))
                                      (let ((_%$%lp-tl2356924954%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2356724947%_)))
                                            (_%$%lp-hd2356824951%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2356724947%_))))
                                        (_%$%loop2356624938%_
                                         _%$%lp-tl2356924954%_
                                         (cons _%$%lp-hd2356824951%_
                                               _%$%lowered2357024945%_))))
                                    (let ((_%$%lowered2357124957%_
                                           (reverse _%$%lowered2357024945%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2356224929%_))
                                          (let ((_%$%e2357224960%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2356224929%_))))
                                            (let ((_%$%tl2357424967%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2357224960%_)))
                                                  (_%$%hd2357324964%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2357224960%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2357324964%_))
                                                  (let ((_%$%e2357524970%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2357324964%_))))
                                                    (let ((_%$%tl2357724977%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2357524970%_)))
                                                          (_%$%hd2357624974%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2357524970%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2357624974%_))
                                                          (if (let ((__tmp39134
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39135_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39134 _%$%hd2357624974%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2357724977%_))
                          (let ((_%$%e2357824980%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2357724977%_))))
                            (let ((_%$%tl2358024987%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2357824980%_)))
                                  (_%$%hd2357924984%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2357824980%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2358024987%_))
                                  (let ((_%$%e2358124990%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2358024987%_))))
                                    (let ((_%$%tl2358324997%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2358124990%_)))
                                          (_%$%hd2358224994%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2358124990%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2358224994%_))
                                          (let ((_%__splice3888438885%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2358224994%_
                                                    '0))))
                                            (let ((_%$%tl2358625003%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3888438885%_
                                                      '1)))
                                                  (_%$%target2358425000%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3888438885%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2358625003%_))
                                                  (letrec ((_%$%loop2358725006%_
                                                            (lambda (_%$%hd2358525010%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2359125013%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2358525010%_))
                          (let ((_%$%e2358825015%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2358525010%_))))
                            (let ((_%$%lp-tl2359025022%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2358825015%_)))
                                  (_%$%lp-hd2358925019%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2358825015%_))))
                              (_%$%loop2358725006%_
                               _%$%lp-tl2359025022%_
                               (cons _%$%lp-hd2358925019%_
                                     _%$%column2359125013%_))))
                          (let ((_%$%column2359225025%_
                                 (reverse _%$%column2359125013%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2358324997%_))
                                (let ((_%$%e2359325028%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2358324997%_))))
                                  (let ((_%$%tl2359525035%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2359325028%_)))
                                        (_%$%hd2359425032%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2359325028%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2359525035%_))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair/null?
                                               _%$%tl2357424967%_))
                                            (let ((_%__splice3888638887%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-split-splice->vector
                                                      _%$%tl2357424967%_
                                                      '0))))
                                              (let ((_%$%tl2359825041%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3888638887%_
                                                        '1)))
                                                    (_%$%target2359625038%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##vector-ref
                                                        _%__splice3888638887%_
                                                        '0))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-null?
                                                       _%$%tl2359825041%_))
                                                    (letrec ((_%$%loop2359925044%_
                                                              (lambda (_%$%hd2359725048%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%rest2360325051%_)
                        (if (let ()
                              (declare (not safe))
                              (gx#stx-pair? _%$%hd2359725048%_))
                            (let ((_%$%e2360025053%_
                                   (let ()
                                     (declare (not safe))
                                     (gx#syntax-e _%$%hd2359725048%_))))
                              (let ((_%$%lp-tl2360225060%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%e2360025053%_)))
                                    (_%$%lp-hd2360125057%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%e2360025053%_))))
                                (_%$%loop2359925044%_
                                 _%$%lp-tl2360225060%_
                                 (cons _%$%lp-hd2360125057%_
                                       _%$%rest2360325051%_))))
                            (let ((_%$%rest2360425063%_
                                   (reverse _%$%rest2360325051%_)))
                              (let ((_%$%g2353925066%_ _%$%rest2360425063%_)
                                    (_%$%g2354025068%_ _%$%hd2359425032%_)
                                    (_%$%g2354125069%_ _%$%column2359225025%_)
                                    (_%$%g2354225070%_ _%$%hd2357924984%_)
                                    (_%$%g2354325071%_ _%$%lowered2357124957%_)
                                    (_%$%g2354425072%_
                                     _%$%declared2355924919%_))
                                (if (and (let ()
                                           (declare (not safe))
                                           (gx#identifier? _%$%g2354225070%_))
                                         (let ((__tmp39136
                                                (let ((__tmp39137
                                                       (let ((__tmp39138
                                                              (lambda (_%$%g2511625119%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               _%$%g2511725122%_)
                        (cons _%$%g2511625119%_ _%$%g2511725122%_))))
                 (declare (not safe))
                 (foldr__0 __tmp39138 '() _%$%g2354125069%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (declare (not safe))
                                                  (gx#syntax->list
                                                   __tmp39137))))
                                           (declare (not safe))
                                           (andmap__0
                                            gx#identifier?
                                            __tmp39136)))
                                    (_%__kont3887838879%_
                                     _%$%g2353925066%_
                                     _%$%g2354025068%_
                                     _%$%g2354125069%_
                                     _%$%g2354225070%_
                                     _%$%g2354325071%_
                                     _%$%g2354425072%_)
                                    (_%__match3898838989%_
                                     _%$%e2354524874%_
                                     _%$%hd2354624878%_
                                     _%$%tl2354724881%_
                                     _%$%e2354824884%_
                                     _%$%hd2354924888%_
                                     _%$%tl2355024891%_
                                     _%__splice3888038881%_
                                     _%$%target2355124894%_
                                     _%$%tl2355324897%_))))))))
              (_%$%loop2359925044%_ _%$%target2359625038%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3898838989%_
                                                     _%$%e2354524874%_
                                                     _%$%hd2354624878%_
                                                     _%$%tl2354724881%_
                                                     _%$%e2354824884%_
                                                     _%$%hd2354924888%_
                                                     _%$%tl2355024891%_
                                                     _%__splice3888038881%_
                                                     _%$%target2355124894%_
                                                     _%$%tl2355324897%_))))
                                            (_%__match3898838989%_
                                             _%$%e2354524874%_
                                             _%$%hd2354624878%_
                                             _%$%tl2354724881%_
                                             _%$%e2354824884%_
                                             _%$%hd2354924888%_
                                             _%$%tl2355024891%_
                                             _%__splice3888038881%_
                                             _%$%target2355124894%_
                                             _%$%tl2355324897%_))
                                        (_%__match3898838989%_
                                         _%$%e2354524874%_
                                         _%$%hd2354624878%_
                                         _%$%tl2354724881%_
                                         _%$%e2354824884%_
                                         _%$%hd2354924888%_
                                         _%$%tl2355024891%_
                                         _%__splice3888038881%_
                                         _%$%target2355124894%_
                                         _%$%tl2355324897%_))))
                                (_%__match3898838989%_
                                 _%$%e2354524874%_
                                 _%$%hd2354624878%_
                                 _%$%tl2354724881%_
                                 _%$%e2354824884%_
                                 _%$%hd2354924888%_
                                 _%$%tl2355024891%_
                                 _%__splice3888038881%_
                                 _%$%target2355124894%_
                                 _%$%tl2355324897%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2358725006%_
                                                     _%$%target2358425000%_
                                                     '()))
                                                  (_%__match3898838989%_
                                                   _%$%e2354524874%_
                                                   _%$%hd2354624878%_
                                                   _%$%tl2354724881%_
                                                   _%$%e2354824884%_
                                                   _%$%hd2354924888%_
                                                   _%$%tl2355024891%_
                                                   _%__splice3888038881%_
                                                   _%$%target2355124894%_
                                                   _%$%tl2355324897%_))))
                                          (_%__match3898838989%_
                                           _%$%e2354524874%_
                                           _%$%hd2354624878%_
                                           _%$%tl2354724881%_
                                           _%$%e2354824884%_
                                           _%$%hd2354924888%_
                                           _%$%tl2355024891%_
                                           _%__splice3888038881%_
                                           _%$%target2355124894%_
                                           _%$%tl2355324897%_))))
                                  (_%__match3898838989%_
                                   _%$%e2354524874%_
                                   _%$%hd2354624878%_
                                   _%$%tl2354724881%_
                                   _%$%e2354824884%_
                                   _%$%hd2354924888%_
                                   _%$%tl2355024891%_
                                   _%__splice3888038881%_
                                   _%$%target2355124894%_
                                   _%$%tl2355324897%_))))
                          (_%__match3898838989%_
                           _%$%e2354524874%_
                           _%$%hd2354624878%_
                           _%$%tl2354724881%_
                           _%$%e2354824884%_
                           _%$%hd2354924888%_
                           _%$%tl2355024891%_
                           _%__splice3888038881%_
                           _%$%target2355124894%_
                           _%$%tl2355324897%_))
                      (_%__match3898838989%_
                       _%$%e2354524874%_
                       _%$%hd2354624878%_
                       _%$%tl2354724881%_
                       _%$%e2354824884%_
                       _%$%hd2354924888%_
                       _%$%tl2355024891%_
                       _%__splice3888038881%_
                       _%$%target2355124894%_
                       _%$%tl2355324897%_))
                  (_%__match3898838989%_
                   _%$%e2354524874%_
                   _%$%hd2354624878%_
                   _%$%tl2354724881%_
                   _%$%e2354824884%_
                   _%$%hd2354924888%_
                   _%$%tl2355024891%_
                   _%__splice3888038881%_
                   _%$%target2355124894%_
                   _%$%tl2355324897%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3898838989%_
                                                   _%$%e2354524874%_
                                                   _%$%hd2354624878%_
                                                   _%$%tl2354724881%_
                                                   _%$%e2354824884%_
                                                   _%$%hd2354924888%_
                                                   _%$%tl2355024891%_
                                                   _%__splice3888038881%_
                                                   _%$%target2355124894%_
                                                   _%$%tl2355324897%_))))
                                          (_%__match3898838989%_
                                           _%$%e2354524874%_
                                           _%$%hd2354624878%_
                                           _%$%tl2354724881%_
                                           _%$%e2354824884%_
                                           _%$%hd2354924888%_
                                           _%$%tl2355024891%_
                                           _%__splice3888038881%_
                                           _%$%target2355124894%_
                                           _%$%tl2355324897%_)))))))
                      (_%$%loop2356624938%_ _%$%target2356324932%_ '()))
                    (_%__match3898838989%_
                     _%$%e2354524874%_
                     _%$%hd2354624878%_
                     _%$%tl2354724881%_
                     _%$%e2354824884%_
                     _%$%hd2354924888%_
                     _%$%tl2355024891%_
                     _%__splice3888038881%_
                     _%$%target2355124894%_
                     _%$%tl2355324897%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3898838989%_
                                                     _%$%e2354524874%_
                                                     _%$%hd2354624878%_
                                                     _%$%tl2354724881%_
                                                     _%$%e2354824884%_
                                                     _%$%hd2354924888%_
                                                     _%$%tl2355024891%_
                                                     _%__splice3888038881%_
                                                     _%$%target2355124894%_
                                                     _%$%tl2355324897%_))))
                                            (_%__match3898838989%_
                                             _%$%e2354524874%_
                                             _%$%hd2354624878%_
                                             _%$%tl2354724881%_
                                             _%$%e2354824884%_
                                             _%$%hd2354924888%_
                                             _%$%tl2355024891%_
                                             _%__splice3888038881%_
                                             _%$%target2355124894%_
                                             _%$%tl2355324897%_)))))))
                        (_%$%loop2355424900%_ _%$%target2355124894%_ '()))))
                   (_%__match3894838949%_
                    (lambda (_%$%e2347625164%_
                             _%$%hd2347725168%_
                             _%$%tl2347825171%_
                             _%$%e2347925174%_
                             _%$%hd2348025178%_
                             _%$%tl2348125181%_
                             _%__splice3887038871%_
                             _%$%target2348225184%_
                             _%$%tl2348425187%_)
                      (letrec ((_%$%loop2348525190%_
                                (lambda (_%$%hd2348325194%_
                                         _%$%declared2348925197%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2348325194%_))
                                      (let ((_%$%e2348625199%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2348325194%_))))
                                        (let ((_%$%lp-tl2348825206%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2348625199%_)))
                                              (_%$%lp-hd2348725203%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2348625199%_))))
                                          (_%$%loop2348525190%_
                                           _%$%lp-tl2348825206%_
                                           (cons _%$%lp-hd2348725203%_
                                                 _%$%declared2348925197%_))))
                                      (let ((_%$%declared2349025209%_
                                             (reverse _%$%declared2348925197%_)))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-pair?
                                               _%$%tl2348125181%_))
                                            (let ((_%$%e2349125212%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gx#syntax-e
                                                      _%$%tl2348125181%_))))
                                              (let ((_%$%tl2349325219%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%e2349125212%_)))
                                                    (_%$%hd2349225216%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%e2349125212%_))))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%hd2349225216%_))
                                                    (let ((_%__splice3887238873%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%hd2349225216%_
                                                              '0))))
                                                      (let ((_%$%tl2349625225%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3887238873%_ '1)))
                    (_%$%target2349425222%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3887238873%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2349625225%_))
                    (letrec ((_%$%loop2349725228%_
                              (lambda (_%$%hd2349525232%_
                                       _%$%lowered2350125235%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2349525232%_))
                                    (let ((_%$%e2349825237%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2349525232%_))))
                                      (let ((_%$%lp-tl2350025244%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2349825237%_)))
                                            (_%$%lp-hd2349925241%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2349825237%_))))
                                        (_%$%loop2349725228%_
                                         _%$%lp-tl2350025244%_
                                         (cons _%$%lp-hd2349925241%_
                                               _%$%lowered2350125235%_))))
                                    (let ((_%$%lowered2350225247%_
                                           (reverse _%$%lowered2350125235%_)))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl2349325219%_))
                                          (let ((_%$%e2350325250%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl2349325219%_))))
                                            (let ((_%$%tl2350525257%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2350325250%_)))
                                                  (_%$%hd2350425254%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2350325250%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd2350425254%_))
                                                  (let ((_%$%e2350625260%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd2350425254%_))))
                                                    (let ((_%$%tl2350825267%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e2350625260%_)))
                                                          (_%$%hd2350725264%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e2350625260%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#identifier?
                                                             _%$%hd2350725264%_))
                                                          (if (let ((__tmp39139
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/scheme-language[1]#_g39140_|))
                        (declare (not safe))
                        (gx#free-identifier=? __tmp39139 _%$%hd2350725264%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2350825267%_))
                          (let ((_%$%e2350925270%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2350825267%_))))
                            (let ((_%$%tl2351125277%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2350925270%_)))
                                  (_%$%hd2351025274%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2350925270%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl2351125277%_))
                                  (let ((_%$%e2351225280%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl2351125277%_))))
                                    (let ((_%$%tl2351425287%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e2351225280%_)))
                                          (_%$%hd2351325284%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e2351225280%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair/null?
                                             _%$%hd2351325284%_))
                                          (let ((_%__splice3887438875%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-split-splice->vector
                                                    _%$%hd2351325284%_
                                                    '0))))
                                            (let ((_%$%tl2351725293%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3887438875%_
                                                      '1)))
                                                  (_%$%target2351525290%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##vector-ref
                                                      _%__splice3887438875%_
                                                      '0))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2351725293%_))
                                                  (letrec ((_%$%loop2351825296%_
                                                            (lambda (_%$%hd2351625300%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%column2352225303%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2351625300%_))
                          (let ((_%$%e2351925305%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2351625300%_))))
                            (let ((_%$%lp-tl2352125312%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2351925305%_)))
                                  (_%$%lp-hd2352025309%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2351925305%_))))
                              (_%$%loop2351825296%_
                               _%$%lp-tl2352125312%_
                               (cons _%$%lp-hd2352025309%_
                                     _%$%column2352225303%_))))
                          (let ((_%$%column2352325315%_
                                 (reverse _%$%column2352225303%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2351425287%_))
                                (let ((_%$%e2352425318%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2351425287%_))))
                                  (let ((_%$%tl2352625325%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2352425318%_)))
                                        (_%$%hd2352525322%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2352425318%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%tl2352625325%_))
                                        (let ((_%$%e2352725328%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%tl2352625325%_))))
                                          (let ((_%$%tl2352925335%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2352725328%_)))
                                                (_%$%hd2352825332%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2352725328%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2352925335%_))
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair/null?
                                                       _%$%tl2350525257%_))
                                                    (let ((_%__splice3887638877%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-split-splice->vector
                                                              _%$%tl2350525257%_
                                                              '0))))
                                                      (let ((_%$%tl2353225341%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##vector-ref _%__splice3887638877%_ '1)))
                    (_%$%target2353025338%_
                     (let ()
                       (declare (not safe))
                       (##vector-ref _%__splice3887638877%_ '0))))
                (if (let ()
                      (declare (not safe))
                      (gx#stx-null? _%$%tl2353225341%_))
                    (letrec ((_%$%loop2353325344%_
                              (lambda (_%$%hd2353125348%_ _%$%rest2353725351%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-pair? _%$%hd2353125348%_))
                                    (let ((_%$%e2353425353%_
                                           (let ()
                                             (declare (not safe))
                                             (gx#syntax-e
                                              _%$%hd2353125348%_))))
                                      (let ((_%$%lp-tl2353625360%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%e2353425353%_)))
                                            (_%$%lp-hd2353525357%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%e2353425353%_))))
                                        (_%$%loop2353325344%_
                                         _%$%lp-tl2353625360%_
                                         (cons _%$%lp-hd2353525357%_
                                               _%$%rest2353725351%_))))
                                    (let ((_%$%rest2353825363%_
                                           (reverse _%$%rest2353725351%_)))
                                      (let ((_%$%g2346925366%_
                                             _%$%rest2353825363%_)
                                            (_%$%g2347025368%_
                                             _%$%hd2352825332%_)
                                            (_%$%g2347125369%_
                                             _%$%hd2352525322%_)
                                            (_%$%g2347225370%_
                                             _%$%column2352325315%_)
                                            (_%$%g2347325371%_
                                             _%$%hd2351025274%_)
                                            (_%$%g2347425372%_
                                             _%$%lowered2350225247%_)
                                            (_%$%g2347525373%_
                                             _%$%declared2349025209%_))
                                        (if (and (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2347325371%_))
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#identifier?
                                                    _%$%g2347025368%_))
                                                 (let ((__tmp39141
                                                        (let ((__tmp39142
                                                               (let ((__tmp39143
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (lambda (_%$%g2542025423%_ _%$%g2542125426%_)
                                (cons _%$%g2542025423%_ _%$%g2542125426%_))))
                         (declare (not safe))
                         (foldr__0 __tmp39143 '() _%$%g2347225370%_))))
                  (declare (not safe))
                  (gx#syntax->list __tmp39142))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (andmap__0
                                                    gx#identifier?
                                                    __tmp39141)))
                                            (_%__kont3886838869%_
                                             _%$%g2346925366%_
                                             _%$%g2347025368%_
                                             _%$%g2347125369%_
                                             _%$%g2347225370%_
                                             _%$%g2347325371%_
                                             _%$%g2347425372%_
                                             _%$%g2347525373%_)
                                            (_%__match3896838969%_
                                             _%$%e2347625164%_
                                             _%$%hd2347725168%_
                                             _%$%tl2347825171%_
                                             _%$%e2347925174%_
                                             _%$%hd2348025178%_
                                             _%$%tl2348125181%_
                                             _%__splice3887038871%_
                                             _%$%target2348225184%_
                                             _%$%tl2348425187%_))))))))
                      (_%$%loop2353325344%_ _%$%target2353025338%_ '()))
                    (_%__match3896838969%_
                     _%$%e2347625164%_
                     _%$%hd2347725168%_
                     _%$%tl2347825171%_
                     _%$%e2347925174%_
                     _%$%hd2348025178%_
                     _%$%tl2348125181%_
                     _%__splice3887038871%_
                     _%$%target2348225184%_
                     _%$%tl2348425187%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3896838969%_
                                                     _%$%e2347625164%_
                                                     _%$%hd2347725168%_
                                                     _%$%tl2347825171%_
                                                     _%$%e2347925174%_
                                                     _%$%hd2348025178%_
                                                     _%$%tl2348125181%_
                                                     _%__splice3887038871%_
                                                     _%$%target2348225184%_
                                                     _%$%tl2348425187%_))
                                                (_%__match3896838969%_
                                                 _%$%e2347625164%_
                                                 _%$%hd2347725168%_
                                                 _%$%tl2347825171%_
                                                 _%$%e2347925174%_
                                                 _%$%hd2348025178%_
                                                 _%$%tl2348125181%_
                                                 _%__splice3887038871%_
                                                 _%$%target2348225184%_
                                                 _%$%tl2348425187%_))))
                                        (_%__match3896838969%_
                                         _%$%e2347625164%_
                                         _%$%hd2347725168%_
                                         _%$%tl2347825171%_
                                         _%$%e2347925174%_
                                         _%$%hd2348025178%_
                                         _%$%tl2348125181%_
                                         _%__splice3887038871%_
                                         _%$%target2348225184%_
                                         _%$%tl2348425187%_))))
                                (_%__match3896838969%_
                                 _%$%e2347625164%_
                                 _%$%hd2347725168%_
                                 _%$%tl2347825171%_
                                 _%$%e2347925174%_
                                 _%$%hd2348025178%_
                                 _%$%tl2348125181%_
                                 _%__splice3887038871%_
                                 _%$%target2348225184%_
                                 _%$%tl2348425187%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2351825296%_
                                                     _%$%target2351525290%_
                                                     '()))
                                                  (_%__match3896838969%_
                                                   _%$%e2347625164%_
                                                   _%$%hd2347725168%_
                                                   _%$%tl2347825171%_
                                                   _%$%e2347925174%_
                                                   _%$%hd2348025178%_
                                                   _%$%tl2348125181%_
                                                   _%__splice3887038871%_
                                                   _%$%target2348225184%_
                                                   _%$%tl2348425187%_))))
                                          (_%__match3896838969%_
                                           _%$%e2347625164%_
                                           _%$%hd2347725168%_
                                           _%$%tl2347825171%_
                                           _%$%e2347925174%_
                                           _%$%hd2348025178%_
                                           _%$%tl2348125181%_
                                           _%__splice3887038871%_
                                           _%$%target2348225184%_
                                           _%$%tl2348425187%_))))
                                  (_%__match3896838969%_
                                   _%$%e2347625164%_
                                   _%$%hd2347725168%_
                                   _%$%tl2347825171%_
                                   _%$%e2347925174%_
                                   _%$%hd2348025178%_
                                   _%$%tl2348125181%_
                                   _%__splice3887038871%_
                                   _%$%target2348225184%_
                                   _%$%tl2348425187%_))))
                          (_%__match3896838969%_
                           _%$%e2347625164%_
                           _%$%hd2347725168%_
                           _%$%tl2347825171%_
                           _%$%e2347925174%_
                           _%$%hd2348025178%_
                           _%$%tl2348125181%_
                           _%__splice3887038871%_
                           _%$%target2348225184%_
                           _%$%tl2348425187%_))
                      (_%__match3896838969%_
                       _%$%e2347625164%_
                       _%$%hd2347725168%_
                       _%$%tl2347825171%_
                       _%$%e2347925174%_
                       _%$%hd2348025178%_
                       _%$%tl2348125181%_
                       _%__splice3887038871%_
                       _%$%target2348225184%_
                       _%$%tl2348425187%_))
                  (_%__match3896838969%_
                   _%$%e2347625164%_
                   _%$%hd2347725168%_
                   _%$%tl2347825171%_
                   _%$%e2347925174%_
                   _%$%hd2348025178%_
                   _%$%tl2348125181%_
                   _%__splice3887038871%_
                   _%$%target2348225184%_
                   _%$%tl2348425187%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%__match3896838969%_
                                                   _%$%e2347625164%_
                                                   _%$%hd2347725168%_
                                                   _%$%tl2347825171%_
                                                   _%$%e2347925174%_
                                                   _%$%hd2348025178%_
                                                   _%$%tl2348125181%_
                                                   _%__splice3887038871%_
                                                   _%$%target2348225184%_
                                                   _%$%tl2348425187%_))))
                                          (_%__match3896838969%_
                                           _%$%e2347625164%_
                                           _%$%hd2347725168%_
                                           _%$%tl2347825171%_
                                           _%$%e2347925174%_
                                           _%$%hd2348025178%_
                                           _%$%tl2348125181%_
                                           _%__splice3887038871%_
                                           _%$%target2348225184%_
                                           _%$%tl2348425187%_)))))))
                      (_%$%loop2349725228%_ _%$%target2349425222%_ '()))
                    (_%__match3896838969%_
                     _%$%e2347625164%_
                     _%$%hd2347725168%_
                     _%$%tl2347825171%_
                     _%$%e2347925174%_
                     _%$%hd2348025178%_
                     _%$%tl2348125181%_
                     _%__splice3887038871%_
                     _%$%target2348225184%_
                     _%$%tl2348425187%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%__match3896838969%_
                                                     _%$%e2347625164%_
                                                     _%$%hd2347725168%_
                                                     _%$%tl2347825171%_
                                                     _%$%e2347925174%_
                                                     _%$%hd2348025178%_
                                                     _%$%tl2348125181%_
                                                     _%__splice3887038871%_
                                                     _%$%target2348225184%_
                                                     _%$%tl2348425187%_))))
                                            (_%__match3896838969%_
                                             _%$%e2347625164%_
                                             _%$%hd2347725168%_
                                             _%$%tl2347825171%_
                                             _%$%e2347925174%_
                                             _%$%hd2348025178%_
                                             _%$%tl2348125181%_
                                             _%__splice3887038871%_
                                             _%$%target2348225184%_
                                             _%$%tl2348425187%_)))))))
                        (_%$%loop2348525190%_ _%$%target2348225184%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3886538866%_))
                  (let ((_%$%e2347625164%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3886538866%_))))
                    (let ((_%$%tl2347825171%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2347625164%_)))
                          (_%$%hd2347725168%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2347625164%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl2347825171%_))
                          (let ((_%$%e2347925174%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl2347825171%_))))
                            (let ((_%$%tl2348125181%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2347925174%_)))
                                  (_%$%hd2348025178%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2347925174%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%hd2348025178%_))
                                  (let ((_%__splice3887038871%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice->vector
                                            _%$%hd2348025178%_
                                            '0))))
                                    (let ((_%$%tl2348425187%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3887038871%_
                                              '1)))
                                          (_%$%target2348225184%_
                                           (let ()
                                             (declare (not safe))
                                             (##vector-ref
                                              _%__splice3887038871%_
                                              '0))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2348425187%_))
                                          (_%__match3894838949%_
                                           _%$%e2347625164%_
                                           _%$%hd2347725168%_
                                           _%$%tl2347825171%_
                                           _%$%e2347925174%_
                                           _%$%hd2348025178%_
                                           _%$%tl2348125181%_
                                           _%__splice3887038871%_
                                           _%$%target2348225184%_
                                           _%$%tl2348425187%_)
                                          (let ()
                                            (declare (not safe))
                                            (_%$%g2346723850%_)))))
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g2346723850%_)))))
                          (let () (declare (not safe)) (_%$%g2346723850%_)))))
                  (let () (declare (not safe)) (_%$%g2346723850%_))))))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-program|
      (lambda (_%stx25488%_)
        (let* ((_%$%g2549125511%_
                (lambda (_%$%g2549225507%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g2549225507%_))))
               (_%$%g2549025580%_
                (lambda (_%$%g2549225515%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g2549225515%_))
                      (let ((_%$%e2549425518%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g2549225515%_))))
                        (let ((_%$%hd2549525522%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2549425518%_)))
                              (_%$%tl2549625525%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2549425518%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2549625525%_))
                              (let ((_g39144_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice
                                        _%$%tl2549625525%_
                                        '0))))
                                (begin
                                  (let ((_g39145_
                                         (let ()
                                           (declare (not safe))
                                           (if (##values? _g39144_)
                                               (##values-length _g39144_)
                                               1))))
                                    (if (not (let ()
                                               (declare (not safe))
                                               (##fx= _g39145_ 2)))
                                        (error "Context expects 2 values"
                                               _g39145_)))
                                  (let ((_%$%target2549725528%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39144_ 0)))
                                        (_%$%tl2549925531%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39144_ 1))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2549925531%_))
                                        (letrec ((_%$%loop2550025534%_
                                                  (lambda (_%$%hd2549825538%_
                                                           _%$%clause2550425541%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2549825538%_))
                                                        (let ((_%$%e2550125543%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2549825538%_))))
                  (let ((_%$%lp-hd2550225547%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2550125543%_)))
                        (_%$%lp-tl2550325550%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2550125543%_))))
                    (_%$%loop2550025534%_
                     _%$%lp-tl2550325550%_
                     (cons _%$%lp-hd2550225547%_ _%$%clause2550425541%_))))
                (let ((_%$%clause2550525553%_
                       (reverse _%$%clause2550425541%_)))
                  (cons (let ()
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'relational-collect))
                        (cons '()
                              (cons '()
                                    (let ((__tmp39146
                                           (lambda (_%$%g2557125574%_
                                                    _%$%g2557225577%_)
                                             (cons _%$%g2557125574%_
                                                   _%$%g2557225577%_))))
                                      (declare (not safe))
                                      (foldr__0
                                       __tmp39146
                                       '()
                                       _%$%clause2550525553%_))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (_%$%loop2550025534%_
                                           _%$%target2549725528%_
                                           '()))
                                        (_%$%g2549125511%_
                                         _%$%g2549225515%_)))))
                              (_%$%g2549125511%_ _%$%g2549225515%_))))
                      (_%$%g2549125511%_ _%$%g2549225515%_)))))
          (_%$%g2549025580%_ _%stx25488%_))))
    (define |gerbil-ascent/program/scheme-language[:0:]#relational-fragment|
      (lambda (_%$stx25585%_)
        (let* ((_%$%g2558925783%_
                (lambda (_%$%g2559025779%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g2559025779%_))))
               (_%$%g2558826517%_
                (lambda (_%$%g2559025787%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g2559025787%_))
                      (let ((_%$%e2560425790%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g2559025787%_))))
                        (let ((_%$%hd2560525794%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2560425790%_)))
                              (_%$%tl2560625797%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2560425790%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl2560625797%_))
                              (let ((_%$%e2560725800%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl2560625797%_))))
                                (let ((_%$%hd2560825804%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e2560725800%_)))
                                      (_%$%tl2560925807%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e2560725800%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd2560825804%_))
                                      (let ((_%$%e2561025810%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd2560825804%_))))
                                        (let ((_%$%hd2561125814%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2561025810%_)))
                                              (_%$%tl2561225817%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2561025810%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#identifier?
                                                 _%$%hd2561125814%_))
                                              (if (let ((__tmp39147
                                                         |gerbil-ascent/program/scheme-language[1]#_g39148_|))
                                                    (declare (not safe))
                                                    (gx#free-identifier=?
                                                     __tmp39147
                                                     _%$%hd2561125814%_))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2561225817%_))
                                                      (let ((_g39149_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice _%$%tl2561225817%_ '0))))
                (begin
                  (let ((_g39150_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39149_)
                               (##values-length _g39149_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39150_ 2)))
                        (error "Context expects 2 values" _g39150_)))
                  (let ((_%$%target2561325820%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39149_ 0)))
                        (_%$%tl2561525823%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39149_ 1))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2561525823%_))
                        (letrec ((_%$%loop2561625826%_
                                  (lambda (_%$%hd2561425830%_
                                           _%$%imported-handle2562025833%_
                                           _%$%import-name2562125834%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2561425830%_))
                                        (let ((_%$%e2561725836%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2561425830%_))))
                                          (let ((_%$%lp-hd2561825840%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2561725836%_)))
                                                (_%$%lp-tl2561925843%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2561725836%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%lp-hd2561825840%_))
                                                (let ((_%$%e2562425846%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%lp-hd2561825840%_))))
                                                  (let ((_%$%hd2562525850%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2562425846%_)))
                                                        (_%$%tl2562625853%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2562425846%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%tl2562625853%_))
                                                        (let ((_%$%e2562725856%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%tl2562625853%_))))
                  (let ((_%$%hd2562825860%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2562725856%_)))
                        (_%$%tl2562925863%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2562725856%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2562925863%_))
                        (_%$%loop2561625826%_
                         _%$%lp-tl2561925843%_
                         (cons _%$%hd2562825860%_
                               _%$%imported-handle2562025833%_)
                         (cons _%$%hd2562525850%_ _%$%import-name2562125834%_))
                        (_%$%g2558925783%_ _%$%g2559025787%_))))
                (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2558925783%_
                                                 _%$%g2559025787%_))))
                                        (let ((_%$%imported-handle2562225866%_
                                               (reverse _%$%imported-handle2562025833%_))
                                              (_%$%import-name2562325868%_
                                               (reverse _%$%import-name2562125834%_)))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%tl2560925807%_))
                                              (let ((_%$%e2563025870%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%tl2560925807%_))))
                                                (let ((_%$%hd2563125874%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2563025870%_)))
                                                      (_%$%tl2563225877%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2563025870%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%hd2563125874%_))
                                                      (let ((_%$%e2563325880%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%hd2563125874%_))))
                (let ((_%$%hd2563425884%_
                       (let () (declare (not safe)) (##car _%$%e2563325880%_)))
                      (_%$%tl2563525887%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%e2563325880%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#identifier? _%$%hd2563425884%_))
                      (if (let ((__tmp39151
                                 |gerbil-ascent/program/scheme-language[1]#_g39152_|))
                            (declare (not safe))
                            (gx#free-identifier=?
                             __tmp39151
                             _%$%hd2563425884%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair/null? _%$%tl2563525887%_))
                              (let ((_g39153_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-split-splice
                                        _%$%tl2563525887%_
                                        '0))))
                                (begin
                                  (let ((_g39154_
                                         (let ()
                                           (declare (not safe))
                                           (if (##values? _g39153_)
                                               (##values-length _g39153_)
                                               1))))
                                    (if (not (let ()
                                               (declare (not safe))
                                               (##fx= _g39154_ 2)))
                                        (error "Context expects 2 values"
                                               _g39154_)))
                                  (let ((_%$%target2563625890%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39153_ 0)))
                                        (_%$%tl2563825893%_
                                         (let ()
                                           (declare (not safe))
                                           (##values-ref _g39153_ 1))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2563825893%_))
                                        (letrec ((_%$%loop2563925896%_
                                                  (lambda (_%$%hd2563725900%_
                                                           _%$%source-rows2564325903%_
                                                           _%$%source-column2564425904%_
                                                           _%$%source-name2564525905%_)
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%hd2563725900%_))
                                                        (let ((_%$%e2564025907%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%hd2563725900%_))))
                  (let ((_%$%lp-hd2564125911%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2564025907%_)))
                        (_%$%lp-tl2564225914%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2564025907%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%lp-hd2564125911%_))
                        (let ((_%$%e2564925917%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%lp-hd2564125911%_))))
                          (let ((_%$%hd2565025921%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2564925917%_)))
                                (_%$%tl2565125924%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2564925917%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2565125924%_))
                                (let ((_%$%e2565225927%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2565125924%_))))
                                  (let ((_%$%hd2565325931%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2565225927%_)))
                                        (_%$%tl2565425934%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2565225927%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%hd2565325931%_))
                                        (let ((_g39155_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice
                                                  _%$%hd2565325931%_
                                                  '0))))
                                          (begin
                                            (let ((_g39156_
                                                   (let ()
                                                     (declare (not safe))
                                                     (if (##values? _g39155_)
                                                         (##values-length
                                                          _g39155_)
                                                         1))))
                                              (if (not (let ()
                                                         (declare (not safe))
                                                         (##fx= _g39156_ 2)))
                                                  (error "Context expects 2 values"
                                                         _g39156_)))
                                            (let ((_%$%target2565525937%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39155_
                                                      0)))
                                                  (_%$%tl2565725940%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39155_
                                                      1))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2565725940%_))
                                                  (letrec ((_%$%loop2565825943%_
                                                            (lambda (_%$%hd2565625947%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%source-column2566225950%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2565625947%_))
                          (let ((_%$%e2565925952%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2565625947%_))))
                            (let ((_%$%lp-hd2566025956%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2565925952%_)))
                                  (_%$%lp-tl2566125959%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2565925952%_))))
                              (_%$%loop2565825943%_
                               _%$%lp-tl2566125959%_
                               (cons _%$%lp-hd2566025956%_
                                     _%$%source-column2566225950%_))))
                          (let ((_%$%source-column2566325962%_
                                 (reverse _%$%source-column2566225950%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%tl2565425934%_))
                                (let ((_%$%e2566425965%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%tl2565425934%_))))
                                  (let ((_%$%hd2566525969%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2566425965%_)))
                                        (_%$%tl2566625972%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2566425965%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-null? _%$%tl2566625972%_))
                                        (_%$%loop2563925896%_
                                         _%$%lp-tl2564225914%_
                                         (cons _%$%hd2566525969%_
                                               _%$%source-rows2564325903%_)
                                         (cons _%$%source-column2566325962%_
                                               _%$%source-column2564425904%_)
                                         (cons _%$%hd2565025921%_
                                               _%$%source-name2564525905%_))
                                        (_%$%g2558925783%_
                                         _%$%g2559025787%_))))
                                (_%$%g2558925783%_ _%$%g2559025787%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2565825943%_
                                                     _%$%target2565525937%_
                                                     '()))
                                                  (_%$%g2558925783%_
                                                   _%$%g2559025787%_)))))
                                        (_%$%g2558925783%_
                                         _%$%g2559025787%_))))
                                (_%$%g2558925783%_ _%$%g2559025787%_))))
                        (_%$%g2558925783%_ _%$%g2559025787%_))))
                (let ((_%$%source-rows2564625975%_
                       (reverse _%$%source-rows2564325903%_))
                      (_%$%source-column2564725977%_
                       (reverse _%$%source-column2564425904%_))
                      (_%$%source-name2564825978%_
                       (reverse _%$%source-name2564525905%_)))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%tl2563225877%_))
                      (let ((_%$%e2566725980%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%tl2563225877%_))))
                        (let ((_%$%hd2566825984%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e2566725980%_)))
                              (_%$%tl2566925987%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e2566725980%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%hd2566825984%_))
                              (let ((_%$%e2567025990%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%hd2566825984%_))))
                                (let ((_%$%hd2567125994%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e2567025990%_)))
                                      (_%$%tl2567225997%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e2567025990%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#identifier? _%$%hd2567125994%_))
                                      (if (let ((__tmp39157
                                                 |gerbil-ascent/program/scheme-language[1]#_g39158_|))
                                            (declare (not safe))
                                            (gx#free-identifier=?
                                             __tmp39157
                                             _%$%hd2567125994%_))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair/null?
                                                 _%$%tl2567225997%_))
                                              (let ((_g39159_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-split-splice
                                                        _%$%tl2567225997%_
                                                        '0))))
                                                (begin
                                                  (let ((_g39160_
                                                         (let ()
                                                           (declare (not safe))
                                                           (if (##values?
                                                                _g39159_)
                                                               (##values-length
                                                                _g39159_)
                                                               1))))
                                                    (if (not (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##fx= _g39160_ 2)))
                (error "Context expects 2 values" _g39160_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (let ((_%$%target2567326000%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##values-ref
                                                            _g39159_
                                                            0)))
                                                        (_%$%tl2567526003%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##values-ref
                                                            _g39159_
                                                            1))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-null?
                                                           _%$%tl2567526003%_))
                                                        (letrec ((_%$%loop2567626006%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (lambda (_%$%hd2567426010%_
                                   _%$%private-column2568026013%_
                                   _%$%private-name2568126014%_)
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%hd2567426010%_))
                                (let ((_%$%e2567726016%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%hd2567426010%_))))
                                  (let ((_%$%lp-hd2567826020%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2567726016%_)))
                                        (_%$%lp-tl2567926023%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2567726016%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%lp-hd2567826020%_))
                                        (let ((_%$%e2568426026%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%lp-hd2567826020%_))))
                                          (let ((_%$%hd2568526030%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2568426026%_)))
                                                (_%$%tl2568626033%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2568426026%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%tl2568626033%_))
                                                (let ((_%$%e2568726036%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%tl2568626033%_))))
                                                  (let ((_%$%hd2568826040%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2568726036%_)))
                                                        (_%$%tl2568926043%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2568726036%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair/null?
                                                           _%$%hd2568826040%_))
                                                        (let ((_g39161_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-split-splice _%$%hd2568826040%_ '0))))
                  (begin
                    (let ((_g39162_
                           (let ()
                             (declare (not safe))
                             (if (##values? _g39161_)
                                 (##values-length _g39161_)
                                 1))))
                      (if (not (let ()
                                 (declare (not safe))
                                 (##fx= _g39162_ 2)))
                          (error "Context expects 2 values" _g39162_)))
                    (let ((_%$%target2569026046%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g39161_ 0)))
                          (_%$%tl2569226049%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g39161_ 1))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl2569226049%_))
                          (letrec ((_%$%loop2569326052%_
                                    (lambda (_%$%hd2569126056%_
                                             _%$%private-column2569726059%_)
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%hd2569126056%_))
                                          (let ((_%$%e2569426061%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%hd2569126056%_))))
                                            (let ((_%$%lp-hd2569526065%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e2569426061%_)))
                                                  (_%$%lp-tl2569626068%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e2569426061%_))))
                                              (_%$%loop2569326052%_
                                               _%$%lp-tl2569626068%_
                                               (cons _%$%lp-hd2569526065%_
                                                     _%$%private-column2569726059%_))))
                                          (let ((_%$%private-column2569826071%_
                                                 (reverse _%$%private-column2569726059%_)))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-null?
                                                   _%$%tl2568926043%_))
                                                (_%$%loop2567626006%_
                                                 _%$%lp-tl2567926023%_
                                                 (cons _%$%private-column2569826071%_
                                                       _%$%private-column2568026013%_)
                                                 (cons _%$%hd2568526030%_
                                                       _%$%private-name2568126014%_))
                                                (_%$%g2558925783%_
                                                 _%$%g2559025787%_)))))))
                            (_%$%loop2569326052%_ _%$%target2569026046%_ '()))
                          (_%$%g2558925783%_ _%$%g2559025787%_)))))
                (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2558925783%_
                                                 _%$%g2559025787%_))))
                                        (_%$%g2558925783%_
                                         _%$%g2559025787%_))))
                                (let ((_%$%private-column2568226074%_
                                       (reverse _%$%private-column2568026013%_))
                                      (_%$%private-name2568326076%_
                                       (reverse _%$%private-name2568126014%_)))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl2566925987%_))
                                      (let ((_%$%e2569926078%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl2566925987%_))))
                                        (let ((_%$%hd2570026082%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e2569926078%_)))
                                              (_%$%tl2570126085%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e2569926078%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd2570026082%_))
                                              (let ((_%$%e2570226088%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd2570026082%_))))
                                                (let ((_%$%hd2570326092%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e2570226088%_)))
                                                      (_%$%tl2570426095%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e2570226088%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#identifier?
                                                         _%$%hd2570326092%_))
                                                      (if (let ((__tmp39163
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         |gerbil-ascent/program/scheme-language[1]#_g39164_|))
                    (declare (not safe))
                    (gx#free-identifier=? __tmp39163 _%$%hd2570326092%_))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair/null? _%$%tl2570426095%_))
                      (let ((_g39165_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-split-splice
                                _%$%tl2570426095%_
                                '0))))
                        (begin
                          (let ((_g39166_
                                 (let ()
                                   (declare (not safe))
                                   (if (##values? _g39165_)
                                       (##values-length _g39165_)
                                       1))))
                            (if (not (let ()
                                       (declare (not safe))
                                       (##fx= _g39166_ 2)))
                                (error "Context expects 2 values" _g39166_)))
                          (let ((_%$%target2570526098%_
                                 (let ()
                                   (declare (not safe))
                                   (##values-ref _g39165_ 0)))
                                (_%$%tl2570726101%_
                                 (let ()
                                   (declare (not safe))
                                   (##values-ref _g39165_ 1))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2570726101%_))
                                (letrec ((_%$%loop2570826104%_
                                          (lambda (_%$%hd2570626108%_
                                                   _%$%exported-name2571226111%_
                                                   _%$%public-name2571326112%_)
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%hd2570626108%_))
                                                (let ((_%$%e2570926114%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%hd2570626108%_))))
                                                  (let ((_%$%lp-hd2571026118%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2570926114%_)))
                                                        (_%$%lp-tl2571126121%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2570926114%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#stx-pair?
                                                           _%$%lp-hd2571026118%_))
                                                        (let ((_%$%e2571626124%_
                                                               (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gx#syntax-e _%$%lp-hd2571026118%_))))
                  (let ((_%$%hd2571726128%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%e2571626124%_)))
                        (_%$%tl2571826131%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%e2571626124%_))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%tl2571826131%_))
                        (let ((_%$%e2571926134%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%tl2571826131%_))))
                          (let ((_%$%hd2572026138%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2571926134%_)))
                                (_%$%tl2572126141%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2571926134%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-null? _%$%tl2572126141%_))
                                (_%$%loop2570826104%_
                                 _%$%lp-tl2571126121%_
                                 (cons _%$%hd2572026138%_
                                       _%$%exported-name2571226111%_)
                                 (cons _%$%hd2571726128%_
                                       _%$%public-name2571326112%_))
                                (_%$%g2558925783%_ _%$%g2559025787%_))))
                        (_%$%g2558925783%_ _%$%g2559025787%_))))
                (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (let ((_%$%exported-name2571426144%_
                                                       (reverse _%$%exported-name2571226111%_))
                                                      (_%$%public-name2571526146%_
                                                       (reverse _%$%public-name2571326112%_)))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair/null?
                                                         _%$%tl2570126085%_))
                                                      (let ((_g39167_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-split-splice _%$%tl2570126085%_ '0))))
                (begin
                  (let ((_g39168_
                         (let ()
                           (declare (not safe))
                           (if (##values? _g39167_)
                               (##values-length _g39167_)
                               1))))
                    (if (not (let () (declare (not safe)) (##fx= _g39168_ 2)))
                        (error "Context expects 2 values" _g39168_)))
                  (let ((_%$%target2572226148%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39167_ 0)))
                        (_%$%tl2572426151%_
                         (let ()
                           (declare (not safe))
                           (##values-ref _g39167_ 1))))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-null? _%$%tl2572426151%_))
                        (letrec ((_%$%loop2572526154%_
                                  (lambda (_%$%hd2572326158%_
                                           _%$%body-term2572926161%_
                                           _%$%body2573026162%_
                                           _%$%head-term2573126163%_
                                           _%$%head2573226164%_)
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair? _%$%hd2572326158%_))
                                        (let ((_%$%e2572626166%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-e
                                                  _%$%hd2572326158%_))))
                                          (let ((_%$%lp-hd2572726170%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%e2572626166%_)))
                                                (_%$%lp-tl2572826173%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%e2572626166%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (gx#stx-pair?
                                                   _%$%lp-hd2572726170%_))
                                                (let ((_%$%e2573726176%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (gx#syntax-e
                                                          _%$%lp-hd2572726170%_))))
                                                  (let ((_%$%hd2573826180%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%e2573726176%_)))
                                                        (_%$%tl2573926183%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%e2573726176%_))))
                                                    (if (let ()
                                                          (declare (not safe))
                                                          (gx#identifier?
                                                           _%$%hd2573826180%_))
                                                        (if (let ((__tmp39169
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/program/scheme-language[1]#_g39170_|))
                      (declare (not safe))
                      (gx#free-identifier=? __tmp39169 _%$%hd2573826180%_))
                    (if (let ()
                          (declare (not safe))
                          (gx#stx-pair? _%$%tl2573926183%_))
                        (let ((_%$%e2574026186%_
                               (let ()
                                 (declare (not safe))
                                 (gx#syntax-e _%$%tl2573926183%_))))
                          (let ((_%$%hd2574126190%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%e2574026186%_)))
                                (_%$%tl2574226193%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%$%e2574026186%_))))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair? _%$%hd2574126190%_))
                                (let ((_%$%e2574326196%_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-e _%$%hd2574126190%_))))
                                  (let ((_%$%hd2574426200%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%e2574326196%_)))
                                        (_%$%tl2574526203%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%e2574326196%_))))
                                    (if (let ()
                                          (declare (not safe))
                                          (gx#stx-pair/null?
                                           _%$%tl2574526203%_))
                                        (let ((_g39171_
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-split-splice
                                                  _%$%tl2574526203%_
                                                  '0))))
                                          (begin
                                            (let ((_g39172_
                                                   (let ()
                                                     (declare (not safe))
                                                     (if (##values? _g39171_)
                                                         (##values-length
                                                          _g39171_)
                                                         1))))
                                              (if (not (let ()
                                                         (declare (not safe))
                                                         (##fx= _g39172_ 2)))
                                                  (error "Context expects 2 values"
                                                         _g39172_)))
                                            (let ((_%$%target2574626206%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39171_
                                                      0)))
                                                  (_%$%tl2574826209%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##values-ref
                                                      _g39171_
                                                      1))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-null?
                                                     _%$%tl2574826209%_))
                                                  (letrec ((_%$%loop2574926212%_
                                                            (lambda (_%$%hd2574726216%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             _%$%head-term2575326219%_)
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%hd2574726216%_))
                          (let ((_%$%e2575026221%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%hd2574726216%_))))
                            (let ((_%$%lp-hd2575126225%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2575026221%_)))
                                  (_%$%lp-tl2575226228%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2575026221%_))))
                              (_%$%loop2574926212%_
                               _%$%lp-tl2575226228%_
                               (cons _%$%lp-hd2575126225%_
                                     _%$%head-term2575326219%_))))
                          (let ((_%$%head-term2575426231%_
                                 (reverse _%$%head-term2575326219%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (gx#stx-pair/null? _%$%tl2574226193%_))
                                (let ((_g39173_
                                       (let ()
                                         (declare (not safe))
                                         (gx#syntax-split-splice
                                          _%$%tl2574226193%_
                                          '0))))
                                  (begin
                                    (let ((_g39174_
                                           (let ()
                                             (declare (not safe))
                                             (if (##values? _g39173_)
                                                 (##values-length _g39173_)
                                                 1))))
                                      (if (not (let ()
                                                 (declare (not safe))
                                                 (##fx= _g39174_ 2)))
                                          (error "Context expects 2 values"
                                                 _g39174_)))
                                    (let ((_%$%target2575526234%_
                                           (let ()
                                             (declare (not safe))
                                             (##values-ref _g39173_ 0)))
                                          (_%$%tl2575726237%_
                                           (let ()
                                             (declare (not safe))
                                             (##values-ref _g39173_ 1))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-null? _%$%tl2575726237%_))
                                          (letrec ((_%$%loop2575826240%_
                                                    (lambda (_%$%hd2575626244%_
                                                             _%$%body-term2576226247%_
                                                             _%$%body2576326248%_)
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%hd2575626244%_))
                                                          (let ((_%$%e2575926250%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%hd2575626244%_))))
                    (let ((_%$%lp-hd2576026254%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e2575926250%_)))
                          (_%$%lp-tl2576126257%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e2575926250%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%lp-hd2576026254%_))
                          (let ((_%$%e2576626260%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%lp-hd2576026254%_))))
                            (let ((_%$%hd2576726264%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e2576626260%_)))
                                  (_%$%tl2576826267%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e2576626260%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair/null? _%$%tl2576826267%_))
                                  (let ((_g39175_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-split-splice
                                            _%$%tl2576826267%_
                                            '0))))
                                    (begin
                                      (let ((_g39176_
                                             (let ()
                                               (declare (not safe))
                                               (if (##values? _g39175_)
                                                   (##values-length _g39175_)
                                                   1))))
                                        (if (not (let ()
                                                   (declare (not safe))
                                                   (##fx= _g39176_ 2)))
                                            (error "Context expects 2 values"
                                                   _g39176_)))
                                      (let ((_%$%target2576926270%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g39175_ 0)))
                                            (_%$%tl2577126273%_
                                             (let ()
                                               (declare (not safe))
                                               (##values-ref _g39175_ 1))))
                                        (if (let ()
                                              (declare (not safe))
                                              (gx#stx-null?
                                               _%$%tl2577126273%_))
                                            (letrec ((_%$%loop2577226276%_
                                                      (lambda (_%$%hd2577026280%_
                                                               _%$%body-term2577626283%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#stx-pair?
                                                               _%$%hd2577026280%_))
                                                            (let ((_%$%e2577326285%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (let ()
                             (declare (not safe))
                             (gx#syntax-e _%$%hd2577026280%_))))
                      (let ((_%$%lp-hd2577426289%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%e2577326285%_)))
                            (_%$%lp-tl2577526292%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%e2577326285%_))))
                        (_%$%loop2577226276%_
                         _%$%lp-tl2577526292%_
                         (cons _%$%lp-hd2577426289%_
                               _%$%body-term2577626283%_))))
                    (let ((_%$%body-term2577726295%_
                           (reverse _%$%body-term2577626283%_)))
                      (_%$%loop2575826240%_
                       _%$%lp-tl2576126257%_
                       (cons _%$%body-term2577726295%_
                             _%$%body-term2576226247%_)
                       (cons _%$%hd2576726264%_ _%$%body2576326248%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%loop2577226276%_
                                               _%$%target2576926270%_
                                               '()))
                                            (_%$%g2558925783%_
                                             _%$%g2559025787%_)))))
                                  (_%$%g2558925783%_ _%$%g2559025787%_))))
                          (_%$%g2558925783%_ _%$%g2559025787%_))))
                  (let ((_%$%body-term2576426298%_
                         (reverse _%$%body-term2576226247%_))
                        (_%$%body2576526300%_ (reverse _%$%body2576326248%_)))
                    (_%$%loop2572526154%_
                     _%$%lp-tl2572826173%_
                     (cons _%$%body-term2576426298%_ _%$%body-term2572926161%_)
                     (cons _%$%body2576526300%_ _%$%body2573026162%_)
                     (cons _%$%head-term2575426231%_ _%$%head-term2573126163%_)
                     (cons _%$%hd2574426200%_ _%$%head2573226164%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (_%$%loop2575826240%_
                                             _%$%target2575526234%_
                                             '()
                                             '()))
                                          (_%$%g2558925783%_
                                           _%$%g2559025787%_)))))
                                (_%$%g2558925783%_ _%$%g2559025787%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%loop2574926212%_
                                                     _%$%target2574626206%_
                                                     '()))
                                                  (_%$%g2558925783%_
                                                   _%$%g2559025787%_)))))
                                        (_%$%g2558925783%_
                                         _%$%g2559025787%_))))
                                (_%$%g2558925783%_ _%$%g2559025787%_))))
                        (_%$%g2558925783%_ _%$%g2559025787%_))
                    (_%$%g2558925783%_ _%$%g2559025787%_))
                (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (_%$%g2558925783%_
                                                 _%$%g2559025787%_))))
                                        (let ((_%$%body-term2573326302%_
                                               (reverse _%$%body-term2572926161%_))
                                              (_%$%body2573426304%_
                                               (reverse _%$%body2573026162%_))
                                              (_%$%head-term2573526305%_
                                               (reverse _%$%head-term2573126163%_))
                                              (_%$%head2573626306%_
                                               (reverse _%$%head2573226164%_)))
                                          (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'let))
                                                (cons (begin
                                                        (let ()
                                                          (declare (not safe))
                                                          (gx#syntax-check-splice-targets
                                                           _%$%imported-handle2562225866%_
                                                           _%$%import-name2562325868%_))
                                                        (let ((__tmp39181
                                                               (lambda (_%$%g2637926417%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%$%g2638026420%_
                                _%$%g2638126422%_)
                         (cons (cons _%$%g2638026420%_
                                     (cons _%$%g2637926417%_ '()))
                               _%$%g2638126422%_)))
                      (__tmp39177
                       (begin
                         (let ()
                           (declare (not safe))
                           (gx#syntax-check-splice-targets
                            _%$%source-name2564825978%_
                            _%$%source-name2564825978%_))
                         (let ((__tmp39180
                                (lambda (_%$%g2638226425%_
                                         _%$%g2638326428%_
                                         _%$%g2638426430%_)
                                  (cons (cons _%$%g2638226425%_
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'gensym))
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'quote))
                              (cons _%$%g2638226425%_ '()))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '()))
                                        _%$%g2638426430%_)))
                               (__tmp39178
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (gx#syntax-check-splice-targets
                                     _%$%private-name2568326076%_
                                     _%$%private-name2568326076%_))
                                  (let ((__tmp39179
                                         (lambda (_%$%g2638526433%_
                                                  _%$%g2638626436%_
                                                  _%$%g2638726438%_)
                                           (cons (cons _%$%g2638526433%_
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'gensym))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'quote))
                                       (cons _%$%g2638526433%_ '()))
                                 '()))
                     '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 _%$%g2638726438%_))))
                                    (declare (not safe))
                                    (foldr__1
                                     __tmp39179
                                     '()
                                     _%$%private-name2568326076%_
                                     _%$%private-name2568326076%_)))))
                           (declare (not safe))
                           (foldr__1
                            __tmp39180
                            __tmp39178
                            _%$%source-name2564825978%_
                            _%$%source-name2564825978%_)))))
                  (declare (not safe))
                  (foldr__1
                   __tmp39181
                   __tmp39177
                   _%$%imported-handle2562225866%_
                   _%$%import-name2562325868%_)))
              (cons (cons (let ()
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'gerbil-ascent-fragment))
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'list))
                                      (begin
                                        (let ()
                                          (declare (not safe))
                                          (gx#syntax-check-splice-targets
                                           _%$%source-rows2564625975%_
                                           _%$%source-column2564725977%_
                                           _%$%source-name2564825978%_))
                                        (let ((__tmp39185
                                               (lambda (_%$%g2638826441%_
                                                        _%$%g2638926444%_
                                                        _%$%g2639026446%_
                                                        _%$%g2639126448%_)
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'relational-source))
                     (cons _%$%g2639026446%_
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'length))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'quote))
                                                   (cons (let ((__tmp39186
                                                                (lambda (_%$%g2639226451%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 _%$%g2639326454%_)
                          (cons _%$%g2639226451%_ _%$%g2639326454%_))))
                   (declare (not safe))
                   (foldr__0 __tmp39186 '() _%$%g2638926444%_))
                 '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '()))
                                 (cons _%$%g2638826441%_ '()))))
               _%$%g2639126448%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (__tmp39182
                                               (begin
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-check-splice-targets
                                                    _%$%private-column2568226074%_
                                                    _%$%private-name2568326076%_))
                                                 (let ((__tmp39183
                                                        (lambda (_%$%g2639426457%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%$%g2639526460%_
                         _%$%g2639626462%_)
                  (cons (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'relational-source))
                              (cons _%$%g2639526460%_
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'length))
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'quote))
                                                            (cons (let ((__tmp39184
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                 (lambda (_%$%g2639726465%_ _%$%g2639826468%_)
                                   (cons _%$%g2639726465%_
                                         _%$%g2639826468%_))))
                            (declare (not safe))
                            (foldr__0 __tmp39184 '() _%$%g2639426457%_))
                          '()))
              '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         '@list))
                                                      '())
                                                '()))))
                        _%$%g2639626462%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (declare (not safe))
                                                   (foldr__1
                                                    __tmp39183
                                                    '()
                                                    _%$%private-column2568226074%_
                                                    _%$%private-name2568326076%_)))))
                                          (declare (not safe))
                                          (__foldr*
                                           __tmp39185
                                           __tmp39182
                                           _%$%source-rows2564625975%_
                                           _%$%source-column2564725977%_
                                           _%$%source-name2564825978%_))))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'list))
                                            (begin
                                              (let ()
                                                (declare (not safe))
                                                (gx#syntax-check-splice-targets
                                                 _%$%body2573426304%_
                                                 _%$%body-term2573326302%_
                                                 _%$%head-term2573526305%_
                                                 _%$%head2573626306%_))
                                              (let ((__tmp39187
                                                     (lambda (_%$%g2639926471%_
                                                              _%$%g2640026474%_
                                                              _%$%g2640126476%_
                                                              _%$%g2640226478%_
                                                              _%$%g2640326480%_)
                                                       (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'gerbil-ascent-rule))
                           (cons (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'list))
                                       (cons (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'relational-atom/lexical))
                                                   (cons (cons _%$%g2640226478%_
                                                               (let ((__tmp39188
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (lambda (_%$%g2640426483%_ _%$%g2640526486%_)
                                (cons _%$%g2640426483%_ _%$%g2640526486%_))))
                         (declare (not safe))
                         (foldr__0 __tmp39188 '() _%$%g2640126476%_)))
                 '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             '()))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'list))
                                             (begin
                                               (let ()
                                                 (declare (not safe))
                                                 (gx#syntax-check-splice-targets
                                                  _%$%g2640026474%_
                                                  _%$%g2639926471%_))
                                               (let ((__tmp39189
                                                      (lambda (_%$%g2640626489%_
                                                               _%$%g2640726492%_
                                                               _%$%g2640826494%_)
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0
                               '#f
                               'relational-checked-clause))
                            (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0
                                     '#f
                                     'relational-atom/lexical))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0
                                           '#f
                                           'relational-negation/lexical))
                                        (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0
                                                 '#f
                                                 'relational-reduce/lexical))
                                              (cons (cons _%$%g2640726492%_
                                                          (let ((__tmp39190
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (lambda (_%$%g2640926497%_ _%$%g2641026500%_)
                           (cons _%$%g2640926497%_ _%$%g2641026500%_))))
                    (declare (not safe))
                    (foldr__0 __tmp39190 '() _%$%g2640626489%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))))
                      _%$%g2640826494%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (declare (not safe))
                                                 (foldr__1
                                                  __tmp39189
                                                  '()
                                                  _%$%g2640026474%_
                                                  _%$%g2639926471%_))))
                                       '())))
                     _%$%g2640326480%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (__foldr*
                                                 __tmp39187
                                                 '()
                                                 _%$%body2573426304%_
                                                 _%$%body-term2573326302%_
                                                 _%$%head-term2573526305%_
                                                 _%$%head2573626306%_))))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'list))
                                                  (begin
                                                    (let ()
                                                      (declare (not safe))
                                                      (gx#syntax-check-splice-targets
                                                       _%$%exported-name2571426144%_
                                                       _%$%public-name2571526146%_))
                                                    (let ((__tmp39191
                                                           (lambda (_%$%g2641126503%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g2641226506%_
                            _%$%g2641326508%_)
                     (cons (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'cons))
                                 (cons (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0
                                                '#f
                                                'quote))
                                             (cons _%$%g2641226506%_ '()))
                                       (cons _%$%g2641126503%_ '())))
                           _%$%g2641326508%_))))
              (declare (not safe))
              (foldr__1
               __tmp39191
               '()
               _%$%exported-name2571426144%_
               _%$%public-name2571526146%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'list))
                                                        (let ((__tmp39192
                                                               (lambda (_%$%g2641426511%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                _%$%g2641526514%_)
                         (cons _%$%g2641426511%_ _%$%g2641526514%_))))
                  (declare (not safe))
                  (foldr__0 __tmp39192 '() _%$%source-name2564825978%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '())))))
                    '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                          (_%$%loop2572526154%_
                           _%$%target2572226148%_
                           '()
                           '()
                           '()
                           '()))
                        (_%$%g2558925783%_ _%$%g2559025787%_)))))
              (_%$%g2558925783%_ _%$%g2559025787%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  (_%$%loop2570826104%_
                                   _%$%target2570526098%_
                                   '()
                                   '()))
                                (_%$%g2558925783%_ _%$%g2559025787%_)))))
                      (_%$%g2558925783%_ _%$%g2559025787%_))
                  (_%$%g2558925783%_ _%$%g2559025787%_))
              (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2558925783%_
                                               _%$%g2559025787%_))))
                                      (_%$%g2558925783%_
                                       _%$%g2559025787%_)))))))
                  (_%$%loop2567626006%_ _%$%target2567326000%_ '() '()))
                (_%$%g2558925783%_ _%$%g2559025787%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2558925783%_
                                               _%$%g2559025787%_))
                                          (_%$%g2558925783%_
                                           _%$%g2559025787%_))
                                      (_%$%g2558925783%_ _%$%g2559025787%_))))
                              (_%$%g2558925783%_ _%$%g2559025787%_))))
                      (_%$%g2558925783%_ _%$%g2559025787%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (_%$%loop2563925896%_
                                           _%$%target2563625890%_
                                           '()
                                           '()
                                           '()))
                                        (_%$%g2558925783%_
                                         _%$%g2559025787%_)))))
                              (_%$%g2558925783%_ _%$%g2559025787%_))
                          (_%$%g2558925783%_ _%$%g2559025787%_))
                      (_%$%g2558925783%_ _%$%g2559025787%_))))
              (_%$%g2558925783%_ _%$%g2559025787%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g2558925783%_
                                               _%$%g2559025787%_)))))))
                          (_%$%loop2561625826%_
                           _%$%target2561325820%_
                           '()
                           '()))
                        (_%$%g2558925783%_ _%$%g2559025787%_)))))
              (_%$%g2558925783%_ _%$%g2559025787%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%$%g2558925783%_
                                                   _%$%g2559025787%_))
                                              (_%$%g2558925783%_
                                               _%$%g2559025787%_))))
                                      (_%$%g2558925783%_ _%$%g2559025787%_))))
                              (_%$%g2558925783%_ _%$%g2559025787%_))))
                      (_%$%g2558925783%_ _%$%g2559025787%_)))))
          (_%$%g2558826517%_ _%$stx25585%_))))))
