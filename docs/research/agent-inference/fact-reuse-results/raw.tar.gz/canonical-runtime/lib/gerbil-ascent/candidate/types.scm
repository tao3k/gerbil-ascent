(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/datum")
    (load-module "std/crypto/digest")
    (load-module "std/encoding/hex"))
  (load-module "gerbil-ascent/candidate/types~0"))
