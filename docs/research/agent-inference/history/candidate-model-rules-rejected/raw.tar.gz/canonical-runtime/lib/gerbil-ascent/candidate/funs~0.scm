(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/funs::timestamp 1791687885)
  (begin
    (define gerbil-ascent/candidate/funs#candidate-same-row-set?
      (lambda (_%left27178%_ _%right27179%_)
        (if (= (length _%left27178%_) (length _%right27179%_))
            (let ((_%$e27181%_ (equal? _%left27178%_ _%right27179%_)))
              (if _%$e27181%_
                  _%$e27181%_
                  (let ((_%a27184%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value)))
                        (_%b27185%_
                         (let ()
                           (declare (not safe))
                           (make-hash-table__%
                            '#f
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value
                            absent-value))))
                    (for-each
                     (lambda (_%row27187%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%a27184%_ _%row27187%_ '#t)))
                     _%left27178%_)
                    (for-each
                     (lambda (_%row27189%_)
                       (let ()
                         (declare (not safe))
                         (__hash-put! _%b27185%_ _%row27189%_ '#t)))
                     _%right27179%_)
                    (if (= (let ()
                             (declare (not safe))
                             (__hash-length _%a27184%_))
                           (let ()
                             (declare (not safe))
                             (__hash-length _%b27185%_)))
                        (let ((__tmp36811
                               (lambda (_%row27191%_)
                                 (if (let ()
                                       (declare (not safe))
                                       (__hash-get _%b27185%_ _%row27191%_))
                                     '#t
                                     '#f))))
                          (declare (not safe))
                          (andmap__0 __tmp36811 _%left27178%_))
                        '#f))))
            '#f)))
    (define gerbil-ascent/candidate/funs#candidate-schema-of
      (lambda (_%snapshot27173%_ _%spec27174%_)
        (append (map (lambda (_%entry27176%_)
                       (cons (car _%entry27176%_) (cadr _%entry27176%_)))
                     (##structure-ref
                      _%snapshot27173%_
                      '4
                      gerbil-ascent/candidate/types#reasoning-snapshot::t
                      '#f))
                (##structure-ref
                 _%spec27174%_
                 '1
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f))))
    (define gerbil-ascent/candidate/funs#candidate-required-entry
      (lambda (_%name27167%_ _%index27168%_)
        (let ((_%$e27170%_ (assq _%name27167%_ _%index27168%_)))
          (if _%$e27170%_
              _%$e27170%_
              (let ()
                (declare (not safe))
                (error '"candidate is missing inspected entry"
                       _%name27167%_))))))
    (define gerbil-ascent/candidate/funs#candidate-bind-atom
      (lambda (_%atom27149%_ _%row27150%_ _%prior27151%_)
        (let _%loop27153%_ ((_%terms27155%_ (cdr _%atom27149%_))
                            (_%values27156%_ _%row27150%_)
                            (_%bindings27157%_ _%prior27151%_))
          (if (null? _%terms27155%_)
              _%bindings27157%_
              (let ((_%term27159%_ (car _%terms27155%_))
                    (_%value27160%_ (car _%values27156%_)))
                (if (eq? _%term27159%_ '?_)
                    (_%loop27153%_
                     (cdr _%terms27155%_)
                     (cdr _%values27156%_)
                     _%bindings27157%_)
                    (if (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/program#candidate-variable?
                           _%term27159%_))
                        (let ((_%old27164%_
                               (assq _%term27159%_ _%bindings27157%_)))
                          (if _%old27164%_
                              (if (equal? (cdr _%old27164%_) _%value27160%_)
                                  (_%loop27153%_
                                   (cdr _%terms27155%_)
                                   (cdr _%values27156%_)
                                   _%bindings27157%_)
                                  '#f)
                              (_%loop27153%_
                               (cdr _%terms27155%_)
                               (cdr _%values27156%_)
                               (cons (cons _%term27159%_ _%value27160%_)
                                     _%bindings27157%_))))
                        (if (equal? _%term27159%_ _%value27160%_)
                            (_%loop27153%_
                             (cdr _%terms27155%_)
                             (cdr _%values27156%_)
                             _%bindings27157%_)
                            '#f))))))))
    (define gerbil-ascent/candidate/funs#candidate-fixed-clause
      (lambda (_%clause27124%_ _%bindings27125%_)
        (let* ((_%mode27127%_ (car _%clause27124%_))
               (_%form27129%_
                (if (eq? _%mode27127%_ 'where)
                    (cadr _%clause27124%_)
                    (caddr _%clause27124%_)))
               (_%inputs27133%_
                (map (lambda (_%name27131%_)
                       (assq _%name27131%_ _%bindings27125%_))
                     (cdr _%form27129%_))))
          (if (let ((__tmp36812
                     (lambda (_%input27136%_) (and _%input27136%_ '#t))))
                (declare (not safe))
                (andmap__0 __tmp36812 _%inputs27133%_))
              (let* ((_%values27138%_
                      (let ()
                        (declare (not safe))
                        (##map cdr _%inputs27133%_)))
                     (_%$e27140%_ _%mode27127%_))
                (if (eq? 'where _%$e27140%_)
                    (let ((_%$e27143%_ (car _%form27129%_)))
                      (if (eq? 'even? _%$e27143%_)
                          (if (exact-integer? (car _%values27138%_))
                              (if (even? (car _%values27138%_))
                                  _%bindings27125%_
                                  '#f)
                              '#f)
                          (if (eq? '< _%$e27143%_)
                              (if (let ()
                                    (declare (not safe))
                                    (andmap__0 exact-integer? _%values27138%_))
                                  (if (< (car _%values27138%_)
                                         (cadr _%values27138%_))
                                      _%bindings27125%_
                                      '#f)
                                  '#f)
                              '#f)))
                    (if (eq? 'compute _%$e27140%_)
                        (if (assq (cadr _%clause27124%_) _%bindings27125%_)
                            '#f
                            (let ((_%$e27146%_ (car _%form27129%_)))
                              (if (eq? 'identity _%$e27146%_)
                                  (cons (cons (cadr _%clause27124%_)
                                              (car _%values27138%_))
                                        _%bindings27125%_)
                                  (if (eq? '+ _%$e27146%_)
                                      (if (let ()
                                            (declare (not safe))
                                            (andmap__0
                                             exact-integer?
                                             _%values27138%_))
                                          (cons (cons (cadr _%clause27124%_)
                                                      (+ (car _%values27138%_)
                                                         (cadr _%values27138%_)))
                                                _%bindings27125%_)
                                          '#f)
                                      '#f))))
                        '#f)))
              '#f))))
    (define gerbil-ascent/candidate/funs#candidate-strata-of
      (lambda (_%schema27087%_ _%rules27088%_)
        (let ((_%levels27092%_
               (map (lambda (_%entry27090%_) (cons (car _%entry27090%_) '0))
                    _%schema27087%_)))
          (let _%loop27094%_ ((_%round27096%_ '0))
            (let ((_%changed?27098%_ '#f))
              (for-each
               (lambda (_%rule27100%_)
                 (let ((_%head27102%_ (car (vector-ref _%rule27100%_ '0))))
                   (for-each
                    (lambda (_%clause27104%_)
                      (let ((_%dependency27112%_
                             (let ((_%$e27106%_ (car _%clause27104%_)))
                               (if (eq? 'not _%$e27106%_)
                                   (cons (caadr _%clause27104%_) '1)
                                   (if (eq? 'reduce _%$e27106%_)
                                       (cons (car (cadddr _%clause27104%_)) '1)
                                       (if (or (eq? 'where _%$e27106%_)
                                               (eq? 'compute _%$e27106%_))
                                           '#f
                                           (cons (car _%clause27104%_)
                                                 '0)))))))
                        (if _%dependency27112%_
                            (let* ((_%head-level27114%_
                                    (gerbil-ascent/candidate/funs#candidate-required-entry
                                     _%head27102%_
                                     _%levels27092%_))
                                   (_%dep-level27116%_
                                    (gerbil-ascent/candidate/funs#candidate-required-entry
                                     (let ()
                                       (declare (not safe))
                                       (##car _%dependency27112%_))
                                     _%levels27092%_))
                                   (_%required27118%_
                                    (+ (cdr _%dep-level27116%_)
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%dependency27112%_)))))
                              (if (< (cdr _%head-level27114%_)
                                     _%required27118%_)
                                  (begin
                                    (set-cdr!
                                     _%head-level27114%_
                                     _%required27118%_)
                                    (set! _%changed?27098%_ '#t))
                                  '#!void))
                            '#!void)))
                    (vector-ref _%rule27100%_ '1))))
               _%rules27088%_)
              (if _%changed?27098%_
                  (if (>= _%round27096%_ (length _%schema27087%_))
                      '#f
                      (_%loop27094%_ (+ _%round27096%_ '1)))
                  _%levels27092%_))))))))
