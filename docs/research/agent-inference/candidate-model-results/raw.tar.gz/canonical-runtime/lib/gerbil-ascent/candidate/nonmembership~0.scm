(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/nonmembership::timestamp 1791689709)
  (begin
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
      (let ((__tmp37794 (list)) (__tmp37793 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'positive-nonmembership
         __tmp37794
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         __tmp37793
         '#f)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t)))
    (define gerbil-ascent/candidate/nonmembership#make-positive-nonmembership
      (lambda _%$args29703%_
        (apply make-instance
               gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
               _%$args29703%_)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#certificate-size-valid?
      (lambda (_%closure29687%_)
        (let ((_%relation-count29689%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                  _%closure29687%_
                  gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)))
              (_%rows29690%_ '0)
              (_%cells29691%_ '0))
          (if _%relation-count29689%_
              (let ((__tmp37795
                     (lambda (_%entry29693%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry29693%_
                                      '3))
                                   '3)
                           (let* ((_%row-list29695%_ (caddr _%entry29693%_))
                                  (_%count29697%_
                                   (let ((__tmp37796
                                          (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                             _%rows29690%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%row-list29695%_
                                      __tmp37796))))
                             (if _%count29697%_
                                 (if (begin
                                       (set! _%rows29690%_
                                             (+ _%rows29690%_ _%count29697%_))
                                       '#t)
                                     (let ((__tmp37797
                                            (lambda (_%row29699%_)
                                              (let ((_%width29701%_
                                                     (let ((__tmp37798
                                                            (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                            _%cells29691%_))))
               (declare (not safe))
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row29699%_
                __tmp37798))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%width29701%_
                                                    (begin
                                                      (set! _%cells29691%_
                                                            (+ _%cells29691%_
                                                               _%width29701%_))
                                                      '#t)
                                                    '#f)))))
                                       (declare (not safe))
                                       (andmap__0
                                        __tmp37797
                                        _%row-list29695%_))
                                     '#f)
                                 '#f))
                           '#f))))
                (declare (not safe))
                (andmap__0 __tmp37795 _%closure29687%_))
              '#f))))
    (define gerbil-ascent/candidate/nonmembership#ground-query?
      (lambda (_%query29683%_)
        (if (list? _%query29683%_)
            (if (pair? _%query29683%_)
                (let ((__tmp37800
                       (lambda (_%term29685%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term29685%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term29685%_))
                                 '#f
                                 (not (eq? _%term29685%_ '?_)))
                             '#f)))
                      (__tmp37799
                       (let () (declare (not safe)) (##cdr _%query29683%_))))
                  (declare (not safe))
                  (andmap__0 __tmp37800 __tmp37799))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/nonmembership#certificate-schema-of
      (lambda (_%snapshot29678%_ _%spec29679%_)
        (let ((__tmp37802
               (lambda (_%entry29681%_)
                 (list (car _%entry29681%_) (cdr _%entry29681%_))))
              (__tmp37801
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/funs#candidate-schema-of
                  _%snapshot29678%_
                  _%spec29679%_))))
          (declare (not safe))
          (##map __tmp37802 __tmp37801))))
    (define gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
      (lambda (_%snapshot29628%_
               _%spec29629%_
               _%candidate-digest29630%_
               _%native-status29631%_
               _%native-rows29632%_
               _%max-steps29633%_)
        (if (and (exact-integer? _%max-steps29633%_) (> _%max-steps29633%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership work budget" _%max-steps29633%_)))
        (let ((_%query29635%_
               (vector-ref
                (##structure-ref
                 _%spec29629%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29637%_
                    (lambda (_%status29675%_ _%closure29676%_)
                      (let ((__tmp37807
                             (##structure-ref
                              _%snapshot29628%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37806
                             (##structure-ref
                              _%snapshot29628%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37805
                             (##structure-ref
                              _%snapshot29628%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp37804
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                                _%spec29629%_)))
                            (__tmp37803
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29635%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
                         _%status29675%_
                         __tmp37807
                         __tmp37806
                         __tmp37805
                         _%candidate-digest29630%_
                         __tmp37804
                         __tmp37803
                         _%max-steps29633%_
                         _%closure29676%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29628%_)))
                    (not (eq? _%native-status29631%_ 'complete))
                    (pair? _%native-rows29632%_)
                    (not (gerbil-ascent/candidate/nonmembership#ground-query?
                          _%query29635%_))
                    (not (let ((__tmp37808
                                (##structure-ref
                                 _%spec29629%_
                                 '3
                                 gerbil-ascent/candidate/types#reasoning-candidate::t
                                 '#f)))
                           (declare (not safe))
                           (andmap__0
                            gerbil-ascent/candidate/provenance#positive-rule-body?
                            __tmp37808))))
                (_%result29637%_ 'unsupported '())
                (if (> (let ((__tmp37809
                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                               _%snapshot29628%_
                               _%spec29629%_)))
                         (declare (not safe))
                         (##length __tmp37809))
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                    (_%result29637%_ 'bounded '())
                    (let* ((_%witness29651%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
                               _%snapshot29628%_
                               _%spec29629%_
                               _%candidate-digest29630%_
                               _%native-status29631%_
                               _%native-rows29632%_
                               _%max-steps29633%_)))
                           (_%status29653%_
                            (##structure-ref
                             _%witness29651%_
                             '1
                             gerbil-ascent/candidate/provenance#positive-proof::t
                             '#f))
                           (_%$e29656%_ _%status29653%_))
                      (if (eq? 'bounded _%$e29656%_)
                          (_%result29637%_ 'bounded '())
                          (if (eq? 'closed-absent _%$e29656%_)
                              (let ((_%grouped29659%_
                                     (let ()
                                       (declare (not safe))
                                       (make-hash-table-eq))))
                                (for-each
                                 (lambda (_%node29661%_)
                                   (let* ((_%name29663%_
                                           (##structure-ref
                                            _%node29661%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f))
                                          (__tmp37810
                                           (cons (##structure-ref
                                                  _%node29661%_
                                                  '4
                                                  gerbil-ascent/candidate/provenance#proof-node::t
                                                  '#f)
                                                 (let ((_%$e29665%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-get
                                                           _%grouped29659%_
                                                           _%name29663%_))))
                                                   (if _%$e29665%_
                                                       _%$e29665%_
                                                       '())))))
                                     (declare (not safe))
                                     (__hash-put!
                                      _%grouped29659%_
                                      _%name29663%_
                                      __tmp37810)))
                                 (##structure-ref
                                  _%witness29651%_
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))
                                (let ((_%closure29673%_
                                       (let ((__tmp37812
                                              (lambda (_%declaration29668%_)
                                                (list (car _%declaration29668%_)
                                                      (cadr _%declaration29668%_)
                                                      (let ((__tmp37813
                                                             (reverse (let ((_%$e29670%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     (let ((__tmp37814
                                            (car _%declaration29668%_)))
                                       (declare (not safe))
                                       (__hash-get
                                        _%grouped29659%_
                                        __tmp37814))))
                                (if _%$e29670%_ _%$e29670%_ '())))))
                (declare (not safe))
                (##map gerbil-ascent/candidate/datum#candidate-copy-pairs
                       __tmp37813)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (__tmp37811
                                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                                               _%snapshot29628%_
                                               _%spec29629%_)))
                                         (declare (not safe))
                                         (##map __tmp37812 __tmp37811))))
                                  (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                                       _%closure29673%_)
                                      (_%result29637%_
                                       'complete
                                       _%closure29673%_)
                                      (_%result29637%_ 'bounded '()))))
                              (_%result29637%_ 'unsupported '()))))))))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__%
      (lambda (_%terms29610%_ _%wildcards?29611%_)
        (map (lambda (_%term29613%_)
               (cons (if (and _%wildcards?29611%_ (eq? _%term29613%_ '?_))
                         'wildcard
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-variable?
                                _%term29613%_))
                             'variable
                             'literal))
                     _%term29613%_))
             _%terms29610%_)))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__0
      (lambda (_%terms29621%_)
        (let ((_%wildcards?29623%_ '#t))
          (gerbil-ascent/candidate/nonmembership#binding-patterns__%
           _%terms29621%_
           _%wildcards?29623%_))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns
      (lambda _g37815_
        (let ((_g37816_ (let () (declare (not safe)) (##length _g37815_))))
          (cond ((let () (declare (not safe)) (##fx= _g37816_ 1))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__0
                        _g37815_))
                ((let () (declare (not safe)) (##fx= _g37816_ 2))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__%
                        _g37815_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/nonmembership#binding-patterns
                  _g37815_))))))
    (define gerbil-ascent/candidate/nonmembership#head-row
      (lambda (_%head29604%_ _%bindings29605%_)
        (map (lambda (_%term29607%_)
               (if (eq? (car _%term29607%_) 'variable)
                   (cdr (assq (cdr _%term29607%_) _%bindings29605%_))
                   (cdr _%term29607%_)))
             _%head29604%_)))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
      (lambda (_%snapshot29429%_
               _%spec29430%_
               _%candidate-digest29431%_
               _%native-status29432%_
               _%native-rows29433%_
               _%certificate29434%_
               _%max-checks29435%_)
        (if (and (exact-integer? _%max-checks29435%_)
                 (> _%max-checks29435%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership verification budget"
                     _%max-checks29435%_)))
        (let* ((_%query29437%_
                (vector-ref
                 (##structure-ref
                  _%spec29430%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%schema29439%_
                (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                 _%snapshot29429%_
                 _%spec29430%_))
               (_%closure29441%_
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%certificate29434%_
                       'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%certificate29434%_
                       '9
                       '#f
                       '#f))
                    '#f))
               (_%preflight29449%_
                (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                     _%closure29441%_)
                    (if (= (length _%closure29441%_)
                           (let ()
                             (declare (not safe))
                             (##length _%schema29439%_)))
                        (if (let ((__tmp37817
                                   (lambda (_%entry29443%_)
                                     (and (list? _%entry29443%_)
                                          (= (let ()
                                               (declare (not safe))
                                               (##length _%entry29443%_))
                                             '3)
                                          (list? (caddr _%entry29443%_))))))
                              (declare (not safe))
                              (andmap__0 __tmp37817 _%closure29441%_))
                            (+ '1
                               (let ((__tmp37818
                                      (map (lambda (_%entry29445%_)
                                             (length (caddr _%entry29445%_)))
                                           _%closure29441%_)))
                                 (declare (not safe))
                                 (##apply + __tmp37818))
                               (let ((__tmp37819
                                      (map (lambda (_%entry29447%_)
                                             (length (caddr _%entry29447%_)))
                                           (##structure-ref
                                            _%snapshot29429%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f))))
                                 (declare (not safe))
                                 (##apply + __tmp37819))
                               (length (##structure-ref
                                        _%spec29430%_
                                        '2
                                        gerbil-ascent/candidate/types#reasoning-candidate::t
                                        '#f)))
                            '#f)
                        '#f)
                    '#f)))
          (if (and (let ()
                     (declare (not safe))
                     (##structure-instance-of?
                      _%certificate29434%_
                      'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                      _%snapshot29429%_))
                   (eq? (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%certificate29434%_
                           '1
                           '#f
                           '#f))
                        'complete)
                   (eq? _%native-status29432%_ 'complete)
                   (null? _%native-rows29433%_)
                   (gerbil-ascent/candidate/nonmembership#ground-query?
                    _%query29437%_)
                   (let ((__tmp37820
                          (##structure-ref
                           _%spec29430%_
                           '3
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)))
                     (declare (not safe))
                     (andmap__0
                      gerbil-ascent/candidate/provenance#positive-rule-body?
                      __tmp37820))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '2
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '3
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '4
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '5
                              '#f
                              '#f))
                           _%candidate-digest29431%_)
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '6
                              '#f
                              '#f))
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                              _%spec29430%_)))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '7
                              '#f
                              '#f))
                           _%query29437%_)
                   _%preflight29449%_
                   (equal? (map (lambda (_%entry29452%_)
                                  (list (car _%entry29452%_)
                                        (cadr _%entry29452%_)))
                                _%closure29441%_)
                           _%schema29439%_))
              (if (> _%preflight29449%_ _%max-checks29435%_)
                  'bounded
                  (if (let ((__tmp37821
                             (lambda (_%entry29456%_)
                               (and (let ((__tmp37822 (caddr _%entry29456%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                       __tmp37822))
                                    (let ((__tmp37824
                                           (lambda (_%row29458%_)
                                             (and (list? _%row29458%_)
                                                  (= (let ()
                                                       (declare (not safe))
                                                       (##length _%row29458%_))
                                                     (cadr _%entry29456%_))
                                                  (let ()
                                                    (declare (not safe))
                                                    (andmap__0
                                                     gerbil-ascent/candidate/program#scalar?
                                                     _%row29458%_)))))
                                          (__tmp37823 (caddr _%entry29456%_)))
                                      (declare (not safe))
                                      (andmap__0 __tmp37824 __tmp37823))))))
                        (declare (not safe))
                        (andmap__0 __tmp37821 _%closure29441%_))
                      (let* ((_%steps29462%_ _%preflight29449%_)
                             (_%bounded?29464%_ '#f)
                             (_%invalid?29466%_ '#f)
                             (_%direct?29523%_
                              (let* ((_%$%closure2946729483%_ _%closure29441%_)
                                     (_%$%else2947129491%_ (lambda () '#f)))
                                (let ((_%$%K2948129520%_ (lambda () '#t))
                                      (_%$%K2947829510%_ (lambda () '#t))
                                      (_%$%K2947329496%_ (lambda () '#t)))
                                  (let ((_%$%try-match2946929516%_
                                         (lambda ()
                                           (if (pair? _%$%closure2946729483%_)
                                               (let ((_%$%tl2948029513%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%closure2946729483%_))))
                                                 (if (null? _%$%tl2948029513%_)
                                                     (_%$%K2947829510%_)
                                                     (if (pair? _%$%tl2948029513%_)
                                                         (let ((_%$%tl2947729502%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##cdr _%$%tl2948029513%_))))
                   (if (null? _%$%tl2947729502%_)
                       (_%$%K2947329496%_)
                       (_%$%else2947129491%_)))
                 (_%$%else2947129491%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%$%else2947129491%_)))))
                                    (if (null? _%$%closure2946729483%_)
                                        (_%$%K2948129520%_)
                                        (_%$%try-match2946929516%_))))))
                             (_%index29525%_
                              (if _%direct?29523%_
                                  '()
                                  (let ((__tmp37825 (length _%closure29441%_)))
                                    (declare (not safe))
                                    (make-hash-table-eq 'size: __tmp37825)))))
                        (letrec* ((_%relation-entry29528%_
                                   (lambda (_%name29600%_)
                                     (if _%direct?29523%_
                                         (let ((_%entry29602%_
                                                (assq _%name29600%_
                                                      _%index29525%_)))
                                           (if _%entry29602%_
                                               (cdr _%entry29602%_)
                                               '#f))
                                         (let ()
                                           (declare (not safe))
                                           (hash-get
                                            _%index29525%_
                                            _%name29600%_)))))
                                  (_g37826_
                                   (let ((_g37827_
                                          (for-each
                                           (lambda (_%entry29530%_)
                                             (let ((_%present29532%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (make-hash-table__%
                                                       '#f
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value))))
                                               (for-each
                                                (lambda (_%row29534%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%present29532%_
                                                     _%row29534%_
                                                     '#t)))
                                                (caddr _%entry29530%_))
                                               (if (_%relation-entry29528%_
                                                    (car _%entry29530%_))
                                                   '#!void
                                                   (let ((_%value29536%_
                                                          (cons (caddr _%entry29530%_)
                                                                _%present29532%_)))
                                                     (if _%direct?29523%_
                                                         (set! _%index29525%_
                                                               (cons (cons (car _%entry29530%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                   _%value29536%_)
                             _%index29525%_))
                 (let ((__tmp37829 (car _%entry29530%_)))
                   (declare (not safe))
                   (hash-put! _%index29525%_ __tmp37829 _%value29536%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           _%closure29441%_)))
                                     #!void
                                     _g37827_))
                                  (_%rows29537%_
                                   (lambda (_%name29596%_)
                                     (let ((_%entry29598%_
                                            (_%relation-entry29528%_
                                             _%name29596%_)))
                                       (if _%entry29598%_
                                           (car _%entry29598%_)
                                           '()))))
                                  (_%contains?29538%_
                                   (lambda (_%name29591%_ _%row29592%_)
                                     (let ((_%entry29594%_
                                            (_%relation-entry29528%_
                                             _%name29591%_)))
                                       (if _%entry29594%_
                                           (let ((__tmp37830
                                                  (cdr _%entry29594%_)))
                                             (declare (not safe))
                                             (hash-get
                                              __tmp37830
                                              _%row29592%_))
                                           '#f)))))
                          (begin
                            (if _%bounded?29464%_
                                '#!void
                                (for-each
                                 (lambda (_%entry29540%_)
                                   (for-each
                                    (lambda (_%row29542%_)
                                      (if (_%contains?29538%_
                                           (car _%entry29540%_)
                                           _%row29542%_)
                                          '#!void
                                          (set! _%invalid?29466%_ '#t)))
                                    (caddr _%entry29540%_)))
                                 (##structure-ref
                                  _%snapshot29429%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f)))
                            (if _%bounded?29464%_
                                '#!void
                                (for-each
                                 (lambda (_%fact29544%_)
                                   (if (_%contains?29538%_
                                        (vector-ref _%fact29544%_ '0)
                                        (vector-ref _%fact29544%_ '1))
                                       '#!void
                                       (set! _%invalid?29466%_ '#t)))
                                 (##structure-ref
                                  _%spec29430%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if (if _%bounded?29464%_
                                    '#f
                                    (_%contains?29538%_
                                     (car _%query29437%_)
                                     (cdr _%query29437%_)))
                                (set! _%invalid?29466%_ '#t)
                                '#!void)
                            (if (or _%bounded?29464%_ _%invalid?29466%_)
                                '#!void
                                (for-each
                                 (lambda (_%rule29549%_)
                                   (let* ((_%head29551%_
                                           (vector-ref _%rule29549%_ '0))
                                          (_%covered-head?29555%_
                                           (if (memq '?_ (cdr _%head29551%_))
                                               '#f
                                               (let ((__tmp37832
                                                      (lambda (_%clause29553%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                               _%clause29553%_))
                                                            '#f
                                                            (equal? _%head29551%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%clause29553%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp37831
                                                      (vector-ref
                                                       _%rule29549%_
                                                       '1)))
                                                 (declare (not safe))
                                                 (ormap__0
                                                  __tmp37832
                                                  __tmp37831))))
                                          (_%head-patterns29557%_
                                           (if _%covered-head?29555%_
                                               '()
                                               (gerbil-ascent/candidate/nonmembership#binding-patterns__%
                                                (cdr _%head29551%_)
                                                '#f)))
                                          (_%head-entry29559%_
                                           (if _%covered-head?29555%_
                                               '#f
                                               (_%relation-entry29528%_
                                                (car _%head29551%_))))
                                          (_%body29563%_
                                           (map (lambda (_%clause29561%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                         _%clause29561%_))
                                                      (vector '#t
                                                              _%clause29561%_
                                                              '())
                                                      (vector '#f
                                                              (gerbil-ascent/candidate/nonmembership#binding-patterns__0
                                                               (cdr _%clause29561%_))
                                                              (_%rows29537%_
                                                               (car _%clause29561%_)))))
                                                (vector-ref
                                                 _%rule29549%_
                                                 '1))))
                                     (letrec ((_%walk29566%_
                                               (lambda (_%remaining29568%_
                                                        _%bindings29569%_)
                                                 (if (or _%bounded?29464%_
                                                         _%invalid?29466%_)
                                                     '#!void
                                                     (if (null? _%remaining29568%_)
                                                         (if (or _%covered-head?29555%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (and _%head-entry29559%_
                              (let ((__tmp37834 (cdr _%head-entry29559%_))
                                    (__tmp37833
                                     (gerbil-ascent/candidate/nonmembership#head-row
                                      _%head-patterns29557%_
                                      _%bindings29569%_)))
                                (declare (not safe))
                                (hash-get __tmp37834 __tmp37833))))
                     '#!void
                     (set! _%invalid?29466%_ '#t))
                 (let ((_%clause29577%_ (car _%remaining29568%_)))
                   (if (vector-ref _%clause29577%_ '0)
                       (begin
                         (set! _%steps29462%_ (+ _%steps29462%_ '1))
                         (if (> _%steps29462%_ _%max-checks29435%_)
                             (set! _%bounded?29464%_ '#t)
                             (let ((_%next29579%_
                                    (let ((__tmp37835
                                           (vector-ref _%clause29577%_ '1)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                       __tmp37835
                                       _%bindings29569%_))))
                               (if _%next29579%_
                                   (_%walk29566%_
                                    (cdr _%remaining29568%_)
                                    _%next29579%_)
                                   '#!void))))
                       (for-each
                        (lambda (_%row29581%_)
                          (if (or _%bounded?29464%_ _%invalid?29466%_)
                              '#!void
                              (begin
                                (set! _%steps29462%_ (+ _%steps29462%_ '1))
                                (if (> _%steps29462%_ _%max-checks29435%_)
                                    (set! _%bounded?29464%_ '#t)
                                    (let ((_%next29586%_
                                           (let ((__tmp37836
                                                  (vector-ref
                                                   _%clause29577%_
                                                   '1)))
                                             (declare (not safe))
                                             (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                              __tmp37836
                                              _%row29581%_
                                              _%bindings29569%_))))
                                      (if _%next29586%_
                                          (_%walk29566%_
                                           (cdr _%remaining29568%_)
                                           _%next29586%_)
                                          '#!void))))))
                        (vector-ref _%clause29577%_ '2)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29566%_ _%body29563%_ '()))))
                                 (##structure-ref
                                  _%spec29430%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if _%invalid?29466%_
                                'invalid
                                (if _%bounded?29464%_ 'bounded 'valid)))))
                      'invalid))
              'invalid))))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership
      (lambda (_%snapshot29421%_
               _%spec29422%_
               _%candidate-digest29423%_
               _%native-status29424%_
               _%native-rows29425%_
               _%certificate29426%_
               _%max-checks29427%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29421%_))
            (gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
             _%snapshot29421%_
             _%spec29422%_
             _%candidate-digest29423%_
             _%native-status29424%_
             _%native-rows29425%_
             _%certificate29426%_
             _%max-checks29427%_)
            'invalid)))))
