def shared_validate_label(text,item,task,supplied,prior):
    import re
    required={'quote','occurrence','category','atom','premises'}
    assert isinstance(item,dict) and set(item)==required,'label schema'
    quote=item['quote'];occurrence=item['occurrence'];category=item['category']
    assert isinstance(quote,str) and quote and type(occurrence) is int and occurrence>=0
    assert category in SHARED_LABEL_TOOL['parameters']['properties']['episodes']['items']['properties']['category']['enum']
    at=-1
    for _ in range(occurrence+1):
        at=text.find(quote,at+1);assert at>=0,'quote not verbatim'
    result={**item,'span':[at,at+len(quote)],'qualifiedPositive':False,'repeatFact':False,'exactRepeat':False,'newConsequence':False}
    if category in ('arithmetic','ambiguous'):
        assert item['atom']==[] and item['premises']==[],'nonsemantic category must not assign atoms'
        return result
    atom=item['atom'];premises=item['premises'];truth=shared_truth(task,atom)
    numbers={int(x) for x in re.findall(r'(?<![\w.])-?\d+(?![\w.])',quote)}
    assert all(n in numbers for a in [atom,*premises] for n in a[1:]),'endpoints absent from quote'
    if category=='absence_recheck':
        assert not truth and re.search(r'\b(no|not|cannot|unreachable|absent|missing|false)\b',quote,re.I),'unsupported absence label'
        result['absenceArgumentCompletenessVerified']=False
        return result
    assert truth,'false positive conclusion'
    if category=='premise_consumed':
        assert atom in supplied or any(p['atom']==atom and p['qualifiedPositive'] for p in prior),'premise not established'
        return result
    assert premises and atom not in premises,'empty or circular support'
    assert all(shared_truth(task,p) for p in premises),'false stated premise'
    if atom[0]=='path':
        assert len(premises)>1 or premises[0][0]=='edge','reference alone is not derivation'
        cursor=atom[1]
        for p in premises:
            assert p[0] in ('edge','path') and p[1]==cursor,'nonchain support'
            cursor=p[2]
        assert cursor==atom[2],'wrong chain endpoint'
    elif atom[0]=='ready':
        n=next(n for n in task['needs'] if n[0]==atom[1])
        assert premises==[['path',n[1],n[2]],['path',n[3],n[4]]],'wrong conjunction support'
    else:raise ValueError('source assertion is not a derived consequence')
    previous=[p for p in prior if p['qualifiedPositive'] and p['atom']==atom]
    result.update(qualifiedPositive=True,repeatFact=bool(previous),exactRepeat=any(p['premises']==premises for p in previous),
                  newConsequence=not previous and atom not in supplied,
                  suppliedPremiseRederived=atom in supplied)
    return result


def shared_label(directory, output):
    plan=shared_check(directory);rows=json.loads((output/'ledger.json').read_text());all_labels=[]
    dest=output/'annotations';dest.mkdir(exist_ok=False)
    for row in rows:
        task=plan['tasks'][row['case']]
        for pass_id in range(plan['annotationPasses']):
            prior=[];result={'case':row['case'],'arm':row['arm'],'pass':pass_id,'calls':[]};all_labels.append(result)
            for call in row['calls']:
                folder=output/'calls'/f"{row['case']}-{row['arm']}"/str(call['turn']);source=folder/'thinking.txt'
                blind=hashlib.sha256((task['id']+str(pass_id)+str(call['turn'])).encode()).hexdigest()[:18]
                out=dest/blind/f"{row['arm']}";out.mkdir(parents=True)
                record={'turn':call['turn'],'grossTokens':None,'failure':None,'accepted':[],'rejected':[]};result['calls'].append(record)
                try:
                    text=source.read_text();assert hashlib.sha256(text.encode()).hexdigest()==call['thinkingSha256']
                    assert text,'no visible reasoning'
                    req={'model':plan['model'],'input':[{'role':'user','content':json.dumps({'edges':task['edges'],'needs':task['needs'],'reasoningText':text})}],
                         'instructions':plan['annotationRubric'],'tools':[plan['annotationTool']],'tool_choice':{'type':'function','name':'annotate'},
                         'reasoning':{'effort':'none'},'max_output_tokens':plan['annotationOutputCap'],'stream':True,'store':False}
                    (out/'request.json').write_text(json.dumps(req,indent=2)+'\n')
                    _,meta=provider(req,provider_key(),out/'response.json');term=meta.get('terminal') or {};u=term.get('usage')
                    if isinstance(u,dict) and all(type(u.get(k)) is int and u[k]>=0 for k in ('input_tokens','output_tokens')):
                        record['grossTokens']=u['input_tokens']+u['output_tokens']
                    assert not meta.get('error') and term.get('status')=='completed','annotation provider failure'
                    calls=[c for c in term['output'] if c['type']=='function_call'];assert len(calls)==1 and calls[0]['name']=='annotate'
                    raw=json.loads(calls[0]['arguments']);assert set(raw)=={'episodes'} and isinstance(raw['episodes'],list)
                    record['raw']=raw['episodes'];supplied=[f['atom'] for f in (call.get('nativePacket') or {}).get('facts',[]) if f['status']=='verified']
                    for item in raw['episodes']:
                        try:
                            label=shared_validate_label(text,item,task,supplied,prior)
                            assert not record['accepted'] or label['span'][0]>=record['accepted'][-1]['span'][1],'overlapping labels'
                            label.update(turn=call['turn'],afterFirstQuestion=call['turn']>0)
                            record['accepted'].append(label);prior.append(label)
                        except Exception as error:record['rejected'].append({'item':item,'failure':str(error)})
                except Exception as error:record['failure']=str(error)
                (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
                (output/'annotation-ledger.json').write_text(json.dumps(all_labels,indent=2)+'\n')
                print('SHARED_LABEL',row['case'],row['arm'],pass_id,call['turn'],len(record['accepted']),len(record['rejected']),record['failure'],flush=True)
    shared_check(directory)


def shared_report(directory, output):
    import tarfile
    plan=shared_check(directory);rows=json.loads((output/'ledger.json').read_text());labels=json.loads((output/'annotation-ledger.json').read_text());points=[];summaries=[]
    for row in rows:
        for pass_id in range(plan['annotationPasses']):
            phase=next(x for x in labels if (x['case'],x['arm'],x['pass'])==(row['case'],row['arm'],pass_id))
            accepted=[e for c in phase['calls'] for e in c['accepted']]
            summaries.append({'case':row['case'],'arm':row['arm'],'pass':pass_id,
                'qualifiedPositive':sum(e['qualifiedPositive'] for e in accepted),
                'sharedPremiseDerivations':sum(e['qualifiedPositive'] and e['atom']==plan['tasks'][row['case']]['sharedAtom'] for e in accepted),
                'observedRepeatedFacts':sum(e['repeatFact'] for e in accepted),
                'observedExactRepeats':sum(e['exactRepeat'] for e in accepted),
                'newConsequencesAfterFirst':sum(e['qualifiedPositive'] and e['newConsequence'] and e['afterFirstQuestion'] for e in accepted),
                'consumedPremises':sum(e['category']=='premise_consumed' for e in accepted),
                'absenceLabels':sum(e['category']=='absence_recheck' for e in accepted),
                'rejected':sum(len(c['rejected']) for c in phase['calls']),'failedCalls':sum(c['failure'] is not None for c in phase['calls'])})
    for case in range(len(plan['tasks'])):
        case_rows=[r for r in rows if r['case']==case]
        for budget in plan['checkpoints']:
            # Completed schedules can be compared at a larger common cap; reservation failures cannot.
            if not all(r['grossTokens']>=budget or r['stop']=='schedule_complete' for r in case_rows):continue
            points.append({'case':case,'budget':budget,'arms':[{'arm':r['arm'],
                'correctDownstreamAnswers':sum(c['correct'] and c.get('atGrossTokens',budget+1)<=budget for c in r['calls']),
                'correctNewAnswersAfterFirst':sum(c['correct'] and c['turn']>0 and c.get('atGrossTokens',budget+1)<=budget for c in r['calls'])} for r in case_rows]})
    concordance=[]
    for row in rows:
        sets=[]
        for pass_id in range(plan['annotationPasses']):
            phase=next(x for x in labels if (x['case'],x['arm'],x['pass'])==(row['case'],row['arm'],pass_id))
            sets.append({json.dumps([e['turn'],e['atom'],e['premises']],sort_keys=True) for c in phase['calls'] for e in c['accepted'] if e['qualifiedPositive']})
        concordance.append({'case':row['case'],'arm':row['arm'],'intersection':len(sets[0]&sets[1]),'union':len(sets[0]|sets[1]),
            'qualifiedEpisodeJaccard':len(sets[0]&sets[1])/len(sets[0]|sets[1]) if sets[0]|sets[1] else None})
    report={'planSha256':hashlib.sha256((directory/'plan.json').read_bytes()).hexdigest(),
        'solverKnownTokens':sum(c['grossTokens'] or 0 for r in rows for c in r['calls']),
        'solverUnknownUsageCalls':sum(c['grossTokens'] is None for r in rows for c in r['calls']),
        'annotationKnownTokens':sum(c['grossTokens'] or 0 for x in labels for c in x['calls']),
        'annotationUnknownUsageCalls':sum(c['grossTokens'] is None for x in labels for c in x['calls']),
        'trajectories':rows,'annotationSummaries':summaries,'annotationConcordance':concordance,'jointCheckpoints':points,
        'claims':'Observed literal derivation counts are lower bounds. Two passes use the same stochastic model, so concordance does not establish independent-rater reliability or completeness. No depth/optimization/causal efficacy claim follows from two small fixtures. Unused budget is not savings. Native cache reuse and model behavior are separate.'}
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    lines=['# Shared-premise Library diagnostic','',report['claims'],'',
        '| Case | Arm | Total input + all output | Correct obligations | Correct new answers after first | Stop |',
        '|---|---|---:|---:|---:|---|']
    for r in rows:lines.append(f"| {r['case']} | {r['arm']} | {r['grossTokens']} | {sum(c['correct'] for c in r['calls'])} | {sum(c['correct'] and c['turn']>0 for c in r['calls'])} | {r['stop']} {r['failure'] or ''} |")
    lines += ['','| Case / arm / annotation pass | Shared-premise derivations | Observed repeated Facts | New consequences after first | Consumed premises | Rejected labels |',
              '|---|---:|---:|---:|---:|---:|']
    for a in summaries:lines.append(f"| {a['case']} / {a['arm']} / {a['pass']} | {a['sharedPremiseDerivations']} | {a['observedRepeatedFacts']} | {a['newConsequencesAfterFirst']} | {a['consumedPremises']} | {a['rejected']} |")
    lines += ['',f"Known solver tokens: {report['solverKnownTokens']}; unknown-usage calls: {report['solverUnknownUsageCalls']}. Known annotation tokens: {report['annotationKnownTokens']}; unknown annotation calls: {report['annotationUnknownUsageCalls']}.",
        '', 'The source-bound native qualification proves support reuse across three distinct downstream obligations, alternative-support preservation, stale-handle rejection and withdrawal recomputation on this fixture. Quint correspondence and Lean premises are separate gates. The baseline/Fact/Scheme arms share the same questions and full reasoning-history replay, and do not prune alternatives. Failures remain in the ledger. No anti-repetition instruction is supplied.',
        '', 'See plan.json for relative source hashes, paper lessons, formal scope, exact tasks, independent grader and frozen annotation rules; raw.tar.gz retains inputs, native artifacts, requests, SSE events, returned thinking and rejected labels. This is a local Darwin source snapshot, not a portable binary wheel or a verified clean Git checkout reproduction.']
    (output/'report.md').write_text('\n'.join(lines)+'\n')
    doc=s.ROOT/'docs/research/agent-inference/fact-reuse-results/shared-premise-diagnostic';doc.mkdir(exist_ok=False)
    for name in ['report.json','report.md','ledger.json','annotation-ledger.json']:shutil.copy2(output/name,doc/name)
    for name in ['plan.json','plan.sha256','qualification.json','cffi-api-receipt.json','native-build-receipt.json']:shutil.copy2(directory/name,doc/name)
    with tarfile.open(doc/'raw.tar.gz','w:gz') as archive:
        archive.add(directory,arcname='frozen');archive.add(output,arcname='run')
    (doc/'integrity.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in doc.iterdir() if p.is_file()},indent=2)+'\n')
    print('SHARED_REPORT',doc,flush=True)
