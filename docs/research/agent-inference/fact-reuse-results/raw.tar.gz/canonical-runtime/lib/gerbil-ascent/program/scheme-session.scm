(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/scheme-snapshot")
    (load-module "gerbil-ascent/program/scheme-query")
    (load-module "gerbil-ascent/program/scheme-checked")
    (load-module "gerbil-ascent/program/session")
    (load-module "gerbil-ascent/program/types")
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop"))
  (load-module "gerbil-ascent/program/scheme-session~0"))
