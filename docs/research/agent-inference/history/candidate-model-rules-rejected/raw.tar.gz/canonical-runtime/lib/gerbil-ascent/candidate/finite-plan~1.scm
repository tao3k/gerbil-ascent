(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37260_|
    (##structure
     gx#syntax-quote::t
     'finite-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37262_|
    (##structure
     gx#syntax-quote::t
     'make-finite-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37264_|
    (##structure
     gx#syntax-quote::t
     'finite-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37266_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37267_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37268_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37269_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37271_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37272_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37273_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37274_|
    (##structure
     gx#syntax-quote::t
     'finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37276_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37277_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37278_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37279_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37281_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37282_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37283_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37284_|
    (##structure
     gx#syntax-quote::t
     '&finite-rule-level-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37286_|
    (##structure
     gx#syntax-quote::t
     'finite-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37288_|
    (##structure
     gx#syntax-quote::t
     'make-finite-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37290_|
    (##structure
     gx#syntax-quote::t
     'finite-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37292_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37293_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37294_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37295_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37296_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37298_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37299_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37300_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37301_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37302_|
    (##structure
     gx#syntax-quote::t
     'finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37304_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37305_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37306_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37307_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37308_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37310_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37311_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37312_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37313_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-output-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/finite-plan[1]#_g37314_|
    (##structure
     gx#syntax-quote::t
     '&finite-clause-operator-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-rule|
      (let ((__obj37173
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37173
           'gerbil-ascent/candidate/finite-plan#finite-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 'finite-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37173
           '(relation head body level)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37173
           '(relation head body level)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '#f '13 '#f '#f))
        (let ((__tmp37259 |gerbil-ascent/candidate/finite-plan[1]#_g37260_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37259 '4 '#f '#f))
        (let ((__tmp37261 |gerbil-ascent/candidate/finite-plan[1]#_g37262_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37261 '14 '#f '#f))
        (let ((__tmp37263 |gerbil-ascent/candidate/finite-plan[1]#_g37264_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37263 '15 '#f '#f))
        (let ((__tmp37265
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37266_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37267_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37268_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37269_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37265 '16 '#f '#f))
        (let ((__tmp37270
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37271_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37272_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37273_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37274_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37270 '17 '#f '#f))
        (let ((__tmp37275
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37276_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37277_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37278_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37279_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37275 '18 '#f '#f))
        (let ((__tmp37280
               (cons (cons 'relation
                           |gerbil-ascent/candidate/finite-plan[1]#_g37281_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37282_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37283_|)
                                 (cons (cons 'level
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37284_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 __tmp37280 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37173 '() '21 '#f '#f))
        __obj37173))
    (define |gerbil-ascent/candidate/finite-plan[:0:]#finite-clause|
      (let ((__obj37174
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37174
           'gerbil-ascent/candidate/finite-plan#finite-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 'finite-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37174
           '(kind relation apply output operator)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37174
           '(kind relation apply output operator)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '#f '13 '#f '#f))
        (let ((__tmp37285 |gerbil-ascent/candidate/finite-plan[1]#_g37286_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37285 '4 '#f '#f))
        (let ((__tmp37287 |gerbil-ascent/candidate/finite-plan[1]#_g37288_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37287 '14 '#f '#f))
        (let ((__tmp37289 |gerbil-ascent/candidate/finite-plan[1]#_g37290_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37289 '15 '#f '#f))
        (let ((__tmp37291
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37292_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37293_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37294_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37295_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37296_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37291 '16 '#f '#f))
        (let ((__tmp37297
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37298_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37299_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37300_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37301_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37302_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37297 '17 '#f '#f))
        (let ((__tmp37303
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37304_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37305_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37306_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37307_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37308_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37303 '18 '#f '#f))
        (let ((__tmp37309
               (cons (cons 'kind
                           |gerbil-ascent/candidate/finite-plan[1]#_g37310_|)
                     (cons (cons 'relation
                                 |gerbil-ascent/candidate/finite-plan[1]#_g37311_|)
                           (cons (cons 'apply
                                       |gerbil-ascent/candidate/finite-plan[1]#_g37312_|)
                                 (cons (cons 'output
                                             |gerbil-ascent/candidate/finite-plan[1]#_g37313_|)
                                       (cons (cons 'operator
                                                   |gerbil-ascent/candidate/finite-plan[1]#_g37314_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 __tmp37309 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37174 '() '21 '#f '#f))
        __obj37174))))
