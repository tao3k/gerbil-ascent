prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-class
   gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
   (@class gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
           ()
           (object::t t::t)
           (fresh head clauses)
           (fresh head clauses)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/proof-frame#proof-binding-flow::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow?
   (@predicate gerbil-ascent/candidate/proof-frame#proof-binding-flow::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#make-proof-binding-flow
   (@constructor gerbil-ascent/candidate/proof-frame#proof-binding-flow::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    fresh
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-head
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    head
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    clauses
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-fresh-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    fresh
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-head-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    head
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-flow-clauses-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    clauses
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    fresh
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    head
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    clauses
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-fresh-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    fresh
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-head-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    head
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-flow-clauses-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
    clauses
    #f))
  (declare-class
   gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
   (@class gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
           ()
           (object::t t::t)
           (relation apply)
           (relation apply)
           #f
           #t
           #t
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/proof-frame#proof-binding-clause::t)
    'class::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause?
   (@predicate gerbil-ascent/candidate/proof-frame#proof-binding-clause::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#make-proof-binding-clause
   (@constructor gerbil-ascent/candidate/proof-frame#proof-binding-clause::t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    apply
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause-relation-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    relation
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#proof-binding-clause-apply-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    apply
    #t))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply
   (@accessor
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    apply
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-clause-relation-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    relation
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#&proof-binding-clause-apply-set!
   (@mutator
    gerbil-ascent/candidate/proof-frame#proof-binding-clause::t
    apply
    #f))
  (declare-type
   gerbil-ascent/candidate/proof-frame#prepare-proof-binding-flow
   (@lambda 2
            #f
            signature:
            (return:
             gerbil-ascent/candidate/proof-frame#proof-binding-flow::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/proof-frame))))
