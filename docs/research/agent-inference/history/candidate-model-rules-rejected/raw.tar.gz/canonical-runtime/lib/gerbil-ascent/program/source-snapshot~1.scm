(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-snapshot[1]#_g36633_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36635_|
    (##structure
     gx#syntax-quote::t
     'make-source-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36637_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36639_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36640_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36641_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36642_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36643_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36645_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36646_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36647_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36648_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36649_|
    (##structure
     gx#syntax-quote::t
     'source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36651_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36652_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36653_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36654_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36655_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36657_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-template-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36658_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-program-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36659_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-declarations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36660_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36661_|
    (##structure
     gx#syntax-quote::t
     '&source-snapshot-materializations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36663_|
    (##structure
     gx#syntax-quote::t
     'source-materialization::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36665_|
    (##structure
     gx#syntax-quote::t
     'make-source-materialization
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36667_|
    (##structure
     gx#syntax-quote::t
     'source-materialization?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36669_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36670_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36671_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36672_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36674_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36675_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36676_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36677_|
    (##structure
     gx#syntax-quote::t
     'source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36679_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36680_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36681_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36682_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36684_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-base-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36685_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36686_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36687_|
    (##structure
     gx#syntax-quote::t
     '&source-materialization-scalar?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36689_|
    (gx#core-deserialize-mark
     '(0
       ($%arg11927 . _%$%arg1192711985%_)
       (id . _%id11952%_)
       (arg . _%arg12015%_)
       ($%arg11928 . _%$%arg1192811999%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36690_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36689_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36693_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36694_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36693_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36696_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36693_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36698_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12049 . _%$%arg1204912119%_)
       (id . _%id12072%_)
       ($%arg12048 . _%$%arg1204812105%_)
       (arg . _%arg12135%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36699_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36698_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36702_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36703_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36702_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36705_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36702_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36707_|
    (gx#core-deserialize-mark
     '(0
       (id . _%id12192%_)
       (arg . _%arg12255%_)
       ($%arg12168 . _%$%arg1216812225%_)
       ($%arg12169 . _%$%arg1216912239%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36708_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36707_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36711_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36712_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36711_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36714_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36711_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36716_|
    (gx#core-deserialize-mark
     '(0
       ($%arg12289 . _%$%arg1228912359%_)
       (id . _%id12312%_)
       (arg . _%arg12375%_)
       ($%arg12288 . _%$%arg1228812345%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36717_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36716_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36720_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36721_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36720_|)))
  (define |gerbil-ascent/program/source-snapshot[1]#_g36723_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-snapshot[1]#_g36720_|)))
  (begin
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-snapshot|
      (let ((__obj36563
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36563
           'gerbil-ascent/program/source-snapshot#source-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 'source-snapshot '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36563
           '(template program declarations rows materializations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36563
           '(template program declarations rows materializations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '#f '13 '#f '#f))
        (let ((__tmp36632 |gerbil-ascent/program/source-snapshot[1]#_g36633_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36632 '4 '#f '#f))
        (let ((__tmp36634 |gerbil-ascent/program/source-snapshot[1]#_g36635_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36634 '14 '#f '#f))
        (let ((__tmp36636 |gerbil-ascent/program/source-snapshot[1]#_g36637_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36636 '15 '#f '#f))
        (let ((__tmp36638
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36639_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36640_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36641_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36642_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36643_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36638 '16 '#f '#f))
        (let ((__tmp36644
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36645_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36646_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36647_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36648_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36649_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36644 '17 '#f '#f))
        (let ((__tmp36650
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36651_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36652_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36653_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36654_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36655_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36650 '18 '#f '#f))
        (let ((__tmp36656
               (cons (cons 'template
                           |gerbil-ascent/program/source-snapshot[1]#_g36657_|)
                     (cons (cons 'program
                                 |gerbil-ascent/program/source-snapshot[1]#_g36658_|)
                           (cons (cons 'declarations
                                       |gerbil-ascent/program/source-snapshot[1]#_g36659_|)
                                 (cons (cons 'rows
                                             |gerbil-ascent/program/source-snapshot[1]#_g36660_|)
                                       (cons (cons 'materializations
                                                   |gerbil-ascent/program/source-snapshot[1]#_g36661_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 __tmp36656 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36563 '() '21 '#f '#f))
        __obj36563))
    (define |gerbil-ascent/program/source-snapshot[:0:]#source-materialization|
      (let ((__obj36564
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36564
           'gerbil-ascent/program/source-snapshot#source-materialization::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36564
           'source-materialization
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36564
           '(base additions rows scalar?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj36564
           '(base additions rows scalar?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '#f '13 '#f '#f))
        (let ((__tmp36662 |gerbil-ascent/program/source-snapshot[1]#_g36663_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36662 '4 '#f '#f))
        (let ((__tmp36664 |gerbil-ascent/program/source-snapshot[1]#_g36665_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36664 '14 '#f '#f))
        (let ((__tmp36666 |gerbil-ascent/program/source-snapshot[1]#_g36667_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36666 '15 '#f '#f))
        (let ((__tmp36668
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36669_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36670_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36671_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36672_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36668 '16 '#f '#f))
        (let ((__tmp36673
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36674_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36675_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36676_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36677_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36673 '17 '#f '#f))
        (let ((__tmp36678
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36679_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36680_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36681_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36682_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36678 '18 '#f '#f))
        (let ((__tmp36683
               (cons (cons 'base
                           |gerbil-ascent/program/source-snapshot[1]#_g36684_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-snapshot[1]#_g36685_|)
                           (cons (cons 'rows
                                       |gerbil-ascent/program/source-snapshot[1]#_g36686_|)
                                 (cons (cons 'scalar?
                                             |gerbil-ascent/program/source-snapshot[1]#_g36687_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 __tmp36683 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj36564 '() '21 '#f '#f))
        __obj36564))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@materialize-source-log|
      (lambda (_%$stx11909%_)
        (let* ((_%__stx3646036461%_ _%$stx11909%_)
               (_%$%g1191411935%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3646036461%_)))))
          (let ((_%__kont3646336464%_
                 (lambda (_%$%g1191612001%_)
                   (cons (let ((__tmp36688
                                |gerbil-ascent/program/source-snapshot[1]#_g36690_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36688
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'base))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'additions))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'previous))
                                                       '())))
                                     (cons (let ((__tmp36691
                                                  (lambda (_%$%g1201612019%_
                                                           _%$%g1201712022%_)
                                                    (cons _%$%g1201612019%_
                                                          _%$%g1201712022%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36691
                                              '()
                                              _%$%g1191612001%_))
                                           '()))
                               (cons (cons (let ((__tmp36692
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36694_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36692
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'previous))
                     (cons (let ((__tmp36695
                                  |gerbil-ascent/program/source-snapshot[1]#_g36696_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36695 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0
                                    '#f
                                    'source-materialization))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__materialize-source-log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'base))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'additions))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'previous))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3646736468%_
                 (lambda (_%$%g1192911942%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'materialize-source-log)))))
            (let* ((_%$%g1191311954%_
                    (lambda ()
                      (let ((_%$%g1192911942%_ _%__stx3646036461%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1192911942%_))
                            (_%__kont3646736468%_ _%$%g1192911942%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1191411935%_))))))
                   (_%__match3648336484%_
                    (lambda (_%$%e1191711961%_
                             _%$%hd1191811965%_
                             _%$%tl1191911968%_
                             _%__splice3646536466%_
                             _%$%target1192011971%_
                             _%$%tl1192211974%_)
                      (letrec ((_%$%loop1192311977%_
                                (lambda (_%$%hd1192111981%_
                                         _%$%arg1192711984%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1192111981%_))
                                      (let ((_%$%e1192411987%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1192111981%_))))
                                        (let ((_%$%lp-tl1192611994%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1192411987%_)))
                                              (_%$%lp-hd1192511991%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1192411987%_))))
                                          (_%$%loop1192311977%_
                                           _%$%lp-tl1192611994%_
                                           (cons _%$%lp-hd1192511991%_
                                                 _%$%arg1192711984%_))))
                                      (let ((_%$%arg1192811997%_
                                             (reverse _%$%arg1192711984%_)))
                                        (_%__kont3646336464%_
                                         _%$%arg1192811997%_))))))
                        (_%$%loop1192311977%_ _%$%target1192011971%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3646036461%_))
                  (let ((_%$%e1191711961%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3646036461%_))))
                    (let ((_%$%tl1191911968%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1191711961%_)))
                          (_%$%hd1191811965%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1191711961%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1191911968%_))
                          (let ((_%__splice3646536466%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1191911968%_
                                    '0))))
                            (let ((_%$%tl1192211974%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3646536466%_ '1)))
                                  (_%$%target1192011971%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3646536466%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1192211974%_))
                                  (_%__match3648336484%_
                                   _%$%e1191711961%_
                                   _%$%hd1191811965%_
                                   _%$%tl1191911968%_
                                   _%__splice3646536466%_
                                   _%$%target1192011971%_
                                   _%$%tl1192211974%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1191311954%_)))))
                          (let () (declare (not safe)) (_%$%g1191311954%_)))))
                  (let () (declare (not safe)) (_%$%g1191311954%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-log-snapshot-equal?|
      (lambda (_%$stx12030%_)
        (let* ((_%__stx3648636487%_ _%$stx12030%_)
               (_%$%g1203512056%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3648636487%_)))))
          (let ((_%__kont3648936490%_
                 (lambda (_%$%g1203712121%_)
                   (cons (let ((__tmp36697
                                |gerbil-ascent/program/source-snapshot[1]#_g36699_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36697
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'log))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'rows))
                           '())))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36700
                                                  (lambda (_%$%g1213612139%_
                                                           _%$%g1213712142%_)
                                                    (cons _%$%g1213612139%_
                                                          _%$%g1213712142%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36700
                                              '()
                                              _%$%g1203712121%_))
                                           '()))
                               (cons (cons (let ((__tmp36701
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36703_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36701
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36704
                                  |gerbil-ascent/program/source-snapshot[1]#_g36705_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36704 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-log-snapshot-equal?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'log))
                                             (cons (let ()
                                                     (declare (not safe))
                                                     (gx#datum->syntax__0
                                                      '#f
                                                      'rows))
                                                   '()))))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3649336494%_
                 (lambda (_%$%g1205012063%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-log-snapshot-equal?)))))
            (let* ((_%$%g1203412074%_
                    (lambda ()
                      (let ((_%$%g1205012063%_ _%__stx3648636487%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1205012063%_))
                            (_%__kont3649336494%_ _%$%g1205012063%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1203512056%_))))))
                   (_%__match3650936510%_
                    (lambda (_%$%e1203812081%_
                             _%$%hd1203912085%_
                             _%$%tl1204012088%_
                             _%__splice3649136492%_
                             _%$%target1204112091%_
                             _%$%tl1204312094%_)
                      (letrec ((_%$%loop1204412097%_
                                (lambda (_%$%hd1204212101%_
                                         _%$%arg1204812104%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1204212101%_))
                                      (let ((_%$%e1204512107%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1204212101%_))))
                                        (let ((_%$%lp-tl1204712114%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1204512107%_)))
                                              (_%$%lp-hd1204612111%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1204512107%_))))
                                          (_%$%loop1204412097%_
                                           _%$%lp-tl1204712114%_
                                           (cons _%$%lp-hd1204612111%_
                                                 _%$%arg1204812104%_))))
                                      (let ((_%$%arg1204912117%_
                                             (reverse _%$%arg1204812104%_)))
                                        (_%__kont3648936490%_
                                         _%$%arg1204912117%_))))))
                        (_%$%loop1204412097%_ _%$%target1204112091%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3648636487%_))
                  (let ((_%$%e1203812081%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3648636487%_))))
                    (let ((_%$%tl1204012088%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1203812081%_)))
                          (_%$%hd1203912085%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1203812081%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1204012088%_))
                          (let ((_%__splice3649136492%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1204012088%_
                                    '0))))
                            (let ((_%$%tl1204312094%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3649136492%_ '1)))
                                  (_%$%target1204112091%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3649136492%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1204312094%_))
                                  (_%__match3650936510%_
                                   _%$%e1203812081%_
                                   _%$%hd1203912085%_
                                   _%$%tl1204012088%_
                                   _%__splice3649136492%_
                                   _%$%target1204112091%_
                                   _%$%tl1204312094%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1203412074%_)))))
                          (let () (declare (not safe)) (_%$%g1203412074%_)))))
                  (let () (declare (not safe)) (_%$%g1203412074%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-source-snapshot-scalar?|
      (lambda (_%$stx12150%_)
        (let* ((_%__stx3651236513%_ _%$stx12150%_)
               (_%$%g1215512176%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3651236513%_)))))
          (let ((_%__kont3651536516%_
                 (lambda (_%$%g1215712241%_)
                   (cons (let ((__tmp36706
                                |gerbil-ascent/program/source-snapshot[1]#_g36708_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36706
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'candidate))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'index))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'rows))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp36709
                                                  (lambda (_%$%g1225612259%_
                                                           _%$%g1225712262%_)
                                                    (cons _%$%g1225612259%_
                                                          _%$%g1225712262%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36709
                                              '()
                                              _%$%g1215712241%_))
                                           '()))
                               (cons (cons (let ((__tmp36710
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36712_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36710
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36713
                                  |gerbil-ascent/program/source-snapshot[1]#_g36714_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36713 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-snapshot-scalar?))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'candidate))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'index))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'rows))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3651936520%_
                 (lambda (_%$%g1217012183%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-snapshot-scalar?)))))
            (let* ((_%$%g1215412194%_
                    (lambda ()
                      (let ((_%$%g1217012183%_ _%__stx3651236513%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1217012183%_))
                            (_%__kont3651936520%_ _%$%g1217012183%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1215512176%_))))))
                   (_%__match3653536536%_
                    (lambda (_%$%e1215812201%_
                             _%$%hd1215912205%_
                             _%$%tl1216012208%_
                             _%__splice3651736518%_
                             _%$%target1216112211%_
                             _%$%tl1216312214%_)
                      (letrec ((_%$%loop1216412217%_
                                (lambda (_%$%hd1216212221%_
                                         _%$%arg1216812224%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1216212221%_))
                                      (let ((_%$%e1216512227%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1216212221%_))))
                                        (let ((_%$%lp-tl1216712234%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1216512227%_)))
                                              (_%$%lp-hd1216612231%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1216512227%_))))
                                          (_%$%loop1216412217%_
                                           _%$%lp-tl1216712234%_
                                           (cons _%$%lp-hd1216612231%_
                                                 _%$%arg1216812224%_))))
                                      (let ((_%$%arg1216912237%_
                                             (reverse _%$%arg1216812224%_)))
                                        (_%__kont3651536516%_
                                         _%$%arg1216912237%_))))))
                        (_%$%loop1216412217%_ _%$%target1216112211%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3651236513%_))
                  (let ((_%$%e1215812201%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3651236513%_))))
                    (let ((_%$%tl1216012208%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1215812201%_)))
                          (_%$%hd1215912205%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1215812201%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1216012208%_))
                          (let ((_%__splice3651736518%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1216012208%_
                                    '0))))
                            (let ((_%$%tl1216312214%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3651736518%_ '1)))
                                  (_%$%target1216112211%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3651736518%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1216312214%_))
                                  (_%__match3653536536%_
                                   _%$%e1215812201%_
                                   _%$%hd1215912205%_
                                   _%$%tl1216012208%_
                                   _%__splice3651736518%_
                                   _%$%target1216112211%_
                                   _%$%tl1216312214%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1215412194%_)))))
                          (let () (declare (not safe)) (_%$%g1215412194%_)))))
                  (let () (declare (not safe)) (_%$%g1215412194%_))))))))
    (define |gerbil-ascent/program/source-snapshot[:0:]#@gerbil-ascent-prepare-source-log-snapshot|
      (lambda (_%$stx12270%_)
        (let* ((_%__stx3653836539%_ _%$stx12270%_)
               (_%$%g1227512296%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3653836539%_)))))
          (let ((_%__kont3654136542%_
                 (lambda (_%$%g1227712361%_)
                   (cons (let ((__tmp36715
                                |gerbil-ascent/program/source-snapshot[1]#_g36717_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp36715
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'snapshot))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'logs))
                                                 '()))
                                     (cons (let ((__tmp36718
                                                  (lambda (_%$%g1237612379%_
                                                           _%$%g1237712382%_)
                                                    (cons _%$%g1237612379%_
                                                          _%$%g1237712382%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp36718
                                              '()
                                              _%$%g1227712361%_))
                                           '()))
                               (cons (cons (let ((__tmp36719
                                                  |gerbil-ascent/program/source-snapshot[1]#_g36721_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp36719
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'snapshot))
                     (cons (let ((__tmp36722
                                  |gerbil-ascent/program/source-snapshot[1]#_g36723_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp36722 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-snapshot))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-log-snapshot))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'snapshot))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'logs))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3654536546%_
                 (lambda (_%$%g1229012303%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-log-snapshot)))))
            (let* ((_%$%g1227412314%_
                    (lambda ()
                      (let ((_%$%g1229012303%_ _%__stx3653836539%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1229012303%_))
                            (_%__kont3654536546%_ _%$%g1229012303%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1227512296%_))))))
                   (_%__match3656136562%_
                    (lambda (_%$%e1227812321%_
                             _%$%hd1227912325%_
                             _%$%tl1228012328%_
                             _%__splice3654336544%_
                             _%$%target1228112331%_
                             _%$%tl1228312334%_)
                      (letrec ((_%$%loop1228412337%_
                                (lambda (_%$%hd1228212341%_
                                         _%$%arg1228812344%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1228212341%_))
                                      (let ((_%$%e1228512347%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1228212341%_))))
                                        (let ((_%$%lp-tl1228712354%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1228512347%_)))
                                              (_%$%lp-hd1228612351%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1228512347%_))))
                                          (_%$%loop1228412337%_
                                           _%$%lp-tl1228712354%_
                                           (cons _%$%lp-hd1228612351%_
                                                 _%$%arg1228812344%_))))
                                      (let ((_%$%arg1228912357%_
                                             (reverse _%$%arg1228812344%_)))
                                        (_%__kont3654136542%_
                                         _%$%arg1228912357%_))))))
                        (_%$%loop1228412337%_ _%$%target1228112331%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3653836539%_))
                  (let ((_%$%e1227812321%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3653836539%_))))
                    (let ((_%$%tl1228012328%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1227812321%_)))
                          (_%$%hd1227912325%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1227812321%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1228012328%_))
                          (let ((_%__splice3654336544%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1228012328%_
                                    '0))))
                            (let ((_%$%tl1228312334%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3654336544%_ '1)))
                                  (_%$%target1228112331%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3654336544%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1228312334%_))
                                  (_%__match3656136562%_
                                   _%$%e1227812321%_
                                   _%$%hd1227912325%_
                                   _%$%tl1228012328%_
                                   _%__splice3654336544%_
                                   _%$%target1228112331%_
                                   _%$%tl1228312334%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1227412314%_)))))
                          (let () (declare (not safe)) (_%$%g1227412314%_)))))
                  (let () (declare (not safe)) (_%$%g1227412314%_))))))))))
