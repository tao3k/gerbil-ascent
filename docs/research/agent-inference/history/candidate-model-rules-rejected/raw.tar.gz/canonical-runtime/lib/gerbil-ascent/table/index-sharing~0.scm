(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/index-sharing::timestamp 1791687858)
  (begin
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-certificate?
      (lambda (_%sets14597%_ _%left14598%_ _%right14599%_)
        (let ((__tmp33534
               (lambda (_%reject14601%_)
                 (if (and (vector? _%sets14597%_)
                          (vector? _%left14598%_)
                          (vector? _%right14599%_)
                          (= (let ()
                               (declare (not safe))
                               (##vector-length _%sets14597%_))
                             (let ()
                               (declare (not safe))
                               (##vector-length _%left14598%_))
                             (let ()
                               (declare (not safe))
                               (##vector-length _%right14599%_))))
                     '#!void
                     (_%reject14601%_ '#f))
                 (let* ((_%count14603%_ (vector-length _%sets14597%_))
                        (_%ids14605%_
                         (let () (declare (not safe)) (##iota _%count14603%_)))
                        (_%widths14607%_ (vector-map length _%sets14597%_))
                        (_%members14609%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14603%_ '#f)))
                        (_%seen-left14611%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14603%_ '#f)))
                        (_%seen-right14613%_
                         (let ()
                           (declare (not safe))
                           (##make-vector _%count14603%_ '#f)))
                        (_%pending14615%_ '())
                        (_%matched14617%_ '0)
                        (_%cover-count14619%_ '0))
                   (letrec ((_%membership14622%_
                             (lambda (_%j14658%_)
                               (let ((_%$e14660%_
                                      (vector-ref
                                       _%members14609%_
                                       _%j14658%_)))
                                 (if _%$e14660%_
                                     _%$e14660%_
                                     (let ((_%table14663%_
                                            (let ()
                                              (declare (not safe))
                                              (make-hash-table__%
                                               '#f
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value
                                               absent-value))))
                                       (for-each
                                        (lambda (_%$%g1466414666%_)
                                          (let ()
                                            (declare (not safe))
                                            (__hash-put!
                                             _%table14663%_
                                             _%$%g1466414666%_
                                             '#t)))
                                        (vector-ref _%sets14597%_ _%j14658%_))
                                       (vector-set!
                                        _%members14609%_
                                        _%j14658%_
                                        _%table14663%_)
                                       _%table14663%_)))))
                            (_%below?14623%_
                             (lambda (_%i14649%_ _%j14650%_)
                               (if (< (vector-ref _%widths14607%_ _%i14649%_)
                                      (vector-ref _%widths14607%_ _%j14650%_))
                                   (let ((_%table14652%_
                                          (_%membership14622%_ _%j14650%_)))
                                     (let ((__tmp33536
                                            (lambda (_%$%g1465314655%_)
                                              (let ()
                                                (declare (not safe))
                                                (hash-key?
                                                 _%table14652%_
                                                 _%$%g1465314655%_))))
                                           (__tmp33535
                                            (vector-ref
                                             _%sets14597%_
                                             _%i14649%_)))
                                       (declare (not safe))
                                       (andmap__0 __tmp33536 __tmp33535)))
                                   '#f)))
                            (_%index?14624%_
                             (lambda (_%x14644%_)
                               (let ((_%$e14646%_ (eq? _%x14644%_ '#f)))
                                 (if _%$e14646%_
                                     _%$e14646%_
                                     (if (exact-integer? _%x14644%_)
                                         (if (<= '0 _%x14644%_)
                                             (< _%x14644%_ _%count14603%_)
                                             '#f)
                                         '#f))))))
                     (if (and (let ((__tmp33537 (vector->list _%left14598%_)))
                                (declare (not safe))
                                (andmap__0 _%index?14624%_ __tmp33537))
                              (let ((__tmp33538 (vector->list _%right14599%_)))
                                (declare (not safe))
                                (andmap__0 _%index?14624%_ __tmp33538)))
                         '#!void
                         (_%reject14601%_ '#f))
                     (let ((__tmp33539
                            (lambda (_%i14626%_)
                              (let ((_%j14628%_
                                     (vector-ref _%left14598%_ _%i14626%_))
                                    (_%owner14629%_
                                     (vector-ref _%right14599%_ _%i14626%_)))
                                (if _%j14628%_
                                    (begin
                                      (if (and (eqv? (vector-ref
                                                      _%right14599%_
                                                      _%j14628%_)
                                                     _%i14626%_)
                                               (_%below?14623%_
                                                _%i14626%_
                                                _%j14628%_))
                                          '#!void
                                          (_%reject14601%_ '#f))
                                      (set! _%matched14617%_
                                            (+ _%matched14617%_ '1)))
                                    '#!void)
                                (if _%owner14629%_
                                    (if (eqv? (vector-ref
                                               _%left14598%_
                                               _%owner14629%_)
                                              _%i14626%_)
                                        '#!void
                                        (_%reject14601%_ '#f))
                                    '#!void)
                                (if _%j14628%_
                                    '#!void
                                    (begin
                                      (vector-set!
                                       _%seen-left14611%_
                                       _%i14626%_
                                       '#t)
                                      (set! _%pending14615%_
                                            (cons _%i14626%_
                                                  _%pending14615%_))))))))
                       (declare (not safe))
                       (##for-each __tmp33539 _%ids14605%_))
                     (let _%traverse14631%_ ()
                       (if (pair? _%pending14615%_)
                           (begin
                             (let ((_%i14634%_ (car _%pending14615%_)))
                               (set! _%pending14615%_ (cdr _%pending14615%_))
                               (let ((__tmp33540
                                      (lambda (_%j14636%_)
                                        (if (and (_%below?14623%_
                                                  _%i14634%_
                                                  _%j14636%_)
                                                 (not (vector-ref
                                                       _%seen-right14613%_
                                                       _%j14636%_)))
                                            (begin
                                              (vector-set!
                                               _%seen-right14613%_
                                               _%j14636%_
                                               '#t)
                                              (let ((_%owner14638%_
                                                     (vector-ref
                                                      _%right14599%_
                                                      _%j14636%_)))
                                                (if _%owner14638%_
                                                    '#!void
                                                    (_%reject14601%_ '#f))
                                                (if (vector-ref
                                                     _%seen-left14611%_
                                                     _%owner14638%_)
                                                    '#!void
                                                    (begin
                                                      (vector-set!
                                                       _%seen-left14611%_
                                                       _%owner14638%_
                                                       '#t)
                                                      (set! _%pending14615%_
                                                            (cons _%owner14638%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%pending14615%_))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '#!void))))
                                 (declare (not safe))
                                 (##for-each __tmp33540 _%ids14605%_)))
                             (_%traverse14631%_))
                           '#!void))
                     (let ((__tmp33541
                            (lambda (_%i14640%_)
                              (if (vector-ref _%seen-left14611%_ _%i14640%_)
                                  '#!void
                                  (set! _%cover-count14619%_
                                        (+ _%cover-count14619%_ '1)))
                              (if (vector-ref _%seen-right14613%_ _%i14640%_)
                                  (set! _%cover-count14619%_
                                        (+ _%cover-count14619%_ '1))
                                  '#!void)
                              (let ((__tmp33542
                                     (lambda (_%j14642%_)
                                       (if (and (_%below?14623%_
                                                 _%i14640%_
                                                 _%j14642%_)
                                                (vector-ref
                                                 _%seen-left14611%_
                                                 _%i14640%_)
                                                (not (vector-ref
                                                      _%seen-right14613%_
                                                      _%j14642%_)))
                                           (_%reject14601%_ '#f)
                                           '#!void))))
                                (declare (not safe))
                                (##for-each __tmp33542 _%ids14605%_)))))
                       (declare (not safe))
                       (##for-each __tmp33541 _%ids14605%_))
                     (= _%matched14617%_ _%cover-count14619%_))))))
          (declare (not safe))
          (##call-with-current-continuation __tmp33534))))
    (define gerbil-ascent/table/index-sharing#ordered-subset?
      (lambda (_%selected14589%_ _%available14590%_)
        (if (null? _%selected14589%_)
            '#t
            (if (null? _%available14590%_)
                '#f
                (if (= (car _%selected14589%_) (car _%available14590%_))
                    (gerbil-ascent/table/index-sharing#ordered-subset?
                     (cdr _%selected14589%_)
                     (cdr _%available14590%_))
                    (if (> (car _%selected14589%_) (car _%available14590%_))
                        (gerbil-ascent/table/index-sharing#ordered-subset?
                         _%selected14589%_
                         (cdr _%available14590%_))
                        '#f))))))
    (define gerbil-ascent/table/index-sharing#column-order::t
      (let ((__tmp33544 (list))
            (__tmp33543
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#column-order::t
         'column-order
         __tmp33544
         '(sets successors)
         __tmp33543
         '#f)))
    (define gerbil-ascent/table/index-sharing#column-order?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#column-order::t)))
    (define gerbil-ascent/table/index-sharing#make-column-order
      (lambda _%$args14586%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#column-order::t
               _%$args14586%_)))
    (define gerbil-ascent/table/index-sharing#column-order-sets
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#column-order-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#column-order-sets-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#column-order-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#&column-order-sets
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#&column-order-successors
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#&column-order-sets-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'sets)))
    (define gerbil-ascent/table/index-sharing#&column-order-successors-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-order::t
         'successors)))
    (define gerbil-ascent/table/index-sharing#compile-column-order
      (lambda (_%sets14577%_)
        (let ((_%widths14579%_ (vector-map length _%sets14577%_))
              (_%ids14580%_
               (let ((__tmp33545 (vector-length _%sets14577%_)))
                 (declare (not safe))
                 (##iota __tmp33545))))
          (let ((__tmp33546
                 (list->vector
                  (let ((__tmp33547
                         (lambda (_%i14582%_)
                           (let ((__tmp33548
                                  (lambda (_%j14584%_)
                                    (if (< (vector-ref
                                            _%widths14579%_
                                            _%i14582%_)
                                           (vector-ref
                                            _%widths14579%_
                                            _%j14584%_))
                                        (gerbil-ascent/table/index-sharing#ordered-subset?
                                         (vector-ref _%sets14577%_ _%i14582%_)
                                         (vector-ref _%sets14577%_ _%j14584%_))
                                        '#f))))
                             (declare (not safe))
                             (##filter __tmp33548 _%ids14580%_)))))
                    (declare (not safe))
                    (##map __tmp33547 _%ids14580%_)))))
            (declare (not safe))
            (##structure
             gerbil-ascent/table/index-sharing#column-order::t
             _%sets14577%_
             __tmp33546)))))
    (define gerbil-ascent/table/index-sharing#distinct-ordered-columns?
      (lambda (_%columns14537%_)
        (let* ((_%$%columns1453814548%_ _%columns14537%_)
               (_%$%else1454014556%_ (lambda () '#t))
               (_%$%K1454214562%_
                (lambda (_%right14559%_ _%left14560%_)
                  (if (< _%left14560%_ _%right14559%_)
                      (gerbil-ascent/table/index-sharing#distinct-ordered-columns?
                       (cdr _%columns14537%_))
                      '#f))))
          (if (pair? _%$%columns1453814548%_)
              (let ((_%$%hd1454314565%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%columns1453814548%_)))
                    (_%$%tl1454414567%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%columns1453814548%_))))
                (let ((_%left14570%_ _%$%hd1454314565%_))
                  (if (pair? _%$%tl1454414567%_)
                      (let* ((_%$%hd1454514572%_
                              (let ()
                                (declare (not safe))
                                (##car _%$%tl1454414567%_)))
                             (_%right14575%_ _%$%hd1454514572%_))
                        (_%$%K1454214562%_ _%right14575%_ _%left14570%_))
                      (_%$%else1454014556%_))))
              (_%$%else1454014556%_)))))
    (define gerbil-ascent/table/index-sharing#columns-lexicographic<?
      (lambda (_%left14529%_ _%right14530%_)
        (if (null? _%left14529%_)
            (pair? _%right14530%_)
            (if (null? _%right14530%_)
                '#f
                (if (< (car _%left14529%_) (car _%right14530%_))
                    '#t
                    (if (> (car _%left14529%_) (car _%right14530%_))
                        '#f
                        (gerbil-ascent/table/index-sharing#columns-lexicographic<?
                         (cdr _%left14529%_)
                         (cdr _%right14530%_))))))))
    (define gerbil-ascent/table/index-sharing#normalize-column-requirements
      (lambda (_%requirements14519%_)
        (let ((_%unique14521%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (for-each
           (lambda (_%columns14523%_)
             (if (and (list? _%columns14523%_)
                      (let ((__tmp33549
                             (lambda (_%n14525%_)
                               (and (exact-integer? _%n14525%_)
                                    (>= _%n14525%_ '0)))))
                        (declare (not safe))
                        (andmap__0 __tmp33549 _%columns14523%_)))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid index sharing columns" _%columns14523%_)))
             (let ((_%ordered14527%_ (list-sort < _%columns14523%_)))
               (if (gerbil-ascent/table/index-sharing#distinct-ordered-columns?
                    _%ordered14527%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"repeated index sharing columns"
                            _%columns14523%_)))
               (if (null? _%ordered14527%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (__hash-put! _%unique14521%_ _%ordered14527%_ '#t)))))
           _%requirements14519%_)
          (list->vector
           (let ((__tmp33550
                  (let () (declare (not safe)) (__hash-keys _%unique14521%_))))
             (declare (not safe))
             (##list-sort
              gerbil-ascent/table/index-sharing#columns-lexicographic<?
              __tmp33550))))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
      (lambda (_%requirements14466%_)
        (let* ((_%sets14468%_
                (gerbil-ascent/table/index-sharing#normalize-column-requirements
                 _%requirements14466%_))
               (_%order14470%_
                (gerbil-ascent/table/index-sharing#compile-column-order
                 _%sets14468%_))
               (_%successors14472%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%order14470%_ '2 '#f '#f)))
               (_%count14474%_
                (vector-length
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%order14470%_ '1 '#f '#f))))
               (_%left14476%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count14474%_ '#f)))
               (_%right14478%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count14474%_ '#f)))
               (_%layout14480%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (letrec* ((_%augment!14483%_
                     (lambda (_%i14509%_ _%visited14510%_)
                       (let ((__tmp33552
                              (lambda (_%j14512%_)
                                (if (vector-ref _%visited14510%_ _%j14512%_)
                                    '#f
                                    (begin
                                      (vector-set!
                                       _%visited14510%_
                                       _%j14512%_
                                       '#t)
                                      (let ((_%prior14514%_
                                             (vector-ref
                                              _%right14478%_
                                              _%j14512%_)))
                                        (if (or (not _%prior14514%_)
                                                (_%augment!14483%_
                                                 _%prior14514%_
                                                 _%visited14510%_))
                                            (begin
                                              (vector-set!
                                               _%left14476%_
                                               _%i14509%_
                                               _%j14512%_)
                                              (vector-set!
                                               _%right14478%_
                                               _%j14512%_
                                               _%i14509%_)
                                              '#t)
                                            '#f))))))
                             (__tmp33551
                              (vector-ref _%successors14472%_ _%i14509%_)))
                         (declare (not safe))
                         (ormap__0 __tmp33552 __tmp33551))))
                    (_g33553_
                     (let ((_g33554_
                            (let ((__tmp33557
                                   (lambda (_%i14485%_)
                                     (_%augment!14483%_
                                      _%i14485%_
                                      (let ()
                                        (declare (not safe))
                                        (##make-vector _%count14474%_ '#f)))))
                                  (__tmp33556
                                   (let ()
                                     (declare (not safe))
                                     (##iota _%count14474%_))))
                              (declare (not safe))
                              (##for-each __tmp33557 __tmp33556))))
                       #!void
                       _g33554_))
                    (_g33558_
                     (let ((_g33559_
                            (if (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-certificate?
                                 _%sets14468%_
                                 _%left14476%_
                                 _%right14478%_)
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"invalid index sharing maximum matching certificate")))))
                       #!void
                       _g33559_))
                    (_%visited14486%_
                     (let ()
                       (declare (not safe))
                       (##make-vector _%count14474%_ '#f))))
            (begin
              (let ((__tmp33562
                     (lambda (_%i14488%_)
                       (if (vector-ref _%right14478%_ _%i14488%_)
                           '#!void
                           (let _%chain14490%_ ((_%j14492%_ _%i14488%_)
                                                (_%members14493%_ '())
                                                (_%permutation14494%_ '()))
                             (if (vector-ref _%visited14486%_ _%j14492%_)
                                 (let ()
                                   (declare (not safe))
                                   (error '"index sharing chain repeats a requirement"))
                                 '#!void)
                             (vector-set! _%visited14486%_ _%j14492%_ '#t)
                             (let* ((_%columns14496%_
                                     (vector-ref _%sets14468%_ _%j14492%_))
                                    (_%next14498%_
                                     (vector-ref _%left14476%_ _%j14492%_))
                                    (_%extended14502%_
                                     (let ((__tmp33563
                                            (filter (lambda (_%c14500%_)
                                                      (not (member _%c14500%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           _%permutation14494%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    _%columns14496%_)))
                                       (declare (not safe))
                                       (##append
                                        _%permutation14494%_
                                        __tmp33563)))
                                    (_%covered14504%_
                                     (cons _%columns14496%_ _%members14493%_)))
                               (if _%next14498%_
                                   (_%chain14490%_
                                    _%next14498%_
                                    _%covered14504%_
                                    _%extended14502%_)
                                   (if (pair? (let ()
                                                (declare (not safe))
                                                (##cdr _%covered14504%_)))
                                       (let ((__tmp33564
                                              (lambda (_%c14507%_)
                                                (let ()
                                                  (declare (not safe))
                                                  (__hash-put!
                                                   _%layout14480%_
                                                   _%c14507%_
                                                   _%extended14502%_)))))
                                         (declare (not safe))
                                         (##for-each
                                          __tmp33564
                                          _%covered14504%_))
                                       '#!void)))))))
                    (__tmp33561
                     (let () (declare (not safe)) (##iota _%count14474%_))))
                (declare (not safe))
                (##for-each __tmp33562 __tmp33561))
              (if (let ((__tmp33565
                         (let ()
                           (declare (not safe))
                           (##vector->list _%visited14486%_))))
                    (declare (not safe))
                    (andmap__0 values __tmp33565))
                  '#!void
                  (let ()
                    (declare (not safe))
                    (error '"index sharing chains omit a requirement")))
              _%layout14480%_)))))
    (define gerbil-ascent/table/index-sharing#shared-index::t
      (let ((__tmp33567 (list)) (__tmp33566 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#shared-index::t
         'shared-index
         __tmp33567
         '(columns root ordinal views projection key-plans)
         __tmp33566
         '#f)))
    (define gerbil-ascent/table/index-sharing#shared-index?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#shared-index::t)))
    (define gerbil-ascent/table/index-sharing#make-shared-index
      (lambda _%$args14463%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#shared-index::t
               _%$args14463%_)))
    (define gerbil-ascent/table/index-sharing#shared-index-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#shared-index-root
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#shared-index-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#shared-index-views
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#shared-index-projection
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#shared-index-key-plans
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#shared-index-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#shared-index-root-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#shared-index-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#shared-index-views-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#shared-index-projection-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#shared-index-key-plans-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#&shared-index-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&shared-index-root
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#&shared-index-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#&shared-index-views
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#&shared-index-projection
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#&shared-index-key-plans
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#&shared-index-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&shared-index-root-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'root)))
    (define gerbil-ascent/table/index-sharing#&shared-index-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'ordinal)))
    (define gerbil-ascent/table/index-sharing#&shared-index-views-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'views)))
    (define gerbil-ascent/table/index-sharing#&shared-index-projection-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'projection)))
    (define gerbil-ascent/table/index-sharing#&shared-index-key-plans-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#shared-index::t
         'key-plans)))
    (define gerbil-ascent/table/index-sharing#column-projection::t
      (let ((__tmp33569 (list)) (__tmp33568 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#column-projection::t
         'column-projection
         __tmp33569
         '(columns writes frame)
         __tmp33568
         '#f)))
    (define gerbil-ascent/table/index-sharing#column-projection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#column-projection::t)))
    (define gerbil-ascent/table/index-sharing#make-column-projection
      (lambda _%$args14460%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#column-projection::t
               _%$args14460%_)))
    (define gerbil-ascent/table/index-sharing#column-projection-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#column-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#column-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#column-projection-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#column-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#column-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&column-projection-columns
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&column-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&column-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&column-projection-columns-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'columns)))
    (define gerbil-ascent/table/index-sharing#&column-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&column-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#column-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-projection::t
      (let ((__tmp33571 (list))
            (__tmp33570
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/table/index-sharing#key-projection::t
         'key-projection
         __tmp33571
         '(physical writes frame)
         __tmp33570
         '#f)))
    (define gerbil-ascent/table/index-sharing#key-projection?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/table/index-sharing#key-projection::t)))
    (define gerbil-ascent/table/index-sharing#make-key-projection
      (lambda _%$args14457%_
        (apply make-instance
               gerbil-ascent/table/index-sharing#key-projection::t
               _%$args14457%_)))
    (define gerbil-ascent/table/index-sharing#key-projection-physical
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#key-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#key-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-projection-physical-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#key-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#key-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&key-projection-physical
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#&key-projection-writes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&key-projection-frame
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#&key-projection-physical-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'physical)))
    (define gerbil-ascent/table/index-sharing#&key-projection-writes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'writes)))
    (define gerbil-ascent/table/index-sharing#&key-projection-frame-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/table/index-sharing#key-projection::t
         'frame)))
    (define gerbil-ascent/table/index-sharing#key-sequence=?
      (lambda (_%left14454%_ _%right14455%_)
        (if (null? _%left14454%_)
            (null? _%right14455%_)
            (if (pair? _%right14455%_)
                (if (equal? (car _%left14454%_)
                            (let ()
                              (declare (not safe))
                              (##car _%right14455%_)))
                    (gerbil-ascent/table/index-sharing#key-sequence=?
                     (cdr _%left14454%_)
                     (let () (declare (not safe)) (##cdr _%right14455%_)))
                    '#f)
                '#f))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-build
      (lambda (_%rows14449%_ _%columns14450%_)
        (let ((_%index14452%_
               (let ((__tmp33573
                      (let ()
                        (declare (not safe))
                        (make-hash-table__%
                         '#f
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value
                         absent-value)))
                     (__tmp33572
                      (let ()
                        (declare (not safe))
                        (make-hash-table__%
                         '#f
                         absent-value
                         absent-value
                         gerbil-ascent/table/index-sharing#key-sequence=?
                         equal?-hash
                         absent-value
                         absent-value
                         absent-value
                         absent-value))))
                 (declare (not safe))
                 (##structure
                  gerbil-ascent/table/index-sharing#shared-index::t
                  _%columns14450%_
                  __tmp33573
                  '0
                  __tmp33572
                  '#f
                  '#f))))
          (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
           _%index14452%_
           (reverse _%rows14449%_))
          _%index14452%_)))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
      (lambda (_%index14412%_ _%rows14413%_)
        (if (pair? _%rows14413%_)
            (begin
              (##structure-set!
               _%index14412%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  gerbil-ascent/table/index-sharing#key-sequence=?
                  equal?-hash
                  absent-value
                  absent-value
                  absent-value
                  absent-value))
               '4
               gerbil-ascent/table/index-sharing#shared-index::t
               '#f)
              (let* ((_%columns14415%_
                      (##structure-ref
                       _%index14412%_
                       '1
                       gerbil-ascent/table/index-sharing#shared-index::t
                       '#f))
                     (_%width14417%_ (length _%columns14415%_))
                     (_%projection14419%_
                      (gerbil-ascent/table/index-sharing#column-projection-for!
                       _%index14412%_
                       _%columns14415%_
                       _%width14417%_))
                     (_%writes14421%_
                      (##structure-ref
                       _%projection14419%_
                       '2
                       gerbil-ascent/table/index-sharing#column-projection::t
                       '#f))
                     (_%frame14423%_
                      (##structure-ref
                       _%projection14419%_
                       '3
                       gerbil-ascent/table/index-sharing#column-projection::t
                       '#f)))
                (letrec ((_%insert!14426%_
                          (lambda (_%node14432%_
                                   _%depth14433%_
                                   _%row14434%_
                                   _%ordinal14435%_)
                            (let ((_%key14437%_
                                   (vector-ref _%frame14423%_ _%depth14433%_)))
                              (if (= (+ _%depth14433%_ '1) _%width14417%_)
                                  (let ((__tmp33574
                                         (cons (cons _%ordinal14435%_
                                                     _%row14434%_)
                                               (let ((_%$e14439%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (hash-get
                                                         _%node14432%_
                                                         _%key14437%_))))
                                                 (if _%$e14439%_
                                                     _%$e14439%_
                                                     '())))))
                                    (declare (not safe))
                                    (hash-put!
                                     _%node14432%_
                                     _%key14437%_
                                     __tmp33574))
                                  (let ((_%child14447%_
                                         (let ((_%$e14442%_
                                                (let ()
                                                  (declare (not safe))
                                                  (hash-get
                                                   _%node14432%_
                                                   _%key14437%_))))
                                           (if _%$e14442%_
                                               _%$e14442%_
                                               (let ((_%fresh14445%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (make-hash-table__%
                                                         '#f
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value
                                                         absent-value))))
                                                 (let ()
                                                   (declare (not safe))
                                                   (hash-put!
                                                    _%node14432%_
                                                    _%key14437%_
                                                    _%fresh14445%_))
                                                 _%fresh14445%_)))))
                                    (_%insert!14426%_
                                     _%child14447%_
                                     (+ _%depth14433%_ '1)
                                     _%row14434%_
                                     _%ordinal14435%_)))))))
                  (let ((__tmp33575
                         (lambda (_%row14428%_)
                           (let ((_%ordinal14430%_
                                  (+ (##structure-ref
                                      _%index14412%_
                                      '3
                                      gerbil-ascent/table/index-sharing#shared-index::t
                                      '#f)
                                     '1)))
                             (gerbil-ascent/table/index-sharing#fill-column-frame!
                              _%row14428%_
                              _%writes14421%_
                              _%frame14423%_)
                             (_%insert!14426%_
                              (##structure-ref
                               _%index14412%_
                               '2
                               gerbil-ascent/table/index-sharing#shared-index::t
                               '#f)
                              '0
                              _%row14428%_
                              _%ordinal14430%_)
                             (##structure-set!
                              _%index14412%_
                              _%ordinal14430%_
                              '3
                              gerbil-ascent/table/index-sharing#shared-index::t
                              '#f)))))
                    (declare (not safe))
                    (##for-each __tmp33575 _%rows14413%_)))))
            '#!void)
        _%index14412%_))
    (define gerbil-ascent/table/index-sharing#column-projection-for!
      (lambda (_%index14404%_ _%columns14405%_ _%width14406%_)
        (let ((_%prior14408%_
               (##structure-ref
                _%index14404%_
                '5
                gerbil-ascent/table/index-sharing#shared-index::t
                '#f)))
          (if (and _%prior14408%_
                   (gerbil-ascent/table/index-sharing#same-columns?
                    _%columns14405%_
                    (##structure-ref
                     _%prior14408%_
                     '1
                     gerbil-ascent/table/index-sharing#column-projection::t
                     '#f)))
              _%prior14408%_
              (let ((_%fresh14410%_
                     (let ((__tmp33578 (list->vector _%columns14405%_))
                           (__tmp33577
                            (gerbil-ascent/table/index-sharing#column-writes
                             _%columns14405%_))
                           (__tmp33576 (make-vector _%width14406%_ '#f)))
                       (declare (not safe))
                       (##structure
                        gerbil-ascent/table/index-sharing#column-projection::t
                        __tmp33578
                        __tmp33577
                        __tmp33576))))
                (##structure-set!
                 _%index14404%_
                 _%fresh14410%_
                 '5
                 gerbil-ascent/table/index-sharing#shared-index::t
                 '#f)
                _%fresh14410%_)))))
    (define gerbil-ascent/table/index-sharing#same-columns?
      (lambda (_%columns14396%_ _%snapshot14397%_)
        (let _%compare14399%_ ((_%remaining14401%_ _%columns14396%_)
                               (_%slot14402%_ '0))
          (if (null? _%remaining14401%_)
              (= _%slot14402%_ (vector-length _%snapshot14397%_))
              (if (< _%slot14402%_ (vector-length _%snapshot14397%_))
                  (if (equal? (car _%remaining14401%_)
                              (vector-ref _%snapshot14397%_ _%slot14402%_))
                      (_%compare14399%_
                       (cdr _%remaining14401%_)
                       (+ _%slot14402%_ '1))
                      '#f)
                  '#f)))))
    (define gerbil-ascent/table/index-sharing#column-writes
      (lambda (_%columns14375%_)
        (let _%gather14377%_ ((_%remaining14379%_ _%columns14375%_)
                              (_%slot14380%_ '0)
                              (_%entries14381%_ '()))
          (if (null? _%remaining14379%_)
              (let ((_%ordered14386%_
                     (list-sort!
                      (lambda (_%a14383%_ _%b14384%_)
                        (< (car _%a14383%_) (car _%b14384%_)))
                      _%entries14381%_)))
                (let _%steps14388%_ ((_%remaining14390%_ _%ordered14386%_)
                                     (_%position14391%_ '0)
                                     (_%writes14392%_ '()))
                  (if (null? _%remaining14390%_)
                      (reverse! _%writes14392%_)
                      (let ((_%entry14394%_ (car _%remaining14390%_)))
                        (_%steps14388%_
                         (cdr _%remaining14390%_)
                         (+ (car _%entry14394%_) '1)
                         (cons (cons (- (car _%entry14394%_) _%position14391%_)
                                     (cdr _%entry14394%_))
                               _%writes14392%_))))))
              (_%gather14377%_
               (cdr _%remaining14379%_)
               (+ _%slot14380%_ '1)
               (cons (cons (car _%remaining14379%_) _%slot14380%_)
                     _%entries14381%_))))))
    (define gerbil-ascent/table/index-sharing#fill-column-frame!
      (lambda (_%row14366%_ _%writes14367%_ _%frame14368%_)
        (if (null? _%writes14367%_)
            '#!void
            (let* ((_%instruction14370%_ (car _%writes14367%_))
                   (_%selected14372%_
                    (list-tail _%row14366%_ (car _%instruction14370%_))))
              (vector-set!
               _%frame14368%_
               (cdr _%instruction14370%_)
               (car _%selected14372%_))
              (gerbil-ascent/table/index-sharing#fill-column-frame!
               (cdr _%selected14372%_)
               (cdr _%writes14367%_)
               _%frame14368%_)))))
    (define gerbil-ascent/table/index-sharing#compile-key-projection
      (lambda (_%logical14343%_ _%physical14344%_)
        (let ((_%width14346%_ (length _%logical14343%_)))
          (letrec ((_%position-of14348%_
                    (lambda (_%column14359%_)
                      (let _%seek14361%_ ((_%remaining14363%_ _%logical14343%_)
                                          (_%position14364%_ '0))
                        (if (pair? _%remaining14363%_)
                            (if (= _%column14359%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%remaining14363%_)))
                                _%position14364%_
                                (_%seek14361%_
                                 (let ()
                                   (declare (not safe))
                                   (##cdr _%remaining14363%_))
                                 (+ _%position14364%_ '1)))
                            '#f)))))
            (let _%gather14350%_ ((_%remaining14352%_ _%physical14344%_)
                                  (_%left14353%_ _%width14346%_)
                                  (_%selected14354%_ '())
                                  (_%prefix14355%_ '()))
              (if (zero? _%left14353%_)
                  (let ((__tmp33581 (list->vector (reverse! _%prefix14355%_)))
                        (__tmp33580
                         (gerbil-ascent/table/index-sharing#column-writes
                          (reverse! _%selected14354%_)))
                        (__tmp33579
                         (let ()
                           (declare (not safe))
                           (##make-vector _%width14346%_ '#f))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/table/index-sharing#key-projection::t
                     __tmp33581
                     __tmp33580
                     __tmp33579))
                  (let ((_%position14357%_
                         (if (pair? _%remaining14352%_)
                             (_%position-of14348%_
                              (let ()
                                (declare (not safe))
                                (##car _%remaining14352%_)))
                             '#f)))
                    (if _%position14357%_
                        '#!void
                        (let ()
                          (declare (not safe))
                          (error '"logical index is not a physical prefix"
                                 _%logical14343%_
                                 _%physical14344%_)))
                    (_%gather14350%_
                     (cdr _%remaining14352%_)
                     (- _%left14353%_ '1)
                     (cons _%position14357%_ _%selected14354%_)
                     (cons (car _%remaining14352%_) _%prefix14355%_)))))))))
    (define gerbil-ascent/table/index-sharing#same-physical-prefix?
      (lambda (_%physical14332%_ _%snapshot14333%_)
        (let _%compare14335%_ ((_%remaining14337%_ _%physical14332%_)
                               (_%slot14338%_ '0))
          (let ((_%$e14340%_
                 (= _%slot14338%_ (vector-length _%snapshot14333%_))))
            (if _%$e14340%_
                _%$e14340%_
                (if (pair? _%remaining14337%_)
                    (if (equal? (let ()
                                  (declare (not safe))
                                  (##car _%remaining14337%_))
                                (vector-ref _%snapshot14333%_ _%slot14338%_))
                        (_%compare14335%_
                         (let ()
                           (declare (not safe))
                           (##cdr _%remaining14337%_))
                         (+ _%slot14338%_ '1))
                        '#f)
                    '#f))))))
    (define gerbil-ascent/table/index-sharing#column-sequence=?
      (lambda (_%left14329%_ _%right14330%_)
        (if (null? _%left14329%_)
            (null? _%right14330%_)
            (if (pair? _%right14330%_)
                (if (= (car _%left14329%_)
                       (let () (declare (not safe)) (##car _%right14330%_)))
                    (gerbil-ascent/table/index-sharing#column-sequence=?
                     (cdr _%left14329%_)
                     (let () (declare (not safe)) (##cdr _%right14330%_)))
                    '#f)
                '#f))))
    (define gerbil-ascent/table/index-sharing#project-lookup-key
      (lambda (_%index14311%_ _%logical14312%_ _%physical14313%_ _%key14314%_)
        (let* ((_%plans14316%_
                (##structure-ref
                 _%index14311%_
                 '6
                 gerbil-ascent/table/index-sharing#shared-index::t
                 '#f))
               (_%prior14318%_
                (if _%plans14316%_
                    (let ()
                      (declare (not safe))
                      (hash-get _%plans14316%_ _%logical14312%_))
                    '#f))
               (_%plan14322%_
                (if (and _%prior14318%_
                         (gerbil-ascent/table/index-sharing#same-physical-prefix?
                          _%physical14313%_
                          (##direct-structure-ref
                           _%prior14318%_
                           '1
                           gerbil-ascent/table/index-sharing#key-projection::t
                           '#f)))
                    _%prior14318%_
                    (let ((_%fresh14320%_
                           (gerbil-ascent/table/index-sharing#compile-key-projection
                            _%logical14312%_
                            _%physical14313%_)))
                      (if _%plans14316%_
                          '#!void
                          (begin
                            (set! _%plans14316%_
                                  (let ()
                                    (declare (not safe))
                                    (make-hash-table__%
                                     '#f
                                     absent-value
                                     absent-value
                                     gerbil-ascent/table/index-sharing#column-sequence=?
                                     equal?-hash
                                     absent-value
                                     absent-value
                                     absent-value
                                     absent-value)))
                            (##structure-set!
                             _%index14311%_
                             _%plans14316%_
                             '6
                             gerbil-ascent/table/index-sharing#shared-index::t
                             '#f)))
                      (let ((__tmp33582
                             (let ()
                               (declare (not safe))
                               (##append _%logical14312%_ '()))))
                        (declare (not safe))
                        (hash-put! _%plans14316%_ __tmp33582 _%fresh14320%_))
                      _%fresh14320%_)))
               (_%frame14324%_
                (##direct-structure-ref
                 _%plan14322%_
                 '3
                 gerbil-ascent/table/index-sharing#key-projection::t
                 '#f)))
          (gerbil-ascent/table/index-sharing#fill-column-frame!
           _%key14314%_
           (##direct-structure-ref
            _%plan14322%_
            '2
            gerbil-ascent/table/index-sharing#key-projection::t
            '#f)
           _%frame14324%_)
          (let ((_%owned14327%_ (vector->list _%frame14324%_)))
            (vector-fill! _%frame14324%_ '#f)
            _%owned14327%_))))
    (define gerbil-ascent/table/index-sharing#adapt-lookup-key
      (lambda (_%index14266%_ _%logical14267%_ _%physical14268%_ _%key14269%_)
        (let* ((_%$%logical1427014280%_ _%logical14267%_)
               (_%$%else1427214288%_
                (lambda ()
                  (gerbil-ascent/table/index-sharing#project-lookup-key
                   _%index14266%_
                   _%logical14267%_
                   _%physical14268%_
                   _%key14269%_)))
               (_%$%K1427414294%_
                (lambda (_%right14291%_ _%left14292%_)
                  (if (and (pair? _%physical14268%_)
                           (pair? (let ()
                                    (declare (not safe))
                                    (##cdr _%physical14268%_)))
                           (= _%left14292%_ (cadr _%physical14268%_))
                           (= _%right14291%_
                              (let ()
                                (declare (not safe))
                                (##car _%physical14268%_))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"logical index is not a physical prefix"
                               _%logical14267%_
                               _%physical14268%_)))
                  (list (cadr _%key14269%_) (car _%key14269%_)))))
          (if (pair? _%$%logical1427014280%_)
              (let ((_%$%hd1427514297%_
                     (let ()
                       (declare (not safe))
                       (##car _%$%logical1427014280%_)))
                    (_%$%tl1427614299%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%logical1427014280%_))))
                (let ((_%left14302%_ _%$%hd1427514297%_))
                  (if (pair? _%$%tl1427614299%_)
                      (let ((_%$%hd1427714304%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%tl1427614299%_)))
                            (_%$%tl1427814306%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%tl1427614299%_))))
                        (let ((_%right14309%_ _%$%hd1427714304%_))
                          (if (null? _%$%tl1427814306%_)
                              (_%$%K1427414294%_ _%right14309%_ _%left14302%_)
                              (_%$%else1427214288%_))))
                      (_%$%else1427214288%_))))
              (_%$%else1427214288%_)))))
    (define gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-rows
      (lambda (_%index14225%_ _%columns14226%_ _%key14227%_)
        (let ((_%physical14229%_
               (##structure-ref
                _%index14225%_
                '1
                gerbil-ascent/table/index-sharing#shared-index::t
                '#f)))
          (if (= (length _%columns14226%_) (length _%key14227%_))
              '#!void
              (let ()
                (declare (not safe))
                (error '"shared index key arity mismatch")))
          (letrec ((_%already-ordered?14231%_
                    (lambda (_%logical14260%_ _%remaining14261%_)
                      (let ((_%$e14263%_ (null? _%logical14260%_)))
                        (if _%$e14263%_
                            _%$e14263%_
                            (if (pair? _%remaining14261%_)
                                (if (= (car _%logical14260%_)
                                       (let ()
                                         (declare (not safe))
                                         (##car _%remaining14261%_)))
                                    (_%already-ordered?14231%_
                                     (cdr _%logical14260%_)
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%remaining14261%_)))
                                    '#f)
                                '#f)))))
                   (_%collect14232%_
                    (lambda (_%node14252%_ _%remaining14253%_ _%tail14254%_)
                      (let ((__tmp33583
                             (lambda (_%_14256%_
                                      _%child14257%_
                                      _%records14258%_)
                               (if (null? (cdr _%remaining14253%_))
                                   (append _%child14257%_ _%records14258%_)
                                   (_%collect14232%_
                                    _%child14257%_
                                    (cdr _%remaining14253%_)
                                    _%records14258%_)))))
                        (declare (not safe))
                        (hash-fold __tmp33583 _%tail14254%_ _%node14252%_)))))
            (let* ((_%physical-key14234%_
                    (if (_%already-ordered?14231%_
                         _%columns14226%_
                         _%physical14229%_)
                        _%key14227%_
                        (gerbil-ascent/table/index-sharing#adapt-lookup-key
                         _%index14225%_
                         _%columns14226%_
                         _%physical14229%_
                         _%key14227%_)))
                   (_%cached14236%_
                    (let ((__tmp33584
                           (##structure-ref
                            _%index14225%_
                            '4
                            gerbil-ascent/table/index-sharing#shared-index::t
                            '#f)))
                      (declare (not safe))
                      (hash-get __tmp33584 _%physical-key14234%_))))
              (if _%cached14236%_
                  (cdr _%cached14236%_)
                  (let ((_%rows14250%_
                         (let _%lookup14239%_ ((_%node14241%_
                                                (##structure-ref
                                                 _%index14225%_
                                                 '2
                                                 gerbil-ascent/table/index-sharing#shared-index::t
                                                 '#f))
                                               (_%remaining14242%_
                                                _%physical14229%_)
                                               (_%key14243%_
                                                _%physical-key14234%_))
                           (if (null? _%key14243%_)
                               (let ((__tmp33585
                                      (list-sort
                                       (lambda (_%a14245%_ _%b14246%_)
                                         (> (car _%a14245%_) (car _%b14246%_)))
                                       (_%collect14232%_
                                        _%node14241%_
                                        _%remaining14242%_
                                        '()))))
                                 (declare (not safe))
                                 (##map cdr __tmp33585))
                               (let ((_%child14248%_
                                      (let ((__tmp33586 (car _%key14243%_)))
                                        (declare (not safe))
                                        (hash-get _%node14241%_ __tmp33586))))
                                 (if _%child14248%_
                                     (if (null? (cdr _%remaining14242%_))
                                         (map cdr _%child14248%_)
                                         (_%lookup14239%_
                                          _%child14248%_
                                          (cdr _%remaining14242%_)
                                          (cdr _%key14243%_)))
                                     '()))))))
                    (let ((__tmp33589
                           (##structure-ref
                            _%index14225%_
                            '4
                            gerbil-ascent/table/index-sharing#shared-index::t
                            '#f))
                          (__tmp33588
                           (let ()
                             (declare (not safe))
                             (##append _%physical-key14234%_ '())))
                          (__tmp33587 (cons '#t _%rows14250%_)))
                      (declare (not safe))
                      (hash-put! __tmp33589 __tmp33588 __tmp33587))
                    _%rows14250%_)))))))))
