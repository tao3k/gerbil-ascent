(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/program")
    (load-module "gerbil-ascent/candidate/funs"))
  (load-module "gerbil-ascent/candidate/grounding-plan~0"))
