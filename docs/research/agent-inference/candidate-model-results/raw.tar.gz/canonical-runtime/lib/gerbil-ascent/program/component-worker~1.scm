(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-worker[1]#_g36381_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36383_|
    (##structure
     gx#syntax-quote::t
     'make-component-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36385_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36387_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36388_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36390_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36391_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36393_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36394_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36396_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36397_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[:0:]#component-snapshot|
    (let ((__obj36372
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36372
         'gerbil-ascent/program/component-worker#component-snapshot::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 'component-snapshot '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '(rows sizes) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '(rows sizes) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '#f '13 '#f '#f))
      (let ((__tmp36380 |gerbil-ascent/program/component-worker[1]#_g36381_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36380 '4 '#f '#f))
      (let ((__tmp36382 |gerbil-ascent/program/component-worker[1]#_g36383_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36382 '14 '#f '#f))
      (let ((__tmp36384 |gerbil-ascent/program/component-worker[1]#_g36385_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36384 '15 '#f '#f))
      (let ((__tmp36386
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36387_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36388_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36386 '16 '#f '#f))
      (let ((__tmp36389
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36390_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36391_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36389 '17 '#f '#f))
      (let ((__tmp36392
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36393_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36394_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36392 '18 '#f '#f))
      (let ((__tmp36395
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36396_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36397_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 __tmp36395 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36372 '() '21 '#f '#f))
      __obj36372)))
