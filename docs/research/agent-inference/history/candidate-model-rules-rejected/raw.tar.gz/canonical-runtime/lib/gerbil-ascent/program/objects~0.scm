(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/objects::timestamp 1791687880)
  (begin
    (define gerbil-ascent/program/objects#current-declaration-check
      (make-parameter clan/poo/mop#validate))
    (define gerbil-ascent/program/objects#declaration-check
      (lambda (_%contract11264%_ _%value11265%_)
        ((let ()
           (declare (not safe))
           (gerbil-ascent/program/objects#current-declaration-check))
         _%contract11264%_
         _%value11265%_)))
    (define gerbil-ascent/program/objects#receive-inert-declarations
      (lambda (_%construct11256%_ _%receive11257%_)
        (call-with-values
         (lambda ()
           (let ((__tmp35990 (lambda () (_%construct11256%_)))
                 (__tmp35989
                  (lambda (_%_contract11261%_ _%value11262%_) _%value11262%_)))
             (declare (not safe))
             (call-with-parameters__1
              __tmp35990
              gerbil-ascent/program/objects#current-declaration-check
              __tmp35989)))
         _%receive11257%_)))
    (define gerbil-ascent/program/objects#validate-inert-root
      (lambda (_%contract11253%_ _%value11254%_)
        (let ((__tmp35991
               (if (null? (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%value11254%_ 'rules)))
                   _%contract11253%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/program/types#gerbil-ascent-owned-root-contract
                      _%contract11253%_)))))
          (declare (not safe))
          (clan/poo/mop#validate __tmp35991 _%value11254%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-program
      (lambda (_%construct11244%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct11244%_
         (lambda _g35992_
           (let ((_g35993_ (let () (declare (not safe)) (##length _g35992_))))
             (cond ((let () (declare (not safe)) (##fx= _g35993_ 1))
                    (apply (lambda (_%program11246%_)
                             (gerbil-ascent/program/objects#validate-inert-root
                              gerbil-ascent/program/types#GerbilAscentProgramContract
                              _%program11246%_))
                           _g35992_))
                   ((let () (declare (not safe)) (##fx= _g35993_ 2))
                    (apply (lambda (_%program11248%_ _%output11249%_)
                             (let ((_%checked11251%_
                                    (gerbil-ascent/program/objects#validate-inert-root
                                     gerbil-ascent/program/types#GerbilAscentProgramContract
                                     _%program11248%_)))
                               (values _%checked11251%_ _%output11249%_)))
                           _g35992_))
                   (else
                    (##raise-wrong-number-of-arguments-exception
                     'case-lambda-dispatch
                     _g35992_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-construct-inert-fragment
      (lambda (_%construct11240%_)
        (gerbil-ascent/program/objects#receive-inert-declarations
         _%construct11240%_
         (lambda (_%fragment11242%_)
           (gerbil-ascent/program/objects#validate-inert-root
            gerbil-ascent/program/types#GerbilAscentFragmentContract
            _%fragment11242%_)))))
    (define gerbil-ascent/program/objects#Relation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRelationContract
         'proto)))
    (define gerbil-ascent/program/objects#Lattice.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         'proto)))
    (define gerbil-ascent/program/objects#Term.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentTermContract
         'proto)))
    (define gerbil-ascent/program/objects#Atom.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAtomContract
         'proto)))
    (define gerbil-ascent/program/objects#Guard.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGuardContract
         'proto)))
    (define gerbil-ascent/program/objects#Generator.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         'proto)))
    (define gerbil-ascent/program/objects#Binding.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentBindingContract
         'proto)))
    (define gerbil-ascent/program/objects#Negation.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentNegationContract
         'proto)))
    (define gerbil-ascent/program/objects#Aggregate.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         'proto)))
    (define gerbil-ascent/program/objects#Rule.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentRuleContract
         'proto)))
    (define gerbil-ascent/program/objects#Fragment.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         'proto)))
    (define gerbil-ascent/program/objects#Program.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentProgramContract
         'proto)))
    (define gerbil-ascent/program/objects#gerbil-ascent-clause-plan
      (lambda (_%clause11236%_ _%atom-plan11237%_ _%bound11238%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%clause11236%_ '.plan))
         _%atom-plan11237%_
         _%bound11238%_)))
    (define gerbil-ascent/program/objects#name-index
      (lambda (_%names11228%_)
        (let ((_%index11230%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%$%g1123111233%_)
             (let ()
               (declare (not safe))
               (__hash-put! _%index11230%_ _%$%g1123111233%_ '#t)))
           _%names11228%_)
          _%index11230%_)))
    (define gerbil-ascent/program/objects#wide-scope?
      (lambda (_%names11218%_)
        (letrec ((_%enough?11220%_
                  (lambda (_%remaining11222%_ _%left11223%_)
                    (if (pair? _%remaining11222%_)
                        (let ((_%$e11225%_
                               (let ()
                                 (declare (not safe))
                                 (##fx= _%left11223%_ '1))))
                          (if _%$e11225%_
                              _%$e11225%_
                              (_%enough?11220%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%remaining11222%_))
                               (let ()
                                 (declare (not safe))
                                 (##fx- _%left11223%_ '1)))))
                        '#f))))
          (_%enough?11220%_ _%names11218%_ '32))))
    (define gerbil-ascent/program/objects#gerbil-ascent-bound-membership
      (lambda (_%names11209%_)
        (if (gerbil-ascent/program/objects#wide-scope? _%names11209%_)
            (let ((_%index11213%_ '#f) (_%reads11214%_ '0))
              (lambda (_%name11216%_)
                (if _%index11213%_
                    (let ()
                      (declare (not safe))
                      (hash-get _%index11213%_ _%name11216%_))
                    (begin
                      (set! _%reads11214%_
                            (let ()
                              (declare (not safe))
                              (##fx+ _%reads11214%_ '1)))
                      (if (let ()
                            (declare (not safe))
                            (##fx= _%reads11214%_ '32))
                          (begin
                            (set! _%index11213%_
                                  (gerbil-ascent/program/objects#name-index
                                   _%names11209%_))
                            (let ()
                              (declare (not safe))
                              (hash-get _%index11213%_ _%name11216%_)))
                          (if (memq _%name11216%_ _%names11209%_) '#t '#f))))))
            (lambda (_%name11211%_)
              (if (memq _%name11211%_ _%names11209%_) '#t '#f)))))
    (define gerbil-ascent/program/objects#require-bound
      (lambda (_%names11204%_ _%bound?11205%_)
        (for-each
         (lambda (_%name11207%_)
           (if (_%bound?11205%_ _%name11207%_)
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"unbound ASCENT clause variable" _%name11207%_))))
         _%names11204%_)))
    (define gerbil-ascent/program/objects#pattern-outputs
      (lambda (_%term11202%_)
        (if (eq? (car _%term11202%_) 'pattern)
            (vector-ref (cdr _%term11202%_) '0)
            '#f)))
    (define gerbil-ascent/program/objects#indexed-atom
      (lambda (_%plan11155%_ _%bound11156%_)
        (let* ((_%wide?11158%_
                (gerbil-ascent/program/objects#wide-scope?
                 (vector-ref _%plan11155%_ '1)))
               (_%prior?11160%_
                (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                 _%bound11156%_))
               (_%seen-bound11162%_
                (if _%wide?11158%_
                    (gerbil-ascent/program/objects#name-index _%bound11156%_)
                    _%bound11156%_)))
          (letrec ((_%seen?11165%_
                    (lambda (_%name11200%_)
                      (if _%wide?11158%_
                          (let ()
                            (declare (not safe))
                            (hash-get _%seen-bound11162%_ _%name11200%_))
                          (memq _%name11200%_ _%seen-bound11162%_)))))
            (let _%loop11167%_ ((_%terms11169%_ (vector-ref _%plan11155%_ '1))
                                (_%column11170%_ '0)
                                (_%columns11171%_ '())
                                (_%bindings11172%_ '())
                                (_%key-terms11173%_ '()))
              (if (null? _%terms11169%_)
                  (vector (vector-ref _%plan11155%_ '0)
                          (vector-ref _%plan11155%_ '1)
                          (reverse _%columns11171%_)
                          (reverse _%bindings11172%_)
                          (reverse _%key-terms11173%_))
                  (let* ((_%term11175%_ (car _%terms11169%_))
                         (_%kind11177%_ (car _%term11175%_))
                         (_%inputs11179%_
                          (if (eq? _%kind11177%_ 'expression)
                              (vector-ref (cdr _%term11175%_) '0)
                              '#f)))
                    (if _%inputs11179%_
                        (gerbil-ascent/program/objects#require-bound
                         _%inputs11179%_
                         _%seen?11165%_)
                        '#!void)
                    (let* ((_%indexed?11188%_
                            (let ((_%$e11182%_ (eq? _%kind11177%_ 'literal)))
                              (if _%$e11182%_
                                  _%$e11182%_
                                  (let ((_%$e11185%_
                                         (if (eq? _%kind11177%_ 'variable)
                                             (let ((__tmp35994
                                                    (cdr _%term11175%_)))
                                               (declare (not safe))
                                               (_%prior?11160%_ __tmp35994))
                                             '#f)))
                                    (if _%$e11185%_
                                        _%$e11185%_
                                        (if _%inputs11179%_
                                            (let ()
                                              (declare (not safe))
                                              (andmap__0
                                               _%prior?11160%_
                                               _%inputs11179%_))
                                            '#f))))))
                           (_%binding11190%_
                            (if (and (eq? _%kind11177%_ 'variable)
                                     (not (_%seen?11165%_
                                           (cdr _%term11175%_))))
                                (cons 'fresh-variable (cdr _%term11175%_))
                                _%term11175%_)))
                      (let ((_%$e11193%_ _%kind11177%_))
                        (if (eq? 'variable _%$e11193%_)
                            (if _%wide?11158%_
                                (let ((__tmp35995 (cdr _%term11175%_)))
                                  (declare (not safe))
                                  (hash-put!
                                   _%seen-bound11162%_
                                   __tmp35995
                                   '#t))
                                (set! _%seen-bound11162%_
                                      (cons (cdr _%term11175%_)
                                            _%seen-bound11162%_)))
                            (if (eq? 'pattern _%$e11193%_)
                                (if _%wide?11158%_
                                    (for-each
                                     (lambda (_%$%g1119511197%_)
                                       (let ()
                                         (declare (not safe))
                                         (hash-put!
                                          _%seen-bound11162%_
                                          _%$%g1119511197%_
                                          '#t)))
                                     (gerbil-ascent/program/objects#pattern-outputs
                                      _%term11175%_))
                                    (set! _%seen-bound11162%_
                                          (append (gerbil-ascent/program/objects#pattern-outputs
                                                   _%term11175%_)
                                                  _%seen-bound11162%_)))
                                '#!void)))
                      (_%loop11167%_
                       (cdr _%terms11169%_)
                       (+ _%column11170%_ '1)
                       (if _%indexed?11188%_
                           (cons _%column11170%_ _%columns11171%_)
                           _%columns11171%_)
                       (cons _%binding11190%_ _%bindings11172%_)
                       (if _%indexed?11188%_
                           (cons _%term11175%_ _%key-terms11173%_)
                           _%key-terms11173%_))))))))))
    (define gerbil-ascent/program/objects#atom-clause-plan
      (lambda (_%clause11135%_ _%atom-plan11136%_ _%bound11137%_)
        (let* ((_%plan11139%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan11136%_ _%clause11135%_)
                 _%bound11137%_))
               (_%next-bound11152%_
                (let ((__tmp35997
                       (lambda (_%term11141%_ _%prior11142%_)
                         (if (eq? (car _%term11141%_) 'variable)
                             (cons (cdr _%term11141%_) _%prior11142%_)
                             (if (eq? (car _%term11141%_) 'pattern)
                                 (let _%loop11146%_ ((_%outputs11148%_
                                                      (gerbil-ascent/program/objects#pattern-outputs
                                                       _%term11141%_))
                                                     (_%next11149%_
                                                      _%prior11142%_))
                                   (if (null? _%outputs11148%_)
                                       _%next11149%_
                                       (begin
                                         (if (memq (car _%outputs11148%_)
                                                   _%next11149%_)
                                             (let ((__tmp35998
                                                    (car _%outputs11148%_)))
                                               (declare (not safe))
                                               (error '"ASCENT pattern variable already bound"
                                                      __tmp35998))
                                             '#!void)
                                         (_%loop11146%_
                                          (cdr _%outputs11148%_)
                                          (cons (car _%outputs11148%_)
                                                _%next11149%_)))))
                                 _%prior11142%_))))
                      (__tmp35996 (vector-ref _%plan11139%_ '1)))
                  (declare (not safe))
                  (foldl__0 __tmp35997 _%bound11137%_ __tmp35996))))
          (vector (vector 'atom _%plan11139%_) _%next-bound11152%_ '1))))
    (define gerbil-ascent/program/objects#negation-clause-plan
      (lambda (_%clause11126%_ _%atom-plan11127%_ _%bound11128%_)
        (let ((_%plan11130%_
               (gerbil-ascent/program/objects#indexed-atom
                (_%atom-plan11127%_ _%clause11126%_)
                _%bound11128%_))
              (_%bound?11131%_
               (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                _%bound11128%_)))
          (for-each
           (lambda (_%term11133%_)
             (if (eq? (car _%term11133%_) 'pattern)
                 (let ()
                   (declare (not safe))
                   (error '"ASCENT pattern cannot bind in negation"))
                 '#!void)
             (if (and (eq? (car _%term11133%_) 'variable)
                      (not (let ((__tmp35999 (cdr _%term11133%_)))
                             (declare (not safe))
                             (_%bound?11131%_ __tmp35999))))
                 (let ((__tmp36000 (cdr _%term11133%_)))
                   (declare (not safe))
                   (error '"unsafe ASCENT negation variable" __tmp36000))
                 '#!void))
           (vector-ref _%plan11130%_ '1))
          (vector (vector 'negation _%plan11130%_) _%bound11128%_ '0))))
    (define gerbil-ascent/program/objects#computed-clause-plan
      (lambda (_%clause11105%_
               _%kind11106%_
               _%function-slot11107%_
               _%bound11108%_)
        (let* ((_%inputs11110%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11105%_ 'variables)))
               (_%name11112%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11105%_ 'variable)))
               (_%names11114%_
                (if (and (eq? _%kind11106%_ 'generator) (list? _%name11112%_))
                    _%name11112%_
                    (list _%name11112%_))))
          (gerbil-ascent/program/objects#require-bound
           _%inputs11110%_
           (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
            _%bound11108%_))
          (let ((_%known11117%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names11114%_)
                     (gerbil-ascent/program/objects#name-index _%bound11108%_)
                     '#f)))
            (let _%loop11119%_ ((_%remaining11121%_ _%names11114%_)
                                (_%next-bound11122%_ _%bound11108%_))
              (if (null? _%remaining11121%_)
                  (vector (vector _%kind11106%_
                                  (if (list? _%name11112%_)
                                      (let ((__tmp36001
                                             (lambda (_%output11124%_)
                                               (cons 'variable
                                                     _%output11124%_))))
                                        (declare (not safe))
                                        (##map __tmp36001 _%name11112%_))
                                      _%name11112%_)
                                  _%inputs11110%_
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%clause11105%_
                                     _%function-slot11107%_)))
                          _%next-bound11122%_
                          '0)
                  (begin
                    (if (if _%known11117%_
                            (let ((__tmp36002 (car _%remaining11121%_)))
                              (declare (not safe))
                              (__hash-get _%known11117%_ __tmp36002))
                            (memq (car _%remaining11121%_)
                                  _%next-bound11122%_))
                        (let ((__tmp36003 (car _%remaining11121%_)))
                          (declare (not safe))
                          (error '"ASCENT computed variable already bound"
                                 __tmp36003))
                        '#!void)
                    (if _%known11117%_
                        (let ((__tmp36004 (car _%remaining11121%_)))
                          (declare (not safe))
                          (__hash-put! _%known11117%_ __tmp36004 '#t))
                        '#!void)
                    (_%loop11119%_
                     (cdr _%remaining11121%_)
                     (cons (car _%remaining11121%_)
                           _%next-bound11122%_)))))))))
    (define gerbil-ascent/program/objects#aggregate-clause-plan
      (lambda (_%clause11075%_ _%atom-plan11076%_ _%bound11077%_)
        (let* ((_%plan11079%_
                (gerbil-ascent/program/objects#indexed-atom
                 (_%atom-plan11076%_ _%clause11075%_)
                 _%bound11077%_))
               (_%name11081%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11075%_ 'variable)))
               (_%names11083%_
                (if (list? _%name11081%_) _%name11081%_ (list _%name11081%_)))
               (_%inputs11085%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%clause11075%_ 'variables)))
               (_%terms11087%_ (vector-ref _%plan11079%_ '1)))
          (if (let ()
                (declare (not safe))
                (ormap__0
                 gerbil-ascent/program/objects#pattern-outputs
                 _%terms11087%_))
              (let ()
                (declare (not safe))
                (error '"ASCENT pattern cannot bind in aggregate"))
              '#!void)
          (let ((_%known11090%_
                 (if (gerbil-ascent/program/objects#wide-scope? _%names11083%_)
                     (gerbil-ascent/program/objects#name-index _%bound11077%_)
                     '#f)))
            (let _%loop11092%_ ((_%remaining11094%_ _%names11083%_)
                                (_%next-bound11095%_ _%bound11077%_))
              (if (null? _%remaining11094%_)
                  '#!void
                  (begin
                    (if (if _%known11090%_
                            (let ((__tmp36005 (car _%remaining11094%_)))
                              (declare (not safe))
                              (__hash-get _%known11090%_ __tmp36005))
                            (memq (car _%remaining11094%_)
                                  _%next-bound11095%_))
                        (let ((__tmp36006 (car _%remaining11094%_)))
                          (declare (not safe))
                          (error '"ASCENT aggregate variable already bound"
                                 __tmp36006))
                        '#!void)
                    (if _%known11090%_
                        (let ((__tmp36007 (car _%remaining11094%_)))
                          (declare (not safe))
                          (__hash-put! _%known11090%_ __tmp36007 '#t))
                        '#!void)
                    (_%loop11092%_
                     (cdr _%remaining11094%_)
                     (cons (car _%remaining11094%_) _%next-bound11095%_))))))
          (let ((_%variables11099%_
                 (if (gerbil-ascent/program/objects#wide-scope?
                      _%inputs11085%_)
                     (gerbil-ascent/program/objects#name-index
                      (let ((__tmp36008
                             (lambda (_%term11097%_)
                               (if (eq? (car _%term11097%_) 'variable)
                                   (cdr _%term11097%_)
                                   '#f))))
                        (declare (not safe))
                        (filter-map__0 __tmp36008 _%terms11087%_)))
                     '#f)))
            (for-each
             (lambda (_%input11101%_)
               (if (if _%variables11099%_
                       (let ()
                         (declare (not safe))
                         (__hash-get _%variables11099%_ _%input11101%_))
                       (let ((__tmp36009
                              (lambda (_%term11103%_)
                                (and (eq? (car _%term11103%_) 'variable)
                                     (eq? (cdr _%term11103%_)
                                          _%input11101%_)))))
                         (declare (not safe))
                         (ormap__0 __tmp36009 _%terms11087%_)))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"ASCENT aggregate input absent from atom"
                            _%input11101%_))))
             _%inputs11085%_))
          (vector (vector 'aggregate
                          _%plan11079%_
                          _%name11081%_
                          _%inputs11085%_
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref _%clause11075%_ 'aggregate))
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%clause11075%_
                             'output-pattern)))
                  (append _%names11083%_ _%bound11077%_)
                  '0))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__%
      (lambda (_%relation-name10947%_
               _%column-count10948%_
               _%source-rows10949%_
               _%provider-value10950%_
               _%storage-value10951%_
               _%field-predicates-value10952%_
               _%domain-descriptor10953%_)
        (if (and (symbol? _%relation-name10947%_)
                 (exact-integer? _%column-count10948%_)
                 (<= '0 _%column-count10948%_)
                 (list? _%source-rows10949%_)
                 (list? _%field-predicates-value10952%_)
                 (or (null? _%field-predicates-value10952%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value10952%_))
                        _%column-count10948%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value10952%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT relation declaration"
                     _%relation-name10947%_
                     _%column-count10948%_)))
        (for-each
         (lambda (_%row10958%_)
           (if (and (list? _%row10958%_)
                    (= (let () (declare (not safe)) (##length _%row10958%_))
                       _%column-count10948%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT relation row"
                        _%relation-name10947%_
                        _%row10958%_
                        _%column-count10948%_)))
           (if (pair? _%field-predicates-value10952%_)
               (let ((__tmp36010
                      (lambda (_%predicate10960%_ _%value10961%_)
                        (if (_%predicate10960%_ _%value10961%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT relation source field type mismatch"
                                     _%relation-name10947%_
                                     _%row10958%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp36010
                  _%field-predicates-value10952%_
                  _%row10958%_))
               '#!void))
         _%source-rows10949%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRelationContract
         (let ((__obj35973
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36012
                  (list (cons 'name
                              (let ((__tmp36013
                                     (lambda (_%@10981%_)
                                       _%relation-name10947%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36013)))
                        (cons 'arity
                              (let ((__tmp36014
                                     (lambda (_%@10987%_)
                                       _%column-count10948%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36014)))
                        (cons 'rows
                              (let ((__tmp36015
                                     (lambda (_%@10992%_)
                                       _%source-rows10949%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36015)))
                        (cons 'field-predicates
                              (let ((__tmp36016
                                     (lambda (_%@10997%_)
                                       _%field-predicates-value10952%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36016)))
                        (cons 'checked-domain
                              (let ((__tmp36017
                                     (lambda (_%@11002%_)
                                       _%domain-descriptor10953%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36017)))
                        (cons 'storage-kind
                              (let ((__tmp36018
                                     (lambda (_%@11007%_) 'relation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36018)))
                        (cons 'index-provider
                              (let ((__tmp36019
                                     (lambda (_%@11012%_)
                                       _%provider-value10950%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36019)))
                        (cons 'storage-provider
                              (let ((__tmp36020
                                     (lambda (_%@11017%_)
                                       _%storage-value10951%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36020)))))
                 (__tmp36011 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Relation.
              __tmp36012
              __tmp36011
              __obj35973))
           __obj35973))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__0
      (lambda (_%relation-name11025%_
               _%column-count11026%_
               _%source-rows11027%_)
        (let* ((_%provider-value11029%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%storage-value11031%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value11033%_ '())
               (_%domain-descriptor11035%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11025%_
           _%column-count11026%_
           _%source-rows11027%_
           _%provider-value11029%_
           _%storage-value11031%_
           _%field-predicates-value11033%_
           _%domain-descriptor11035%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__1
      (lambda (_%relation-name11037%_
               _%column-count11038%_
               _%source-rows11039%_
               _%provider-value11040%_)
        (let* ((_%storage-value11042%_
                gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
               (_%field-predicates-value11044%_ '())
               (_%domain-descriptor11046%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11037%_
           _%column-count11038%_
           _%source-rows11039%_
           _%provider-value11040%_
           _%storage-value11042%_
           _%field-predicates-value11044%_
           _%domain-descriptor11046%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__2
      (lambda (_%relation-name11048%_
               _%column-count11049%_
               _%source-rows11050%_
               _%provider-value11051%_
               _%storage-value11052%_)
        (let* ((_%field-predicates-value11054%_ '())
               (_%domain-descriptor11056%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11048%_
           _%column-count11049%_
           _%source-rows11050%_
           _%provider-value11051%_
           _%storage-value11052%_
           _%field-predicates-value11054%_
           _%domain-descriptor11056%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation__3
      (lambda (_%relation-name11058%_
               _%column-count11059%_
               _%source-rows11060%_
               _%provider-value11061%_
               _%storage-value11062%_
               _%field-predicates-value11063%_)
        (let ((_%domain-descriptor11065%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__%
           _%relation-name11058%_
           _%column-count11059%_
           _%source-rows11060%_
           _%provider-value11061%_
           _%storage-value11062%_
           _%field-predicates-value11063%_
           _%domain-descriptor11065%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-relation
      (lambda _g36021_
        (let ((_g36022_ (let () (declare (not safe)) (##length _g36021_))))
          (cond ((let () (declare (not safe)) (##fx= _g36022_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__0
                        _g36021_))
                ((let () (declare (not safe)) (##fx= _g36022_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__1
                        _g36021_))
                ((let () (declare (not safe)) (##fx= _g36022_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__2
                        _g36021_))
                ((let () (declare (not safe)) (##fx= _g36022_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__3
                        _g36021_))
                ((let () (declare (not safe)) (##fx= _g36022_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-relation__%
                        _g36021_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-relation
                  _g36021_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__%
      (lambda (_%relation-name10806%_
               _%column-count10807%_
               _%source-rows10808%_
               _%join-procedure10809%_
               _%provider-value10810%_
               _%field-predicates-value10811%_
               _%operator-descriptor10812%_
               _%domain-descriptor10813%_)
        (if (and (symbol? _%relation-name10806%_)
                 (exact-integer? _%column-count10807%_)
                 (> _%column-count10807%_ '0)
                 (list? _%source-rows10808%_)
                 (procedure? _%join-procedure10809%_)
                 (list? _%field-predicates-value10811%_)
                 (or (null? _%field-predicates-value10811%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%field-predicates-value10811%_))
                        _%column-count10807%_))
                 (let ()
                   (declare (not safe))
                   (andmap__0 procedure? _%field-predicates-value10811%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT lattice declaration"
                     _%relation-name10806%_
                     _%column-count10807%_)))
        (for-each
         (lambda (_%row10818%_)
           (if (and (list? _%row10818%_)
                    (= (let () (declare (not safe)) (##length _%row10818%_))
                       _%column-count10807%_))
               '#!void
               (let ()
                 (declare (not safe))
                 (error '"invalid ASCENT lattice row"
                        _%relation-name10806%_
                        _%row10818%_
                        _%column-count10807%_)))
           (if (pair? _%field-predicates-value10811%_)
               (let ((__tmp36023
                      (lambda (_%predicate10820%_ _%value10821%_)
                        (if (_%predicate10820%_ _%value10821%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT lattice source field type mismatch"
                                     _%relation-name10806%_
                                     _%row10818%_))))))
                 (declare (not safe))
                 (##for-each
                  __tmp36023
                  _%field-predicates-value10811%_
                  _%row10818%_))
               '#!void))
         _%source-rows10808%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentLatticeContract
         (let ((__obj35974
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36025
                  (list (cons 'name
                              (let ((__tmp36026
                                     (lambda (_%@10842%_)
                                       _%relation-name10806%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36026)))
                        (cons 'arity
                              (let ((__tmp36027
                                     (lambda (_%@10848%_)
                                       _%column-count10807%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36027)))
                        (cons 'rows
                              (let ((__tmp36028
                                     (lambda (_%@10853%_)
                                       _%source-rows10808%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36028)))
                        (cons 'field-predicates
                              (let ((__tmp36029
                                     (lambda (_%@10858%_)
                                       _%field-predicates-value10811%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36029)))
                        (cons 'checked-domain
                              (let ((__tmp36030
                                     (lambda (_%@10863%_)
                                       _%domain-descriptor10813%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36030)))
                        (cons 'storage-kind
                              (let ((__tmp36031
                                     (lambda (_%@10868%_) 'lattice)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36031)))
                        (cons 'join
                              (let ((__tmp36032
                                     (lambda (_%@10873%_)
                                       _%join-procedure10809%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36032)))
                        (cons 'checked-operator
                              (let ((__tmp36033
                                     (lambda (_%@10878%_)
                                       _%operator-descriptor10812%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36033)))
                        (cons 'index-provider
                              (let ((__tmp36034
                                     (lambda (_%@10883%_)
                                       _%provider-value10810%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36034)))))
                 (__tmp36024 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Lattice.
              __tmp36025
              __tmp36024
              __obj35974))
           __obj35974))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__0
      (lambda (_%relation-name10891%_
               _%column-count10892%_
               _%source-rows10893%_
               _%join-procedure10894%_)
        (let* ((_%provider-value10896%_
                gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider)
               (_%field-predicates-value10898%_ '())
               (_%operator-descriptor10900%_ '#f)
               (_%domain-descriptor10902%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10891%_
           _%column-count10892%_
           _%source-rows10893%_
           _%join-procedure10894%_
           _%provider-value10896%_
           _%field-predicates-value10898%_
           _%operator-descriptor10900%_
           _%domain-descriptor10902%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__1
      (lambda (_%relation-name10904%_
               _%column-count10905%_
               _%source-rows10906%_
               _%join-procedure10907%_
               _%provider-value10908%_)
        (let* ((_%field-predicates-value10910%_ '())
               (_%operator-descriptor10912%_ '#f)
               (_%domain-descriptor10914%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10904%_
           _%column-count10905%_
           _%source-rows10906%_
           _%join-procedure10907%_
           _%provider-value10908%_
           _%field-predicates-value10910%_
           _%operator-descriptor10912%_
           _%domain-descriptor10914%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__2
      (lambda (_%relation-name10916%_
               _%column-count10917%_
               _%source-rows10918%_
               _%join-procedure10919%_
               _%provider-value10920%_
               _%field-predicates-value10921%_)
        (let* ((_%operator-descriptor10923%_ '#f)
               (_%domain-descriptor10925%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10916%_
           _%column-count10917%_
           _%source-rows10918%_
           _%join-procedure10919%_
           _%provider-value10920%_
           _%field-predicates-value10921%_
           _%operator-descriptor10923%_
           _%domain-descriptor10925%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice__3
      (lambda (_%relation-name10927%_
               _%column-count10928%_
               _%source-rows10929%_
               _%join-procedure10930%_
               _%provider-value10931%_
               _%field-predicates-value10932%_
               _%operator-descriptor10933%_)
        (let ((_%domain-descriptor10935%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
           _%relation-name10927%_
           _%column-count10928%_
           _%source-rows10929%_
           _%join-procedure10930%_
           _%provider-value10931%_
           _%field-predicates-value10932%_
           _%operator-descriptor10933%_
           _%domain-descriptor10935%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-lattice
      (lambda _g36035_
        (let ((_g36036_ (let () (declare (not safe)) (##length _g36035_))))
          (cond ((let () (declare (not safe)) (##fx= _g36036_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__0
                        _g36035_))
                ((let () (declare (not safe)) (##fx= _g36036_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__1
                        _g36035_))
                ((let () (declare (not safe)) (##fx= _g36036_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__2
                        _g36035_))
                ((let () (declare (not safe)) (##fx= _g36036_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__3
                        _g36035_))
                ((let () (declare (not safe)) (##fx= _g36036_ 8))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-lattice__%
                        _g36035_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-lattice
                  _g36035_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-variable
      (lambda (_%name10780%_)
        (if (symbol? _%name10780%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT variable name must be a symbol" _%name10780%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35975
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36038
                  (list (cons 'kind
                              (let ((__tmp36039
                                     (lambda (_%@10794%_) 'variable)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36039)))
                        (cons 'value
                              (let ((__tmp36040
                                     (lambda (_%@10800%_) _%name10780%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36040)))))
                 (__tmp36037 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp36038
              __tmp36037
              __obj35975))
           __obj35975))))
    (define gerbil-ascent/program/objects#gerbil-ascent-wildcard
      (lambda ()
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35976
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36042
                  (list (cons 'kind
                              (let ((__tmp36043
                                     (lambda (_%@10769%_) 'wildcard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36043)))
                        (cons 'value
                              (let ((__tmp36044 (lambda (_%@10775%_) '#f)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36044)))))
                 (__tmp36041 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp36042
              __tmp36041
              __obj35976))
           __obj35976))))
    (define gerbil-ascent/program/objects#gerbil-ascent-literal
      (lambda (_%literal-value10731%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35977
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36046
                  (list (cons 'kind
                              (let ((__tmp36047
                                     (lambda (_%@10745%_) 'literal)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36047)))
                        (cons 'value
                              (let ((__tmp36048
                                     (lambda (_%@10751%_)
                                       _%literal-value10731%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36048)))))
                 (__tmp36045 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp36046
              __tmp36045
              __obj35977))
           __obj35977))))
    (define gerbil-ascent/program/objects#gerbil-ascent-expression
      (lambda (_%input-variables10705%_ _%compute10706%_)
        (if (and (list? _%input-variables10705%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%input-variables10705%_))
                 (procedure? _%compute10706%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT head expression"
                     _%input-variables10705%_
                     _%compute10706%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35978
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36050
                  (list (cons 'kind
                              (let ((__tmp36051
                                     (lambda (_%@10720%_) 'expression)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36051)))
                        (cons 'value
                              (let ((__tmp36052
                                     (lambda (_%@10726%_)
                                       (vector _%input-variables10705%_
                                               _%compute10706%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36052)))))
                 (__tmp36049 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp36050
              __tmp36049
              __obj35978))
           __obj35978))))
    (define gerbil-ascent/program/objects#gerbil-ascent-pattern
      (lambda (_%output-variables10679%_ _%matcher10680%_)
        (if (and (list? _%output-variables10679%_)
                 (let ()
                   (declare (not safe))
                   (andmap__0 symbol? _%output-variables10679%_))
                 (procedure? _%matcher10680%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT pattern"
                     _%output-variables10679%_
                     _%matcher10680%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentTermContract
         (let ((__obj35979
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36054
                  (list (cons 'kind
                              (let ((__tmp36055
                                     (lambda (_%@10694%_) 'pattern)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36055)))
                        (cons 'value
                              (let ((__tmp36056
                                     (lambda (_%@10700%_)
                                       (vector _%output-variables10679%_
                                               _%matcher10680%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36056)))))
                 (__tmp36053 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Term.
              __tmp36054
              __tmp36053
              __obj35979))
           __obj35979))))
    (define gerbil-ascent/program/objects#gerbil-ascent-atom
      (lambda (_%relation-name10638%_ _%atom-terms10639%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAtomContract
         (let ((__obj35980
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36058
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36059
                                     (lambda (_%self10655%_) 'atom)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36059)))
                        (cons 'relation
                              (let ((__tmp36060
                                     (lambda (_%self10661%_)
                                       _%relation-name10638%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36060)))
                        (cons 'terms
                              (let ((__tmp36061
                                     (lambda (_%self10666%_)
                                       _%atom-terms10639%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36061)))
                        (cons '.plan
                              (let ((__tmp36062
                                     (lambda (_%self10671%_)
                                       (lambda (_%atom-plan10676%_
                                                _%bound10677%_)
                                         (gerbil-ascent/program/objects#atom-clause-plan
                                          _%self10671%_
                                          _%atom-plan10676%_
                                          _%bound10677%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36062)))))
                 (__tmp36057 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Atom.
              __tmp36058
              __tmp36057
              __obj35980))
           __obj35980))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__%
      (lambda (_%input-variables10578%_
               _%guard-procedure10579%_
               _%operator-descriptor10580%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGuardContract
         (let ((__obj35981
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36064
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36065
                                     (lambda (_%self10597%_) 'guard)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36065)))
                        (cons 'variables
                              (let ((__tmp36066
                                     (lambda (_%self10603%_)
                                       _%input-variables10578%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36066)))
                        (cons 'predicate
                              (let ((__tmp36067
                                     (lambda (_%self10608%_)
                                       _%guard-procedure10579%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36067)))
                        (cons 'checked-operator
                              (let ((__tmp36068
                                     (lambda (_%self10613%_)
                                       _%operator-descriptor10580%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36068)))
                        (cons '.plan
                              (let ((__tmp36069
                                     (lambda (_%self10618%_)
                                       (lambda (_%_atom-plan10623%_
                                                _%bound10624%_)
                                         (gerbil-ascent/program/objects#require-bound
                                          (let ()
                                            (declare (not safe))
                                            (clan/poo/object#.ref
                                             _%self10618%_
                                             'variables))
                                          (gerbil-ascent/program/objects#gerbil-ascent-bound-membership
                                           _%bound10624%_))
                                         (vector (vector 'guard
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self10618%_
                                                            'variables))
                                                         (let ()
                                                           (declare (not safe))
                                                           (clan/poo/object#.ref
                                                            _%self10618%_
                                                            'predicate)))
                                                 _%bound10624%_
                                                 '0)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36069)))))
                 (__tmp36063 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Guard.
              __tmp36064
              __tmp36063
              __obj35981))
           __obj35981))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard__0
      (lambda (_%input-variables10629%_ _%guard-procedure10630%_)
        (let ((_%operator-descriptor10632%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-guard__%
           _%input-variables10629%_
           _%guard-procedure10630%_
           _%operator-descriptor10632%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-guard
      (lambda _g36070_
        (let ((_g36071_ (let () (declare (not safe)) (##length _g36070_))))
          (cond ((let () (declare (not safe)) (##fx= _g36071_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__0
                        _g36070_))
                ((let () (declare (not safe)) (##fx= _g36071_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-guard__%
                        _g36070_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-guard
                  _g36070_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-generator
      (lambda (_%output-variable10529%_
               _%input-variables10530%_
               _%generator-procedure10531%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentGeneratorContract
         (let ((__obj35982
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36073
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36074
                                     (lambda (_%self10548%_) 'generator)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36074)))
                        (cons 'variable
                              (let ((__tmp36075
                                     (lambda (_%self10554%_)
                                       _%output-variable10529%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36075)))
                        (cons 'variables
                              (let ((__tmp36076
                                     (lambda (_%self10559%_)
                                       _%input-variables10530%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36076)))
                        (cons 'generate
                              (let ((__tmp36077
                                     (lambda (_%self10564%_)
                                       _%generator-procedure10531%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36077)))
                        (cons '.plan
                              (let ((__tmp36078
                                     (lambda (_%self10569%_)
                                       (lambda (_%_atom-plan10574%_
                                                _%bound10575%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self10569%_
                                          'generator
                                          'generate
                                          _%bound10575%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36078)))))
                 (__tmp36072 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Generator.
              __tmp36073
              __tmp36072
              __obj35982))
           __obj35982))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__%
      (lambda (_%output-variable10460%_
               _%input-variables10461%_
               _%binding-procedure10462%_
               _%operator-descriptor10463%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentBindingContract
         (let ((__obj35983
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36080
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36081
                                     (lambda (_%self10481%_) 'binding)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36081)))
                        (cons 'variable
                              (let ((__tmp36082
                                     (lambda (_%self10487%_)
                                       _%output-variable10460%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36082)))
                        (cons 'variables
                              (let ((__tmp36083
                                     (lambda (_%self10492%_)
                                       _%input-variables10461%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36083)))
                        (cons 'compute
                              (let ((__tmp36084
                                     (lambda (_%self10497%_)
                                       _%binding-procedure10462%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36084)))
                        (cons 'checked-operator
                              (let ((__tmp36085
                                     (lambda (_%self10502%_)
                                       _%operator-descriptor10463%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36085)))
                        (cons '.plan
                              (let ((__tmp36086
                                     (lambda (_%self10507%_)
                                       (lambda (_%_atom-plan10512%_
                                                _%bound10513%_)
                                         (gerbil-ascent/program/objects#computed-clause-plan
                                          _%self10507%_
                                          'binding
                                          'compute
                                          _%bound10513%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36086)))))
                 (__tmp36079 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Binding.
              __tmp36080
              __tmp36079
              __obj35983))
           __obj35983))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding__0
      (lambda (_%output-variable10518%_
               _%input-variables10519%_
               _%binding-procedure10520%_)
        (let ((_%operator-descriptor10522%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-binding__%
           _%output-variable10518%_
           _%input-variables10519%_
           _%binding-procedure10520%_
           _%operator-descriptor10522%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-binding
      (lambda _g36087_
        (let ((_g36088_ (let () (declare (not safe)) (##length _g36087_))))
          (cond ((let () (declare (not safe)) (##fx= _g36088_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__0
                        _g36087_))
                ((let () (declare (not safe)) (##fx= _g36088_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-binding__%
                        _g36087_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-binding
                  _g36087_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-negation
      (lambda (_%relation-name10418%_ _%atom-terms10419%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentNegationContract
         (let ((__obj35984
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36090
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36091
                                     (lambda (_%self10435%_) 'negation)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36091)))
                        (cons 'relation
                              (let ((__tmp36092
                                     (lambda (_%self10441%_)
                                       _%relation-name10418%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36092)))
                        (cons 'terms
                              (let ((__tmp36093
                                     (lambda (_%self10446%_)
                                       _%atom-terms10419%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36093)))
                        (cons '.plan
                              (let ((__tmp36094
                                     (lambda (_%self10451%_)
                                       (lambda (_%atom-plan10456%_
                                                _%bound10457%_)
                                         (gerbil-ascent/program/objects#negation-clause-plan
                                          _%self10451%_
                                          _%atom-plan10456%_
                                          _%bound10457%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36094)))))
                 (__tmp36089 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Negation.
              __tmp36090
              __tmp36089
              __obj35984))
           __obj35984))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
      (lambda (_%output-variable10309%_
               _%relation-name10310%_
               _%atom-terms10311%_
               _%value-variables10312%_
               _%aggregate-procedure10313%_
               _%matcher10314%_
               _%operator-descriptor10315%_)
        (if (or (and (symbol? _%output-variable10309%_) (not _%matcher10314%_))
                (and (pair? _%output-variable10309%_)
                     (let ()
                       (declare (not safe))
                       (andmap__0 symbol? _%output-variable10309%_))
                     (procedure? _%matcher10314%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT aggregate output"
                     _%output-variable10309%_
                     _%matcher10314%_)))
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentAggregateContract
         (let ((__obj35985
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36096
                  (list (cons 'ascent-clause-kind
                              (let ((__tmp36097
                                     (lambda (_%self10339%_) 'aggregate)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36097)))
                        (cons 'variable
                              (let ((__tmp36098
                                     (lambda (_%self10345%_)
                                       _%output-variable10309%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36098)))
                        (cons 'relation
                              (let ((__tmp36099
                                     (lambda (_%self10350%_)
                                       _%relation-name10310%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36099)))
                        (cons 'terms
                              (let ((__tmp36100
                                     (lambda (_%self10355%_)
                                       _%atom-terms10311%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36100)))
                        (cons 'variables
                              (let ((__tmp36101
                                     (lambda (_%self10360%_)
                                       _%value-variables10312%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36101)))
                        (cons 'aggregate
                              (let ((__tmp36102
                                     (lambda (_%self10365%_)
                                       _%aggregate-procedure10313%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36102)))
                        (cons 'output-pattern
                              (let ((__tmp36103
                                     (lambda (_%self10370%_)
                                       _%matcher10314%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36103)))
                        (cons 'checked-operator
                              (let ((__tmp36104
                                     (lambda (_%self10375%_)
                                       _%operator-descriptor10315%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36104)))
                        (cons '.plan
                              (let ((__tmp36105
                                     (lambda (_%self10380%_)
                                       (lambda (_%atom-plan10385%_
                                                _%bound10386%_)
                                         (gerbil-ascent/program/objects#aggregate-clause-plan
                                          _%self10380%_
                                          _%atom-plan10385%_
                                          _%bound10386%_)))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36105)))))
                 (__tmp36095 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Aggregate.
              __tmp36096
              __tmp36095
              __obj35985))
           __obj35985))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
      (lambda (_%output-variable10391%_
               _%relation-name10392%_
               _%atom-terms10393%_
               _%value-variables10394%_
               _%aggregate-procedure10395%_)
        (let* ((_%matcher10397%_ '#f) (_%operator-descriptor10399%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable10391%_
           _%relation-name10392%_
           _%atom-terms10393%_
           _%value-variables10394%_
           _%aggregate-procedure10395%_
           _%matcher10397%_
           _%operator-descriptor10399%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
      (lambda (_%output-variable10401%_
               _%relation-name10402%_
               _%atom-terms10403%_
               _%value-variables10404%_
               _%aggregate-procedure10405%_
               _%matcher10406%_)
        (let ((_%operator-descriptor10408%_ '#f))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output-variable10401%_
           _%relation-name10402%_
           _%atom-terms10403%_
           _%value-variables10404%_
           _%aggregate-procedure10405%_
           _%matcher10406%_
           _%operator-descriptor10408%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-aggregate
      (lambda _g36106_
        (let ((_g36107_ (let () (declare (not safe)) (##length _g36106_))))
          (cond ((let () (declare (not safe)) (##fx= _g36107_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__0
                        _g36106_))
                ((let () (declare (not safe)) (##fx= _g36107_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__1
                        _g36106_))
                ((let () (declare (not safe)) (##fx= _g36107_ 7))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
                        _g36106_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-aggregate
                  _g36106_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-rule
      (lambda (_%head-atoms10282%_ _%body-atoms10283%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentRuleContract
         (let ((__obj35986
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36109
                  (list (cons 'heads
                              (let ((__tmp36110
                                     (lambda (_%@10297%_)
                                       _%head-atoms10282%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36110)))
                        (cons 'body
                              (let ((__tmp36111
                                     (lambda (_%@10303%_)
                                       _%body-atoms10283%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36111)))))
                 (__tmp36108 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Rule.
              __tmp36109
              __tmp36108
              __obj35986))
           __obj35986))))
    (define gerbil-ascent/program/objects#fragment-export-resolver
      (lambda (_%export-values10271%_)
        (if (list? _%export-values10271%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT fragment exports"
                     _%export-values10271%_)))
        (let ((_%entries10273%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (for-each
           (lambda (_%entry10275%_)
             (if (and (pair? _%entry10275%_)
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##car _%entry10275%_)))
                      (symbol? (let ()
                                 (declare (not safe))
                                 (##cdr _%entry10275%_)))
                      (not (let ((__tmp36112
                                  (let ()
                                    (declare (not safe))
                                    (##car _%entry10275%_))))
                             (declare (not safe))
                             (__hash-get _%entries10273%_ __tmp36112))))
                 '#!void
                 (let ()
                   (declare (not safe))
                   (error '"invalid or duplicate ASCENT fragment export"
                          _%entry10275%_)))
             (let ((__tmp36114 (car _%entry10275%_))
                   (__tmp36113 (cdr _%entry10275%_)))
               (declare (not safe))
               (__hash-put! _%entries10273%_ __tmp36114 __tmp36113)))
           _%export-values10271%_)
          (lambda (_%label10277%_)
            (let ((_%$e10279%_
                   (let ()
                     (declare (not safe))
                     (__hash-get _%entries10273%_ _%label10277%_))))
              (if _%$e10279%_
                  _%$e10279%_
                  (let ()
                    (declare (not safe))
                    (error '"unknown relational fragment export"
                           _%label10277%_))))))))
    (define gerbil-ascent/program/objects#declared-name-membership
      (lambda (_%relations10253%_)
        (let ((_%remaining10255%_ _%relations10253%_)
              (_%names10256%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (lambda (_%name10258%_)
            (let ((_%$e10260%_
                   (let ()
                     (declare (not safe))
                     (__hash-get _%names10256%_ _%name10258%_))))
              (if _%$e10260%_
                  _%$e10260%_
                  (let _%scan10263%_ ()
                    (if (null? _%remaining10255%_)
                        '#f
                        (let ((_%found10266%_
                               (let ((__tmp36115 (car _%remaining10255%_)))
                                 (declare (not safe))
                                 (clan/poo/object#.ref __tmp36115 'name))))
                          (set! _%remaining10255%_ (cdr _%remaining10255%_))
                          (let ()
                            (declare (not safe))
                            (__hash-put! _%names10256%_ _%found10266%_ '#t))
                          (let ((_%$e10268%_
                                 (eq? _%found10266%_ _%name10258%_)))
                            (if _%$e10268%_
                                _%$e10268%_
                                (_%scan10263%_))))))))))))
    (define gerbil-ascent/program/objects#checked-source-handles
      (lambda (_%relations10240%_ _%source-handle-values10241%_)
        (if (list? _%source-handle-values10241%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid ASCENT source handles"
                     _%source-handle-values10241%_)))
        (letrec* ((_%seen10243%_
                   (let () (declare (not safe)) (make-hash-table-eq)))
                  (_%declared?10244%_
                   (gerbil-ascent/program/objects#declared-name-membership
                    _%relations10240%_)))
          (let _%loop10246%_ ((_%remaining10248%_
                               _%source-handle-values10241%_)
                              (_%copied10249%_ '()))
            (if (null? _%remaining10248%_)
                (reverse _%copied10249%_)
                (let ((_%name10251%_ (car _%remaining10248%_)))
                  (if (and (symbol? _%name10251%_)
                           (if (let ()
                                 (declare (not safe))
                                 (__hash-get _%seen10243%_ _%name10251%_))
                               '#f
                               (let ()
                                 (declare (not safe))
                                 (_%declared?10244%_ _%name10251%_))))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"invalid or duplicate ASCENT source handle"
                               _%name10251%_)))
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%seen10243%_ _%name10251%_ '#t))
                  (_%loop10246%_
                   (cdr _%remaining10248%_)
                   (cons _%name10251%_ _%copied10249%_))))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__%
      (lambda (_%relation-values10179%_
               _%rule-values10180%_
               _%export-values10181%_
               _%source-handle-values10182%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentFragmentContract
         (let ((__obj35987
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36117
                  (list (cons 'relations
                              (let ((__tmp36118
                                     (lambda (_%@10198%_)
                                       _%relation-values10179%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36118)))
                        (cons 'rules
                              (let ((__tmp36119
                                     (lambda (_%@10204%_)
                                       _%rule-values10180%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36119)))
                        (cons 'exports
                              (let ((__tmp36120
                                     (lambda (_%@10209%_)
                                       (gerbil-ascent/program/objects#fragment-export-resolver
                                        _%export-values10181%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36120)))
                        (cons 'source-handles
                              (let ((__tmp36121
                                     (lambda (_%@10214%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%relation-values10179%_
                                        _%source-handle-values10182%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36121)))))
                 (__tmp36116 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Fragment.
              __tmp36117
              __tmp36116
              __obj35987))
           __obj35987))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__0
      (lambda (_%relation-values10222%_ _%rule-values10223%_)
        (let* ((_%export-values10225%_ '())
               (_%source-handle-values10227%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values10222%_
           _%rule-values10223%_
           _%export-values10225%_
           _%source-handle-values10227%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment__1
      (lambda (_%relation-values10229%_
               _%rule-values10230%_
               _%export-values10231%_)
        (let ((_%source-handle-values10233%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
           _%relation-values10229%_
           _%rule-values10230%_
           _%export-values10231%_
           _%source-handle-values10233%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-fragment
      (lambda _g36122_
        (let ((_g36123_ (let () (declare (not safe)) (##length _g36122_))))
          (cond ((let () (declare (not safe)) (##fx= _g36123_ 2))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__0
                        _g36122_))
                ((let () (declare (not safe)) (##fx= _g36123_ 3))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__1
                        _g36122_))
                ((let () (declare (not safe)) (##fx= _g36123_ 4))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-fragment__%
                        _g36122_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-fragment
                  _g36122_))))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__%
      (lambda (_%declared-relations10105%_
               _%declared-rules10106%_
               _%input-fact-limit10107%_
               _%derived-fact-limit10108%_
               _%output-fact-limit10109%_
               _%source-handle-values10110%_)
        (gerbil-ascent/program/objects#declaration-check
         gerbil-ascent/program/types#GerbilAscentProgramContract
         (let ((__obj35988
                (let ()
                  (declare (not safe))
                  (##structure
                   clan/poo/object#object::t
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f
                   '#f))))
           (let ((__tmp36125
                  (list (cons 'relations
                              (let ((__tmp36126
                                     (lambda (_%@10129%_)
                                       _%declared-relations10105%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36126)))
                        (cons 'rules
                              (let ((__tmp36127
                                     (lambda (_%@10135%_)
                                       _%declared-rules10106%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36127)))
                        (cons 'source-handles
                              (let ((__tmp36128
                                     (lambda (_%@10140%_)
                                       (gerbil-ascent/program/objects#checked-source-handles
                                        _%declared-relations10105%_
                                        _%source-handle-values10110%_))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36128)))
                        (cons 'max-input-facts
                              (let ((__tmp36129
                                     (lambda (_%@10145%_)
                                       _%input-fact-limit10107%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36129)))
                        (cons 'max-derived-facts
                              (let ((__tmp36130
                                     (lambda (_%@10150%_)
                                       _%derived-fact-limit10108%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36130)))
                        (cons 'max-output-facts
                              (let ((__tmp36131
                                     (lambda (_%@10155%_)
                                       _%output-fact-limit10109%_)))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp36131)))))
                 (__tmp36124 (list)))
             (declare (not safe))
             (clan/poo/object#object:::init!__%
              '#f
              gerbil-ascent/program/objects#Program.
              __tmp36125
              __tmp36124
              __obj35988))
           __obj35988))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program__0
      (lambda (_%declared-relations10163%_
               _%declared-rules10164%_
               _%input-fact-limit10165%_
               _%derived-fact-limit10166%_
               _%output-fact-limit10167%_)
        (let ((_%source-handle-values10169%_ '()))
          (gerbil-ascent/program/objects#gerbil-ascent-program__%
           _%declared-relations10163%_
           _%declared-rules10164%_
           _%input-fact-limit10165%_
           _%derived-fact-limit10166%_
           _%output-fact-limit10167%_
           _%source-handle-values10169%_))))
    (define gerbil-ascent/program/objects#gerbil-ascent-program
      (lambda _g36132_
        (let ((_g36133_ (let () (declare (not safe)) (##length _g36132_))))
          (cond ((let () (declare (not safe)) (##fx= _g36133_ 5))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__0
                        _g36132_))
                ((let () (declare (not safe)) (##fx= _g36133_ 6))
                 (apply gerbil-ascent/program/objects#gerbil-ascent-program__%
                        _g36132_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/objects#gerbil-ascent-program
                  _g36132_))))))))
