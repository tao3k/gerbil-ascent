(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-worker[1]#_g36821_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36823_|
    (##structure
     gx#syntax-quote::t
     'make-component-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36825_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36827_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36828_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36830_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36831_|
    (##structure
     gx#syntax-quote::t
     'component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36833_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36834_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36836_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[1]#_g36837_|
    (##structure
     gx#syntax-quote::t
     '&component-snapshot-sizes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-worker[:0:]#component-snapshot|
    (let ((__obj36684
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj36684
         'gerbil-ascent/program/component-worker#component-snapshot::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 'component-snapshot '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '(rows sizes) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '(rows sizes) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '#f '13 '#f '#f))
      (let ((__tmp36820 |gerbil-ascent/program/component-worker[1]#_g36821_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36820 '4 '#f '#f))
      (let ((__tmp36822 |gerbil-ascent/program/component-worker[1]#_g36823_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36822 '14 '#f '#f))
      (let ((__tmp36824 |gerbil-ascent/program/component-worker[1]#_g36825_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36824 '15 '#f '#f))
      (let ((__tmp36826
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36827_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36828_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36826 '16 '#f '#f))
      (let ((__tmp36829
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36830_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36831_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36829 '17 '#f '#f))
      (let ((__tmp36832
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36833_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36834_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36832 '18 '#f '#f))
      (let ((__tmp36835
             (cons (cons 'rows
                         |gerbil-ascent/program/component-worker[1]#_g36836_|)
                   (cons (cons 'sizes
                               |gerbil-ascent/program/component-worker[1]#_g36837_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 __tmp36835 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj36684 '() '21 '#f '#f))
      __obj36684)))
