(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/session::timestamp 1791689709)
  (begin
    (define gerbil-ascent/program/session#Session.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentSessionContract
         'proto)))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session__%
      (lambda (_%@@keywords19737%_
               _%$%measure-rule-times?1973419738%_
               _%program19739%_)
        (let ((_%measure-rule-times?19741%_
               (if (eq? _%$%measure-rule-times?1973419738%_ absent-value)
                   '#f
                   _%$%measure-rule-times?1973419738%_)))
          (if (boolean? _%measure-rule-times?19741%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule timing option"
                       _%measure-rule-times?19741%_)))
          (letrec ((_%copy-source-rows19743%_
                    (lambda (_%rows20125%_)
                      (if (list? _%rows20125%_)
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT source rows"
                                   _%rows20125%_)))
                      (map (lambda (_%row20127%_)
                             (if (list? _%row20127%_)
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"invalid ASCENT source row"
                                          _%row20127%_)))
                             (map identity _%row20127%_))
                           _%rows20125%_))))
            (let* ((_%relations19745%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program19739%_ 'relations)))
                   (_%initial-relations19771%_
                    (map (lambda (_%relation19747%_)
                           (let ((__obj37726
                                  (let ()
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#object::t
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f))))
                             (let ((__tmp37730
                                    (list (cons 'rows
                                                (let ((__tmp37731
                                                       (lambda (_%@19765%_)
                                                         (_%copy-source-rows19743%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (clan/poo/object#.ref
                                                             _%relation19747%_
                                                             'rows))))))
                                                  (declare (not safe))
                                                  (##structure
                                                   clan/poo/object#$self-slot-spec::t
                                                   __tmp37731)))))
                                   (__tmp37729 (list)))
                               (declare (not safe))
                               (clan/poo/object#object:::init!__%
                                '#f
                                _%relation19747%_
                                __tmp37730
                                __tmp37729
                                __obj37726))
                             __obj37726))
                         _%relations19745%_))
                   (_%initial-program19790%_
                    (let ((__obj37727
                           (let ()
                             (declare (not safe))
                             (##structure
                              clan/poo/object#object::t
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f))))
                      (let ((__tmp37733
                             (list (cons 'relations
                                         (let ((__tmp37734
                                                (lambda (_%@19784%_)
                                                  _%initial-relations19771%_)))
                                           (declare (not safe))
                                           (##structure
                                            clan/poo/object#$self-slot-spec::t
                                            __tmp37734)))))
                            (__tmp37732 (list)))
                        (declare (not safe))
                        (clan/poo/object#object:::init!__%
                         '#f
                         _%program19739%_
                         __tmp37733
                         __tmp37732
                         __obj37727))
                      __obj37727))
                   (_%source-snapshot19792%_
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
                       _%initial-program19790%_)))
                   (_%single-relation-name19794%_
                    (if (pair? _%relations19745%_)
                        (if (null? (let ()
                                     (declare (not safe))
                                     (##cdr _%relations19745%_)))
                            (let ((__tmp37735
                                   (let ()
                                     (declare (not safe))
                                     (##car _%relations19745%_))))
                              (declare (not safe))
                              (clan/poo/object#.ref __tmp37735 'name))
                            '#f)
                        '#f))
                   (_%positions19796%_
                    (let () (declare (not safe)) (make-hash-table-eq)))
                   (_%initial19800%_
                    (list->vector
                     (let ((__tmp37736
                            (lambda (_%relation19798%_)
                              (cons (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%relation19798%_
                                       'rows))
                                    '()))))
                       (declare (not safe))
                       (##map __tmp37736 _%initial-relations19771%_))))
                   (_%safe-set-flush?19810%_
                    (let ((__tmp37737
                           (lambda (_%relation19802%_)
                             (let ((_%$e19804%_
                                    (eq? (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%relation19802%_
                                            'storage-kind))
                                         'lattice)))
                               (if _%$e19804%_
                                   _%$e19804%_
                                   (let ((_%$e19807%_
                                          (not (let ((__tmp37738
                                                      (let ()
                                                        (declare (not safe))
                                                        (clan/poo/object#.ref
                                                         _%relation19802%_
                                                         'storage-provider))))
                                                 (declare (not safe))
                                                 (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                                  __tmp37738)))))
                                     (if _%$e19807%_
                                         _%$e19807%_
                                         (let ((__tmp37739
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%relation19802%_
                                                   'index-provider))))
                                           (declare (not safe))
                                           (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                            __tmp37739)))))))))
                      (declare (not safe))
                      (andmap__0 __tmp37737 _%relations19745%_)))
                   (_%atomic-appends19817%_
                    (list->vector
                     (map (lambda (_%relation19812%_)
                            (let ((_%$e19814%_
                                   (eq? (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%relation19812%_
                                           'storage-kind))
                                        'lattice)))
                              (if _%$e19814%_
                                  _%$e19814%_
                                  (if _%safe-set-flush?19810%_
                                      (let ((__tmp37740
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%relation19812%_
                                                'storage-provider))))
                                        (declare (not safe))
                                        (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                         __tmp37740))
                                      '#f))))
                          _%relations19745%_)))
                   (_%direct-appends?19821%_
                    (let ((__tmp37742 (lambda (_%safe?19819%_) _%safe?19819%_))
                          (__tmp37741
                           (let ()
                             (declare (not safe))
                             (##vector->list _%atomic-appends19817%_))))
                      (declare (not safe))
                      (andmap__0 __tmp37742 __tmp37741)))
                   (_%pending19823%_
                    (list->vector
                     (let ()
                       (declare (not safe))
                       (##vector->list _%initial19800%_))))
                   (_%committed19825%_
                    (list->vector
                     (let ()
                       (declare (not safe))
                       (##vector->list _%initial19800%_))))
                   (_%committed-result19827%_ '#f)
                   (_%initialized?19829%_ '#f)
                   (_%clean?19831%_ '#f)
                   (_%partial?19833%_ '#f)
                   (_%replay-on-timeout?19835%_ '#f)
                   (_%replacement-active?19837%_ '#f)
                   (_%last-result19839%_ '#f)
                   (_%engine19841%_
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                       _%initial-program19790%_
                       '#t
                       '#f
                       '#f
                       _%measure-rule-times?19741%_)))
                   (_%engine-analysis19843%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19841%_ '.analysis)))
                   (_%engine-schema19845%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19841%_ '.schema)))
                   (_%engine-base-rows19849%_
                    (list->vector
                     (let ((__tmp37743
                            (lambda (_%relation19847%_)
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation19847%_
                                 'rows)))))
                       (declare (not safe))
                       (##map __tmp37743 _%initial-relations19771%_))))
                   (_%engine-append19851%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19841%_ '.append-source!)))
                   (_%engine-additions19853%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref
                       _%engine19841%_
                       '.source-additions)))
                   (_%engine-overrides19855%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref
                       _%engine19841%_
                       '.source-overrides))))
              (for-each
               (lambda (_%relation19858%_ _%index19859%_)
                 (let ((__tmp37745
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation19858%_ 'name)))
                       (__tmp37744 (+ _%index19859%_ '1)))
                   (declare (not safe))
                   (__hash-put! _%positions19796%_ __tmp37745 __tmp37744)))
               _%relations19745%_
               (let ((__tmp37746 (length _%relations19745%_)))
                 (declare (not safe))
                 (##iota __tmp37746)))
              (letrec* ((_%snapshot-copy19861%_
                         (lambda (_%rows20121%_)
                           (vector-map
                            (lambda (_%state20123%_)
                              (cons (car _%state20123%_) (cdr _%state20123%_)))
                            _%rows20121%_)))
                        (_%copy-append-row19862%_
                         (lambda (_%index20115%_ _%name20116%_ _%row20117%_)
                           (if (and (list? _%row20117%_)
                                    (= (let ()
                                         (declare (not safe))
                                         (##length _%row20117%_))
                                       (vector-ref
                                        (vector-ref _%engine-schema19845%_ '2)
                                        _%index20115%_)))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT session source row"
                                        _%name20116%_
                                        _%row20117%_)))
                           (map (lambda (_%value20119%_) _%value20119%_)
                                _%row20117%_)))
                        (_%engine-source-snapshot19863%_
                         (lambda ()
                           (list->vector
                            (let ((__tmp37749
                                   (lambda (_%index20111%_)
                                     (let ((_%replacement20113%_
                                            (vector-ref
                                             _%engine-overrides19855%_
                                             _%index20111%_)))
                                       (if _%replacement20113%_
                                           (cons _%replacement20113%_ '())
                                           (cons (vector-ref
                                                  _%engine-base-rows19849%_
                                                  _%index20111%_)
                                                 (vector-ref
                                                  _%engine-additions19853%_
                                                  _%index20111%_))))))
                                  (__tmp37747
                                   (let ((__tmp37748
                                          (length _%relations19745%_)))
                                     (declare (not safe))
                                     (##iota __tmp37748))))
                              (declare (not safe))
                              (##map __tmp37749 __tmp37747)))))
                        (_%position-of19864%_
                         (lambda (_%name20106%_)
                           (if (and _%single-relation-name19794%_
                                    (eq? _%name20106%_
                                         _%single-relation-name19794%_))
                               '0
                               (let ((_%slot20108%_
                                      (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%positions19796%_
                                         _%name20106%_))))
                                 (if _%slot20108%_
                                     '#!void
                                     (let ()
                                       (declare (not safe))
                                       (error '"unknown ASCENT relation"
                                              _%name20106%_)))
                                 (- _%slot20108%_ '1)))))
                        (_%prepare-source-cut19865%_
                         (lambda (_%rows20086%_)
                           (let* ((_%snapshot20088%_ _%source-snapshot19792%_)
                                  (_%logs20091%_ _%rows20086%_)
                                  (_%snapshot20095%_ _%snapshot20088%_))
                             (declare (not safe))
                             (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
                              _%snapshot20095%_
                              _%logs20091%_))))
                        (_%restore!19866%_
                         (lambda (_%rows20072%_)
                           (set! _%engine19841%_ '#f)
                           (let* ((_%cut20074%_
                                   (_%prepare-source-cut19865%_ _%rows20072%_))
                                  (_%candidate20076%_
                                   (##direct-structure-ref
                                    _%cut20074%_
                                    '2
                                    gerbil-ascent/program/source-snapshot#source-snapshot::t
                                    '#f))
                                  (_%fresh20078%_
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                      _%candidate20076%_
                                      '#t
                                      _%engine-analysis19843%_
                                      _%engine-schema19845%_
                                      _%measure-rule-times?19741%_)))
                                  (_%restored-result20080%_
                                   (if _%initialized?19829%_
                                       ((let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%fresh20078%_
                                           '.run)))
                                       '#f)))
                             (_%adopt-engine!19867%_
                              _%fresh20078%_
                              _%cut20074%_)
                             (set! _%pending19823%_
                                   (_%snapshot-copy19861%_ _%rows20072%_))
                             (set! _%partial?19833%_ '#f)
                             (set! _%clean?19831%_
                                   (if _%initialized?19829%_
                                       (equal? (vector->list _%rows20072%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector->list
                                                  _%committed19825%_)))
                                       '#f))
                             (set! _%replay-on-timeout?19835%_
                                   (if _%initialized?19829%_
                                       (not _%clean?19831%_)
                                       '#f))
                             (if _%clean?19831%_
                                 (set! _%last-result19839%_
                                       (let ((_%$e20083%_
                                              _%committed-result19827%_))
                                         (if _%$e20083%_
                                             _%$e20083%_
                                             _%restored-result20080%_)))
                                 '#!void))))
                        (_%adopt-engine!19867%_
                         (lambda (_%fresh20069%_ _%cut20070%_)
                           (set! _%source-snapshot19792%_ _%cut20070%_)
                           (set! _%engine19841%_ _%fresh20069%_)
                           (set! _%replay-on-timeout?19835%_ '#f)
                           (set! _%engine-append19851%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20069%_
                                    '.append-source!)))
                           (set! _%engine-additions19853%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20069%_
                                    '.source-additions)))
                           (set! _%engine-overrides19855%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20069%_
                                    '.source-overrides)))
                           (set! _%engine-base-rows19849%_
                                 (##direct-structure-ref
                                  _%cut20070%_
                                  '4
                                  gerbil-ascent/program/source-snapshot#source-snapshot::t
                                  '#f))))
                        (_%attempt19868%_
                         (lambda (_%thunk20064%_)
                           (let ((__tmp37751
                                  (lambda (_%failure20066%_)
                                    (vector '#f _%failure20066%_)))
                                 (__tmp37750
                                  (lambda () (vector '#t (_%thunk20064%_)))))
                             (declare (not safe))
                             (__with-catch __tmp37751 __tmp37750))))
                        (_%recover!19869%_
                         (lambda (_%rows20058%_ _%failure20059%_)
                           (let ((_%restored20062%_
                                  (_%attempt19868%_
                                   (lambda ()
                                     (_%restore!19866%_ _%rows20058%_)))))
                             (if (vector-ref _%restored20062%_ '0)
                                 '#!void
                                 (_%restore!19866%_ _%committed19825%_)))
                           (let ()
                             (declare (not safe))
                             (raise _%failure20059%_))))
                        (_%record-append!19870%_
                         (lambda (_%index20053%_ _%source-state20054%_)
                           (let ((_%replacement20056%_
                                  (vector-ref
                                   _%engine-overrides19855%_
                                   _%index20053%_)))
                             (if _%replacement20056%_
                                 (begin
                                   (set-car!
                                    _%source-state20054%_
                                    _%replacement20056%_)
                                   (set-cdr! _%source-state20054%_ '()))
                                 (set-cdr!
                                  _%source-state20054%_
                                  (vector-ref
                                   _%engine-additions19853%_
                                   _%index20053%_))))
                           (set! _%clean?19831%_ '#f)))
                        (_%check-idle!19871%_
                         (lambda ()
                           (if _%replacement-active?19837%_
                               (let ()
                                 (declare (not safe))
                                 (error '"ASCENT session operation during replacement validation"))
                               '#!void)))
                        (_%append-source!19872%_
                         (lambda (_%name20039%_ _%row20040%_)
                           (_%check-idle!19871%_)
                           (if _%partial?19833%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (let* ((_%index20042%_
                                   (_%position-of19864%_ _%name20039%_))
                                  (_%source-state20044%_
                                   (vector-ref
                                    _%pending19823%_
                                    _%index20042%_))
                                  (_%owned-row20046%_
                                   (_%copy-append-row19862%_
                                    _%index20042%_
                                    _%name20039%_
                                    _%row20040%_)))
                             (if (vector-ref
                                  _%atomic-appends19817%_
                                  _%index20042%_)
                                 (begin
                                   (_%engine-append19851%_
                                    _%name20039%_
                                    _%owned-row20046%_)
                                   (_%record-append!19870%_
                                    _%index20042%_
                                    _%source-state20044%_))
                                 (let ((__tmp37753
                                        (lambda (_%failure20049%_)
                                          (_%recover!19869%_
                                           _%pending19823%_
                                           _%failure20049%_)))
                                       (__tmp37752
                                        (lambda ()
                                          (_%engine-append19851%_
                                           _%name20039%_
                                           _%owned-row20046%_)
                                          (_%record-append!19870%_
                                           _%index20042%_
                                           _%source-state20044%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp37753 __tmp37752))))))
                        (_%direct-append-source!19873%_
                         (lambda (_%name20031%_ _%row20032%_)
                           (_%check-idle!19871%_)
                           (if _%partial?19833%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (let* ((_%index20034%_
                                   (_%position-of19864%_ _%name20031%_))
                                  (_%owned-row20036%_
                                   (_%copy-append-row19862%_
                                    _%index20034%_
                                    _%name20031%_
                                    _%row20032%_)))
                             (_%engine-append19851%_
                              _%name20031%_
                              _%owned-row20036%_))
                           (set! _%clean?19831%_ '#f)))
                        (_%replace-source!19874%_
                         (lambda (_%name20015%_ _%rows20016%_)
                           (_%check-idle!19871%_)
                           (if _%partial?19833%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (if (and _%initialized?19829%_
                                    _%clean?19831%_
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
                                       _%program19739%_)))
                               (let ((_%previous-committed20018%_
                                      _%committed19825%_)
                                     (_%previous-result20019%_
                                      _%committed-result19827%_))
                                 (_%replace-sources!__0__3772437725%_
                                  (list (cons _%name20015%_ _%rows20016%_)))
                                 (set! _%committed19825%_
                                       _%previous-committed20018%_)
                                 (set! _%committed-result19827%_
                                       _%previous-result20019%_)
                                 (set! _%last-result19839%_
                                       _%previous-result20019%_)
                                 (set! _%clean?19831%_ '#f)
                                 (set! _%replay-on-timeout?19835%_ '#t)
                                 '#!void)
                               (let* ((_%index20021%_
                                       (_%position-of19864%_ _%name20015%_))
                                      (_%source-state20023%_
                                       (vector-ref
                                        _%pending19823%_
                                        _%index20021%_))
                                      (_%owned-rows20025%_
                                       (_%copy-source-rows19743%_
                                        _%rows20016%_))
                                      (_%outcome20028%_
                                       (_%attempt19868%_
                                        (lambda ()
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19841%_
                                              '.replace-source!))
                                           _%name20015%_
                                           _%owned-rows20025%_)
                                          (vector-set!
                                           _%pending19823%_
                                           _%index20021%_
                                           (cons _%owned-rows20025%_ '()))))))
                                 (if (vector-ref _%outcome20028%_ '0)
                                     '#!void
                                     (begin
                                       (vector-set!
                                        _%pending19823%_
                                        _%index20021%_
                                        _%source-state20023%_)
                                       (_%recover!19869%_
                                        _%pending19823%_
                                        (vector-ref _%outcome20028%_ '1))))
                                 (set! _%clean?19831%_ '#f)
                                 (vector-ref _%outcome20028%_ '1)))))
                        (_%replace-sources!__3772237723%_
                         (lambda (_%replacements19996%_ _%accept-result19997%_)
                           (_%check-idle!19871%_)
                           (if (or (not _%accept-result19997%_)
                                   (procedure? _%accept-result19997%_))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT replacement acceptance procedure")))
                           (let ((__tmp37756
                                  (lambda ()
                                    (set! _%replacement-active?19837%_ '#t)))
                                 (__tmp37755
                                  (lambda ()
                                    (_%replace-sources/idle!19876%_
                                     _%replacements19996%_
                                     _%accept-result19997%_)))
                                 (__tmp37754
                                  (lambda ()
                                    (set! _%replacement-active?19837%_ '#f))))
                             (declare (not safe))
                             (##dynamic-wind
                              __tmp37756
                              __tmp37755
                              __tmp37754))))
                        (_%replace-sources!__0__3772437725%_
                         (lambda (_%replacements20008%_)
                           (let ((_%accept-result20010%_ '#f))
                             (_%replace-sources!__3772237723%_
                              _%replacements20008%_
                              _%accept-result20010%_))))
                        (_%replace-sources!19875%_
                         (lambda _g37757_
                           (let ((_g37758_
                                  (let ()
                                    (declare (not safe))
                                    (##length _g37757_))))
                             (cond ((let ()
                                      (declare (not safe))
                                      (##fx= _g37758_ 1))
                                    (apply _%replace-sources!__0__3772437725%_
                                           _g37757_))
                                   ((let ()
                                      (declare (not safe))
                                      (##fx= _g37758_ 2))
                                    (apply _%replace-sources!__3772237723%_
                                           _g37757_))
                                   (else
                                    (##raise-wrong-number-of-arguments-exception
                                     'case-lambda-dispatch
                                     _g37757_))))))
                        (_%replace-sources/idle!19876%_
                         (lambda (_%replacements19973%_ _%accept-result19974%_)
                           (if (and _%initialized?19829%_ _%clean?19831%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacement requires a completed clean session")))
                           (if (list? _%replacements19973%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacements must be a list"
                                        _%replacements19973%_)))
                           (if (null? _%replacements19973%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacement requires at least one source"))
                               '#!void)
                           (let ((_%prospective19976%_
                                  (_%snapshot-copy19861%_ _%committed19825%_))
                                 (_%seen19977%_
                                  (let ()
                                    (declare (not safe))
                                    (make-hash-table-eq))))
                             (for-each
                              (lambda (_%replacement19979%_)
                                (if (and (pair? _%replacement19979%_)
                                         (symbol? (let ()
                                                    (declare (not safe))
                                                    (##car _%replacement19979%_))))
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"invalid source replacement"
                                             _%replacement19979%_)))
                                (let* ((_%name19981%_
                                        (car _%replacement19979%_))
                                       (_%index19983%_
                                        (_%position-of19864%_ _%name19981%_)))
                                  (if (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%seen19977%_
                                         _%name19981%_))
                                      (let ()
                                        (declare (not safe))
                                        (error '"duplicate batch source"
                                               _%name19981%_))
                                      '#!void)
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%seen19977%_
                                     _%name19981%_
                                     '#t))
                                  (let ((__tmp37761 (cdr _%replacement19979%_))
                                        (__tmp37760
                                         (vector-ref
                                          (vector-ref
                                           _%engine-schema19845%_
                                           '2)
                                          _%index19983%_))
                                        (__tmp37759
                                         (vector-ref
                                          (vector-ref
                                           _%engine-schema19845%_
                                           '3)
                                          _%index19983%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
                                     _%name19981%_
                                     __tmp37761
                                     __tmp37760
                                     __tmp37759))
                                  (vector-set!
                                   _%prospective19976%_
                                   _%index19983%_
                                   (cons (_%copy-source-rows19743%_
                                          (cdr _%replacement19979%_))
                                         '()))))
                              _%replacements19973%_)
                             (let* ((_%cut19986%_
                                     (_%prepare-source-cut19865%_
                                      _%prospective19976%_))
                                    (_%candidate19988%_
                                     (##direct-structure-ref
                                      _%cut19986%_
                                      '2
                                      gerbil-ascent/program/source-snapshot#source-snapshot::t
                                      '#f))
                                    (_%fresh19990%_
                                     (let ((__tmp37762
                                            (if _%engine19841%_
                                                ((let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%engine19841%_
                                                    '.native-publication)))
                                                '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
                                        _%committed19825%_
                                        _%candidate19988%_
                                        _%committed-result19827%_
                                        _%engine-analysis19843%_
                                        _%engine-schema19845%_
                                        _%measure-rule-times?19741%_
                                        _%cut19986%_
                                        __tmp37762)))
                                    (_%result19992%_
                                     ((let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%fresh19990%_
                                         '.run)))))
                               (if (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%result19992%_
                                      'finished))
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"batch source replacement did not complete")))
                               (if (and _%accept-result19974%_
                                        (not (eq? '#t
                                                  (_%accept-result19974%_
                                                   _%result19992%_))))
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT replacement result was not accepted"))
                                   '#!void)
                               (_%adopt-engine!19867%_
                                _%fresh19990%_
                                _%cut19986%_)
                               (set! _%pending19823%_
                                     (_%snapshot-copy19861%_
                                      _%prospective19976%_))
                               (set! _%committed19825%_
                                     (_%snapshot-copy19861%_
                                      _%prospective19976%_))
                               (set! _%last-result19839%_ _%result19992%_)
                               (set! _%committed-result19827%_ _%result19992%_)
                               (set! _%clean?19831%_ '#t)
                               (set! _%partial?19833%_ '#f)
                               _%result19992%_))))
                        (_%run!19877%_
                         (lambda ()
                           (_%check-idle!19871%_)
                           (if _%clean?19831%_
                               _%last-result19839%_
                               (let* ((_%next-pending19967%_
                                       (if _%direct-appends?19821%_
                                           (_%engine-source-snapshot19863%_)
                                           _%pending19823%_))
                                      (_%outcome19970%_
                                       (_%attempt19868%_
                                        (lambda ()
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19841%_
                                              '.run)))))))
                                 (if (vector-ref _%outcome19970%_ '0)
                                     '#!void
                                     (_%recover!19869%_
                                      _%committed19825%_
                                      (vector-ref _%outcome19970%_ '1)))
                                 (set! _%initialized?19829%_ '#t)
                                 (set! _%pending19823%_ _%next-pending19967%_)
                                 (set! _%committed19825%_
                                       (_%snapshot-copy19861%_
                                        _%next-pending19967%_))
                                 (set! _%last-result19839%_
                                       (vector-ref _%outcome19970%_ '1))
                                 (set! _%committed-result19827%_
                                       _%last-result19839%_)
                                 (set! _%clean?19831%_ '#t)
                                 (set! _%partial?19833%_ '#f)
                                 (set! _%replay-on-timeout?19835%_ '#f)
                                 _%last-result19839%_))))
                        (_%run-timeout!19878%_
                         (lambda (_%duration-nanoseconds19946%_)
                           (_%check-idle!19871%_)
                           (if (and (exact-integer?
                                     _%duration-nanoseconds19946%_)
                                    (>= _%duration-nanoseconds19946%_ '0))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT timeout in nanoseconds"
                                        _%duration-nanoseconds19946%_)))
                           (if _%clean?19831%_
                               _%last-result19839%_
                               (let* ((_%next-pending19948%_
                                       (if _%direct-appends?19821%_
                                           (_%engine-source-snapshot19863%_)
                                           _%pending19823%_))
                                      (_%outcome19961%_
                                       (_%attempt19868%_
                                        (lambda ()
                                          (if (or _%replay-on-timeout?19835%_
                                                  ((let ()
                                                     (declare (not safe))
                                                     (clan/poo/object#.ref
                                                      _%engine19841%_
                                                      '.recomputed?))))
                                              (let* ((_%cut19954%_
                                                      (_%prepare-source-cut19865%_
                                                       _%next-pending19948%_))
                                                     (_%candidate19956%_
                                                      (##direct-structure-ref
                                                       _%cut19954%_
                                                       '2
                                                       gerbil-ascent/program/source-snapshot#source-snapshot::t
                                                       '#f))
                                                     (_%fresh19958%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                                         _%candidate19956%_
                                                         '#t
                                                         _%engine-analysis19843%_
                                                         _%engine-schema19845%_
                                                         _%measure-rule-times?19741%_))))
                                                (_%adopt-engine!19867%_
                                                 _%fresh19958%_
                                                 _%cut19954%_))
                                              '#!void)
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19841%_
                                              '.run-timeout))
                                           _%duration-nanoseconds19946%_)))))
                                 (if (vector-ref _%outcome19961%_ '0)
                                     '#!void
                                     (_%recover!19869%_
                                      _%committed19825%_
                                      (vector-ref _%outcome19961%_ '1)))
                                 (let ((_%result19964%_
                                        (vector-ref _%outcome19961%_ '1)))
                                   (set! _%last-result19839%_ _%result19964%_)
                                   (set! _%pending19823%_
                                         _%next-pending19948%_)
                                   (if (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%result19964%_
                                          'finished))
                                       (begin
                                         (set! _%initialized?19829%_ '#t)
                                         (set! _%committed19825%_
                                               (_%snapshot-copy19861%_
                                                _%next-pending19948%_))
                                         (set! _%committed-result19827%_
                                               _%result19964%_)
                                         (set! _%clean?19831%_ '#t)
                                         (set! _%partial?19833%_ '#f))
                                       (set! _%partial?19833%_ '#t))
                                   _%result19964%_))))))
                (let ((__tmp37763
                       (let ((__obj37728
                              (let ()
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#object::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp37765
                                (list (cons '.append-source!
                                            (let ((__tmp37766
                                                   (lambda (_%@19920%_)
                                                     (if _%direct-appends?19821%_
                                                         _%direct-append-source!19873%_
                                                         _%append-source!19872%_))))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37766)))
                                      (cons '.replace-source!
                                            (let ((__tmp37767
                                                   (lambda (_%@19926%_)
                                                     _%replace-source!19874%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37767)))
                                      (cons '.replace-sources!
                                            (let ((__tmp37768
                                                   (lambda (_%@19931%_)
                                                     _%replace-sources!19875%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37768)))
                                      (cons '.run
                                            (let ((__tmp37769
                                                   (lambda (_%@19936%_)
                                                     _%run!19877%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37769)))
                                      (cons '.run-timeout
                                            (let ((__tmp37770
                                                   (lambda (_%@19941%_)
                                                     _%run-timeout!19878%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37770)))))
                               (__tmp37764 (list)))
                           (declare (not safe))
                           (clan/poo/object#object:::init!__%
                            '#f
                            gerbil-ascent/program/session#Session.
                            __tmp37765
                            __tmp37764
                            __obj37728))
                         __obj37728)))
                  (declare (not safe))
                  (clan/poo/mop#validate
                   gerbil-ascent/program/types#GerbilAscentSessionContract
                   __tmp37763))))))))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session__@
      (lambda (_%@@keywords20132%_ . _%args20133%_)
        (apply gerbil-ascent/program/session#gerbil-ascent-open-session__%
               _%@@keywords20132%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords20132%_
                  'measure-rule-times?:
                  absent-value))
               _%args20133%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session
      (lambda _%$%args1973520139%_
        (apply keyword-dispatch
               '#(measure-rule-times?:)
               gerbil-ascent/program/session#gerbil-ascent-open-session__@
               _%$%args1973520139%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-append-source!
      (lambda (_%session19729%_ _%name19730%_ _%row19731%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19729%_ '.append-source!))
         _%name19730%_
         _%row19731%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-source!
      (lambda (_%session19725%_ _%name19726%_ _%rows19727%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19725%_ '.replace-source!))
         _%name19726%_
         _%rows19727%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
      (lambda (_%session19709%_ _%replacements19710%_ _%accept-result19711%_)
        (if _%accept-result19711%_
            ((let ()
               (declare (not safe))
               (clan/poo/object#.ref _%session19709%_ '.replace-sources!))
             _%replacements19710%_
             _%accept-result19711%_)
            ((let ()
               (declare (not safe))
               (clan/poo/object#.ref _%session19709%_ '.replace-sources!))
             _%replacements19710%_))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
      (lambda (_%session19716%_ _%replacements19717%_)
        (let ((_%accept-result19719%_ '#f))
          (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
           _%session19716%_
           _%replacements19717%_
           _%accept-result19719%_))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!
      (lambda _g37771_
        (let ((_g37772_ (let () (declare (not safe)) (##length _g37771_))))
          (cond ((let () (declare (not safe)) (##fx= _g37772_ 2))
                 (apply gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                        _g37771_))
                ((let () (declare (not safe)) (##fx= _g37772_ 3))
                 (apply gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
                        _g37771_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!
                  _g37771_))))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-run
      (lambda (_%session19706%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19706%_ '.run)))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-run-timeout
      (lambda (_%session19703%_ _%duration-nanoseconds19704%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19703%_ '.run-timeout))
         _%duration-nanoseconds19704%_)))))
