(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/core/relation-view")
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "core/types")
    (load-module "gerbil-ascent/table/eqrel")
    (load-module "gerbil-ascent/table/trrel")
    (load-module "gerbil-ascent/table/trrel-uf"))
  (load-module "gerbil-ascent/table/storage~0"))
