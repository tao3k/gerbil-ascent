(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/reuse[1]#_g37399_|
    (##structure
     gx#syntax-quote::t
     'native-reuse::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37401_|
    (##structure
     gx#syntax-quote::t
     'make-native-reuse
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37403_|
    (##structure
     gx#syntax-quote::t
     'native-reuse?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37405_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37406_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37407_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37408_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37409_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37411_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37412_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37413_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37414_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37415_|
    (##structure
     gx#syntax-quote::t
     'native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37417_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37418_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37419_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37420_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37421_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37423_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-result-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37424_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-affected-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37425_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-reader-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37426_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-publication-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37427_|
    (##structure
     gx#syntax-quote::t
     '&native-reuse-source-only-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37429_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37431_|
    (##structure
     gx#syntax-quote::t
     'make-closure-seed-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37433_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37435_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37436_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37437_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37438_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37439_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37440_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37442_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37443_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37444_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37445_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37446_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37447_|
    (##structure
     gx#syntax-quote::t
     'closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37449_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37450_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37451_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37452_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37453_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37454_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37456_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37457_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-seen-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37458_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37459_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-all-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37460_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-delta-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/reuse[1]#_g37461_|
    (##structure
     gx#syntax-quote::t
     '&closure-seed-state-lattice-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/reuse[:0:]#native-reuse|
      (let ((__obj37379
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37379
           'gerbil-ascent/program/reuse#native-reuse::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 'native-reuse '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37379
           '(result affected reader publication source-only)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37379
           '(result affected reader publication source-only)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '#f '13 '#f '#f))
        (let ((__tmp37398 |gerbil-ascent/program/reuse[1]#_g37399_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37398 '4 '#f '#f))
        (let ((__tmp37400 |gerbil-ascent/program/reuse[1]#_g37401_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37400 '14 '#f '#f))
        (let ((__tmp37402 |gerbil-ascent/program/reuse[1]#_g37403_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37402 '15 '#f '#f))
        (let ((__tmp37404
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37405_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37406_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37407_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37408_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37409_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37404 '16 '#f '#f))
        (let ((__tmp37410
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37411_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37412_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37413_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37414_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37415_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37410 '17 '#f '#f))
        (let ((__tmp37416
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37417_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37418_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37419_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37420_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37421_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37416 '18 '#f '#f))
        (let ((__tmp37422
               (cons (cons 'result |gerbil-ascent/program/reuse[1]#_g37423_|)
                     (cons (cons 'affected
                                 |gerbil-ascent/program/reuse[1]#_g37424_|)
                           (cons (cons 'reader
                                       |gerbil-ascent/program/reuse[1]#_g37425_|)
                                 (cons (cons 'publication
                                             |gerbil-ascent/program/reuse[1]#_g37426_|)
                                       (cons (cons 'source-only
                                                   |gerbil-ascent/program/reuse[1]#_g37427_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 __tmp37422 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37379 '() '21 '#f '#f))
        __obj37379))
    (define |gerbil-ascent/program/reuse[:0:]#closure-seed-state|
      (let ((__obj37380
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37380
           'gerbil-ascent/program/reuse#closure-seed-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37380
           'closure-seed-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37380
           '(all seen delta all-size delta-size lattice-rows)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37380
           '(all seen delta all-size delta-size lattice-rows)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '#f '13 '#f '#f))
        (let ((__tmp37428 |gerbil-ascent/program/reuse[1]#_g37429_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37428 '4 '#f '#f))
        (let ((__tmp37430 |gerbil-ascent/program/reuse[1]#_g37431_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37430 '14 '#f '#f))
        (let ((__tmp37432 |gerbil-ascent/program/reuse[1]#_g37433_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37432 '15 '#f '#f))
        (let ((__tmp37434
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37435_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37436_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37437_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37438_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37439_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37440_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37434 '16 '#f '#f))
        (let ((__tmp37441
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37442_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37443_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37444_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37445_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37446_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37447_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37441 '17 '#f '#f))
        (let ((__tmp37448
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37449_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37450_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37451_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37452_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37453_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37454_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37448 '18 '#f '#f))
        (let ((__tmp37455
               (cons (cons 'all |gerbil-ascent/program/reuse[1]#_g37456_|)
                     (cons (cons 'seen
                                 |gerbil-ascent/program/reuse[1]#_g37457_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/reuse[1]#_g37458_|)
                                 (cons (cons 'all-size
                                             |gerbil-ascent/program/reuse[1]#_g37459_|)
                                       (cons (cons 'delta-size
                                                   |gerbil-ascent/program/reuse[1]#_g37460_|)
                                             (cons (cons 'lattice-rows
                                                         |gerbil-ascent/program/reuse[1]#_g37461_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 __tmp37455 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37380 '() '21 '#f '#f))
        __obj37380))))
