#ifdef ___LINKER_INFO
; File: "gerbil-ascent__candidate__program-identity.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__candidate__program-identity"
("gerbil-ascent__candidate__program-identity")
()
(("gerbil-ascent__candidate__program-identity"))
( #|*/"*/"symbols|#
"bytes"
"fxmax"
"gerbil-ascent/candidate/program-identity"
"gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint"
"gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint"
"gerbil-ascent/candidate/program-identity#datum-fingerprint"
"gerbil-ascent/candidate/program-identity#entry-datum"
"gerbil-ascent/candidate/program-identity#program-shape"
"gerbil-ascent__candidate__program-identity"
"gerbil-ascent__candidate__program-identity#"
"in-range-inclusive?"
"in-range?"
"positive-program-v1"
"start"
"u8vector-length"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
"context"
"contract"
"value"
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/candidate/program-identity#datum-fingerprint"
"gerbil-ascent/candidate/program-identity#entry-datum"
"gerbil-ascent/candidate/program-identity#program-shape"
"gerbil-ascent__candidate__program-identity#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint"
"gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint"
"gerbil-ascent/candidate/program-identity::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##string->utf8"
"##structure-ref"
"call-with-output-string"
"gerbil-ascent/candidate/types#reasoning-candidate::t"
"map"
"raise-contract-violation-error"
"std/crypto/digest#__sha256"
"std/encoding/hex#__hex-encode__%"
"vector-ref"
"write"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__candidate__program-identity"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____candidate____program_2d_identity
#define ___MH_PROC ___H_gerbil_2d_ascent____candidate____program_2d_identity
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 15
#define ___KEYCOUNT 3
#define ___GLOCOUNT 18
#define ___SUPCOUNT 7
#define ___CNSCOUNT 13
#define ___SUBCOUNT 7
#define ___LBLCOUNT 55
#define ___MODDESCR ___REF_SUB(4)
#include "gambit.h"

___NEED_SYM(___S_bytes)
___NEED_SYM(___S_fxmax)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___NEED_SYM(___S_gerbil_2d_ascent____candidate____program_2d_identity)
___NEED_SYM(___S_gerbil_2d_ascent____candidate____program_2d_identity_23_)
___NEED_SYM(___S_in_2d_range_2d_inclusive_3f_)
___NEED_SYM(___S_in_2d_range_3f_)
___NEED_SYM(___S_positive_2d_program_2d_v1)
___NEED_SYM(___S_start)
___NEED_SYM(___S_u8vector_2d_length)

___NEED_KEY(___K_context)
___NEED_KEY(___K_contract)
___NEED_KEY(___K_value)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_string_2d__3e_utf8)
___NEED_GLO(___G__23__23_structure_2d_ref)
___NEED_GLO(___G_call_2d_with_2d_output_2d_string)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent____candidate____program_2d_identity_23_)
___NEED_GLO(___G_map)
___NEED_GLO(___G_raise_2d_contract_2d_violation_2d_error)
___NEED_GLO(___G_std_2f_crypto_2f_digest_23_____sha256)
___NEED_GLO(___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
___NEED_GLO(___G_vector_2d_ref)
___NEED_GLO(___G_write)

___BEGIN_SYM
___DEF_SYM(0,___S_bytes,"bytes")
___DEF_SYM(1,___S_fxmax,"fxmax")
___DEF_SYM(2,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity,"gerbil-ascent/candidate/program-identity")

___DEF_SYM(3,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,"gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint")

___DEF_SYM(4,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,"gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint")

___DEF_SYM(5,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,"gerbil-ascent/candidate/program-identity#datum-fingerprint")

___DEF_SYM(6,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,"gerbil-ascent/candidate/program-identity#entry-datum")

___DEF_SYM(7,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,"gerbil-ascent/candidate/program-identity#program-shape")

___DEF_SYM(8,___S_gerbil_2d_ascent____candidate____program_2d_identity,"gerbil-ascent__candidate__program-identity")

___DEF_SYM(9,___S_gerbil_2d_ascent____candidate____program_2d_identity_23_,"gerbil-ascent__candidate__program-identity#")

___DEF_SYM(10,___S_in_2d_range_2d_inclusive_3f_,"in-range-inclusive?")
___DEF_SYM(11,___S_in_2d_range_3f_,"in-range?")
___DEF_SYM(12,___S_positive_2d_program_2d_v1,"positive-program-v1")
___DEF_SYM(13,___S_start,"start")
___DEF_SYM(14,___S_u8vector_2d_length,"u8vector-length")
___END_SYM

#define ___SYM_bytes ___SYM(0,___S_bytes)
#define ___SYM_fxmax ___SYM(1,___S_fxmax)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity ___SYM(2,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint ___SYM(3,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint ___SYM(4,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint ___SYM(5,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum ___SYM(6,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape ___SYM(7,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
#define ___SYM_gerbil_2d_ascent____candidate____program_2d_identity ___SYM(8,___S_gerbil_2d_ascent____candidate____program_2d_identity)
#define ___SYM_gerbil_2d_ascent____candidate____program_2d_identity_23_ ___SYM(9,___S_gerbil_2d_ascent____candidate____program_2d_identity_23_)
#define ___SYM_in_2d_range_2d_inclusive_3f_ ___SYM(10,___S_in_2d_range_2d_inclusive_3f_)
#define ___SYM_in_2d_range_3f_ ___SYM(11,___S_in_2d_range_3f_)
#define ___SYM_positive_2d_program_2d_v1 ___SYM(12,___S_positive_2d_program_2d_v1)
#define ___SYM_start ___SYM(13,___S_start)
#define ___SYM_u8vector_2d_length ___SYM(14,___S_u8vector_2d_length)

___BEGIN_KEY
___DEF_KEY(0,___K_context,"context")
___DEF_KEY(1,___K_contract,"contract")
___DEF_KEY(2,___K_value,"value")
___END_KEY

#define ___KEY_context ___KEY(0,___K_context)
#define ___KEY_contract ___KEY(1,___K_contract)
#define ___KEY_value ___KEY(2,___K_value)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint")

___DEF_GLO(1,"gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint")

___DEF_GLO(2,"gerbil-ascent/candidate/program-identity#datum-fingerprint")

___DEF_GLO(3,"gerbil-ascent/candidate/program-identity#entry-datum")

___DEF_GLO(4,"gerbil-ascent/candidate/program-identity#program-shape")

___DEF_GLO(5,"gerbil-ascent/candidate/program-identity::timestamp")

___DEF_GLO(6,"gerbil-ascent__candidate__program-identity#")

___DEF_GLO(7,"##dead-end")
___DEF_GLO(8,"##string->utf8")
___DEF_GLO(9,"##structure-ref")
___DEF_GLO(10,"call-with-output-string")
___DEF_GLO(11,"gerbil-ascent/candidate/types#reasoning-candidate::t")

___DEF_GLO(12,"map")
___DEF_GLO(13,"raise-contract-violation-error")
___DEF_GLO(14,"std/crypto/digest#__sha256")
___DEF_GLO(15,"std/encoding/hex#__hex-encode__%")
___DEF_GLO(16,"vector-ref")
___DEF_GLO(17,"write")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint ___GLO(0,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint ___PRM(0,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint ___GLO(1,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint ___PRM(1,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint ___GLO(2,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint ___PRM(2,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum ___GLO(3,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum ___PRM(3,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape ___GLO(4,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape ___PRM(4,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp ___GLO(5,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp ___PRM(5,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____candidate____program_2d_identity_23_ ___GLO(6,___G_gerbil_2d_ascent____candidate____program_2d_identity_23_)
#define ___PRM_gerbil_2d_ascent____candidate____program_2d_identity_23_ ___PRM(6,___G_gerbil_2d_ascent____candidate____program_2d_identity_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(7,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(7,___G__23__23_dead_2d_end)
#define ___GLO__23__23_string_2d__3e_utf8 ___GLO(8,___G__23__23_string_2d__3e_utf8)
#define ___PRM__23__23_string_2d__3e_utf8 ___PRM(8,___G__23__23_string_2d__3e_utf8)
#define ___GLO__23__23_structure_2d_ref ___GLO(9,___G__23__23_structure_2d_ref)
#define ___PRM__23__23_structure_2d_ref ___PRM(9,___G__23__23_structure_2d_ref)
#define ___GLO_call_2d_with_2d_output_2d_string ___GLO(10,___G_call_2d_with_2d_output_2d_string)
#define ___PRM_call_2d_with_2d_output_2d_string ___PRM(10,___G_call_2d_with_2d_output_2d_string)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t ___GLO(11,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t ___PRM(11,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
#define ___GLO_map ___GLO(12,___G_map)
#define ___PRM_map ___PRM(12,___G_map)
#define ___GLO_raise_2d_contract_2d_violation_2d_error ___GLO(13,___G_raise_2d_contract_2d_violation_2d_error)
#define ___PRM_raise_2d_contract_2d_violation_2d_error ___PRM(13,___G_raise_2d_contract_2d_violation_2d_error)
#define ___GLO_std_2f_crypto_2f_digest_23_____sha256 ___GLO(14,___G_std_2f_crypto_2f_digest_23_____sha256)
#define ___PRM_std_2f_crypto_2f_digest_23_____sha256 ___PRM(14,___G_std_2f_crypto_2f_digest_23_____sha256)
#define ___GLO_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_ ___GLO(15,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
#define ___PRM_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_ ___PRM(15,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
#define ___GLO_vector_2d_ref ___GLO(16,___G_vector_2d_ref)
#define ___PRM_vector_2d_ref ___PRM(16,___G_vector_2d_ref)
#define ___GLO_write ___GLO(17,___G_write)
#define ___PRM_write ___PRM(17,___G_write)

___BEGIN_CNS
 ___DEF_CNS(___REF_SYM(10,___S_in_2d_range_2d_inclusive_3f_),___REF_CNS(1))
,___DEF_CNS(___REF_SYM(13,___S_start),___REF_CNS(2))
,___DEF_CNS(___REF_CNS(3),___REF_NUL)
,___DEF_CNS(___REF_SYM(14,___S_u8vector_2d_length),___REF_CNS(4))
,___DEF_CNS(___REF_SYM(0,___S_bytes),___REF_NUL)
,___DEF_CNS(___REF_SYM(11,___S_in_2d_range_3f_),___REF_CNS(6))
,___DEF_CNS(___REF_FIX(0),___REF_CNS(7))
,___DEF_CNS(___REF_CNS(8),___REF_NUL)
,___DEF_CNS(___REF_SYM(1,___S_fxmax),___REF_CNS(9))
,___DEF_CNS(___REF_CNS(10),___REF_CNS(12))
,___DEF_CNS(___REF_SYM(14,___S_u8vector_2d_length),___REF_CNS(11))
,___DEF_CNS(___REF_SYM(0,___S_bytes),___REF_NUL)
,___DEF_CNS(___REF_FIX(1),___REF_NUL)
___END_CNS

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08feL)
___DEF_SUB_STR(___X1,0UL)
               ___STR0
___DEF_SUB_STR(___X2,18UL)
               ___STR8(99,111,110,116,114,97,99,116)
               ___STR8(32,118,105,111,108,97,116,105)
               ___STR2(111,110)
___DEF_SUB_STR(___X3,18UL)
               ___STR8(99,111,110,116,114,97,99,116)
               ___STR8(32,118,105,111,108,97,116,105)
               ___STR2(111,110)
___DEF_SUB_VEC(___X4,6UL)
               ___VEC1(___REF_SUB(5))
               ___VEC1(___REF_SUB(6))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X5,1UL)
               ___VEC1(___REF_SYM(8,___S_gerbil_2d_ascent____candidate____program_2d_identity))
               ___VEC0
___DEF_SUB_VEC(___X6,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
,___DEF_SUB(___X5)
,___DEF_SUB(___X6)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____candidate____program_2d_identity_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L22_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L23_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL(___L24_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____candidate____program_2d_identity_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____candidate____program_2d_identity_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____candidate____program_2d_identity_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____candidate____program_2d_identity_23_)
   ___SET_GLO(5,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_3a__3a_timestamp,___BIGFIX(0,1791691006LL))
   ___SET_R1(___VOID)
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum
#undef ___PH_LBL0
#define ___PH_LBL0 3
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(0L))))
   ___GOTO(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
   ___SET_R2(___VECTORREF(___R1,___FIX(0L)))
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(1L))))
   ___GOTO(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
   ___SET_R3(___VECTORREF(___R1,___FIX(1L)))
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
   ___IF(___VECTORINBOUNDSP(___R1,___FIX(2L)))
   ___GOTO(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___END_IF
___DEF_GLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R2)
   ___SET_STK(3,___R3)
   ___SET_R2(___FIX(2L))
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_R0(___LBL(1))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_R1(___VECTORREF(___R1,___FIX(2L)))
   ___BEGIN_ALLOC_LIST(3UL,___R1)
   ___ADD_LIST_ELEM(1,___R3)
   ___ADD_LIST_ELEM(2,___R2)
   ___END_ALLOC_LIST(3)
   ___SET_R1(___GET_LIST(3))
   ___CHECK_HEAP(2,4096)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___JUMPRET(___R0)
___DEF_GLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R2(___FIX(1L))
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_GLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___FIX(0L))
   ___SET_R0(___LBL(3))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape
#undef ___PH_LBL0
#define ___PH_LBL0 8
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L22_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L23_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_P_HLBL(___L24_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(9,___R1)
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___FIX(1L))
   ___SET_R0(___LBL(1))
   ___ADJFP(9)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(-5,___R1)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___FIX(2L))
   ___SET_R0(___LBL(2))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L35_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R0(___LBL(15))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___CDR(___R2))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L25_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L31_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___POLL(5)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L30_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R0(___LBL(7))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(13))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L27_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___GOTO(___L30_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___CDR(___R2))
   ___POLL(8)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___PAIRP(___R2))
   ___GOTO(___L28_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___IF(___NOT(___NULLP(___R2)))
   ___GOTO(___L31_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L32_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R1(___NUL)
   ___JUMPRET(___R0)
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___POLL(10)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(-5,___R1)
   ___SET_R1(___CDR(___STK(-6)))
   ___SET_R0(___LBL(13))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L30_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CAR(___R1))
   ___ADJFP(8)
   ___POLL(12)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R0(___LBL(11))
   ___JUMPINT(___SET_NARGS(1),___PRC(3),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R1(___CONS(___STK(-5),___R1))
   ___ADJFP(-7)
   ___CHECK_HEAP(14,4096)
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(-4,___R1)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___FIX(3L))
   ___SET_R0(___LBL(16))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___NOT(___PROCEDUREP(___PRC(3))))
   ___GOTO(___L34_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R0(___LBL(18))
   ___POLL(17)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___GOTO(___L29_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_STK(-3,___R1)
   ___SET_STK(1,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___FIX(4L))
   ___SET_R0(___LBL(19))
   ___ADJFP(1)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___IF(___NOT(___VECTORP(___R1)))
   ___GOTO(___L33_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___IF(___NOT(___VECTORINBOUNDSP(___R1,___FIX(0L))))
   ___GOTO(___L33_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___END_IF
   ___SET_R1(___VECTORREF(___R1,___FIX(0L)))
   ___SET_STK(-2,___R1)
   ___SET_STK(5,___STK(-6))
   ___SET_R3(___FAL)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___FIX(5L))
   ___SET_R0(___LBL(20))
   ___ADJFP(5)
   ___JUMPPRM(___SET_NARGS(4),___PRM__23__23_structure_2d_ref)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___BEGIN_ALLOC_LIST(5UL,___R1)
   ___ADD_LIST_ELEM(1,___STK(-6))
   ___ADD_LIST_ELEM(2,___STK(-7))
   ___ADD_LIST_ELEM(3,___STK(-8))
   ___ADD_LIST_ELEM(4,___STK(-9))
   ___END_ALLOC_LIST(5)
   ___SET_R1(___GET_LIST(5))
   ___ADJFP(-11)
   ___CHECK_HEAP(21,4096)
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___ADJFP(-1)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___FIX(0L))
   ___SET_R0(___LBL(22))
   ___JUMPPRM(___SET_NARGS(2),___PRM_vector_2d_ref)
___DEF_SLBL(22,___L22_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R0(___LBL(22))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(23))
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(23,___L23_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R0(___LBL(23))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R2(___R1)
   ___SET_R1(___PRC(3))
   ___SET_R0(___LBL(24))
   ___JUMPPRM(___SET_NARGS(2),___PRM_map)
___DEF_SLBL(24,___L24_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
   ___SET_R0(___LBL(24))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint
#undef ___PH_LBL0
#define ___PH_LBL0 34
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(2),8)
   ___ADD_CLO_ELEM(0,___R1)
   ___END_SETUP_CLO(1)
   ___SET_R2(___STK(2))
   ___SET_R1(___SUB(1))
   ___ADJFP(4)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_R0(___LBL(3))
   ___JUMPGLOSAFE(___SET_NARGS(2),10,___G_call_2d_with_2d_output_2d_string)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_R0(___LBL(4))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_string_2d__3e_utf8)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),14,___G_std_2f_crypto_2f_digest_23_____sha256)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_R2(___U8VECTORLENGTH(___R1))
   ___SET_R3(___U8VECTORLENGTH(___R1))
   ___SET_R3(___FIXMAX(___R3,___FIX(1L)))
   ___IF(___NOT(___FIXLT(___FIX(0L),___R3)))
   ___GOTO(___L11_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___END_IF
   ___SET_R3(___U8VECTORLENGTH(___R1))
   ___IF(___NOT(___AND(___FIXLE(___FIX(0L),___R2),___FIXLE(___R2,___R3))))
   ___GOTO(___L10_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___END_IF
   ___SET_R3(___R2)
   ___SET_R2(___FIX(0L))
   ___SET_R0(___STK(-3))
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),15,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
___DEF_GLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_STK(1,___SUB(2))
   ___SET_STK(2,___KEY_context)
   ___SET_STK(3,___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity)
   ___SET_STK(4,___KEY_contract)
   ___SET_R3(___R2)
   ___SET_R2(___KEY_value)
   ___SET_R1(___CNS(0))
   ___SET_R0(___LBL(7))
   ___ADJFP(4)
   ___JUMPGLOSAFE(___SET_NARGS(7),13,___G_raise_2d_contract_2d_violation_2d_error)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_R1(___VOID)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___SET_STK(1,___SUB(3))
   ___SET_STK(2,___KEY_context)
   ___SET_STK(3,___SYM_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity)
   ___SET_STK(4,___KEY_contract)
   ___SET_R3(___FIX(0L))
   ___SET_R2(___KEY_value)
   ___SET_R1(___CNS(5))
   ___SET_R0(___LBL(7))
   ___ADJFP(4)
   ___JUMPGLOSAFE(___SET_NARGS(7),13,___G_raise_2d_contract_2d_violation_2d_error)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(8,1,0,0)
   ___SET_R2(___R1)
   ___SET_R1(___CLO(___R4,1))
   ___POLL(9)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
   ___JUMPPRM(___SET_NARGS(2),___PRM_write)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint
#undef ___PH_LBL0
#define ___PH_LBL0 45
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
   ___SET_STK(1,___R0)
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
   ___SET_R0(___LBL(2))
   ___JUMPINT(___SET_NARGS(1),___PRC(8),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
   ___SET_R0(___STK(-3))
   ___POLL(3)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(34),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint
#undef ___PH_LBL0
#define ___PH_LBL0 50
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___SET_STK(1,___R0)
   ___ADJFP(4)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___SET_R0(___LBL(2))
   ___JUMPINT(___SET_NARGS(1),___PRC(8),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___SET_R1(___CONS(___SYM_positive_2d_program_2d_v1,___R1))
   ___SET_R0(___STK(-3))
   ___CHECK_HEAP(3,4096)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint)
   ___ADJFP(-4)
   ___JUMPINT(___SET_NARGS(1),___PRC(34),___L_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____candidate____program_2d_identity_23_,___REF_SYM(9,___S_gerbil_2d_ascent____candidate____program_2d_identity_23_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____candidate____program_2d_identity_23_,0,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,___REF_SYM(6,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum),___REF_FAL,4,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___REF_SYM(7,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape),___REF_FAL,25,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,8,0,0x3f03L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,8,0,0x3f0fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,9,0,0x3dL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETI,1,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___REF_SYM(5,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint),___REF_FAL,10,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,1,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,___REF_SYM(3,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint),___REF_FAL,4,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,___REF_SYM(4,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint),___REF_FAL,5,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,___IFD(___RETI,4,4,0x3f0L))
___END_LBL

___BEGIN_MOD_PRM
___DEF_MOD_PRM(6,___G_gerbil_2d_ascent____candidate____program_2d_identity_23_,1)
___DEF_MOD_PRM(3,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,3)
___DEF_MOD_PRM(4,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,8)
___DEF_MOD_PRM(2,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,34)
___DEF_MOD_PRM(0,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,45)
___DEF_MOD_PRM(1,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,50)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(6,___G_gerbil_2d_ascent____candidate____program_2d_identity_23_,1)
___DEF_MOD_GLO(3,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,3)
___DEF_MOD_GLO(4,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,8)
___DEF_MOD_GLO(2,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,34)
___DEF_MOD_GLO(0,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,45)
___DEF_MOD_GLO(1,___G_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,50)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_bytes,"bytes")
___DEF_MOD_SYM(1,___S_fxmax,"fxmax")
___DEF_MOD_SYM(2,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity,"gerbil-ascent/candidate/program-identity")

___DEF_MOD_SYM(3,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_finite_2d_program_2d_fingerprint,"gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint")

___DEF_MOD_SYM(4,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_candidate_2d_positive_2d_program_2d_fingerprint,"gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint")

___DEF_MOD_SYM(5,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_datum_2d_fingerprint,"gerbil-ascent/candidate/program-identity#datum-fingerprint")

___DEF_MOD_SYM(6,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_entry_2d_datum,"gerbil-ascent/candidate/program-identity#entry-datum")

___DEF_MOD_SYM(7,___S_gerbil_2d_ascent_2f_candidate_2f_program_2d_identity_23_program_2d_shape,"gerbil-ascent/candidate/program-identity#program-shape")

___DEF_MOD_SYM(8,___S_gerbil_2d_ascent____candidate____program_2d_identity,"gerbil-ascent__candidate__program-identity")

___DEF_MOD_SYM(9,___S_gerbil_2d_ascent____candidate____program_2d_identity_23_,"gerbil-ascent__candidate__program-identity#")

___DEF_MOD_SYM(10,___S_in_2d_range_2d_inclusive_3f_,"in-range-inclusive?")
___DEF_MOD_SYM(11,___S_in_2d_range_3f_,"in-range?")
___DEF_MOD_SYM(12,___S_positive_2d_program_2d_v1,"positive-program-v1")
___DEF_MOD_SYM(13,___S_start,"start")
___DEF_MOD_SYM(14,___S_u8vector_2d_length,"u8vector-length")
___DEF_MOD_KEY(0,___K_context,"context")
___DEF_MOD_KEY(1,___K_contract,"contract")
___DEF_MOD_KEY(2,___K_value,"value")
___END_MOD_SYM_KEY

#endif
