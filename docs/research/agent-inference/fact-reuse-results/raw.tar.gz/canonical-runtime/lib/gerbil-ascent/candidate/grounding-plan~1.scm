(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37602_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37604_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-rule
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37606_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37608_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37609_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37610_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37611_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37613_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37614_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37615_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37616_|
    (##structure
     gx#syntax-quote::t
     'grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37618_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37619_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37620_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37621_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37623_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-name-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37624_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-head-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37625_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-body-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37626_|
    (##structure
     gx#syntax-quote::t
     '&grounding-rule-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37628_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37630_|
    (##structure
     gx#syntax-quote::t
     'make-grounding-clause
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37632_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37634_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37635_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37637_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37638_|
    (##structure
     gx#syntax-quote::t
     'grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37640_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37641_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37643_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/grounding-plan[1]#_g37644_|
    (##structure
     gx#syntax-quote::t
     '&grounding-clause-apply-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-rule|
      (let ((__obj37575
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37575
           'gerbil-ascent/candidate/grounding-plan#grounding-rule::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 'grounding-rule '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37575
           '(name head body label)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37575
           '(name head body label)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '#f '13 '#f '#f))
        (let ((__tmp37601
               |gerbil-ascent/candidate/grounding-plan[1]#_g37602_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37601 '4 '#f '#f))
        (let ((__tmp37603
               |gerbil-ascent/candidate/grounding-plan[1]#_g37604_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37603 '14 '#f '#f))
        (let ((__tmp37605
               |gerbil-ascent/candidate/grounding-plan[1]#_g37606_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37605 '15 '#f '#f))
        (let ((__tmp37607
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37608_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37609_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37610_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37611_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37607 '16 '#f '#f))
        (let ((__tmp37612
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37613_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37614_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37615_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37616_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37612 '17 '#f '#f))
        (let ((__tmp37617
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37618_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37619_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37620_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37621_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37617 '18 '#f '#f))
        (let ((__tmp37622
               (cons (cons 'name
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37623_|)
                     (cons (cons 'head
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37624_|)
                           (cons (cons 'body
                                       |gerbil-ascent/candidate/grounding-plan[1]#_g37625_|)
                                 (cons (cons 'label
                                             |gerbil-ascent/candidate/grounding-plan[1]#_g37626_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 __tmp37622 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37575 '() '21 '#f '#f))
        __obj37575))
    (define |gerbil-ascent/candidate/grounding-plan[:0:]#grounding-clause|
      (let ((__obj37576
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37576
           'gerbil-ascent/candidate/grounding-plan#grounding-clause::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 'grounding-clause '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '(relation apply) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '(relation apply) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '#f '13 '#f '#f))
        (let ((__tmp37627
               |gerbil-ascent/candidate/grounding-plan[1]#_g37628_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37627 '4 '#f '#f))
        (let ((__tmp37629
               |gerbil-ascent/candidate/grounding-plan[1]#_g37630_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37629 '14 '#f '#f))
        (let ((__tmp37631
               |gerbil-ascent/candidate/grounding-plan[1]#_g37632_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37631 '15 '#f '#f))
        (let ((__tmp37633
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37634_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37635_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37633 '16 '#f '#f))
        (let ((__tmp37636
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37637_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37638_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37636 '17 '#f '#f))
        (let ((__tmp37639
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37640_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37641_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37639 '18 '#f '#f))
        (let ((__tmp37642
               (cons (cons 'relation
                           |gerbil-ascent/candidate/grounding-plan[1]#_g37643_|)
                     (cons (cons 'apply
                                 |gerbil-ascent/candidate/grounding-plan[1]#_g37644_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 __tmp37642 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37576 '() '21 '#f '#f))
        __obj37576))))
