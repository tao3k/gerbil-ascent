(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(define |gerbil-ascent/program/update-selection[:0:]#select-affected|
  (lambda (_%$stx13008%_)
    (let* ((_%$%g1301213041%_
            (lambda (_%$%g1301313037%_)
              (let ()
                (declare (not safe))
                (gx#raise-syntax-error
                 '#f
                 '"Bad syntax; invalid match target"
                 _%$%g1301313037%_))))
           (_%$%g1301113137%_
            (lambda (_%$%g1301313045%_)
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%$%g1301313045%_))
                  (let ((_%$%e1301813048%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%g1301313045%_))))
                    (let ((_%$%hd1301913052%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1301813048%_)))
                          (_%$%tl1302013055%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1301813048%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair? _%$%tl1302013055%_))
                          (let ((_%$%e1302113058%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-e _%$%tl1302013055%_))))
                            (let ((_%$%hd1302213062%_
                                   (let ()
                                     (declare (not safe))
                                     (##car _%$%e1302113058%_)))
                                  (_%$%tl1302313065%_
                                   (let ()
                                     (declare (not safe))
                                     (##cdr _%$%e1302113058%_))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-pair? _%$%tl1302313065%_))
                                  (let ((_%$%e1302413068%_
                                         (let ()
                                           (declare (not safe))
                                           (gx#syntax-e _%$%tl1302313065%_))))
                                    (let ((_%$%hd1302513072%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%e1302413068%_)))
                                          (_%$%tl1302613075%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%e1302413068%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (gx#stx-pair? _%$%tl1302613075%_))
                                          (let ((_%$%e1302713078%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (gx#syntax-e
                                                    _%$%tl1302613075%_))))
                                            (let ((_%$%hd1302813082%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%e1302713078%_)))
                                                  (_%$%tl1302913085%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%e1302713078%_))))
                                              (if (let ()
                                                    (declare (not safe))
                                                    (gx#stx-pair?
                                                     _%$%hd1302813082%_))
                                                  (let ((_%$%e1303013088%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (gx#syntax-e
                                                            _%$%hd1302813082%_))))
                                                    (let ((_%$%hd1303113092%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%e1303013088%_)))
                                                          (_%$%tl1303213095%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%e1303013088%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#stx-pair?
                                                             _%$%tl1303213095%_))
                                                          (let ((_%$%e1303313098%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%$%tl1303213095%_))))
                    (let ((_%$%hd1303413102%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1303313098%_)))
                          (_%$%tl1303513105%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1303313098%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-null? _%$%tl1303513105%_))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-null? _%$%tl1302913085%_))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'let))
                                    (cons (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'bitmap))
                                                      (cons _%$%hd1302213062%_
                                                            '()))
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'source))
                                                            (cons _%$%hd1302513072%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          '()))
              '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'def))
                                                      (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'keep?))
                          (cons _%$%hd1303113092%_ '()))
                    (cons (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'vector-ref))
                                (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'bitmap))
                                      (cons _%$%hd1303413102%_ '())))
                          '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'let))
                                                            (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (declare (not safe))
                            (gx#datum->syntax__0 '#f 'scan))
                          (cons (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'remaining))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'source))
                                                  '()))
                                      '())
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0 '#f 'match))
                                            (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'remaining))
                                                  (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f '@list))
                            '())
                      (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'source))
                            '()))
                (cons (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f '@list))
                                  (cons _%$%hd1303113092%_
                                        (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'rest))))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'cond))
                                        (cons (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'keep?))
                                                          (cons _%$%hd1303113092%_
                                                                '()))
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'scan))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'rest))
                              '()))
                  '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'eq?))
                        (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'remaining))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'source))
                                    '())))
                  (cons (cons (let ()
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'filter))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'keep?))
                                    (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0 '#f 'rest))
                                          '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (gx#datum->syntax__0 '#f 'else))
                        (cons (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0
                                       '#f
                                       'with-list-builder))
                                    (cons (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'collect))
                                                '())
                                          (cons (cons (let ()
                                                        (declare (not safe))
                                                        (gx#datum->syntax__0
                                                         '#f
                                                         'let))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'prefix))
                                                            (cons (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'pending))
                                      (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'source))
                                            '()))
                                '())
                          (cons (cons (let ()
                                        (declare (not safe))
                                        (gx#datum->syntax__0 '#f 'unless))
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'eq?))
                                                  (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'pending))
                                                        (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'remaining))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'collect))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'car))
                            (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'pending))
                                  '()))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'prefix))
                      (cons (cons (let ()
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'cdr))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'pending))
                                        '()))
                            '()))
                '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (cons (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'for-each))
                                                            (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'lambda))
                                (cons (cons _%$%hd1303113092%_ '())
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'when))
                                                  (cons (cons (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gx#datum->syntax__0 '#f 'keep?))
                      (cons _%$%hd1303113092%_ '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'collect))
                            (cons _%$%hd1303113092%_ '()))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                          (cons (let ()
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'rest))
                                '())))
              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              '()))
                  '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  '()))
                      '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      '()))))
              '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                              (_%$%g1301213041%_ _%$%g1301313045%_))
                          (_%$%g1301213041%_ _%$%g1301313045%_))))
                  (_%$%g1301213041%_ _%$%g1301313045%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  (_%$%g1301213041%_
                                                   _%$%g1301313045%_))))
                                          (_%$%g1301213041%_
                                           _%$%g1301313045%_))))
                                  (_%$%g1301213041%_ _%$%g1301313045%_))))
                          (_%$%g1301213041%_ _%$%g1301313045%_))))
                  (_%$%g1301213041%_ _%$%g1301313045%_)))))
      (_%$%g1301113137%_ _%$stx13008%_))))
