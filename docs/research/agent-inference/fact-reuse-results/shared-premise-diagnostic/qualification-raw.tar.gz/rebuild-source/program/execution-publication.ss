;;; -*- Gerbil -*-
;;; SPDX-FileCopyrightText: 2026 tao3k team and Contributors
;;; SPDX-License-Identifier: Apache-2.0 AND LGPL-2.1-or-later
(import :gerbil-ascent/core/relation-view
        (only-in :std/iter for in-range)
        (only-in :std/list/list-builder with-list-builder)
        (only-in "result.ss" gerbil-ascent-publish-rows gerbil-ascent-make-owned-result))
(export make-execution-publication gerbil-ascent-publish-execution!)

;;; A private cut owns detached publication vectors, never live engine vectors
;;; or a public Result. Public wrappers and observation lists remain fresh.
(defstruct execution-cut (snapshots sizes representations) final: #t)
(defstruct execution-publication (cut) constructor: :init! final: #t)
;; : (forall (r) (-> (ExecutionPublication r) Void))
;; : (-> ExecutionPublication Void)
(defmethod {:init! execution-publication} (lambda (self) (struct-instance-init! self #f)))


;; : (forall (row) (-> Names (RowsVector row) Sizes Deadline (ExecutionCut row)))
;; : (-> Names RowsVector Sizes Deadline ExecutionCut)
(def (prepare-execution-cut names all all-size deadline)
  (let* ((snapshots
           (if (vector? deadline)
             (gerbil-ascent-publish-rows all deadline all-size)
             (vector-map (lambda (rows) (if (relation-view? rows) rows (reverse rows))) all)))
         (sizes (vector-copy all-size))
         (representations
           (with-list-builder (collect!)
             (for (index (in-range (vector-length names)))
               (let ((rows (vector-ref all index)) (size (vector-ref sizes index)))
                 (collect! (list (vector-ref names index)
                            (if (relation-view? rows) 'rectangles 'explicit)
                            size (if (relation-view? rows) (relation-view-units rows) size))))))))
    (make-execution-cut snapshots sizes representations)))

;;; Caller storage checks and staged admission precede this boundary. Changed
;;; execution revokes the previous cut before any fallible publication work;
;;; a failed publication therefore cannot make a later clean call reuse it.
;; : (forall (r p) (-> (ExecutionPublication r) Boolean Names Arities (RowsVector r) Sizes Deadline Observation NameResolver Boolean Boolean (Values p OwnedPublication)))
;; : (-> ExecutionPublication Boolean Names Arities RowsVector Sizes Deadline Observation NameResolver Boolean Boolean (Values EvaluationResult OwnedPublication))
(def (gerbil-ascent-publish-execution! (state :- execution-publication) changed?
                                     names arity all all-size deadline observation
                                     position-of complete? session?)
  (when (or changed? (not session?)) (set! state.cut #f))
  (using (cut (or state.cut (prepare-execution-cut names all all-size deadline)) :- execution-cut)
    (let-values (((result publication)
                  (gerbil-ascent-make-owned-result names arity cut.snapshots cut.sizes
                    cut.representations observation position-of complete? session?)))
      (set! state.cut cut)
      (values result publication))))
