(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/index::timestamp 1791689693)
  (begin
    (define gerbil-ascent/program/index#row-indexes::t
      (let ((__tmp35821 (list)) (__tmp35820 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#row-indexes::t
         'row-indexes
         __tmp35821
         '(rows advance! plan! visit-parts)
         __tmp35820
         '#f)))
    (define gerbil-ascent/program/index#row-indexes?
      (let ()
        (declare (not safe))
        (__make-class-predicate gerbil-ascent/program/index#row-indexes::t)))
    (define gerbil-ascent/program/index#make-row-indexes
      (lambda _%$args15325%_
        (apply make-instance
               gerbil-ascent/program/index#row-indexes::t
               _%$args15325%_)))
    (define gerbil-ascent/program/index#row-indexes-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#row-indexes-advance!
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#row-indexes-plan!
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#row-indexes-visit-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#row-indexes-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#row-indexes-advance!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#row-indexes-plan!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#row-indexes-visit-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#&row-indexes-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#&row-indexes-advance!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#&row-indexes-plan!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#&row-indexes-visit-parts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#&row-indexes-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'rows)))
    (define gerbil-ascent/program/index#&row-indexes-advance!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'advance!)))
    (define gerbil-ascent/program/index#&row-indexes-plan!-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'plan!)))
    (define gerbil-ascent/program/index#&row-indexes-visit-parts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#row-indexes::t
         'visit-parts)))
    (define gerbil-ascent/program/index#row-indexes-plan-atoms!
      (lambda (_%indexes15319%_)
        (lambda (_%atoms15321%_)
          ((##structure-ref
            _%indexes15319%_
            '3
            gerbil-ascent/program/index#row-indexes::t
            '#f)
           (lambda (_%accept!15323%_)
             (for-each _%accept!15323%_ _%atoms15321%_))))))
    (define gerbil-ascent/program/index#visit-action-atoms!
      (lambda (_%actions15312%_ _%accept!15313%_)
        (for-each
         (lambda (_%action15315%_)
           (let ((_%atom15317%_ (vector-ref _%action15315%_ '0)))
             (if (vector? _%atom15317%_)
                 (_%accept!15313%_ _%atom15317%_)
                 '#!void)))
         _%actions15312%_)))
    (define gerbil-ascent/program/index#collect-sharing-atoms
      (lambda (_%visit!15126%_ _%providers15127%_)
        (let* ((_%seen15129%_
                (let ((__tmp35822 (vector-length _%providers15127%_)))
                  (declare (not safe))
                  (##make-vector __tmp35822 '#f)))
               (_%head15131%_ (cons '#f '()))
               (_%tail15134%_ _%head15131%_))
          (letrec ((_%accept!15295%_
                    (lambda (_%atom15297%_)
                      (let ((_%index15299%_ (vector-ref _%atom15297%_ '0))
                            (_%columns15300%_ (vector-ref _%atom15297%_ '2)))
                        (if (and (let ((__tmp35823
                                        (vector-ref
                                         _%providers15127%_
                                         _%index15299%_)))
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                    __tmp35823))
                                 (pair? _%columns15300%_))
                            (let ((_%table15307%_
                                   (let ((_%$e15302%_
                                          (vector-ref
                                           _%seen15129%_
                                           _%index15299%_)))
                                     (if _%$e15302%_
                                         _%$e15302%_
                                         (let ((_%fresh15305%_
                                                (let ()
                                                  (declare (not safe))
                                                  (make-hash-table__%
                                                   '#f
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value
                                                   absent-value))))
                                           (vector-set!
                                            _%seen15129%_
                                            _%index15299%_
                                            _%fresh15305%_)
                                           _%fresh15305%_)))))
                              (if (let ()
                                    (declare (not safe))
                                    (hash-get _%table15307%_ _%columns15300%_))
                                  '#!void
                                  (begin
                                    (let ()
                                      (declare (not safe))
                                      (hash-put!
                                       _%table15307%_
                                       _%columns15300%_
                                       '#t))
                                    (let ((_%new-tail15309%_
                                           (cons _%atom15297%_ '())))
                                      (let ()
                                        (declare (not safe))
                                        (##set-cdr!
                                         _%tail15134%_
                                         _%new-tail15309%_))
                                      (set! _%tail15134%_
                                            _%new-tail15309%_)))))
                            '#!void)))))
            (_%visit!15126%_ _%accept!15295%_)
            (let () (declare (not safe)) (##cdr _%head15131%_))))))
    (define gerbil-ascent/program/index#provider-row-member::t
      (let ((__tmp35825 (list)) (__tmp35824 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#provider-row-member::t
         'provider-row-member
         __tmp35825
         '(ordinal key occurrences)
         __tmp35824
         '#f)))
    (define gerbil-ascent/program/index#provider-row-member?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#provider-row-member::t)))
    (define gerbil-ascent/program/index#make-provider-row-member
      (lambda _%$args15123%_
        (apply make-instance
               gerbil-ascent/program/index#provider-row-member::t
               _%$args15123%_)))
    (define gerbil-ascent/program/index#provider-row-member-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#provider-row-member-key
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#provider-row-member-occurrences
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#provider-row-member-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#provider-row-member-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#provider-row-member-occurrences-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#&provider-row-member-ordinal
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#&provider-row-member-key
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#&provider-row-member-occurrences
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#&provider-row-member-ordinal-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'ordinal)))
    (define gerbil-ascent/program/index#&provider-row-member-key-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'key)))
    (define gerbil-ascent/program/index#&provider-row-member-occurrences-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-member::t
         'occurrences)))
    (define gerbil-ascent/program/index#provider-row-witness::t
      (let ((__tmp35827 (list)) (__tmp35826 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#provider-row-witness::t
         'provider-row-witness
         __tmp35827
         '(members counts)
         __tmp35826
         '#f)))
    (define gerbil-ascent/program/index#provider-row-witness?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#provider-row-witness::t)))
    (define gerbil-ascent/program/index#make-provider-row-witness
      (lambda _%$args15120%_
        (apply make-instance
               gerbil-ascent/program/index#provider-row-witness::t
               _%$args15120%_)))
    (define gerbil-ascent/program/index#provider-row-witness-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#provider-row-witness-counts
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#provider-row-witness-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#provider-row-witness-counts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#&provider-row-witness-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#&provider-row-witness-counts
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#&provider-row-witness-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'members)))
    (define gerbil-ascent/program/index#&provider-row-witness-counts-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#provider-row-witness::t
         'counts)))
    (define gerbil-ascent/program/index#checked-provider-rows
      (lambda (_%rows15099%_ _%terms15100%_ _%witness15101%_ _%key15102%_)
        (let ((_%snapshot15104%_
               (let ((__tmp35828 (length _%terms15100%_)))
                 (declare (not safe))
                 (gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot/arity
                  _%rows15099%_
                  __tmp35828)))
              (_%seen15105%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%matched15106%_ '0))
          (let ((__tmp35829
                 (lambda (_%row15108%_)
                   (let ((_%member15110%_
                          (let ((__tmp35830
                                 (##structure-ref
                                  _%witness15101%_
                                  '1
                                  gerbil-ascent/program/index#provider-row-witness::t
                                  '#f)))
                            (declare (not safe))
                            (hash-get __tmp35830 _%row15108%_))))
                     (if _%member15110%_
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"ASCENT index provider returned foreign row")))
                     (let ((_%enumerated15115%_
                            (let ((_%$e15112%_
                                   (let ((__tmp35831
                                          (##structure-ref
                                           _%member15110%_
                                           '1
                                           gerbil-ascent/program/index#provider-row-member::t
                                           '#f)))
                                     (declare (not safe))
                                     (__hash-get _%seen15105%_ __tmp35831))))
                              (if _%$e15112%_ _%$e15112%_ '0))))
                       (if (>= _%enumerated15115%_
                               (##structure-ref
                                _%member15110%_
                                '3
                                gerbil-ascent/program/index#provider-row-member::t
                                '#f))
                           (let ()
                             (declare (not safe))
                             (error '"ASCENT index provider returned duplicate row"))
                           '#!void)
                       (let ((__tmp35833
                              (##structure-ref
                               _%member15110%_
                               '1
                               gerbil-ascent/program/index#provider-row-member::t
                               '#f))
                             (__tmp35832 (+ _%enumerated15115%_ '1)))
                         (declare (not safe))
                         (__hash-put! _%seen15105%_ __tmp35833 __tmp35832)))
                     (if (equal? (##structure-ref
                                  _%member15110%_
                                  '2
                                  gerbil-ascent/program/index#provider-row-member::t
                                  '#f)
                                 _%key15102%_)
                         (set! _%matched15106%_ (+ _%matched15106%_ '1))
                         '#!void)))))
            (declare (not safe))
            (##for-each __tmp35829 _%snapshot15104%_))
          (if (= _%matched15106%_
                 (or (let ((__tmp35834
                            (##structure-ref
                             _%witness15101%_
                             '2
                             gerbil-ascent/program/index#provider-row-witness::t
                             '#f)))
                       (declare (not safe))
                       (hash-get __tmp35834 _%key15102%_))
                     '0))
              '#!void
              (let ()
                (declare (not safe))
                (error '"ASCENT index provider omitted matching rows")))
          _%snapshot15104%_)))
    (define gerbil-ascent/program/index#extend-provider-row-witness!
      (lambda (_%witness15077%_ _%rows15078%_ _%columns15079%_)
        (let ((_%members15081%_
               (##structure-ref
                _%witness15077%_
                '1
                gerbil-ascent/program/index#provider-row-witness::t
                '#f))
              (_%counts15082%_
               (##structure-ref
                _%witness15077%_
                '2
                gerbil-ascent/program/index#provider-row-witness::t
                '#f)))
          (for-each
           (lambda (_%row15084%_)
             (let* ((_%member15091%_
                     (let ((_%$e15086%_
                            (let ()
                              (declare (not safe))
                              (hash-get _%members15081%_ _%row15084%_))))
                       (if _%$e15086%_
                           _%$e15086%_
                           (let ((_%fresh15089%_
                                  (let ((__tmp35836
                                         (let ()
                                           (declare (not safe))
                                           (hash-length _%members15081%_)))
                                        (__tmp35835
                                         (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/table/funs#gerbil-ascent-index-key
                                            _%row15084%_
                                            _%columns15079%_))))
                                    (declare (not safe))
                                    (##structure
                                     gerbil-ascent/program/index#provider-row-member::t
                                     __tmp35836
                                     __tmp35835
                                     '0))))
                             (let ()
                               (declare (not safe))
                               (hash-put!
                                _%members15081%_
                                _%row15084%_
                                _%fresh15089%_))
                             _%fresh15089%_))))
                    (_%key15093%_
                     (##structure-ref
                      _%member15091%_
                      '2
                      gerbil-ascent/program/index#provider-row-member::t
                      '#f)))
               (##structure-set!
                _%member15091%_
                (+ '1
                   (##structure-ref
                    _%member15091%_
                    '3
                    gerbil-ascent/program/index#provider-row-member::t
                    '#f))
                '3
                gerbil-ascent/program/index#provider-row-member::t
                '#f)
               (let ((__tmp35837
                      (+ '1
                         (let ((_%$e15096%_
                                (let ()
                                  (declare (not safe))
                                  (hash-get _%counts15082%_ _%key15093%_))))
                           (if _%$e15096%_ _%$e15096%_ '0)))))
                 (declare (not safe))
                 (hash-put! _%counts15082%_ _%key15093%_ __tmp35837))))
           _%rows15078%_))
        _%witness15077%_))
    (define gerbil-ascent/program/index#build-provider-row-witness
      (lambda (_%rows15074%_ _%columns15075%_)
        (gerbil-ascent/program/index#extend-provider-row-witness!
         (let ((__tmp35839
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value)))
               (__tmp35838
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
           (declare (not safe))
           (##structure
            gerbil-ascent/program/index#provider-row-witness::t
            __tmp35839
            __tmp35838))
         _%rows15074%_
         _%columns15075%_)))
    (define gerbil-ascent/program/index#row-indexes-plan-rules!
      (lambda (_%indexes15065%_ _%rules15066%_)
        ((##structure-ref
          _%indexes15065%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%accept!15068%_)
           (for-each
            (lambda (_%rule15070%_)
              (for-each
               (lambda (_%clause15072%_)
                 (if (let ((__tmp35840 (vector-ref _%clause15072%_ '0)))
                       (declare (not safe))
                       (##memq __tmp35840 '(atom negation aggregate)))
                     (_%accept!15068%_ (vector-ref _%clause15072%_ '1))
                     '#!void))
               (vector-ref _%rule15070%_ '1)))
            _%rules15066%_)))))
    (define gerbil-ascent/program/index#row-indexes-plan-actions!
      (lambda (_%indexes15058%_ _%actions15059%_)
        ((##structure-ref
          _%indexes15058%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%$%g1506015062%_)
           (gerbil-ascent/program/index#visit-action-atoms!
            _%actions15059%_
            _%$%g1506015062%_)))))
    (define gerbil-ascent/program/index#row-indexes-plan-positive-rules!
      (lambda (_%indexes15051%_ _%rules15052%_)
        ((##structure-ref
          _%indexes15051%_
          '3
          gerbil-ascent/program/index#row-indexes::t
          '#f)
         (lambda (_%accept!15054%_)
           (for-each
            (lambda (_%rule15056%_)
              (gerbil-ascent/program/index#visit-action-atoms!
               (vector-ref (vector-ref _%rule15056%_ '0) '1)
               _%accept!15054%_))
            _%rules15052%_)))))
    (define gerbil-ascent/program/index#empty-row-indexes
      (let ((__tmp35845
             (lambda (_%atom15025%_
                      _%environment15026%_
                      _%use-delta?15027%_
                      _%slot-terms15028%_)
               (let ()
                 (declare (not safe))
                 (error '"ASCENT empty index owner has no lookup consumer"))))
            (__tmp35842
             (let ((_%$%opt-lambda1502915035%_
                    (lambda (_%index15031%_
                             _%rows15032%_
                             _%reverse-order?15033%_)
                      '#!void)))
               (lambda _g35843_
                 (let ((_g35844_
                        (let () (declare (not safe)) (##length _g35843_))))
                   (cond ((let () (declare (not safe)) (##fx= _g35844_ 2))
                          (apply (lambda (_%index15038%_ _%rows15039%_)
                                   (let ((_%reverse-order?15041%_ '#f))
                                     (_%$%opt-lambda1502915035%_
                                      _%index15038%_
                                      _%rows15039%_
                                      _%reverse-order?15041%_)))
                                 _g35843_))
                         ((let () (declare (not safe)) (##fx= _g35844_ 3))
                          (apply _%$%opt-lambda1502915035%_ _g35843_))
                         (else
                          (##raise-wrong-number-of-arguments-exception
                           'case-lambda-dispatch
                           _g35843_)))))))
            (__tmp35841
             (lambda (_%visit!15047%_)
               (_%visit!15047%_
                (lambda (_%_15049%_)
                  (let ()
                    (declare (not safe))
                    (error '"ASCENT empty index owner has lookup requirements")))))))
        (declare (not safe))
        (##structure
         gerbil-ascent/program/index#row-indexes::t
         __tmp35845
         __tmp35842
         __tmp35841
         '#f)))
    (define gerbil-ascent/program/index#physical-index-entry::t
      (let ((__tmp35847 (list)) (__tmp35846 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#physical-index-entry::t
         'physical-index-entry
         __tmp35847
         '(version lookup shared? witness)
         __tmp35846
         '#f)))
    (define gerbil-ascent/program/index#physical-index-entry?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#physical-index-entry::t)))
    (define gerbil-ascent/program/index#make-physical-index-entry
      (lambda _%$args15022%_
        (apply make-instance
               gerbil-ascent/program/index#physical-index-entry::t
               _%$args15022%_)))
    (define gerbil-ascent/program/index#physical-index-entry-version
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#physical-index-entry-lookup
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#physical-index-entry-shared?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#physical-index-entry-witness
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#physical-index-entry-version-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#physical-index-entry-lookup-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#physical-index-entry-shared?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#physical-index-entry-witness-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#&physical-index-entry-version
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#&physical-index-entry-lookup
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#&physical-index-entry-shared?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#&physical-index-entry-witness
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#&physical-index-entry-version-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'version)))
    (define gerbil-ascent/program/index#&physical-index-entry-lookup-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'lookup)))
    (define gerbil-ascent/program/index#&physical-index-entry-shared?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'shared?)))
    (define gerbil-ascent/program/index#&physical-index-entry-witness-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#physical-index-entry::t
         'witness)))
    (define gerbil-ascent/program/index#atom-index-view::t
      (let ((__tmp35849 (list)) (__tmp35848 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/index#atom-index-view::t
         'atom-index-view
         __tmp35849
         '(entry permutation)
         __tmp35848
         '#f)))
    (define gerbil-ascent/program/index#atom-index-view?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/index#atom-index-view::t)))
    (define gerbil-ascent/program/index#make-atom-index-view
      (lambda _%$args15019%_
        (apply make-instance
               gerbil-ascent/program/index#atom-index-view::t
               _%$args15019%_)))
    (define gerbil-ascent/program/index#atom-index-view-entry
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#atom-index-view-permutation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#atom-index-view-entry-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#atom-index-view-permutation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#&atom-index-view-entry
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#&atom-index-view-permutation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#&atom-index-view-entry-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'entry)))
    (define gerbil-ascent/program/index#&atom-index-view-permutation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/index#atom-index-view::t
         'permutation)))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
      (lambda (_%all14988%_
               _%delta14989%_
               _%all-size14990%_
               _%delta-size14991%_
               _%all-version14992%_
               _%delta-version14993%_
               _%index-providers14994%_
               _%required?14995%_)
        (if _%required?14995%_
            (gerbil-ascent/program/index#make-required-row-indexes
             _%all14988%_
             _%delta14989%_
             _%all-size14990%_
             _%delta-size14991%_
             _%all-version14992%_
             _%delta-version14993%_
             _%index-providers14994%_)
            gerbil-ascent/program/index#empty-row-indexes)))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
      (lambda (_%all15000%_
               _%delta15001%_
               _%all-size15002%_
               _%delta-size15003%_
               _%all-version15004%_
               _%delta-version15005%_
               _%index-providers15006%_)
        (let ((_%required?15008%_ '#t))
          (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
           _%all15000%_
           _%delta15001%_
           _%all-size15002%_
           _%delta-size15003%_
           _%all-version15004%_
           _%delta-version15005%_
           _%index-providers15006%_
           _%required?15008%_))))
    (define gerbil-ascent/program/index#gerbil-ascent-make-row-indexes
      (lambda _g35850_
        (let ((_g35851_ (let () (declare (not safe)) (##length _g35850_))))
          (cond ((let () (declare (not safe)) (##fx= _g35851_ 7))
                 (apply gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                        _g35850_))
                ((let () (declare (not safe)) (##fx= _g35851_ 8))
                 (apply gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__%
                        _g35850_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/index#gerbil-ascent-make-row-indexes
                  _g35850_))))))
    (define gerbil-ascent/program/index#make-required-row-indexes
      (lambda (_%all14688%_
               _%delta14689%_
               _%all-size14690%_
               _%delta-size14691%_
               _%all-version14692%_
               _%delta-version14693%_
               _%index-providers14694%_)
        (let ((_%all-indexes14707%_ '#f)
              (_%delta-indexes14708%_ '#f)
              (_%all-atoms14709%_ '#f)
              (_%delta-atoms14710%_ '#f)
              (_%layouts14711%_
               (let ((__tmp35852 (vector-length _%all14688%_)))
                 (declare (not safe))
                 (##make-vector __tmp35852 '#f)))
              (_%planned-atoms14712%_ '#f)
              (_%sharing?14713%_
               (let ((_%found?14696%_ '#f))
                 (vector-for-each
                  (lambda (_%provider14698%_)
                    (let ((_%next14704%_
                           (let ((_%$e14701%_ _%found?14696%_))
                             (if _%$e14701%_
                                 _%$e14701%_
                                 (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                    _%provider14698%_))))))
                      (if (eq? _%next14704%_ '#!void)
                          '#!void
                          (set! _%found?14696%_ _%next14704%_))))
                  _%index-providers14694%_)
                 _%found?14696%_))
              (_%ordered-all14714%_ '#f)
              (_%ordered-delta14715%_ '#f))
          (letrec* ((_%ordered-cut14717%_
                     (lambda (_%captured14966%_
                              _%index14967%_
                              _%use-delta?14968%_)
                       (let* ((_%cache14980%_
                               (if _%use-delta?14968%_
                                   (let ((_%$e14970%_ _%ordered-delta14715%_))
                                     (if _%$e14970%_
                                         _%$e14970%_
                                         (let ((_%v14973%_
                                                (let ((__tmp35853
                                                       (vector-length
                                                        _%all14688%_)))
                                                  (declare (not safe))
                                                  (##make-vector
                                                   __tmp35853
                                                   '#f))))
                                           (set! _%ordered-delta14715%_
                                                 _%v14973%_)
                                           _%v14973%_)))
                                   (let ((_%$e14975%_ _%ordered-all14714%_))
                                     (if _%$e14975%_
                                         _%$e14975%_
                                         (let ((_%v14978%_
                                                (let ((__tmp35854
                                                       (vector-length
                                                        _%all14688%_)))
                                                  (declare (not safe))
                                                  (##make-vector
                                                   __tmp35854
                                                   '#f))))
                                           (set! _%ordered-all14714%_
                                                 _%v14978%_)
                                           _%v14978%_)))))
                              (_%prior14982%_
                               (vector-ref _%cache14980%_ _%index14967%_)))
                         (if (and _%prior14982%_
                                  (eq? (car _%prior14982%_) _%captured14966%_))
                             (cdr _%prior14982%_)
                             (let ((_%rows14985%_
                                    (if (eq? (##structure-ref
                                              _%captured14966%_
                                              '4
                                              gerbil-ascent/core/relation-view#relation-view::t
                                              '#f)
                                             'delta)
                                        (let ()
                                          (declare (not safe))
                                          (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                                           _%captured14966%_))
                                        (reverse (let ()
                                                   (declare (not safe))
                                                   (gerbil-ascent/core/relation-view#gerbil-ascent-view-rows
                                                    _%captured14966%_))))))
                               (vector-set!
                                _%cache14980%_
                                _%index14967%_
                                (cons _%captured14966%_ _%rows14985%_))
                               _%rows14985%_)))))
                    (_%plan!14718%_
                     (lambda (_%visit!14959%_)
                       (if (or _%all-indexes14707%_ _%delta-indexes14708%_)
                           (let ()
                             (declare (not safe))
                             (error '"cannot replan a live physical index"))
                           '#!void)
                       (let ((_%fresh14964%_
                              (if _%sharing?14713%_
                                  (gerbil-ascent/program/index#collect-sharing-atoms
                                   _%visit!14959%_
                                   _%index-providers14694%_)
                                  '#f)))
                         (set! _%planned-atoms14712%_
                               (if (pair? _%fresh14964%_)
                                   _%fresh14964%_
                                   '#f)))))
                    (_%ensure-layouts!14719%_
                     (lambda ()
                       (if _%planned-atoms14712%_
                           (let ((_%requirements14874%_
                                  (let ((__tmp35855
                                         (vector-length _%all14688%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35855 '())))
                                 (_%fresh14875%_
                                  (let ((__tmp35856
                                         (vector-length _%all14688%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35856 '#f))))
                             (for-each
                              (lambda (_%atom14877%_)
                                (let ((_%i14879%_
                                       (vector-ref _%atom14877%_ '0))
                                      (_%columns14880%_
                                       (vector-ref _%atom14877%_ '2)))
                                  (if (and (let ((__tmp35857
                                                  (vector-ref
                                                   _%index-providers14694%_
                                                   _%i14879%_)))
                                             (declare (not safe))
                                             (gerbil-ascent/table/provider#gerbil-ascent-curried-index-provider?
                                              __tmp35857))
                                           (= (length _%columns14880%_)
                                              (let ((__tmp35858
                                                     (let ((_%seen14882%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (for-each
                                                        (lambda (_%c14884%_)
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (__hash-put!
                                                             _%seen14882%_
                                                             _%c14884%_
                                                             '#t)))
                                                        _%columns14880%_)
                                                       _%seen14882%_)))
                                                (declare (not safe))
                                                (__hash-length __tmp35858))))
                                      (vector-set!
                                       _%requirements14874%_
                                       _%i14879%_
                                       (cons _%columns14880%_
                                             (vector-ref
                                              _%requirements14874%_
                                              _%i14879%_)))
                                      '#!void)))
                              _%planned-atoms14712%_)
                             (let ((_%$start14886%_ '0)
                                   (_%$end14888%_
                                    (vector-length _%all14688%_)))
                               (if (> _%$start14886%_ _%$end14888%_)
                                   (let ((_%$start14891%_ '0)
                                         (_%$end14893%_
                                          (vector-length _%all14688%_))
                                         (_%$step14895%_ '-1))
                                     (if (> _%$step14895%_ '0)
                                         (let _%loop14899%_ ((_%k14902%_
                                                              _%$start14891%_))
                                           (if (< _%k14902%_ _%$end14893%_)
                                               (begin
                                                 (let ((_%columns14908%_
                                                        (vector-ref
                                                         _%requirements14874%_
                                                         _%k14902%_)))
                                                   (if (pair? _%columns14908%_)
                                                       (let ((_%layout14910%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                         _%columns14908%_))))
                 (vector-set!
                  _%fresh14875%_
                  _%k14902%_
                  (if (> (let ()
                           (declare (not safe))
                           (__hash-length _%layout14910%_))
                         '0)
                      _%layout14910%_
                      '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%loop14899%_
                                                  (+ _%k14902%_
                                                     _%$step14895%_)))
                                               '#!void))
                                         (if (< _%$step14895%_ '0)
                                             (let _%loop14913%_ ((_%k14915%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%$start14891%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if (> _%k14915%_ _%$end14893%_)
                                                   (begin
                                                     (let ((_%columns14920%_
                                                            (vector-ref
                                                             _%requirements14874%_
                                                             _%k14915%_)))
                                                       (if (pair? _%columns14920%_)
                                                           (let ((_%layout14922%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                             _%columns14920%_))))
                     (vector-set!
                      _%fresh14875%_
                      _%k14915%_
                      (if (> (let ()
                               (declare (not safe))
                               (__hash-length _%layout14922%_))
                             '0)
                          _%layout14922%_
                          '#f)))
                   '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%loop14913%_
                                                      (+ _%k14915%_
                                                         _%$step14895%_)))
                                                   '#!void))
                                             (let ()
                                               (raise-contract-violation-error
                                                '"contract violation"
                                                'context:
                                                'gerbil-ascent/program/index
                                                'contract:
                                                '(not (zero? -1))
                                                'value:
                                                _%$step14895%_)
                                               '#!void))))
                                   (let ((_%$start14925%_ '0)
                                         (_%$end14927%_
                                          (vector-length _%all14688%_))
                                         (_%$step14929%_ '1))
                                     (if (> _%$step14929%_ '0)
                                         (let _%loop14933%_ ((_%k14936%_
                                                              _%$start14925%_))
                                           (if (< _%k14936%_ _%$end14927%_)
                                               (begin
                                                 (let ((_%columns14942%_
                                                        (vector-ref
                                                         _%requirements14874%_
                                                         _%k14936%_)))
                                                   (if (pair? _%columns14942%_)
                                                       (let ((_%layout14944%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                         _%columns14942%_))))
                 (vector-set!
                  _%fresh14875%_
                  _%k14936%_
                  (if (> (let ()
                           (declare (not safe))
                           (__hash-length _%layout14944%_))
                         '0)
                      _%layout14944%_
                      '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%loop14933%_
                                                  (+ _%k14936%_
                                                     _%$step14929%_)))
                                               '#!void))
                                         (if (< _%$step14929%_ '0)
                                             (let _%loop14947%_ ((_%k14949%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%$start14925%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (if (> _%k14949%_ _%$end14927%_)
                                                   (begin
                                                     (let ((_%columns14954%_
                                                            (vector-ref
                                                             _%requirements14874%_
                                                             _%k14949%_)))
                                                       (if (pair? _%columns14954%_)
                                                           (let ((_%layout14956%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (gerbil-ascent/table/index-sharing#gerbil-ascent-index-sharing-layout
                             _%columns14954%_))))
                     (vector-set!
                      _%fresh14875%_
                      _%k14949%_
                      (if (> (let ()
                               (declare (not safe))
                               (__hash-length _%layout14956%_))
                             '0)
                          _%layout14956%_
                          '#f)))
                   '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (_%loop14947%_
                                                      (+ _%k14949%_
                                                         _%$step14929%_)))
                                                   '#!void))
                                             (let ()
                                               (raise-contract-violation-error
                                                '"contract violation"
                                                'context:
                                                'gerbil-ascent/program/index
                                                'contract:
                                                '(not (zero? 1))
                                                'value:
                                                _%$step14929%_)
                                               '#!void))))))
                             (set! _%layouts14711%_ _%fresh14875%_)
                             (set! _%planned-atoms14712%_ '#f))
                           '#!void)))
                    (_%visit-parts14720%_
                     (lambda (_%atom14865%_
                              _%environment14866%_
                              _%use-delta?14867%_
                              _%slot-terms14868%_
                              _%consume14869%_)
                       (let ((_%captured14871%_
                              (vector-ref
                               (if _%use-delta?14867%_
                                   _%delta14689%_
                                   _%all14688%_)
                               (vector-ref _%atom14865%_ '0))))
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/core/relation-view#gerbil-ascent-admitted-row-parts?
                                _%captured14871%_))
                             (if (let ((__tmp35859
                                        (vector-ref
                                         _%index-providers14694%_
                                         (vector-ref _%atom14865%_ '0))))
                                   (declare (not safe))
                                   (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                    __tmp35859))
                                 (begin
                                   ((if _%slot-terms14868%_
                                        gerbil-ascent/core/relation-view#gerbil-ascent-visit-admitted-view-parts!
                                        gerbil-ascent/core/relation-view#gerbil-ascent-visit-view-parts!)
                                    _%captured14871%_
                                    (vector-ref _%atom14865%_ '2)
                                    (if _%slot-terms14868%_
                                        (let ((__tmp35861
                                               (vector-ref _%atom14865%_ '1))
                                              (__tmp35860
                                               (vector-ref _%atom14865%_ '2)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                           __tmp35861
                                           __tmp35860
                                           _%environment14866%_
                                           _%slot-terms14868%_))
                                        (let ((__tmp35862
                                               (vector-ref _%atom14865%_ '4)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                           __tmp35862
                                           _%environment14866%_)))
                                    _%consume14869%_)
                                   '#t)
                                 '#f)
                             '#f))))
                    (_%indexed-rows__3580735808%_
                     (lambda (_%atom14753%_
                              _%environment14754%_
                              _%use-delta?14755%_
                              _%slot-terms14756%_
                              _%ordered?14757%_)
                       (let* ((_%index14759%_ (vector-ref _%atom14753%_ '0))
                              (_%columns14761%_ (vector-ref _%atom14753%_ '2))
                              (_%captured14763%_
                               (vector-ref
                                (if _%use-delta?14755%_
                                    _%delta14689%_
                                    _%all14688%_)
                                _%index14759%_))
                              (_%rows14765%_
                               (if (and _%ordered?14757%_
                                        (let ()
                                          (declare (not safe))
                                          (##structure-instance-of?
                                           _%captured14763%_
                                           'gerbil-ascent/core/relation-view#relation-view::t)))
                                   (_%ordered-cut14717%_
                                    _%captured14763%_
                                    _%index14759%_
                                    _%use-delta?14755%_)
                                   _%captured14763%_)))
                         (if (let ()
                               (declare (not safe))
                               (##structure-instance-of?
                                _%rows14765%_
                                'gerbil-ascent/core/relation-view#relation-view::t))
                             (let ((__tmp35863
                                    (if _%slot-terms14756%_
                                        (let ((__tmp35864
                                               (vector-ref _%atom14753%_ '1)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                           __tmp35864
                                           _%columns14761%_
                                           _%environment14754%_
                                           _%slot-terms14756%_))
                                        (let ((__tmp35865
                                               (vector-ref _%atom14753%_ '4)))
                                          (declare (not safe))
                                          (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                           __tmp35865
                                           _%environment14754%_)))))
                               (declare (not safe))
                               (gerbil-ascent/core/relation-view#gerbil-ascent-view-select
                                _%rows14765%_
                                _%columns14761%_
                                __tmp35863))
                             (if (or (null? _%columns14761%_)
                                     (< (vector-ref
                                         (if _%use-delta?14755%_
                                             _%delta-size14691%_
                                             _%all-size14690%_)
                                         _%index14759%_)
                                        '32))
                                 _%rows14765%_
                                 (begin
                                   (_%ensure-layouts!14719%_)
                                   (let* ((_%identities14781%_
                                           (if _%use-delta?14755%_
                                               (let ((_%$e14771%_
                                                      _%delta-atoms14710%_))
                                                 (if _%$e14771%_
                                                     _%$e14771%_
                                                     (let ((_%fresh14774%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (set! _%delta-atoms14710%_
                                                             _%fresh14774%_)
                                                       _%fresh14774%_)))
                                               (let ((_%$e14776%_
                                                      _%all-atoms14709%_))
                                                 (if _%$e14776%_
                                                     _%$e14776%_
                                                     (let ((_%fresh14779%_
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (make-hash-table-eq))))
                                                       (set! _%all-atoms14709%_
                                                             _%fresh14779%_)
                                                       _%fresh14779%_)))))
                                          (_%version14783%_
                                           (vector-ref
                                            (if _%use-delta?14755%_
                                                _%delta-version14693%_
                                                _%all-version14692%_)
                                            _%index14759%_))
                                          (_%view14828%_
                                           (let ((_%$e14785%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-get
                                                     _%identities14781%_
                                                     _%atom14753%_))))
                                             (if _%$e14785%_
                                                 _%$e14785%_
                                                 (let* ((_%layout14788%_
                                                         (vector-ref
                                                          _%layouts14711%_
                                                          _%index14759%_))
                                                        (_%permutation14790%_
                                                         (if _%layout14788%_
                                                             (let ((__tmp35866
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            (list-sort < _%columns14761%_)))
                       (declare (not safe))
                       (hash-get _%layout14788%_ __tmp35866))
                     '#f))
                (_%physical-columns14795%_
                 (let ((_%$e14792%_ _%permutation14790%_))
                   (if _%$e14792%_ _%$e14792%_ _%columns14761%_)))
                (_%caches14807%_
                 (if _%use-delta?14755%_
                     (let ((_%$e14797%_ _%delta-indexes14708%_))
                       (if _%$e14797%_
                           _%$e14797%_
                           (let ((_%fresh14800%_
                                  (let ((__tmp35867
                                         (vector-length _%delta14689%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35867 '#f))))
                             (set! _%delta-indexes14708%_ _%fresh14800%_)
                             _%fresh14800%_)))
                     (let ((_%$e14802%_ _%all-indexes14707%_))
                       (if _%$e14802%_
                           _%$e14802%_
                           (let ((_%fresh14805%_
                                  (let ((__tmp35868
                                         (vector-length _%all14688%_)))
                                    (declare (not safe))
                                    (##make-vector __tmp35868 '#f))))
                             (set! _%all-indexes14707%_ _%fresh14805%_)
                             _%fresh14805%_)))))
                (_%cache14814%_
                 (let ((_%$e14809%_
                        (vector-ref _%caches14807%_ _%index14759%_)))
                   (if _%$e14809%_
                       _%$e14809%_
                       (let ((_%fresh14812%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table__%
                                 '#f
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value))))
                         (vector-set!
                          _%caches14807%_
                          _%index14759%_
                          _%fresh14812%_)
                         _%fresh14812%_))))
                (_%shared14816%_
                 (let ()
                   (declare (not safe))
                   (hash-get _%cache14814%_ _%physical-columns14795%_)))
                (_%resolved14823%_
                 (let ((_%$e14818%_ _%shared14816%_))
                   (if _%$e14818%_
                       _%$e14818%_
                       (let ((_%fresh14821%_
                              (let ((__tmp35869
                                     (if _%permutation14790%_ '#t '#f)))
                                (declare (not safe))
                                (##structure
                                 gerbil-ascent/program/index#physical-index-entry::t
                                 '#f
                                 '#f
                                 __tmp35869
                                 '#f))))
                         (let ()
                           (declare (not safe))
                           (hash-put!
                            _%cache14814%_
                            _%physical-columns14795%_
                            _%fresh14821%_))
                         _%fresh14821%_))))
                (_%view14826%_
                 (let ()
                   (declare (not safe))
                   (##structure
                    gerbil-ascent/program/index#atom-index-view::t
                    _%resolved14823%_
                    _%permutation14790%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (let ()
                                                     (declare (not safe))
                                                     (__hash-put!
                                                      _%identities14781%_
                                                      _%atom14753%_
                                                      _%view14826%_))
                                                   _%view14826%_))))
                                          (_%entry14830%_
                                           (##structure-ref
                                            _%view14828%_
                                            '1
                                            gerbil-ascent/program/index#atom-index-view::t
                                            '#f))
                                          (_%permutation14832%_
                                           (##structure-ref
                                            _%view14828%_
                                            '2
                                            gerbil-ascent/program/index#atom-index-view::t
                                            '#f))
                                          (_%provider14834%_
                                           (vector-ref
                                            _%index-providers14694%_
                                            _%index14759%_))
                                          (_%lookup14841%_
                                           (if (and (##structure-ref
                                                     _%entry14830%_
                                                     '1
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    (= (##structure-ref
                                                        _%entry14830%_
                                                        '1
                                                        gerbil-ascent/program/index#physical-index-entry::t
                                                        '#f)
                                                       _%version14783%_))
                                               (##structure-ref
                                                _%entry14830%_
                                                '2
                                                gerbil-ascent/program/index#physical-index-entry::t
                                                '#f)
                                               (let* ((_%members14836%_
                                                       (if _%permutation14832%_
                                                           '#f
                                                           (if (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (declare (not safe))
                         (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                          _%provider14834%_))
                       '#f
                       (gerbil-ascent/program/index#build-provider-row-witness
                        _%rows14765%_
                        _%columns14761%_))))
              (_%built14838%_
               (if _%permutation14832%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-build
                      _%rows14765%_
                      _%permutation14832%_))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/table/access#gerbil-ascent-physical-index-build
                      _%provider14834%_
                      _%rows14765%_
                      _%columns14761%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (##structure-set!
                                                  _%entry14830%_
                                                  _%built14838%_
                                                  '2
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (##structure-set!
                                                  _%entry14830%_
                                                  _%members14836%_
                                                  '4
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (##structure-set!
                                                  _%entry14830%_
                                                  _%version14783%_
                                                  '1
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 _%built14838%_))))
                                     (if (if _%permutation14832%_
                                             '#f
                                             (and (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                                     _%provider14834%_))
                                                  (null? (cdr _%columns14761%_))))
                                         (let ((__tmp35870
                                                (let ((__tmp35872
                                                       (car (vector-ref
                                                             _%atom14753%_
                                                             '4)))
                                                      (__tmp35871
                                                       (if _%slot-terms14756%_
                                                           (car _%slot-terms14756%_)
                                                           '#f)))
                                                  (declare (not safe))
                                                  (gerbil-ascent/core/positive-plan#gerbil-ascent-index-value
                                                   __tmp35872
                                                   _%environment14754%_
                                                   __tmp35871))))
                                           (declare (not safe))
                                           (gerbil-ascent/table/access#gerbil-ascent-physical-index-single-rows
                                            _%lookup14841%_
                                            __tmp35870))
                                         (let ((_%key14844%_
                                                (if _%slot-terms14756%_
                                                    (let ((__tmp35873
                                                           (vector-ref
                                                            _%atom14753%_
                                                            '1)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
                                                       __tmp35873
                                                       _%columns14761%_
                                                       _%environment14754%_
                                                       _%slot-terms14756%_))
                                                    (let ((__tmp35874
                                                           (vector-ref
                                                            _%atom14753%_
                                                            '4)))
                                                      (declare (not safe))
                                                      (gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
                                                       __tmp35874
                                                       _%environment14754%_)))))
                                           (if _%permutation14832%_
                                               (let ()
                                                 (declare (not safe))
                                                 (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-rows
                                                  _%lookup14841%_
                                                  _%columns14761%_
                                                  _%key14844%_))
                                               (if (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                                      _%provider14834%_))
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
                                                      _%provider14834%_
                                                      _%lookup14841%_
                                                      _%key14844%_))
                                                   (let ((__tmp35876
                                                          (lambda (_%failure14846%_)
                                                            (##structure-set!
                                                             _%entry14830%_
                                                             '#f
                                                             '1
                                                             gerbil-ascent/program/index#physical-index-entry::t
                                                             '#f)
                                                            (let ()
                                                              (declare
                                                                (not safe))
                                                              (raise _%failure14846%_))))
                                                         (__tmp35875
                                                          (lambda ()
                                                            (gerbil-ascent/program/index#checked-provider-rows
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gerbil-ascent/table/access#gerbil-ascent-physical-index-rows
                        _%provider14834%_
                        _%lookup14841%_
                        _%key14844%_))
                     (vector-ref _%atom14753%_ '1)
                     (##structure-ref
                      _%entry14830%_
                      '4
                      gerbil-ascent/program/index#physical-index-entry::t
                      '#f)
                     _%key14844%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (__with-catch
                                                      __tmp35876
                                                      __tmp35875)))))))))))))
                    (_%indexed-rows__0__3580935810%_
                     (lambda (_%atom14852%_
                              _%environment14853%_
                              _%use-delta?14854%_
                              _%slot-terms14855%_)
                       (let ((_%ordered?14857%_ '#f))
                         (_%indexed-rows__3580735808%_
                          _%atom14852%_
                          _%environment14853%_
                          _%use-delta?14854%_
                          _%slot-terms14855%_
                          _%ordered?14857%_))))
                    (_%indexed-rows14721%_
                     (lambda _g35877_
                       (let ((_g35878_
                              (let ()
                                (declare (not safe))
                                (##length _g35877_))))
                         (cond ((let ()
                                  (declare (not safe))
                                  (##fx= _g35878_ 4))
                                (apply _%indexed-rows__0__3580935810%_
                                       _g35877_))
                               ((let ()
                                  (declare (not safe))
                                  (##fx= _g35878_ 5))
                                (apply _%indexed-rows__3580735808%_ _g35877_))
                               (else
                                (##raise-wrong-number-of-arguments-exception
                                 'case-lambda-dispatch
                                 _g35877_))))))
                    (_%advance-all-indexes!__3581135812%_
                     (lambda (_%index14725%_
                              _%new-rows14726%_
                              _%reverse-order?14727%_)
                       (let ((_%cache14729%_
                              (if _%all-indexes14707%_
                                  (vector-ref
                                   _%all-indexes14707%_
                                   _%index14725%_)
                                  '#f)))
                         (if (and _%cache14729%_ (pair? _%new-rows14726%_))
                             (let ((_%rows14731%_
                                    (if _%reverse-order?14727%_
                                        (reverse _%new-rows14726%_)
                                        _%new-rows14726%_))
                                   (_%version14732%_
                                    (vector-ref
                                     _%all-version14692%_
                                     _%index14725%_))
                                   (_%provider14733%_
                                    (vector-ref
                                     _%index-providers14694%_
                                     _%index14725%_)))
                               (let ((__tmp35879
                                      (lambda (_%columns14735%_ _%entry14736%_)
                                        (if (and (##structure-ref
                                                  _%entry14736%_
                                                  '1
                                                  gerbil-ascent/program/index#physical-index-entry::t
                                                  '#f)
                                                 (= (##structure-ref
                                                     _%entry14736%_
                                                     '1
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    _%version14732%_))
                                            (begin
                                              (##structure-set!
                                               _%entry14736%_
                                               '#f
                                               '1
                                               gerbil-ascent/program/index#physical-index-entry::t
                                               '#f)
                                              (let ((_%extended14738%_
                                                     (if (##structure-ref
                                                          _%entry14736%_
                                                          '3
                                                          gerbil-ascent/program/index#physical-index-entry::t
                                                          '#f)
                                                         (let ((__tmp35880
                                                                (##structure-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         _%entry14736%_
                         '2
                         gerbil-ascent/program/index#physical-index-entry::t
                         '#f)))
                   (declare (not safe))
                   (gerbil-ascent/table/index-sharing#gerbil-ascent-shared-index-extend!
                    __tmp35880
                    _%rows14731%_))
                 (let ((__tmp35881
                        (##structure-ref
                         _%entry14736%_
                         '2
                         gerbil-ascent/program/index#physical-index-entry::t
                         '#f)))
                   (declare (not safe))
                   (gerbil-ascent/table/access#gerbil-ascent-physical-index-extend!
                    _%provider14733%_
                    __tmp35881
                    _%rows14731%_
                    _%columns14735%_)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (##structure-set!
                                                 _%entry14736%_
                                                 _%extended14738%_
                                                 '2
                                                 gerbil-ascent/program/index#physical-index-entry::t
                                                 '#f)
                                                (if (##structure-ref
                                                     _%entry14736%_
                                                     '4
                                                     gerbil-ascent/program/index#physical-index-entry::t
                                                     '#f)
                                                    (gerbil-ascent/program/index#extend-provider-row-witness!
                                                     (##structure-ref
                                                      _%entry14736%_
                                                      '4
                                                      gerbil-ascent/program/index#physical-index-entry::t
                                                      '#f)
                                                     _%rows14731%_
                                                     _%columns14735%_)
                                                    '#!void)
                                                (##structure-set!
                                                 _%entry14736%_
                                                 (+ _%version14732%_ '1)
                                                 '1
                                                 gerbil-ascent/program/index#physical-index-entry::t
                                                 '#f)))
                                            '#!void))))
                                 (declare (not safe))
                                 (hash-for-each __tmp35879 _%cache14729%_)))
                             '#!void))))
                    (_%advance-all-indexes!__0__3581335814%_
                     (lambda (_%index14743%_ _%new-rows14744%_)
                       (let ((_%reverse-order?14746%_ '#f))
                         (_%advance-all-indexes!__3581135812%_
                          _%index14743%_
                          _%new-rows14744%_
                          _%reverse-order?14746%_))))
                    (_%advance-all-indexes!14722%_
                     (lambda _g35882_
                       (let ((_g35883_
                              (let ()
                                (declare (not safe))
                                (##length _g35882_))))
                         (cond ((let ()
                                  (declare (not safe))
                                  (##fx= _g35883_ 2))
                                (apply _%advance-all-indexes!__0__3581335814%_
                                       _g35882_))
                               ((let ()
                                  (declare (not safe))
                                  (##fx= _g35883_ 3))
                                (apply _%advance-all-indexes!__3581135812%_
                                       _g35882_))
                               (else
                                (##raise-wrong-number-of-arguments-exception
                                 'case-lambda-dispatch
                                 _g35882_)))))))
            (let ()
              (declare (not safe))
              (##structure
               gerbil-ascent/program/index#row-indexes::t
               _%indexed-rows14721%_
               _%advance-all-indexes!14722%_
               _%plan!14718%_
               _%visit-parts14720%_))))))))
