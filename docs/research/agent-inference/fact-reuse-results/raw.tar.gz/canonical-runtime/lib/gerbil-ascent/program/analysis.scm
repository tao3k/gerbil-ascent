(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/table/storage"))
  (load-module "gerbil-ascent/program/analysis~0"))
