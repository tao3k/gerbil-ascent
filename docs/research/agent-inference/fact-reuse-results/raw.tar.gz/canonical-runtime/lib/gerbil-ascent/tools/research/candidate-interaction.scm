(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/encoding/json")
    (load-module "std/error")
    (load-module "gerbil-ascent/candidate/evidence-store")
    (load-module "gerbil-ascent/candidate/feedback")
    (load-module "gerbil-ascent/candidate/reasoning"))
  (load-module "gerbil-ascent/tools/research/candidate-interaction~0"))
