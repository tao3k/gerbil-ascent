prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/activation#gerbil-ascent-activate-rule
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/activation)))
  (declare-type
   gerbil-ascent/program/activation#gerbil-ascent-activate-plans
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/activation))))
