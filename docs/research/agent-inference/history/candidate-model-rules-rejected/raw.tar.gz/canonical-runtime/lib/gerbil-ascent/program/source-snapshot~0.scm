(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/source-snapshot::timestamp 1791687883)
  (begin
    (define gerbil-ascent/program/source-snapshot#source-snapshot::t
      (let ((__tmp36568 (list))
            (__tmp36567
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-snapshot#source-snapshot::t
         'source-snapshot
         __tmp36568
         '(template program declarations rows materializations)
         __tmp36567
         '#f)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-snapshot#source-snapshot::t)))
    (define gerbil-ascent/program/source-snapshot#make-source-snapshot
      (lambda _%$args13004%_
        (apply make-instance
               gerbil-ascent/program/source-snapshot#source-snapshot::t
               _%$args13004%_)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-template
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-program
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-declarations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-materializations
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-template-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-declarations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-snapshot-materializations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-template
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-program
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-declarations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-materializations
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-template-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'template)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-program-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'program)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-declarations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'declarations)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-snapshot-materializations-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-snapshot::t
         'materializations)))
    (define gerbil-ascent/program/source-snapshot#source-materialization::t
      (let ((__tmp36570 (list))
            (__tmp36569
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/source-snapshot#source-materialization::t
         'source-materialization
         __tmp36570
         '(base additions rows scalar?)
         __tmp36569
         '#f)))
    (define gerbil-ascent/program/source-snapshot#source-materialization?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/source-snapshot#source-materialization::t)))
    (define gerbil-ascent/program/source-snapshot#make-source-materialization
      (lambda _%$args13001%_
        (apply make-instance
               gerbil-ascent/program/source-snapshot#source-materialization::t
               _%$args13001%_)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-base
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-scalar?
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-base-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#source-materialization-scalar?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-base
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-additions
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-scalar?
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-base-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'base)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-additions-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'additions)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'rows)))
    (define gerbil-ascent/program/source-snapshot#&source-materialization-scalar?-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/source-snapshot#source-materialization::t
         'scalar?)))
    (define gerbil-ascent/program/source-snapshot#capture-source-materialization
      (lambda (_%base12992%_ _%additions12993%_ _%rows12994%_)
        (let ((__tmp36571
               (let ((__tmp36572
                      (lambda ()
                        (let ((__tmp36573
                               (lambda (_%$%g1299612998%_)
                                 (let ()
                                   (declare (not safe))
                                   (andmap__0
                                    gerbil-ascent/program/scheme-checked#relational-scalar?
                                    _%$%g1299612998%_)))))
                          (declare (not safe))
                          (andmap__0 __tmp36573 _%rows12994%_)))))
                 (declare (not safe))
                 (__make-atomic-promise __tmp36572))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/source-snapshot#source-materialization::t
           _%base12992%_
           _%additions12993%_
           _%rows12994%_
           __tmp36571))))
    (define gerbil-ascent/program/source-snapshot#__materialize-source-log
      (lambda (_%base12978%_ _%additions12979%_ _%previous12980%_)
        (let ((_%previous12983%_ _%previous12980%_))
          (if (and (eq? _%base12978%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%previous12983%_
                           '1
                           '#f
                           '#f)))
                   (eq? _%additions12979%_
                        (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%previous12983%_
                           '2
                           '#f
                           '#f))))
              _%previous12983%_
              (gerbil-ascent/program/source-snapshot#capture-source-materialization
               _%base12978%_
               _%additions12979%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/source-log#gerbil-ascent-source-log-rows
                  _%base12978%_
                  _%additions12979%_)))))))
    (define gerbil-ascent/program/source-snapshot#materialize-source-log
      (lambda (_%base12964%_ _%additions12965%_ _%previous12966%_)
        (let ((_%previous12969%_ _%previous12966%_))
          (gerbil-ascent/program/source-snapshot#__materialize-source-log
           _%base12964%_
           _%additions12965%_
           _%previous12969%_))))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
      (lambda (_%snapshot12936%_
               _%candidate12937%_
               _%index12938%_
               _%log12939%_
               _%rows12940%_)
        (let ((_%snapshot12943%_ _%snapshot12936%_))
          (if (eq? _%candidate12937%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%snapshot12943%_ '2 '#f '#f)))
              (let* ((_%materialization12952%_
                      (vector-ref
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%snapshot12943%_
                          '5
                          '#f
                          '#f))
                       _%index12938%_))
                     (_%materialization12954%_ _%materialization12952%_))
                (if (eq? (car _%log12939%_)
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%materialization12954%_
                            '1
                            '#f
                            '#f)))
                    (if (eq? (cdr _%log12939%_)
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%materialization12954%_
                                '2
                                '#f
                                '#f)))
                        (eq? _%rows12940%_
                             (let ()
                               (declare (not safe))
                               (##unchecked-structure-ref
                                _%materialization12954%_
                                '3
                                '#f
                                '#f)))
                        '#f)
                    '#f))
              '#f))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-log-snapshot-equal?
      (lambda (_%snapshot12920%_
               _%candidate12921%_
               _%index12922%_
               _%log12923%_
               _%rows12924%_)
        (let ((_%snapshot12927%_ _%snapshot12920%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
           _%snapshot12927%_
           _%candidate12921%_
           _%index12922%_
           _%log12923%_
           _%rows12924%_))))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
      (lambda (_%snapshot12893%_
               _%candidate12894%_
               _%index12895%_
               _%rows12896%_)
        (let ((_%snapshot12899%_ _%snapshot12893%_))
          (if (eq? _%candidate12894%_
                   (let ()
                     (declare (not safe))
                     (##unchecked-structure-ref _%snapshot12899%_ '2 '#f '#f)))
              (let* ((_%materialization12908%_
                      (vector-ref
                       (let ()
                         (declare (not safe))
                         (##unchecked-structure-ref
                          _%snapshot12899%_
                          '5
                          '#f
                          '#f))
                       _%index12895%_))
                     (_%materialization12910%_ _%materialization12908%_))
                (if (eq? _%rows12896%_
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%materialization12910%_
                            '3
                            '#f
                            '#f)))
                    (force (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%materialization12910%_
                              '4
                              '#f
                              '#f)))
                    '#f))
              '#f))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot-scalar?
      (lambda (_%snapshot12878%_
               _%candidate12879%_
               _%index12880%_
               _%rows12881%_)
        (let ((_%snapshot12884%_ _%snapshot12878%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
           _%snapshot12884%_
           _%candidate12879%_
           _%index12880%_
           _%rows12881%_))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
      (lambda (_%program12868%_)
        (let* ((_%declarations12870%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%program12868%_ 'relations)))
               (_%rows12874%_
                (list->vector
                 (map (lambda (_%relation12872%_)
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation12872%_ 'rows)))
                      _%declarations12870%_)))
               (__tmp36574
                (vector-map
                 (lambda (_%base12876%_)
                   (gerbil-ascent/program/source-snapshot#capture-source-materialization
                    _%base12876%_
                    '()
                    _%base12876%_))
                 _%rows12874%_)))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/source-snapshot#source-snapshot::t
           _%program12868%_
           _%program12868%_
           _%declarations12870%_
           _%rows12874%_
           __tmp36574))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-prepare-source-snapshot
      (lambda (_%snapshot12863%_ _%rows12864%_)
        (gerbil-ascent/program/source-snapshot#prepare-source-snapshot
         _%snapshot12863%_
         _%rows12864%_
         (vector-map
          (lambda (_%base12866%_)
            (gerbil-ascent/program/source-snapshot#capture-source-materialization
             _%base12866%_
             '()
             _%base12866%_))
          _%rows12864%_)
         '#f)))
    (define gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
      (lambda (_%snapshot12506%_ _%logs12507%_)
        (let ((_%snapshot12510%_ _%snapshot12506%_))
          (if (= (vector-length _%logs12507%_)
                 (vector-length
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%snapshot12510%_ '4 '#f '#f))))
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT source snapshot width")))
          (let ((_%rows12519%_
                 (let ((__tmp36575 (vector-length _%logs12507%_)))
                   (declare (not safe))
                   (##make-vector __tmp36575)))
                (_%materializations12520%_
                 (let ((__tmp36576 (vector-length _%logs12507%_)))
                   (declare (not safe))
                   (##make-vector __tmp36576)))
                (_%changed?12521%_ '#f))
            (let ((_%$start12523%_ '0)
                  (_%$end12525%_ (vector-length _%logs12507%_)))
              (if (> _%$start12523%_ _%$end12525%_)
                  (let ((_%$start12528%_ '0)
                        (_%$end12530%_ (vector-length _%logs12507%_))
                        (_%$step12532%_ '-1))
                    (if (> _%$step12532%_ '0)
                        (let _%loop12536%_ ((_%k12539%_ _%$start12528%_))
                          (if (< _%k12539%_ _%$end12530%_)
                              (begin
                                (let* ((_%$%g1254412551%_
                                        (vector-ref _%logs12507%_ _%k12539%_))
                                       (_%$%E1254612555%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%g1254412551%_
                                                   '([base . additions])))
                                          '#!void))
                                       (_%$%K1254712608%_
                                        (lambda (_%additions12558%_
                                                 _%base12559%_)
                                          (let* ((_%previous12561%_
                                                  (vector-ref
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot12510%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   _%k12539%_))
                                                 (_%next12599%_
                                                  (let* ((_%base12563%_
                                                          _%base12559%_)
                                                         (_%additions12566%_
                                                          _%additions12558%_)
                                                         (_%previous12569%_
                                                          _%previous12561%_)
                                                         (_%previous12573%_
                                                          _%previous12569%_))
                                                    (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                     _%base12563%_
                                                     _%additions12566%_
                                                     _%previous12573%_)))
                                                 (_%next12601%_ _%next12599%_))
                                            (if (eq? _%next12601%_
                                                     _%previous12561%_)
                                                '#!void
                                                (set! _%changed?12521%_ '#t))
                                            (vector-set!
                                             _%materializations12520%_
                                             _%k12539%_
                                             _%next12601%_)
                                            (vector-set!
                                             _%rows12519%_
                                             _%k12539%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%next12601%_
                                                '3
                                                '#f
                                                '#f)))))))
                                  (if (pair? _%$%g1254412551%_)
                                      (let ((_%$%hd1254812611%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%g1254412551%_)))
                                            (_%$%tl1254912613%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%g1254412551%_))))
                                        (let* ((_%base12616%_
                                                _%$%hd1254812611%_)
                                               (_%additions12618%_
                                                _%$%tl1254912613%_))
                                          (_%$%K1254712608%_
                                           _%additions12618%_
                                           _%base12616%_)))
                                      (_%$%E1254612555%_)))
                                (_%loop12536%_ (+ _%k12539%_ _%$step12532%_)))
                              '#!void))
                        (if (< _%$step12532%_ '0)
                            (let _%loop12621%_ ((_%k12623%_ _%$start12528%_))
                              (if (> _%k12623%_ _%$end12530%_)
                                  (begin
                                    (let* ((_%$%g1262712634%_
                                            (vector-ref
                                             _%logs12507%_
                                             _%k12623%_))
                                           (_%$%E1262912638%_
                                            (lambda ()
                                              (let ()
                                                (declare (not safe))
                                                (error '"No clause matching"
                                                       _%$%g1262712634%_
                                                       '([base . additions])))
                                              '#!void))
                                           (_%$%K1263012685%_
                                            (lambda (_%additions12641%_
                                                     _%base12642%_)
                                              (let* ((_%previous12644%_
                                                      (vector-ref
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%snapshot12510%_
                                                          '5
                                                          '#f
                                                          '#f))
                                                       _%k12623%_))
                                                     (_%next12676%_
                                                      (let* ((_%base12646%_
                                                              _%base12642%_)
                                                             (_%additions12649%_
                                                              _%additions12641%_)
                                                             (_%previous12652%_
                                                              _%previous12644%_)
                                                             (_%previous12656%_
                                                              _%previous12652%_))
                                                        (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                         _%base12646%_
                                                         _%additions12649%_
                                                         _%previous12656%_)))
                                                     (_%next12678%_
                                                      _%next12676%_))
                                                (if (eq? _%next12678%_
                                                         _%previous12644%_)
                                                    '#!void
                                                    (set! _%changed?12521%_
                                                          '#t))
                                                (vector-set!
                                                 _%materializations12520%_
                                                 _%k12623%_
                                                 _%next12678%_)
                                                (vector-set!
                                                 _%rows12519%_
                                                 _%k12623%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%next12678%_
                                                    '3
                                                    '#f
                                                    '#f)))))))
                                      (if (pair? _%$%g1262712634%_)
                                          (let ((_%$%hd1263112688%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%g1262712634%_)))
                                                (_%$%tl1263212690%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%g1262712634%_))))
                                            (let* ((_%base12693%_
                                                    _%$%hd1263112688%_)
                                                   (_%additions12695%_
                                                    _%$%tl1263212690%_))
                                              (_%$%K1263012685%_
                                               _%additions12695%_
                                               _%base12693%_)))
                                          (_%$%E1262912638%_)))
                                    (_%loop12621%_
                                     (+ _%k12623%_ _%$step12532%_)))
                                  '#!void))
                            (let ()
                              (raise-contract-violation-error
                               '"contract violation"
                               'context:
                               'gerbil-ascent/program/source-snapshot
                               'contract:
                               '(not (zero? -1))
                               'value:
                               _%$step12532%_)
                              '#!void))))
                  (let ((_%$start12698%_ '0)
                        (_%$end12700%_ (vector-length _%logs12507%_))
                        (_%$step12702%_ '1))
                    (if (> _%$step12702%_ '0)
                        (let _%loop12706%_ ((_%k12709%_ _%$start12698%_))
                          (if (< _%k12709%_ _%$end12700%_)
                              (begin
                                (let* ((_%$%g1271412721%_
                                        (vector-ref _%logs12507%_ _%k12709%_))
                                       (_%$%E1271612725%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%g1271412721%_
                                                   '([base . additions])))
                                          '#!void))
                                       (_%$%K1271712773%_
                                        (lambda (_%additions12728%_
                                                 _%base12729%_)
                                          (let* ((_%previous12731%_
                                                  (vector-ref
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%snapshot12510%_
                                                      '5
                                                      '#f
                                                      '#f))
                                                   _%k12709%_))
                                                 (_%next12764%_
                                                  (let* ((_%base12733%_
                                                          _%base12729%_)
                                                         (_%additions12736%_
                                                          _%additions12728%_)
                                                         (_%previous12739%_
                                                          _%previous12731%_)
                                                         (_%previous12743%_
                                                          _%previous12739%_))
                                                    (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                     _%base12733%_
                                                     _%additions12736%_
                                                     _%previous12743%_)))
                                                 (_%next12766%_ _%next12764%_))
                                            (if (eq? _%next12766%_
                                                     _%previous12731%_)
                                                '#!void
                                                (set! _%changed?12521%_ '#t))
                                            (vector-set!
                                             _%materializations12520%_
                                             _%k12709%_
                                             _%next12766%_)
                                            (vector-set!
                                             _%rows12519%_
                                             _%k12709%_
                                             (let ()
                                               (declare (not safe))
                                               (##unchecked-structure-ref
                                                _%next12766%_
                                                '3
                                                '#f
                                                '#f)))))))
                                  (if (pair? _%$%g1271412721%_)
                                      (let ((_%$%hd1271812776%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%g1271412721%_)))
                                            (_%$%tl1271912778%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%g1271412721%_))))
                                        (let* ((_%base12781%_
                                                _%$%hd1271812776%_)
                                               (_%additions12783%_
                                                _%$%tl1271912778%_))
                                          (_%$%K1271712773%_
                                           _%additions12783%_
                                           _%base12781%_)))
                                      (_%$%E1271612725%_)))
                                (_%loop12706%_ (+ _%k12709%_ _%$step12702%_)))
                              '#!void))
                        (if (< _%$step12702%_ '0)
                            (let _%loop12786%_ ((_%k12788%_ _%$start12698%_))
                              (if (> _%k12788%_ _%$end12700%_)
                                  (begin
                                    (let* ((_%$%g1279212799%_
                                            (vector-ref
                                             _%logs12507%_
                                             _%k12788%_))
                                           (_%$%E1279412803%_
                                            (lambda ()
                                              (let ()
                                                (declare (not safe))
                                                (error '"No clause matching"
                                                       _%$%g1279212799%_
                                                       '([base . additions])))
                                              '#!void))
                                           (_%$%K1279512850%_
                                            (lambda (_%additions12806%_
                                                     _%base12807%_)
                                              (let* ((_%previous12809%_
                                                      (vector-ref
                                                       (let ()
                                                         (declare (not safe))
                                                         (##unchecked-structure-ref
                                                          _%snapshot12510%_
                                                          '5
                                                          '#f
                                                          '#f))
                                                       _%k12788%_))
                                                     (_%next12841%_
                                                      (let* ((_%base12811%_
                                                              _%base12807%_)
                                                             (_%additions12814%_
                                                              _%additions12806%_)
                                                             (_%previous12817%_
                                                              _%previous12809%_)
                                                             (_%previous12821%_
                                                              _%previous12817%_))
                                                        (gerbil-ascent/program/source-snapshot#__materialize-source-log
                                                         _%base12811%_
                                                         _%additions12814%_
                                                         _%previous12821%_)))
                                                     (_%next12843%_
                                                      _%next12841%_))
                                                (if (eq? _%next12843%_
                                                         _%previous12809%_)
                                                    '#!void
                                                    (set! _%changed?12521%_
                                                          '#t))
                                                (vector-set!
                                                 _%materializations12520%_
                                                 _%k12788%_
                                                 _%next12843%_)
                                                (vector-set!
                                                 _%rows12519%_
                                                 _%k12788%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##unchecked-structure-ref
                                                    _%next12843%_
                                                    '3
                                                    '#f
                                                    '#f)))))))
                                      (if (pair? _%$%g1279212799%_)
                                          (let ((_%$%hd1279612853%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%g1279212799%_)))
                                                (_%$%tl1279712855%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%g1279212799%_))))
                                            (let* ((_%base12858%_
                                                    _%$%hd1279612853%_)
                                                   (_%additions12860%_
                                                    _%$%tl1279712855%_))
                                              (_%$%K1279512850%_
                                               _%additions12860%_
                                               _%base12858%_)))
                                          (_%$%E1279412803%_)))
                                    (_%loop12786%_
                                     (+ _%k12788%_ _%$step12702%_)))
                                  '#!void))
                            (let ()
                              (raise-contract-violation-error
                               '"contract violation"
                               'context:
                               'gerbil-ascent/program/source-snapshot
                               'contract:
                               '(not (zero? 1))
                               'value:
                               _%$step12702%_)
                              '#!void))))))
            (if _%changed?12521%_
                (gerbil-ascent/program/source-snapshot#prepare-source-snapshot
                 _%snapshot12510%_
                 _%rows12519%_
                 _%materializations12520%_
                 '#t)
                _%snapshot12510%_)))))
    (define gerbil-ascent/program/source-snapshot#gerbil-ascent-prepare-source-log-snapshot
      (lambda (_%snapshot12493%_ _%logs12494%_)
        (let ((_%snapshot12497%_ _%snapshot12493%_))
          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
           _%snapshot12497%_
           _%logs12494%_))))
    (define gerbil-ascent/program/source-snapshot#prepare-source-snapshot
      (lambda (_%snapshot12390%_
               _%rows12391%_
               _%materializations12392%_
               _%roots-changed?12393%_)
        (let* ((_%$%snapshot1239412404%_ _%snapshot12390%_)
               (_%$%E1239612407%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%snapshot1239412404%_
                           '((source-snapshot
                              template
                              program
                              declarations
                              previous
                              _))))
                  '#!void))
               (_%$%K1239712467%_
                (lambda (_%previous12410%_
                         _%declarations12411%_
                         _%program12412%_
                         _%template12413%_)
                  (if (= (vector-length _%rows12391%_)
                         (vector-length _%previous12410%_))
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"invalid ASCENT source snapshot width")))
                  (let* ((_%changed?12415%_ '#f)
                         (_%next12446%_
                          (map (lambda (_%prototype12417%_
                                        _%declaration12418%_
                                        _%index12419%_)
                                 (let ((_%replacement12421%_
                                        (vector-ref
                                         _%rows12391%_
                                         _%index12419%_)))
                                   (if (eq? _%replacement12421%_
                                            (vector-ref
                                             _%previous12410%_
                                             _%index12419%_))
                                       _%declaration12418%_
                                       (begin
                                         (set! _%changed?12415%_ '#t)
                                         (let ((__obj36565
                                                (let ()
                                                  (declare (not safe))
                                                  (##structure
                                                   clan/poo/object#object::t
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f
                                                   '#f))))
                                           (let ((__tmp36578
                                                  (list (cons 'rows
                                                              (let ((__tmp36579
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (lambda (_%@12440%_) _%replacement12421%_)))
                        (declare (not safe))
                        (##structure
                         clan/poo/object#$self-slot-spec::t
                         __tmp36579)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (__tmp36577 (list)))
                                             (declare (not safe))
                                             (clan/poo/object#object:::init!__%
                                              '#f
                                              _%prototype12417%_
                                              __tmp36578
                                              __tmp36577
                                              __obj36565))
                                           __obj36565)))))
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref
                                  _%template12413%_
                                  'relations))
                               _%declarations12411%_
                               (let ((__tmp36580
                                      (vector-length _%rows12391%_)))
                                 (declare (not safe))
                                 (##iota __tmp36580)))))
                    (if _%changed?12415%_
                        (let ((__tmp36581
                               (let ((__obj36566
                                      (let ()
                                        (declare (not safe))
                                        (##structure
                                         clan/poo/object#object::t
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f
                                         '#f))))
                                 (let ((__tmp36583
                                        (list (cons 'relations
                                                    (let ((__tmp36584
                                                           (lambda (_%@12461%_)
                                                             _%next12446%_)))
                                                      (declare (not safe))
                                                      (##structure
                                                       clan/poo/object#$self-slot-spec::t
                                                       __tmp36584)))))
                                       (__tmp36582 (list)))
                                   (declare (not safe))
                                   (clan/poo/object#object:::init!__%
                                    '#f
                                    _%template12413%_
                                    __tmp36583
                                    __tmp36582
                                    __obj36566))
                                 __obj36566)))
                          (declare (not safe))
                          (##structure
                           gerbil-ascent/program/source-snapshot#source-snapshot::t
                           _%template12413%_
                           __tmp36581
                           _%next12446%_
                           _%rows12391%_
                           _%materializations12392%_))
                        (if _%roots-changed?12393%_
                            (let ()
                              (declare (not safe))
                              (##structure
                               gerbil-ascent/program/source-snapshot#source-snapshot::t
                               _%template12413%_
                               _%program12412%_
                               _%declarations12411%_
                               _%previous12410%_
                               _%materializations12392%_))
                            _%snapshot12390%_))))))
          (if (let ()
                (declare (not safe))
                (##structure-direct-instance-of?
                 _%$%snapshot1239412404%_
                 'gerbil-ascent/program/source-snapshot#source-snapshot::t))
              (let* ((_%$%e1239812470%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1239412404%_
                         '1
                         '#f
                         '#f)))
                     (_%template12473%_ _%$%e1239812470%_)
                     (_%$%e1239912475%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1239412404%_
                         '2
                         '#f
                         '#f)))
                     (_%program12478%_ _%$%e1239912475%_)
                     (_%$%e1240012480%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1239412404%_
                         '3
                         '#f
                         '#f)))
                     (_%declarations12483%_ _%$%e1240012480%_)
                     (_%$%e1240112485%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1239412404%_
                         '4
                         '#f
                         '#f)))
                     (_%previous12488%_ _%$%e1240112485%_)
                     (_%$%e1240212490%_
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref
                         _%$%snapshot1239412404%_
                         '5
                         '#f
                         '#f))))
                (_%$%K1239712467%_
                 _%previous12488%_
                 _%declarations12483%_
                 _%program12478%_
                 _%template12473%_))
              (_%$%E1239612407%_)))))))
