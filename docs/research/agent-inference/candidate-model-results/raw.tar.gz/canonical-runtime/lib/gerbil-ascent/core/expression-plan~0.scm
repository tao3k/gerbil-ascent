(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/expression-plan::timestamp 1791689683)
  (begin
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-call
      (lambda (_%procedure8221%_ _%slots8222%_)
        (let* ((_%$%slots82238257%_ _%slots8222%_)
               (_%$%else82298269%_
                (lambda ()
                  (lambda (_%frame8265%_)
                    (apply _%procedure8221%_
                           (map (lambda (_%slot8267%_)
                                  (vector-ref _%frame8265%_ _%slot8267%_))
                                _%slots8222%_))))))
          (let ((_%$%K82558459%_
                 (lambda () (lambda (_%frame8457%_) (_%procedure8221%_))))
                (_%$%K82528443%_
                 (lambda (_%one8433%_)
                   (lambda (_%frame8435%_)
                     (let* ((_%slot8437%_ _%one8433%_)
                            (_%next8439%_
                             (vector-ref _%frame8435%_ _%slot8437%_)))
                       (_%procedure8221%_ _%next8439%_)))))
                (_%$%K82478412%_
                 (lambda (_%two8395%_ _%one8396%_)
                   (lambda (_%frame8398%_)
                     (let* ((_%slot8400%_ _%one8396%_)
                            (_%next8402%_
                             (vector-ref _%frame8398%_ _%slot8400%_))
                            (_%slot8406%_ _%two8395%_)
                            (_%next8408%_
                             (vector-ref _%frame8398%_ _%slot8406%_)))
                       (_%procedure8221%_ _%next8402%_ _%next8408%_)))))
                (_%$%K82408367%_
                 (lambda (_%three8343%_ _%two8344%_ _%one8345%_)
                   (lambda (_%frame8347%_)
                     (let* ((_%slot8349%_ _%one8345%_)
                            (_%next8351%_
                             (vector-ref _%frame8347%_ _%slot8349%_))
                            (_%slot8355%_ _%two8344%_)
                            (_%next8357%_
                             (vector-ref _%frame8347%_ _%slot8355%_))
                            (_%slot8361%_ _%three8343%_)
                            (_%next8363%_
                             (vector-ref _%frame8347%_ _%slot8361%_)))
                       (_%procedure8221%_
                        _%next8351%_
                        _%next8357%_
                        _%next8363%_)))))
                (_%$%K82318308%_
                 (lambda (_%four8273%_ _%three8275%_ _%two8277%_ _%one8279%_)
                   (lambda (_%frame8282%_)
                     (let* ((_%slot8284%_ _%one8279%_)
                            (_%next8286%_
                             (vector-ref _%frame8282%_ _%slot8284%_))
                            (_%slot8290%_ _%two8277%_)
                            (_%next8292%_
                             (vector-ref _%frame8282%_ _%slot8290%_))
                            (_%slot8296%_ _%three8275%_)
                            (_%next8298%_
                             (vector-ref _%frame8282%_ _%slot8296%_))
                            (_%slot8302%_ _%four8273%_)
                            (_%next8304%_
                             (vector-ref _%frame8282%_ _%slot8302%_)))
                       (_%procedure8221%_
                        _%next8286%_
                        _%next8292%_
                        _%next8298%_
                        _%next8304%_))))))
            (let ((_%$%try-match82258453%_
                   (lambda ()
                     (if (pair? _%$%slots82238257%_)
                         (let ((_%$%tl82548448%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%slots82238257%_)))
                               (_%$%hd82538446%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%slots82238257%_))))
                           (if (null? _%$%tl82548448%_)
                               (let ((_%one8451%_ _%$%hd82538446%_))
                                 (_%$%K82528443%_ _%one8451%_))
                               (if (pair? _%$%tl82548448%_)
                                   (let ((_%$%tl82518424%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl82548448%_)))
                                         (_%$%hd82508422%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl82548448%_))))
                                     (if (null? _%$%tl82518424%_)
                                         (let ((_%one8420%_ _%$%hd82538446%_)
                                               (_%two8427%_ _%$%hd82508422%_))
                                           (_%$%K82478412%_
                                            _%two8427%_
                                            _%one8420%_))
                                         (if (pair? _%$%tl82518424%_)
                                             (let ((_%$%tl82468386%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##cdr _%$%tl82518424%_)))
                                                   (_%$%hd82458384%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (##car _%$%tl82518424%_))))
                                               (if (null? _%$%tl82468386%_)
                                                   (let ((_%one8375%_
                                                          _%$%hd82538446%_)
                                                         (_%two8382%_
                                                          _%$%hd82508422%_)
                                                         (_%three8389%_
                                                          _%$%hd82458384%_))
                                                     (_%$%K82408367%_
                                                      _%three8389%_
                                                      _%two8382%_
                                                      _%one8375%_))
                                                   (if (pair? _%$%tl82468386%_)
                                                       (let ((_%$%tl82398334%_
                                                              (let ()
                                                                (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (not safe))
                        (##cdr _%$%tl82468386%_)))
                     (_%$%hd82388332%_
                      (let () (declare (not safe)) (##car _%$%tl82468386%_))))
                 (if (null? _%$%tl82398334%_)
                     (let ((_%one8316%_ _%$%hd82538446%_)
                           (_%two8323%_ _%$%hd82508422%_)
                           (_%three8330%_ _%$%hd82458384%_)
                           (_%four8337%_ _%$%hd82388332%_))
                       (_%$%K82318308%_
                        _%four8337%_
                        _%three8330%_
                        _%two8323%_
                        _%one8316%_))
                     (_%$%else82298269%_)))
               (_%$%else82298269%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (_%$%else82298269%_))))
                                   (_%$%else82298269%_))))
                         (_%$%else82298269%_)))))
              (if (null? _%$%slots82238257%_)
                  (_%$%K82558459%_)
                  (_%$%try-match82258453%_)))))))
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
      (lambda (_%actions8198%_)
        (if (null? _%actions8198%_)
            (lambda (_%_8200%_) '#t)
            (let* ((_%action8202%_ (car _%actions8198%_))
                   (_%next8204%_
                    (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
                     (cdr _%actions8198%_)))
                   (_%$e8207%_ (vector-ref _%action8202%_ '0)))
              (if (eq? 'guard _%$e8207%_)
                  (let ((_%call8210%_ (vector-ref _%action8202%_ '1)))
                    (lambda (_%frame8212%_)
                      (let ((_%pass?8214%_ (_%call8210%_ _%frame8212%_)))
                        (if (boolean? _%pass?8214%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"ASCENT guard must return a boolean"
                                     _%pass?8214%_)))
                        (if _%pass?8214%_ (_%next8204%_ _%frame8212%_) '#f))))
                  (if (eq? 'binding _%$e8207%_)
                      (let ((_%slot8216%_ (vector-ref _%action8202%_ '1))
                            (_%call8217%_ (vector-ref _%action8202%_ '2)))
                        (lambda (_%frame8219%_)
                          (vector-set!
                           _%frame8219%_
                           _%slot8216%_
                           (_%call8217%_ _%frame8219%_))
                          (_%next8204%_ _%frame8219%_)))
                      '#!void))))))
    (define gerbil-ascent/core/expression-plan#gerbil-ascent-compile-input-guard
      (lambda (_%names8113%_)
        (let* ((_%$%names81148130%_ _%names8113%_)
               (_%$%else81188147%_
                (lambda ()
                  (let ((_%expected8138%_ (list->vector _%names8113%_)))
                    (lambda (_%current8140%_)
                      (let _%compare8142%_ ((_%remaining8144%_ _%current8140%_)
                                            (_%slot8145%_ '0))
                        (if (= _%slot8145%_
                               (let ()
                                 (declare (not safe))
                                 (##vector-length _%expected8138%_)))
                            (null? _%remaining8144%_)
                            (if (pair? _%remaining8144%_)
                                (if (equal? (let ()
                                              (declare (not safe))
                                              (##car _%remaining8144%_))
                                            (vector-ref
                                             _%expected8138%_
                                             _%slot8145%_))
                                    (_%compare8142%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%remaining8144%_))
                                     (+ _%slot8145%_ '1))
                                    '#f)
                                '#f))))))))
          (let ((_%$%K81288195%_ (lambda () null?))
                (_%$%K81258181%_
                 (lambda (_%one8177%_)
                   (lambda (_%current8179%_)
                     (if (pair? _%current8179%_)
                         (if (eq? (let ()
                                    (declare (not safe))
                                    (##car _%current8179%_))
                                  _%one8177%_)
                             (null? (let ()
                                      (declare (not safe))
                                      (##cdr _%current8179%_)))
                             '#f)
                         '#f))))
                (_%$%K81208156%_
                 (lambda (_%two8151%_ _%one8152%_)
                   (lambda (_%current8154%_)
                     (if (pair? _%current8154%_)
                         (if (eq? (let ()
                                    (declare (not safe))
                                    (##car _%current8154%_))
                                  _%one8152%_)
                             (if (pair? (let ()
                                          (declare (not safe))
                                          (##cdr _%current8154%_)))
                                 (if (eq? (cadr _%current8154%_) _%two8151%_)
                                     (null? (cddr _%current8154%_))
                                     '#f)
                                 '#f)
                             '#f)
                         '#f)))))
            (let ((_%$%try-match81168191%_
                   (lambda ()
                     (if (pair? _%$%names81148130%_)
                         (let ((_%$%tl81278186%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%names81148130%_)))
                               (_%$%hd81268184%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%names81148130%_))))
                           (if (null? _%$%tl81278186%_)
                               (let ((_%one8189%_ _%$%hd81268184%_))
                                 (_%$%K81258181%_ _%one8189%_))
                               (if (pair? _%$%tl81278186%_)
                                   (let ((_%$%tl81248168%_
                                          (let ()
                                            (declare (not safe))
                                            (##cdr _%$%tl81278186%_)))
                                         (_%$%hd81238166%_
                                          (let ()
                                            (declare (not safe))
                                            (##car _%$%tl81278186%_))))
                                     (if (null? _%$%tl81248168%_)
                                         (let ((_%one8164%_ _%$%hd81268184%_)
                                               (_%two8171%_ _%$%hd81238166%_))
                                           (_%$%K81208156%_
                                            _%two8171%_
                                            _%one8164%_))
                                         (_%$%else81188147%_)))
                                   (_%$%else81188147%_))))
                         (_%$%else81188147%_)))))
              (if (null? _%$%names81148130%_)
                  (_%$%K81288195%_)
                  (_%$%try-match81168191%_)))))))))
