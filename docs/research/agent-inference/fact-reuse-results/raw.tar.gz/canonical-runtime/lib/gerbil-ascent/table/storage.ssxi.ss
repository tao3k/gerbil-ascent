prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/table

(begin
  (declare-type
   gerbil-ascent/table/storage#+make-state+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+make-state+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/table/storage#+extend+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+extend+)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/table/storage#GerbilAscentStorageProviderContract
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#GerbilAscentStorageProviderContract)
    'clan/poo/object#object::t))
  (declare-type
   gerbil-ascent/table/storage#StorageProvider.
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#StorageProvider.)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-make-state
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-set-batch-admit!
   (@lambda 4
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-extend
   (@lambda 6
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#+canonical-set-storage-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+canonical-set-storage-provider+)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider
   (optimizer-resolve-class
    '(typedecl
      gerbil-ascent/table/storage#gerbil-ascent-eqrel-storage-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider
   (optimizer-resolve-class
    '(typedecl
      gerbil-ascent/table/storage#gerbil-ascent-trrel-storage-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider
   (optimizer-resolve-class
    '(typedecl
      gerbil-ascent/table/storage#gerbil-ascent-trrel-uf-storage-provider)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#+native-storage-providers+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+native-storage-providers+)
    'list::t))
  (declare-class
   gerbil-ascent/table/storage#storage-state-owner::t
   (@class gerbil-ascent/table/storage#storage-state-owner::t
           ()
           (object::t t::t)
           (value phase)
           (value phase)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#storage-state-owner::t)
    'class::t))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner?
   (@predicate gerbil-ascent/table/storage#storage-state-owner::t))
  (declare-type
   gerbil-ascent/table/storage#make-storage-state-owner
   (@constructor gerbil-ascent/table/storage#storage-state-owner::t))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner-value
   (@accessor gerbil-ascent/table/storage#storage-state-owner::t value #t))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner-phase
   (@accessor gerbil-ascent/table/storage#storage-state-owner::t phase #t))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner-value-set!
   (@mutator gerbil-ascent/table/storage#storage-state-owner::t value #t))
  (declare-type
   gerbil-ascent/table/storage#storage-state-owner-phase-set!
   (@mutator gerbil-ascent/table/storage#storage-state-owner::t phase #t))
  (declare-type
   gerbil-ascent/table/storage#&storage-state-owner-value
   (@accessor gerbil-ascent/table/storage#storage-state-owner::t value #f))
  (declare-type
   gerbil-ascent/table/storage#&storage-state-owner-phase
   (@accessor gerbil-ascent/table/storage#storage-state-owner::t phase #f))
  (declare-type
   gerbil-ascent/table/storage#&storage-state-owner-value-set!
   (@mutator gerbil-ascent/table/storage#storage-state-owner::t value #f))
  (declare-type
   gerbil-ascent/table/storage#&storage-state-owner-phase-set!
   (@mutator gerbil-ascent/table/storage#storage-state-owner::t phase #f))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-engine-state
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-owned-states
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-check-state!
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-admit-state!
   (@lambda 1
            #f
            signature:
            (return:
             void::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#owned-storage-rows
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#call-with-storage-state
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-extension
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-engine-extension
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-canonical-view-storage-provider?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-eqrel-state?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+canonical-eqrel-storage-provider+)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#+canonical-uf-storage-provider+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/table/storage#+canonical-uf-storage-provider+)
    't::t))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-canonical-uf-storage-provider?
   (@lambda 1
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-view-extension!
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage)))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view
   (@case-lambda
    (1
     gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__0
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/storage))
    (2
     gerbil-ascent/table/storage#gerbil-ascent-storage-freeze-view__%
     signature:
     (return:
      t::t
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/table/storage))))
  (declare-type
   gerbil-ascent/table/storage#gerbil-ascent-storage-publish-view!
   (@lambda 4
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/table/storage))))
