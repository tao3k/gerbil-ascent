(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/tools/research/candidate-interaction::timestamp
    1791687114)
  (begin
    (define gerbil-ascent/tools/research/candidate-interaction#edges
      '((0 1) (0 2) (1 0) (1 2) (2 0) (2 1)))
    (define gerbil-ascent/tools/research/candidate-interaction#ordinals
      (lambda (_%n2323%_)
        (let _%loop2325%_ ((_%i2327%_ '0))
          (if (= _%i2327%_ _%n2323%_)
              '()
              (cons _%i2327%_ (_%loop2325%_ (+ _%i2327%_ '1)))))))
    (define gerbil-ascent/tools/research/candidate-interaction#graph
      (lambda (_%mask2318%_)
        (let ((__tmp5151
               (lambda (_%edge2320%_ _%index2321%_)
                 (if (zero? (bitwise-and
                             _%mask2318%_
                             (arithmetic-shift '1 _%index2321%_)))
                     '#f
                     _%edge2320%_)))
              (__tmp5150
               (gerbil-ascent/tools/research/candidate-interaction#ordinals
                '6)))
          (declare (not safe))
          (filter-map__1
           __tmp5151
           gerbil-ascent/tools/research/candidate-interaction#edges
           __tmp5150))))
    (define gerbil-ascent/tools/research/candidate-interaction#walk
      (lambda (_%pairs2292%_ _%origin2293%_ _%even?2294%_)
        (let _%loop2296%_ ((_%pending2298%_
                            (let ((__tmp5159
                                   (lambda (_%e2314%_)
                                     (list (cadr _%e2314%_) '1)))
                                  (__tmp5158
                                   (filter (lambda (_%e2316%_)
                                             (= _%origin2293%_
                                                (car _%e2316%_)))
                                           _%pairs2292%_)))
                              (declare (not safe))
                              (##map __tmp5159 __tmp5158)))
                           (_%seen2299%_ '()))
          (if (null? _%pending2298%_)
              (let ((__tmp5152
                     (lambda (_%v2301%_)
                       (if (let ((__tmp5153
                                  (lambda (_%s2303%_)
                                    (and (= _%v2301%_ (car _%s2303%_))
                                         (or (not _%even?2294%_)
                                             (= '0 (cadr _%s2303%_)))))))
                             (declare (not safe))
                             (ormap__0 __tmp5153 _%seen2299%_))
                           _%v2301%_
                           '#f))))
                (declare (not safe))
                (filter-map__0 __tmp5152 '(0 1 2)))
              (let ((_%s2308%_ (car _%pending2298%_)))
                (if (member _%s2308%_ _%seen2299%_)
                    (_%loop2296%_ (cdr _%pending2298%_) _%seen2299%_)
                    (_%loop2296%_
                     (let ((__tmp5157 (cdr _%pending2298%_))
                           (__tmp5154
                            (let ((__tmp5156
                                   (lambda (_%e2310%_)
                                     (list (cadr _%e2310%_)
                                           (- '1 (cadr _%s2308%_)))))
                                  (__tmp5155
                                   (filter (lambda (_%e2312%_)
                                             (= (car _%s2308%_)
                                                (car _%e2312%_)))
                                           _%pairs2292%_)))
                              (declare (not safe))
                              (##map __tmp5156 __tmp5155))))
                       (declare (not safe))
                       (##append __tmp5157 __tmp5154))
                     (cons _%s2308%_ _%seen2299%_))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#expected
      (lambda (_%case-id2283%_ _%pairs2284%_)
        (if (= _%case-id2283%_ '2)
            (let ((__tmp5160
                   (filter (lambda (_%v2286%_)
                             (member _%v2286%_
                                     (gerbil-ascent/tools/research/candidate-interaction#walk
                                      _%pairs2284%_
                                      '1
                                      '#f)))
                           (gerbil-ascent/tools/research/candidate-interaction#walk
                            _%pairs2284%_
                            '0
                            '#f))))
              (declare (not safe))
              (##map list __tmp5160))
            (let ((__tmp5161
                   (let ((__tmp5162
                          (lambda (_%u2288%_)
                            (map (lambda (_%v2290%_)
                                   (list _%u2288%_ _%v2290%_))
                                 (gerbil-ascent/tools/research/candidate-interaction#walk
                                  _%pairs2284%_
                                  _%u2288%_
                                  (= _%case-id2283%_ '1))))))
                     (declare (not safe))
                     (##map __tmp5162 '(0 1 2)))))
              (declare (not safe))
              (##apply append __tmp5161)))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__%
      (lambda (_%case-id2265%_ _%rules2266%_ _%row-budget2267%_)
        (let ((__tmp5165 (if (= _%case-id2265%_ '2) '((relation both 1)) '()))
              (__tmp5164
               (map (lambda (_%r2269%_) (cons 'rule _%r2269%_)) _%rules2266%_))
              (__tmp5163
               (list (if (= _%case-id2265%_ '2)
                         '(query both ?z)
                         '(query path ?x ?y))
                     (list 'limits '16 _%row-budget2267%_ '128))))
          (declare (not safe))
          (##append
           '(candidate (relation path 2))
           __tmp5165
           __tmp5164
           __tmp5163))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__0
      (lambda (_%case-id2274%_ _%rules2275%_)
        (let ((_%row-budget2277%_ '64))
          (gerbil-ascent/tools/research/candidate-interaction#proposal__%
           _%case-id2274%_
           _%rules2275%_
           _%row-budget2277%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal
      (lambda _g5166_
        (let ((_g5167_ (let () (declare (not safe)) (##length _g5166_))))
          (cond ((let () (declare (not safe)) (##fx= _g5167_ 2))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__0
                        _g5166_))
                ((let () (declare (not safe)) (##fx= _g5167_ 3))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__%
                        _g5166_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/tools/research/candidate-interaction#proposal
                  _g5166_))))))
    (define gerbil-ascent/tools/research/candidate-interaction#source
      (lambda (_%case-id2260%_ _%generation2261%_ _%pairs2262%_)
        (let ((__tmp5171
               (let ((__tmp5172 (number->string _%case-id2260%_)))
                 (declare (not safe))
                 (##string-append '"library-candidate-" __tmp5172)))
              (__tmp5168
               (let ((__tmp5170 (list (list 'edge '2 _%pairs2262%_)))
                     (__tmp5169
                      (if (= _%case-id2260%_ '2)
                          '((left 1 ((0))) (right 1 ((1))))
                          '())))
                 (declare (not safe))
                 (##append __tmp5170 __tmp5169))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           __tmp5171
           _%generation2261%_
           __tmp5168))))
    (define gerbil-ascent/tools/research/candidate-interaction#wire
      (lambda (_%x2255%_)
        (if (symbol? _%x2255%_)
            (let () (declare (not safe)) (##symbol->string _%x2255%_))
            (if (pair? _%x2255%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#wire
                         _%x2255%_))
                _%x2255%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#symbols
      (lambda (_%x2249%_)
        (if (string? _%x2249%_)
            (let () (declare (not safe)) (##string->symbol _%x2249%_))
            (if (list? _%x2249%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#symbols
                         _%x2249%_))
                (if (and (integer? _%x2249%_) (exact? _%x2249%_))
                    _%x2249%_
                    (let ()
                      (declare (not safe))
                      (error '"invalid rule datum")))))))
    (define gerbil-ascent/tools/research/candidate-interaction#observe
      (lambda (_%case-id2225%_ _%generation2226%_ _%pairs2227%_ _%rules2228%_)
        (let* ((_%s2230%_
                (gerbil-ascent/tools/research/candidate-interaction#source
                 _%case-id2225%_
                 _%generation2226%_
                 _%pairs2227%_))
               (_%p2232%_
                (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                 _%case-id2225%_
                 _%rules2228%_))
               (_%r2234%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                   _%s2230%_
                   _%p2232%_
                   '#f)))
               (_%wanted2236%_
                (gerbil-ascent/tools/research/candidate-interaction#expected
                 _%case-id2225%_
                 _%pairs2227%_))
               (_%f2238%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                   _%s2230%_
                   _%p2232%_
                   _%r2234%_
                   _%wanted2236%_)))
               (_%ht2241%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '10
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"generation" _%generation2226%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"edges" _%pairs2227%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"expected" _%wanted2236%_))
          (let ((__tmp5173
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%r2234%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"nativeStatus" __tmp5173))
          (let ((__tmp5174
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%r2234%_ '7 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"actual" __tmp5174))
          (let ((__tmp5175
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2238%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"status" __tmp5175))
          (let ((__tmp5176
                 (map (lambda (_%d2244%_)
                        (let ((_%ht2246%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp5177
                                 (gerbil-ascent/tools/research/candidate-interaction#wire
                                  (##structure-ref
                                   _%d2244%_
                                   '1
                                   gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                   '#f))))
                            (declare (not safe))
                            (__hash-put! _%ht2246%_ '"code" __tmp5177))
                          (let ((__tmp5178
                                 (##structure-ref
                                  _%d2244%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                  '#f)))
                            (declare (not safe))
                            (__hash-put! _%ht2246%_ '"detail" __tmp5178))
                          _%ht2246%_))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%r2234%_ '8 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"diagnostics" __tmp5176))
          (let ((__tmp5179
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2238%_ '2 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"reason" __tmp5179))
          (let ((__tmp5180
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2238%_ '3 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"missing" __tmp5180))
          (let ((__tmp5181
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2238%_ '4 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2241%_ '"extra" __tmp5181))
          _%ht2241%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#correct
      '(((path ?x ?y) (edge ?x ?y)) ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))
    (define gerbil-ascent/tools/research/candidate-interaction#even-rules
      '(((path ?x ?z) (edge ?x ?y) (edge ?y ?z))
        ((path ?x ?w) (path ?x ?y) (edge ?y ?z) (edge ?z ?w))))
    (define gerbil-ascent/tools/research/candidate-interaction#both-rules
      (let ()
        (declare (not safe))
        (##append
         gerbil-ascent/tools/research/candidate-interaction#correct
         '(((both ?z) (left ?x) (right ?y) (path ?x ?z) (path ?y ?z))))))
    (define gerbil-ascent/tools/research/candidate-interaction#grade
      (lambda (_%case-id2218%_ _%rules2219%_)
        (let ((__tmp5185
               (lambda (_%mask2221%_)
                 (gerbil-ascent/tools/research/candidate-interaction#observe
                  _%case-id2218%_
                  _%mask2221%_
                  (gerbil-ascent/tools/research/candidate-interaction#graph
                   _%mask2221%_)
                  _%rules2219%_)))
              (__tmp5182
               (let ((__tmp5184
                      (lambda (_%mask2223%_)
                        (not (let ()
                               (declare (not safe))
                               (##member _%mask2223%_ '(0 1 3 9))))))
                     (__tmp5183
                      (gerbil-ascent/tools/research/candidate-interaction#ordinals
                       '64)))
                 (declare (not safe))
                 (##filter __tmp5184 __tmp5183))))
          (declare (not safe))
          (##map __tmp5185 __tmp5182))))
    (define gerbil-ascent/tools/research/candidate-interaction#qualification
      (lambda (_%group2100%_)
        (let ((_%checks2102%_ '0)
              (_%mutants2103%_
               (list gerbil-ascent/tools/research/candidate-interaction#correct
                     (let ()
                       (declare (not safe))
                       (##cdr gerbil-ascent/tools/research/candidate-interaction#correct))
                     (list (let ()
                             (declare (not safe))
                             (##car gerbil-ascent/tools/research/candidate-interaction#correct)))
                     '(((path ?x ?y) (edge ?x ?y))
                       ((path ?x ?z) (path ?x ?y) (edge ?x ?z)))
                     '(((path ?x ?y) (edge ?y ?x))
                       ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))))
          (let ((__tmp5187
                 (lambda (_%rules2105%_ _%index2106%_)
                   (if (= _%group2100%_ _%index2106%_)
                       (let ((_%mismatches2108%_ '0))
                         (let ((__tmp5189
                                (lambda (_%mask2110%_)
                                  (let ((_%r2112%_
                                         (gerbil-ascent/tools/research/candidate-interaction#observe
                                          '0
                                          _%mask2110%_
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           _%mask2110%_)
                                          _%rules2105%_)))
                                    (if (string=?
                                         (let* ((_%h2114%_ _%r2112%_)
                                                (_%key2117%_ '"nativeStatus")
                                                (_%default2120%_ absent-obj)
                                                (_%h2124%_ _%h2114%_)
                                                (_%h2126%_ _%h2124%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2126%_
                                            _%key2117%_
                                            _%default2120%_))
                                         '"complete")
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"incomplete control"
                                                 _%r2112%_)))
                                    (if (string=?
                                         (let* ((_%h2144%_ _%r2112%_)
                                                (_%key2147%_ '"status")
                                                (_%default2150%_ absent-obj)
                                                (_%h2154%_ _%h2144%_)
                                                (_%h2156%_ _%h2154%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2156%_
                                            _%key2147%_
                                            _%default2150%_))
                                         '"match")
                                        '#!void
                                        (set! _%mismatches2108%_
                                              (+ _%mismatches2108%_ '1)))
                                    (set! _%checks2102%_
                                          (+ _%checks2102%_ '1)))))
                               (__tmp5188
                                (gerbil-ascent/tools/research/candidate-interaction#ordinals
                                 '64)))
                           (declare (not safe))
                           (##for-each __tmp5189 __tmp5188))
                         (if (if (= _%index2106%_ '0)
                                 (= _%mismatches2108%_ '0)
                                 (> _%mismatches2108%_ '0))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"mutant control failed"))))
                       '#!void)))
                (__tmp5186
                 (gerbil-ascent/tools/research/candidate-interaction#ordinals
                  '5)))
            (declare (not safe))
            (##for-each __tmp5187 _%mutants2103%_ __tmp5186))
          (let ((__tmp5191
                 (lambda (_%id2168%_ _%rules2169%_)
                   (if (= _%group2100%_ (+ _%id2168%_ '4))
                       (let ((__tmp5193
                              (lambda (_%mask2171%_)
                                (if (string=?
                                     (let* ((_%h2173%_
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2168%_
                                              _%mask2171%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2171%_)
                                              _%rules2169%_))
                                            (_%key2176%_ '"status")
                                            (_%default2179%_ absent-obj)
                                            (_%h2183%_ _%h2173%_)
                                            (_%h2185%_ _%h2183%_))
                                       (declare (not safe))
                                       (__hash-ref__%
                                        _%h2185%_
                                        _%key2176%_
                                        _%default2179%_))
                                     '"match")
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"independent walk disagrees")))
                                (set! _%checks2102%_ (+ _%checks2102%_ '1))))
                             (__tmp5192
                              (gerbil-ascent/tools/research/candidate-interaction#ordinals
                               '64)))
                         (declare (not safe))
                         (##for-each __tmp5193 __tmp5192))
                       '#!void)))
                (__tmp5190
                 (list gerbil-ascent/tools/research/candidate-interaction#even-rules
                       gerbil-ascent/tools/research/candidate-interaction#both-rules)))
            (declare (not safe))
            (##for-each __tmp5191 '(1 2) __tmp5190))
          (if (= _%group2100%_ '7)
              (begin
                (let* ((_%s2199%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '8)))
                       (_%p2201%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct))
                       (_%r2203%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2199%_
                           _%p2201%_
                           '#f))))
                  (if (eq? (let ((__tmp5194
                                  (let ((__tmp5196
                                         (gerbil-ascent/tools/research/candidate-interaction#source
                                          '0
                                          '1
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8)))
                                        (__tmp5195
                                         (gerbil-ascent/tools/research/candidate-interaction#expected
                                          '0
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                     __tmp5196
                                     _%p2201%_
                                     _%r2203%_
                                     __tmp5195))))
                             (declare (not safe))
                             (##unchecked-structure-ref __tmp5194 '2 '#f '#f))
                           'unbound)
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"stale receipt accepted"))))
                (let* ((_%s2206%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '9)))
                       (_%p2208%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__%
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct
                         '1))
                       (_%r2210%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2206%_
                           _%p2208%_
                           '#f)))
                       (_%f2212%_
                        (let ((__tmp5197
                               (gerbil-ascent/tools/research/candidate-interaction#expected
                                '0
                                (gerbil-ascent/tools/research/candidate-interaction#graph
                                 '9))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                           _%s2206%_
                           _%p2208%_
                           _%r2210%_
                           __tmp5197))))
                  (if (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%f2212%_ '1 '#f '#f))
                           'match)
                      (let ()
                        (declare (not safe))
                        (error '"bounded failure became match"))
                      '#!void)))
              '#!void)
          (let ((_%ht2215%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '3
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2215%_ '"checks" _%checks2102%_))
            (let ((__tmp5198 (= _%group2100%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2215%_ '"staleRejected" __tmp5198))
            (let ((__tmp5199 (= _%group2100%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2215%_ '"boundedNotMatch" __tmp5199))
            _%ht2215%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#dispatch
      (lambda (_%request1987%_)
        (let ((_%op2014%_
               (let* ((_%h1989%_ _%request1987%_)
                      (_%key1992%_ '"op")
                      (_%default1995%_ absent-obj)
                      (_%h1999%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h1989%_)))
                      (_%h2001%_ _%h1999%_))
                 (declare (not safe))
                 (__hash-ref__% _%h2001%_ _%key1992%_ _%default1995%_))))
          (if (string=? _%op2014%_ '"qualify")
              (gerbil-ascent/tools/research/candidate-interaction#qualification
               (let* ((_%h2016%_ _%request1987%_)
                      (_%key2019%_ '"group")
                      (_%default2022%_ absent-obj)
                      (_%h2026%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h2016%_)))
                      (_%h2028%_ _%h2026%_))
                 (declare (not safe))
                 (__hash-ref__% _%h2028%_ _%key2019%_ _%default2022%_)))
              (let* ((_%id2065%_
                      (let* ((_%h2041%_ _%request1987%_)
                             (_%key2044%_ '"case")
                             (_%default2047%_ absent-obj)
                             (_%h2051%_
                              (let ()
                                (declare (not safe))
                                (cast HashTable::interface _%h2041%_)))
                             (_%h2053%_ _%h2051%_))
                        (declare (not safe))
                        (__hash-ref__% _%h2053%_ _%key2044%_ _%default2047%_)))
                     (_%rules2092%_
                      (gerbil-ascent/tools/research/candidate-interaction#symbols
                       (let* ((_%h2067%_ _%request1987%_)
                              (_%key2070%_ '"rules")
                              (_%default2073%_ absent-obj)
                              (_%h2077%_
                               (let ()
                                 (declare (not safe))
                                 (cast HashTable::interface _%h2067%_)))
                              (_%h2079%_ _%h2077%_))
                         (declare (not safe))
                         (__hash-ref__%
                          _%h2079%_
                          _%key2070%_
                          _%default2073%_)))))
                (if (let ()
                      (declare (not safe))
                      (##member _%id2065%_ '(0 1 2)))
                    '#!void
                    (let () (declare (not safe)) (error '"invalid case")))
                (if (string=? _%op2014%_ '"grade")
                    (gerbil-ascent/tools/research/candidate-interaction#grade
                     _%id2065%_
                     _%rules2092%_)
                    (if (string=? _%op2014%_ '"feedback")
                        (let ((__tmp5200
                               (lambda (_%mask2097%_)
                                 (gerbil-ascent/tools/research/candidate-interaction#observe
                                  _%id2065%_
                                  _%mask2097%_
                                  (gerbil-ascent/tools/research/candidate-interaction#graph
                                   _%mask2097%_)
                                  _%rules2092%_))))
                          (declare (not safe))
                          (##map __tmp5200 '(0 1 3 9)))
                        (let ()
                          (declare (not safe))
                          (error '"invalid operation")))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#main
      (lambda _%args1918%_
        (let () (declare (not safe)) (displayln '"{\"ready\":true}"))
        (force-output)
        (let _%loop1920%_ ()
          (let ((_%line1923%_ (read-line)))
            (if (eof-object? _%line1923%_)
                '#!void
                (begin
                  (let ((__tmp5201
                         (let ((__tmp5202
                                (let ((__tmp5206
                                       (lambda (_%$%g19241926%_)
                                         (let* ((_%e1930%_ _%$%g19241926%_)
                                                (_%ht1932%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (make-hash-table__%
                                                    '#f
                                                    '1
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value))))
                                           (let ((__tmp5207
                                                  (let ()
                                                    (declare (not safe))
                                                    (std/error#exception->string
                                                     _%e1930%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%ht1932%_
                                              '"error"
                                              __tmp5207))
                                           _%ht1932%_)))
                                      (__tmp5203
                                       (lambda ()
                                         (gerbil-ascent/tools/research/candidate-interaction#dispatch
                                          (let ((__tmp5205
                                                 (lambda ()
                                                   (call-with-input-string
                                                    _%line1923%_
                                                    std/encoding/json/util#read-json)))
                                                (__tmp5204
                                                 (let* ((_%object-as-hash1938%_
                                                         '#t)
                                                        (_%key-as-symbol1941%_
                                                         '#f)
                                                        (_%array-as-vector1944%_
                                                         '#f)
                                                        (_%key-as-symbol1949%_
                                                         _%key-as-symbol1941%_)
                                                        (_%array-as-vector1967%_
                                                         _%array-as-vector1944%_)
                                                        (_%object-as-hash1977%_
                                                         _%object-as-hash1938%_))
                                                   (declare (not safe))
                                                   (std/encoding/json/env#__make-JSONReadOptions__%
                                                    '#f
                                                    _%key-as-symbol1949%_
                                                    _%array-as-vector1967%_
                                                    _%object-as-hash1977%_))))
                                            (declare (not safe))
                                            (call-with-parameters__1
                                             __tmp5205
                                             std/encoding/json/env#current-json-read-options
                                             __tmp5204))))))
                                  (declare (not safe))
                                  (__with-catch __tmp5206 __tmp5203))))
                           (declare (not safe))
                           (std/encoding/json/util#json->string __tmp5202))))
                    (declare (not safe))
                    (displayln __tmp5201))
                  (force-output)
                  (_%loop1920%_)))))))))
