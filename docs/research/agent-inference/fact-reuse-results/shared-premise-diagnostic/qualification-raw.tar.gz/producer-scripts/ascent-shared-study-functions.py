# Minimal shared-premise diagnostic in the existing Python project consumer.
SHARED_CANDIDATE = ['candidate', ['relation', 'path', 2], ['relation', 'ready', 1],
    ['rule', ['path', '?x', '?y'], ['edge', '?x', '?y']],
    ['rule', ['path', '?x', '?z'], ['path', '?x', '?y'], ['edge', '?y', '?z']],
    ['rule', ['ready', '?f'], ['need', '?f', '?a', '?b', '?c', '?d'],
        ['path', '?a', '?b'], ['path', '?c', '?d']],
    ['query', 'ready', '?f'], ['limits', 256, 1024, 1024]]
SHARED_QUESTION = 'Which of the listed transitions are permitted by the rules? Return their IDs.'
SHARED_TOOL = {'type': 'function', 'name': 'submit_answer',
    'description': 'Return the permitted transition IDs.', 'parameters': {'type': 'object',
    'properties': {'permitted': {'type': 'array', 'items': {'type': 'integer'}}},
    'required': ['permitted'], 'additionalProperties': False}}
SHARED_RUBRIC = '''Label only explicit atomic episodes in supplied visible reasoning. Each label has a verbatim contiguous quote, zero-based occurrence, category, concluded atom and explicitly stated ordered premises. Categories: premise_consumed (uses established evidence without proving it again), positive_derivation (an actual supported inference), absence_recheck (explicit argument that a path or transition is absent), new_residual (a supported inference about the current downstream obligation), arithmetic (resource/objective computation), ambiguous (unsupported or unclear). Relations: edge, path, ready. ready ID requires both paths of that needs row. Atom and premise endpoints must appear literally in the quote. No edges or premises may be supplied from your own source knowledge. A reference/assertion alone is not a derivation. For arithmetic and ambiguous, atom and premises may be empty. Do not infer unexposed reasoning. Do not add labels merely to populate a category. Do not repair wrong IDs. Include explicit negative reasoning, but do not infer absence from missing text. You are not given arm, score or cost; supplied reasoning can still reveal its condition. Return labels in text order. Completeness is not guaranteed.'''
SHARED_LABEL_TOOL = {'type': 'function', 'name': 'annotate', 'description': 'Record literal reasoning episodes.',
    'parameters': {'type': 'object', 'properties': {'episodes': {'type': 'array', 'items': {
    'type': 'object', 'properties': {'quote': {'type': 'string'}, 'occurrence': {'type': 'integer'},
    'category': {'type': 'string', 'enum': ['premise_consumed', 'positive_derivation', 'absence_recheck', 'new_residual', 'arithmetic', 'ambiguous']},
    'atom': {'type': 'array', 'items': {'type': ['string', 'integer']}},
    'premises': {'type': 'array', 'items': {'type': 'array', 'items': {'type': ['string', 'integer']}}}},
    'required': ['quote', 'occurrence', 'category', 'atom', 'premises'], 'additionalProperties': False}}},
    'required': ['episodes'], 'additionalProperties': False}}


def shared_tasks():
    edges = [[0,1],[1,2],[0,10],[10,2],[3,4],[5,6],[7,8],[8,9],[11,12]]
    needs = [[0,0,2,3,4],[1,0,2,4,3],[2,0,2,5,6],[3,0,2,6,5],[4,0,2,7,9],[5,0,2,9,7]]
    return [{'id': f'shared-premise-{i}', 'edges': edges if i == 0 else
              [e for e in edges if e != [5,6]] + [[6,5]], 'needs': needs,
              'schedule': [[0,1],[2,3],[4,5]], 'sharedAtom': ['path',0,2]} for i in range(2)]


def shared_source(task, generation=0, edges=None):
    return {'identity': task['id'], 'generation': generation,
            'relations': [['edge',2,task['edges'] if edges is None else edges], ['need',5,task['needs']]]}


def shared_truth(task, atom):
    """Independent finite graph oracle for this fixture, never production evaluation."""
    if not isinstance(atom,list) or not atom or atom[0] not in ('edge','path','ready'):
        raise ValueError('unknown fixture atom')
    if any(type(n) is not int for n in atom[1:]): raise ValueError('noninteger atom')
    if atom[0] == 'edge':
        if len(atom) != 3: raise ValueError('edge arity')
        return atom[1:] in task['edges']
    if atom[0] == 'ready':
        if len(atom) != 2: raise ValueError('ready arity')
        n = next(n for n in task['needs'] if n[0] == atom[1])
        return shared_truth(task,['path',n[1],n[2]]) and shared_truth(task,['path',n[3],n[4]])
    if len(atom) != 3: raise ValueError('path arity')
    todo = [b for a,b in task['edges'] if a == atom[1]]; seen = set()
    while todo:
        at = todo.pop()
        if at == atom[2]: return True
        if at in seen: continue
        seen.add(at); todo.extend(b for a,b in task['edges'] if a == at)
    return False


def shared_atoms(task, ids):
    return [list(a) for a in dict.fromkeys(tuple(a) for n in task['needs'] if n[0] in ids
        for a in (['path',n[1],n[2]], ['path',n[3],n[4]]))]


def shared_packet(store, task, ids):
    src=shared_source(task); begin=time.monotonic(); r=store.resolve(src,SHARED_CANDIDATE)
    if r['status'] != 'verified': raise ValueError('unverified native evidence')
    facts=[]; fragments=[]
    for atom in shared_atoms(task,ids):
        f=store.fact(src,SHARED_CANDIDATE,r['handle'],atom)
        if f['status'] not in ('verified','finite-absent'): raise ValueError('unknown native fact')
        if (f['status']=='verified') != shared_truth(task,atom): raise ValueError('native/oracle disagreement')
        facts.append({'atom':atom,'status':f['status']})
        if f['status']=='verified':
            p=store.fragment(src,SHARED_CANDIDATE,r['handle'],atom)
            if p['status']!='verified': raise ValueError('unverified fragment')
            fragments.append({'atom':atom,'roots':p['roots'],'nodes':p['nodes']})
    return {'scope':dict(r['scope']),'facts':facts,'fragments':fragments,
            'nodeEncoding':['id','kind','relation','row','ruleLabel','inputs'],
            'nativeStats':store.stats(),'nativeSeconds':time.monotonic()-begin,'reused':r['reused']}


def shared_qualify(engine):
    from ascent_engine.evidence import ComputationalEvidence
    results=[]
    for task in shared_tasks():
        with ComputationalEvidence(engine) as store:
            src=shared_source(task); first=store.resolve(src,SHARED_CANDIDATE)
            assert first['status']=='verified'
            assert sorted(first['rows'])==[[n[0]] for n in task['needs'] if shared_truth(task,['ready',n[0]])]
            packets=[shared_packet(store,task,ids) for ids in task['schedule']]
            assert all(p['nativeStats']['proof-builds']==1 and p['reused'] for p in packets)
            shared=[next(f for f in p['fragments'] if f['atom']==task['sharedAtom']) for p in packets]
            assert shared[0]==shared[1]==shared[2]
            for p in packets:
                for f in p['fragments']:
                    ids=set();assert all(not any(parent not in ids for parent in n[5]) and
                        not (n[0] in ids) and (ids.add(n[0]) is None) for n in f['nodes'])
                    assert set(f['roots']) <= ids
            handle=first['handle']; remaining=[e for e in task['edges'] if e != [1,2]]
            alt=shared_source(task,1,remaining)
            assert store.fact(alt,SHARED_CANDIDATE,handle,task['sharedAtom'])['status']=='unknown'
            ar=store.resolve(alt,SHARED_CANDIDATE);assert ar['status']=='verified'
            assert store.fact(alt,SHARED_CANDIDATE,ar['handle'],task['sharedAtom'])['status']=='verified'
            removed=shared_source(task,2,[e for e in remaining if e != [10,2]])
            assert store.fragment(removed,SHARED_CANDIDATE,ar['handle'],task['sharedAtom'])['status']=='unknown'
            rr=store.resolve(removed,SHARED_CANDIDATE);assert rr['status']=='verified' and rr['rows']==[]
            assert store.fact(removed,SHARED_CANDIDATE,rr['handle'],task['sharedAtom'])['status']=='finite-absent'
            mutants=[]
            for kind in ('missing-rule','wrong-join'):
                mutant=copy.deepcopy(SHARED_CANDIDATE)
                if kind=='missing-rule':mutant.pop(4)
                else:mutant[4][-1]=['edge','?x','?z']
                bad=store.resolve(src,mutant);assert bad['status']=='verified'
                # Grade intermediate shared P too: final ready rows alone miss this wrong join.
                assert store.fact(src,mutant,bad['handle'],['path',0,2])['status']=='finite-absent'
                assert shared_truth(task,['path',0,2])
                assert store.fact(src,mutant,handle,['path',0,2])['status']=='unknown'
                mutants.append(kind)
            results.append({'task':task['id'],'packets':packets,'alternativeSupportPreserved':True,
                'staleHandlesRefused':True,'withdrawalRecomputed':True,'mutantsDistinguished':mutants})
    return results


def shared_freeze(library, directory):
    directory.mkdir(parents=True,exist_ok=False)
    from ascent_engine.evidence import ComputationalEvidence
    import ascent_engine.evidence as evidence_module
    root=s.ROOT; library=library.resolve(); dst=directory/library.name;shutil.copy2(library,dst)
    # Use the installed API extension when available, rather than falling back silently.
    with Engine() as engine:
        qualification=shared_qualify(engine)
    (directory/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
    capture=json.loads((root/'.cache/ascent/candidate-interaction/runtime/source-capture.json').read_text())
    abi=root/'.cache/ascent/candidate-interaction/shared-premise-ffi-build'
    extra=json.loads((abi/'source-binding.json').read_text())
    binding={**capture['sourceSha256'],**extra}
    names=['bindings/c/runtime.c','bindings/c/ascent.h','python/pyproject.toml','build.ss',
           'python/src/ascent_engine/__init__.py','python/src/ascent_engine/evidence.py',
           'python/src/ascent_engine/conversation.py','python/src/ascent_engine/build.py',
           'python/src/ascent_engine/api_build.py','python/src/ascent_test_support/evidence_chain_study.py',
           'python/src/ascent_test_support/model_study.py','python/src/ascent_test_support/movie_study.py',
           'python/src/ascent_test_support/inference_reuse_study.py','python/src/ascent_test_support/complex_movie_study.py',
           'python/src/ascent_test_support/evidence_chain_workload.py','python/src/ascent_test_support/query_contract.py',
           'packages/proofs/quint/SharedPremiseReuse.qnt','packages/proofs/quint/VerifiedCandidate.qnt',
           'packages/proofs/lean/ProofDag.lean','docs/research/agent-inference/factor-reuse-2026-study.org']
    for name in names: binding[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
    for name,h in binding.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,'source drift '+name
        target=directory/'inputs'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
    api=Path(os.environ['ASCENT_CFFI_RECEIPT']);api_receipt=json.loads(api.read_text())
    assert api_receipt['producerReceiptSha256'] and api_receipt['headerSha256']==binding['bindings/c/ascent.h']
    # API bundling changes the dylib install name, so its hash is separately bound.
    shutil.copy2(api,directory/'cffi-api-receipt.json')
    shutil.copy2(library.with_suffix(library.suffix+'.json'),directory/'native-build-receipt.json')
    metadata={'schema':'ascent.shared-premise-diagnostic.v1','tasks':shared_tasks(),'candidate':SHARED_CANDIDATE,
        'question':SHARED_QUESTION,'tool':SHARED_TOOL,'arms':['baseline','facts','scheme'],
        'orders':[['baseline','facts','scheme'],['scheme','facts','baseline']],
        'model':'deepseek-flash','reasoningEffort':'low','totalBudget':32768,'maxOutputTokens':32768,
        'minimumOutputTokens':1024,'inputPadding':256,'maxCalls':3,'checkpoints':[4096,8192,16384,24576,32768],
        'library':library.name,'librarySha256':hashlib.sha256(library.read_bytes()).hexdigest(),
        'inputs':binding,'qualificationSha256':hashlib.sha256((directory/'qualification.json').read_bytes()).hexdigest(),
        'annotationRubric':SHARED_RUBRIC,'annotationTool':SHARED_LABEL_TOOL,'annotationPasses':2,'annotationOutputCap':8192,
        'annotationRules':'Exact nonoverlapping quotes; endpoint literals; independent finite truth; explicit ordered edge/path chain or ready conjunction for positive inference. premise_consumed must refer to an earlier or supplied true atom. new_residual is derived by classification after validation, never trusted from label name. A repeated positive atom is counted across different questions in the same source scope. Exact-premise repeat reported separately. Negative claims require an explicit negative argument and independently absent atom, but completeness of the quoted absence argument is unproven. Arithmetic and ambiguity are reported without assigning cached-atom savings. Rejected/empty/missing labels remain visible. Two blind passes of the SAME model are correlated annotations, not independent-rater validation.',
        'claims':{'correctReuse':'Equal native support nodes across different obligations; source/handle binding and independent answer agreement.',
                  'reducedRepetition':'Requires directly supported baseline repetitions plus validated annotation coverage; native hits alone are insufficient.',
                  'newInference':'Distinct correct downstream answers and qualified nonsupplied consequences after the first obligation. No optimization or depth claim.'},
        'controls':'Same task, sibling schedule, history policy, answer schema and input-plus-all-output cap. No pruning, ranking, optimal answer or anti-repetition instruction. Fact and Scheme supply identical atomic outcomes; Scheme adds checked ancestor-closed fragments. Unused reservations are censored, not savings. All failed calls and unknown usage retained.',
        'sourceState':{'head':__import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dirtySourceSnapshot':True,'cleanCheckoutReproductionVerified':False},
        'papers':[{'id':'BYODS','url':'https://kmicinski.com/assets/byods.pdf','role':'concretization/delta semantics; separate from model efficacy'},
                  {'id':'DatalogBench-v1','url':'https://arxiv.org/html/2609.37233v1','role':'held-out execution and oracle mutation tests'},
                  {'id':'MiniCache-v1','url':'https://arxiv.org/html/2607.20507v1','role':'shared computation with different request variables'}],
        'formalBoundary':'SharedPremiseReuse.qnt models finite fixture truth and source-generation admission. ProofDag.lean proves specified ordered positive-DAG soundness under premises, not CFFI correctness or model behavior. VerifiedCandidate assumes independent grader validity. Native correspondence receipts are separate.'}
    (directory/'plan.json').write_text(json.dumps(metadata,indent=2)+'\n')
    (directory/'plan.sha256').write_text(hashlib.sha256((directory/'plan.json').read_bytes()).hexdigest()+'\n')
    print('SHARED_PREMISE_FROZEN', (directory/'plan.sha256').read_text().strip(),flush=True)


def shared_check(directory, _output=None):
    plan=json.loads((directory/'plan.json').read_text())
    assert hashlib.sha256((directory/'plan.json').read_bytes()).hexdigest()==(directory/'plan.sha256').read_text().strip()
    assert hashlib.sha256((directory/plan['library']).read_bytes()).hexdigest()==plan['librarySha256']
    assert hashlib.sha256((directory/'qualification.json').read_bytes()).hexdigest()==plan['qualificationSha256']
    for name,h in plan['inputs'].items():
        path=Path(name)
        assert not path.is_absolute() and '..' not in path.parts and '.cache' not in path.parts
        assert hashlib.sha256((directory/'inputs'/path).read_bytes()).hexdigest()==h,'snapshot drift '+name
        assert hashlib.sha256((s.ROOT/path).read_bytes()).hexdigest()==h,'loaded checkout drift '+name
    return plan


def shared_action(terminal):
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('duplicate answer key')
            d[k]=v
        return d
    out=terminal.get('output',[]);calls=[x for x in out if x.get('type')=='function_call']
    if calls:
        assert len(calls)==1 and calls[0]['name']=='submit_answer','ambiguous action'
        payload=calls[0]['arguments']
    else:
        messages=[x for x in out if x.get('type')=='message'];assert len(messages)==1,'missing action'
        parts=messages[0]['content'];assert parts and all(p['type']=='output_text' for p in parts)
        payload=''.join(p['text'] for p in parts)
    answer=json.loads(payload,object_pairs_hook=unique)
    assert set(answer)=={'permitted'} and isinstance(answer['permitted'],list),'invalid answer schema'
    assert all(type(i) is int for i in answer['permitted']) and len(set(answer['permitted']))==len(answer['permitted']),'invalid IDs'
    return answer['permitted'],calls


def shared_live(directory, output):
    from ascent_engine.evidence import ComputationalEvidence
    plan=shared_check(directory);output.mkdir(parents=True,exist_ok=False);rows=[]
    save=lambda: (output/'ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
    with Engine() as engine:
        for case,task in enumerate(plan['tasks']):
            for arm in plan['orders'][case]:
                row={'case':case,'arm':arm,'calls':[],'grossTokens':0,'stop':None,'failure':None};rows.append(row);save()
                history=None;prior_usage=None
                with ComputationalEvidence(engine) as store:
                    try:
                        for turn,ids in enumerate(task['schedule']):
                            context={'question':plan['question'],'obligations':[n for n in task['needs'] if n[0] in ids]}
                            packet=shared_packet(store,task,ids) if arm!='baseline' else None
                            if packet:
                                context['evidence']={k:packet[k] for k in ('scope','facts')}
                                if arm=='scheme':context['evidence'].update({k:packet[k] for k in ('fragments','nodeEncoding')})
                            if history is None:
                                context['task']={'edges':task['edges'],'needColumns':['id','a','b','c','d'],
                                    'rules':plan['candidate'][3:6], 'query':['ready','?f']}
                                history=ResponseHistory(json.dumps(context,separators=(',',':')));new_items=history.items
                            else:
                                history.append_feedback(context);new_items=[history.items[-1]]
                            req={'model':plan['model'],'input':history.input(),'tools':[plan['tool']],'tool_choice':'auto',
                                 'reasoning':{'effort':plan['reasoningEffort']},'stream':True,'store':False,
                                 'text':{'format':{'type':'json_schema','name':'permitted_transitions','schema':plan['tool']['parameters']}},
                                 'max_output_tokens':plan['maxOutputTokens']}
                            bound=(len(json.dumps(req,ensure_ascii=False).encode()) if prior_usage is None else
                                prior_usage+sum(len(json.dumps(x,ensure_ascii=False).encode()) for x in new_items)) + plan['inputPadding']
                            cap=min(plan['maxOutputTokens'],plan['totalBudget']-row['grossTokens']-bound)
                            if cap<plan['minimumOutputTokens']:row.update(stop='budget_reservation',nextInputReservation=bound);break
                            req['max_output_tokens']=cap
                            folder=output/'calls'/f'{case}-{arm}'/str(turn);folder.mkdir(parents=True)
                            record={'turn':turn,'usage':None,'grossTokens':None,'failure':None,'correct':False,'inputReservation':bound,'outputCap':cap,'nativePacket':packet}
                            row['calls'].append(record);save();(folder/'request.json').write_text(json.dumps(req,indent=2)+'\n')
                            _,meta=provider(req,provider_key(),folder/'response.json');term=meta.get('terminal') or {}
                            text=''.join(p.get('text','') for x in term.get('output',[]) if x.get('type')=='reasoning'
                                        for p in x.get('content',[]) if p.get('type')=='reasoning_text')
                            (folder/'thinking.txt').write_text(text);record['thinkingSha256']=hashlib.sha256(text.encode()).hexdigest()
                            record.update(status=term.get('status'),providerError=meta.get('error'),incompleteDetails=term.get('incomplete_details'),usage=term.get('usage'))
                            u=record['usage']
                            if not isinstance(u,dict) or any(type(u.get(k)) is not int or u[k]<0 for k in ('input_tokens','output_tokens')):raise ValueError('unknown usage')
                            record['grossTokens']=u['input_tokens']+u['output_tokens'];row['grossTokens']+=record['grossTokens'];record['atGrossTokens']=row['grossTokens']
                            assert u['input_tokens']<=bound and u['output_tokens']<=cap and row['grossTokens']<=plan['totalBudget'],'budget violation'
                            if meta.get('error') or term.get('status')!='completed':raise ValueError('provider incomplete or failed')
                            answer,calls=shared_action(term);assert set(answer)<=set(ids),'unknown transition ID'
                            record.update(answer=answer,expected=[i for i in ids if shared_truth(task,['ready',i])])
                            record['correct']=sorted(answer)==record['expected'];history.append_response(term)
                            for call in calls:history.append_result(call['call_id'],{'recorded':True})
                            prior_usage=record['grossTokens']
                            # A paired result is extra input too, not part of the previous usage.
                            if calls:prior_usage+=sum(len(json.dumps(x,ensure_ascii=False).encode()) for x in history.items[-len(calls):])
                            (folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');save()
                            print('SHARED_TURN',case,arm,turn,row['grossTokens'],'correct',record['correct'],flush=True)
                        row['stop']=row['stop'] or 'schedule_complete'
                    except Exception as error:
                        row.update(stop='failure',failure=str(error))
                        if row['calls']:
                            row['calls'][-1]['failure']=str(error)
                            (output/'calls'/f'{case}-{arm}'/str(row['calls'][-1]['turn'])/'receipt.json').write_text(json.dumps(row['calls'][-1],indent=2)+'\n')
                    finally:
                        row['unusedBudget']=plan['totalBudget']-row['grossTokens'] if all(c['grossTokens'] is not None for c in row['calls']) else None;save()
    shared_check(directory);print('SHARED_MODEL_COMPLETE',flush=True)
