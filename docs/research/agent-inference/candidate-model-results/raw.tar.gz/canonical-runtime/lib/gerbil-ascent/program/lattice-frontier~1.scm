(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33871_|
    (##structure
     gx#syntax-quote::t
     'lattice-round::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33873_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-round
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33875_|
    (##structure
     gx#syntax-quote::t
     'lattice-round?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33877_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33878_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33879_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33880_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33882_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33883_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33884_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33885_|
    (##structure
     gx#syntax-quote::t
     'lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33887_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33888_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33889_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33890_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33892_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-table-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33893_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-changes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33894_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33895_|
    (##structure
     gx#syntax-quote::t
     '&lattice-round-ordered?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33897_|
    (##structure
     gx#syntax-quote::t
     'lattice-change::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33899_|
    (##structure
     gx#syntax-quote::t
     'make-lattice-change
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33901_|
    (##structure
     gx#syntax-quote::t
     'lattice-change?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33903_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33904_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33906_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33907_|
    (##structure
     gx#syntax-quote::t
     'lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33909_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33910_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33912_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33913_|
    (##structure
     gx#syntax-quote::t
     '&lattice-change-sequence-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33915_|
    (gx#core-deserialize-mark
     '(0
       ($%arg15683 . _%$%arg1568315754%_)
       ($%arg15682 . _%$%arg1568215740%_)
       (id . _%id15707%_)
       (arg . _%arg15770%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33916_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33915_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33919_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33920_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33919_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33922_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33919_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33924_|
    (gx#core-deserialize-mark
     '(0
       ($%arg15804 . _%$%arg1580415874%_)
       ($%arg15803 . _%$%arg1580315860%_)
       (id . _%id15827%_)
       (arg . _%arg15890%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33925_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33924_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33928_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33929_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33928_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33931_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33928_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33933_|
    (gx#core-deserialize-mark
     '(0
       ($%arg15924 . _%$%arg1592415994%_)
       ($%arg15923 . _%$%arg1592315980%_)
       (id . _%id15947%_)
       (arg . _%arg16010%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33934_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33933_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33937_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33938_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33937_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33940_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33937_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33942_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16043 . _%$%arg1604316100%_)
       ($%arg16044 . _%$%arg1604416114%_)
       (id . _%id16067%_)
       (arg . _%arg16130%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33943_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33942_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33946_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33947_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33946_|)))
  (define |gerbil-ascent/program/lattice-frontier[1]#_g33949_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/lattice-frontier[1]#_g33946_|)))
  (begin
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-round|
      (let ((__obj33811
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33811
           'gerbil-ascent/program/lattice-frontier#lattice-round::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 'lattice-round '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33811
           '(table changes sequence ordered?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33811
           '(table changes sequence ordered?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '#f '13 '#f '#f))
        (let ((__tmp33870
               |gerbil-ascent/program/lattice-frontier[1]#_g33871_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33870 '4 '#f '#f))
        (let ((__tmp33872
               |gerbil-ascent/program/lattice-frontier[1]#_g33873_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33872 '14 '#f '#f))
        (let ((__tmp33874
               |gerbil-ascent/program/lattice-frontier[1]#_g33875_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33874 '15 '#f '#f))
        (let ((__tmp33876
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33877_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33878_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33879_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33880_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33876 '16 '#f '#f))
        (let ((__tmp33881
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33882_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33883_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33884_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33885_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33881 '17 '#f '#f))
        (let ((__tmp33886
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33887_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33888_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33889_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33890_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33886 '18 '#f '#f))
        (let ((__tmp33891
               (cons (cons 'table
                           |gerbil-ascent/program/lattice-frontier[1]#_g33892_|)
                     (cons (cons 'changes
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33893_|)
                           (cons (cons 'sequence
                                       |gerbil-ascent/program/lattice-frontier[1]#_g33894_|)
                                 (cons (cons 'ordered?
                                             |gerbil-ascent/program/lattice-frontier[1]#_g33895_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 __tmp33891 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33811 '() '21 '#f '#f))
        __obj33811))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#lattice-change|
      (let ((__obj33812
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33812
           'gerbil-ascent/program/lattice-frontier#lattice-change::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 'lattice-change '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '(row sequence) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '(row sequence) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '#f '13 '#f '#f))
        (let ((__tmp33896
               |gerbil-ascent/program/lattice-frontier[1]#_g33897_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33896 '4 '#f '#f))
        (let ((__tmp33898
               |gerbil-ascent/program/lattice-frontier[1]#_g33899_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33898 '14 '#f '#f))
        (let ((__tmp33900
               |gerbil-ascent/program/lattice-frontier[1]#_g33901_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33900 '15 '#f '#f))
        (let ((__tmp33902
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33903_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33904_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33902 '16 '#f '#f))
        (let ((__tmp33905
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33906_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33907_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33905 '17 '#f '#f))
        (let ((__tmp33908
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33909_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33910_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33908 '18 '#f '#f))
        (let ((__tmp33911
               (cons (cons 'row
                           |gerbil-ascent/program/lattice-frontier[1]#_g33912_|)
                     (cons (cons 'sequence
                                 |gerbil-ascent/program/lattice-frontier[1]#_g33913_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 __tmp33911 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33812 '() '21 '#f '#f))
        __obj33812))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-ref|
      (lambda (_%$stx15664%_)
        (let* ((_%__stx3370833709%_ _%$stx15664%_)
               (_%$%g1566915690%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3370833709%_)))))
          (let ((_%__kont3371133712%_
                 (lambda (_%$%g1567115756%_)
                   (cons (let ((__tmp33914
                                |gerbil-ascent/program/lattice-frontier[1]#_g33916_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33914
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 '()))
                                     (cons (let ((__tmp33917
                                                  (lambda (_%$%g1577115774%_
                                                           _%$%g1577215777%_)
                                                    (cons _%$%g1577115774%_
                                                          _%$%g1577215777%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33917
                                              '()
                                              _%$%g1567115756%_))
                                           '()))
                               (cons (cons (let ((__tmp33918
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33920_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33918
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33921
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33922_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33921 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-ref))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3371533716%_
                 (lambda (_%$%g1568415697%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-ref)))))
            (let* ((_%$%g1566815709%_
                    (lambda ()
                      (let ((_%$%g1568415697%_ _%__stx3370833709%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1568415697%_))
                            (_%__kont3371533716%_ _%$%g1568415697%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1566915690%_))))))
                   (_%__match3373133732%_
                    (lambda (_%$%e1567215716%_
                             _%$%hd1567315720%_
                             _%$%tl1567415723%_
                             _%__splice3371333714%_
                             _%$%target1567515726%_
                             _%$%tl1567715729%_)
                      (letrec ((_%$%loop1567815732%_
                                (lambda (_%$%hd1567615736%_
                                         _%$%arg1568215739%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1567615736%_))
                                      (let ((_%$%e1567915742%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1567615736%_))))
                                        (let ((_%$%lp-tl1568115749%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1567915742%_)))
                                              (_%$%lp-hd1568015746%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1567915742%_))))
                                          (_%$%loop1567815732%_
                                           _%$%lp-tl1568115749%_
                                           (cons _%$%lp-hd1568015746%_
                                                 _%$%arg1568215739%_))))
                                      (let ((_%$%arg1568315752%_
                                             (reverse _%$%arg1568215739%_)))
                                        (_%__kont3371133712%_
                                         _%$%arg1568315752%_))))))
                        (_%$%loop1567815732%_ _%$%target1567515726%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3370833709%_))
                  (let ((_%$%e1567215716%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3370833709%_))))
                    (let ((_%$%tl1567415723%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1567215716%_)))
                          (_%$%hd1567315720%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1567215716%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1567415723%_))
                          (let ((_%__splice3371333714%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1567415723%_
                                    '0))))
                            (let ((_%$%tl1567715729%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3371333714%_ '1)))
                                  (_%$%target1567515726%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3371333714%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1567715729%_))
                                  (_%__match3373133732%_
                                   _%$%e1567215716%_
                                   _%$%hd1567315720%_
                                   _%$%tl1567415723%_
                                   _%__splice3371333714%_
                                   _%$%target1567515726%_
                                   _%$%tl1567715729%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1566815709%_)))))
                          (let () (declare (not safe)) (_%$%g1566815709%_)))))
                  (let () (declare (not safe)) (_%$%g1566815709%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-stage!|
      (lambda (_%$stx15785%_)
        (let* ((_%__stx3373433735%_ _%$stx15785%_)
               (_%$%g1579015811%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3373433735%_)))))
          (let ((_%__kont3373733738%_
                 (lambda (_%$%g1579215876%_)
                   (cons (let ((__tmp33923
                                |gerbil-ascent/program/lattice-frontier[1]#_g33925_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33923
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'key))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'row))
                                                       '())))
                                     (cons (let ((__tmp33926
                                                  (lambda (_%$%g1589115894%_
                                                           _%$%g1589215897%_)
                                                    (cons _%$%g1589115894%_
                                                          _%$%g1589215897%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33926
                                              '()
                                              _%$%g1579215876%_))
                                           '()))
                               (cons (cons (let ((__tmp33927
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33929_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33927
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33930
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33931_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33930 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-stage!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'key))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'row))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3374133742%_
                 (lambda (_%$%g1580515818%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-stage!)))))
            (let* ((_%$%g1578915829%_
                    (lambda ()
                      (let ((_%$%g1580515818%_ _%__stx3373433735%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1580515818%_))
                            (_%__kont3374133742%_ _%$%g1580515818%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1579015811%_))))))
                   (_%__match3375733758%_
                    (lambda (_%$%e1579315836%_
                             _%$%hd1579415840%_
                             _%$%tl1579515843%_
                             _%__splice3373933740%_
                             _%$%target1579615846%_
                             _%$%tl1579815849%_)
                      (letrec ((_%$%loop1579915852%_
                                (lambda (_%$%hd1579715856%_
                                         _%$%arg1580315859%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1579715856%_))
                                      (let ((_%$%e1580015862%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1579715856%_))))
                                        (let ((_%$%lp-tl1580215869%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1580015862%_)))
                                              (_%$%lp-hd1580115866%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1580015862%_))))
                                          (_%$%loop1579915852%_
                                           _%$%lp-tl1580215869%_
                                           (cons _%$%lp-hd1580115866%_
                                                 _%$%arg1580315859%_))))
                                      (let ((_%$%arg1580415872%_
                                             (reverse _%$%arg1580315859%_)))
                                        (_%__kont3373733738%_
                                         _%$%arg1580415872%_))))))
                        (_%$%loop1579915852%_ _%$%target1579615846%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3373433735%_))
                  (let ((_%$%e1579315836%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3373433735%_))))
                    (let ((_%$%tl1579515843%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1579315836%_)))
                          (_%$%hd1579415840%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1579315836%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1579515843%_))
                          (let ((_%__splice3373933740%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1579515843%_
                                    '0))))
                            (let ((_%$%tl1579815849%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3373933740%_ '1)))
                                  (_%$%target1579615846%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3373933740%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1579815849%_))
                                  (_%__match3375733758%_
                                   _%$%e1579315836%_
                                   _%$%hd1579415840%_
                                   _%$%tl1579515843%_
                                   _%__splice3373933740%_
                                   _%$%target1579615846%_
                                   _%$%tl1579815849%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1578915829%_)))))
                          (let () (declare (not safe)) (_%$%g1578915829%_)))))
                  (let () (declare (not safe)) (_%$%g1578915829%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-rows|
      (lambda (_%$stx15905%_)
        (let* ((_%__stx3376033761%_ _%$stx15905%_)
               (_%$%g1591015931%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3376033761%_)))))
          (let ((_%__kont3376333764%_
                 (lambda (_%$%g1591215996%_)
                   (cons (let ((__tmp33932
                                |gerbil-ascent/program/lattice-frontier[1]#_g33934_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33932
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp33935
                                                  (lambda (_%$%g1601116014%_
                                                           _%$%g1601216017%_)
                                                    (cons _%$%g1601116014%_
                                                          _%$%g1601216017%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33935
                                              '()
                                              _%$%g1591215996%_))
                                           '()))
                               (cons (cons (let ((__tmp33936
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33938_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33936
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33939
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33940_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33939 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3376733768%_
                 (lambda (_%$%g1592515938%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-rows)))))
            (let* ((_%$%g1590915949%_
                    (lambda ()
                      (let ((_%$%g1592515938%_ _%__stx3376033761%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1592515938%_))
                            (_%__kont3376733768%_ _%$%g1592515938%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1591015931%_))))))
                   (_%__match3378333784%_
                    (lambda (_%$%e1591315956%_
                             _%$%hd1591415960%_
                             _%$%tl1591515963%_
                             _%__splice3376533766%_
                             _%$%target1591615966%_
                             _%$%tl1591815969%_)
                      (letrec ((_%$%loop1591915972%_
                                (lambda (_%$%hd1591715976%_
                                         _%$%arg1592315979%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1591715976%_))
                                      (let ((_%$%e1592015982%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1591715976%_))))
                                        (let ((_%$%lp-tl1592215989%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1592015982%_)))
                                              (_%$%lp-hd1592115986%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1592015982%_))))
                                          (_%$%loop1591915972%_
                                           _%$%lp-tl1592215989%_
                                           (cons _%$%lp-hd1592115986%_
                                                 _%$%arg1592315979%_))))
                                      (let ((_%$%arg1592415992%_
                                             (reverse _%$%arg1592315979%_)))
                                        (_%__kont3376333764%_
                                         _%$%arg1592415992%_))))))
                        (_%$%loop1591915972%_ _%$%target1591615966%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3376033761%_))
                  (let ((_%$%e1591315956%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3376033761%_))))
                    (let ((_%$%tl1591515963%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1591315956%_)))
                          (_%$%hd1591415960%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1591315956%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1591515963%_))
                          (let ((_%__splice3376533766%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1591515963%_
                                    '0))))
                            (let ((_%$%tl1591815969%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3376533766%_ '1)))
                                  (_%$%target1591615966%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3376533766%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1591815969%_))
                                  (_%__match3378333784%_
                                   _%$%e1591315956%_
                                   _%$%hd1591415960%_
                                   _%$%tl1591515963%_
                                   _%__splice3376533766%_
                                   _%$%target1591615966%_
                                   _%$%tl1591815969%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1590915949%_)))))
                          (let () (declare (not safe)) (_%$%g1590915949%_)))))
                  (let () (declare (not safe)) (_%$%g1590915949%_))))))))
    (define |gerbil-ascent/program/lattice-frontier[:0:]#@lattice-frontier-clear!|
      (lambda (_%$stx16025%_)
        (let* ((_%__stx3378633787%_ _%$stx16025%_)
               (_%$%g1603016051%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3378633787%_)))))
          (let ((_%__kont3378933790%_
                 (lambda (_%$%g1603216116%_)
                   (cons (let ((__tmp33941
                                |gerbil-ascent/program/lattice-frontier[1]#_g33943_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp33941
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0
                                              '#f
                                              'frontier))
                                           '())
                                     (cons (let ((__tmp33944
                                                  (lambda (_%$%g1613116134%_
                                                           _%$%g1613216137%_)
                                                    (cons _%$%g1613116134%_
                                                          _%$%g1613216137%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp33944
                                              '()
                                              _%$%g1603216116%_))
                                           '()))
                               (cons (cons (let ((__tmp33945
                                                  |gerbil-ascent/program/lattice-frontier[1]#_g33947_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp33945
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'frontier))
                     (cons (let ((__tmp33948
                                  |gerbil-ascent/program/lattice-frontier[1]#_g33949_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp33948 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'lattice-round))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f '__lattice-frontier-clear!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'frontier))
                           '()))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3379333794%_
                 (lambda (_%$%g1604516058%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0 '#f 'lattice-frontier-clear!)))))
            (let* ((_%$%g1602916069%_
                    (lambda ()
                      (let ((_%$%g1604516058%_ _%__stx3378633787%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1604516058%_))
                            (_%__kont3379333794%_ _%$%g1604516058%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1603016051%_))))))
                   (_%__match3380933810%_
                    (lambda (_%$%e1603316076%_
                             _%$%hd1603416080%_
                             _%$%tl1603516083%_
                             _%__splice3379133792%_
                             _%$%target1603616086%_
                             _%$%tl1603816089%_)
                      (letrec ((_%$%loop1603916092%_
                                (lambda (_%$%hd1603716096%_
                                         _%$%arg1604316099%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1603716096%_))
                                      (let ((_%$%e1604016102%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1603716096%_))))
                                        (let ((_%$%lp-tl1604216109%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1604016102%_)))
                                              (_%$%lp-hd1604116106%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1604016102%_))))
                                          (_%$%loop1603916092%_
                                           _%$%lp-tl1604216109%_
                                           (cons _%$%lp-hd1604116106%_
                                                 _%$%arg1604316099%_))))
                                      (let ((_%$%arg1604416112%_
                                             (reverse _%$%arg1604316099%_)))
                                        (_%__kont3378933790%_
                                         _%$%arg1604416112%_))))))
                        (_%$%loop1603916092%_ _%$%target1603616086%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3378633787%_))
                  (let ((_%$%e1603316076%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3378633787%_))))
                    (let ((_%$%tl1603516083%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1603316076%_)))
                          (_%$%hd1603416080%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1603316076%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1603516083%_))
                          (let ((_%__splice3379133792%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1603516083%_
                                    '0))))
                            (let ((_%$%tl1603816089%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3379133792%_ '1)))
                                  (_%$%target1603616086%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3379133792%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1603816089%_))
                                  (_%__match3380933810%_
                                   _%$%e1603316076%_
                                   _%$%hd1603416080%_
                                   _%$%tl1603516083%_
                                   _%__splice3379133792%_
                                   _%$%target1603616086%_
                                   _%$%tl1603816089%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1602916069%_)))))
                          (let () (declare (not safe)) (_%$%g1602916069%_)))))
                  (let () (declare (not safe)) (_%$%g1602916069%_))))))))))
