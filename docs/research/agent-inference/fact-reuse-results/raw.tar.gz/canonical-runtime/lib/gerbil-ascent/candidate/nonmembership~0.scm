(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/nonmembership::timestamp 1791691027)
  (begin
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
      (let ((__tmp38215 (list)) (__tmp38214 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'positive-nonmembership
         __tmp38215
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         __tmp38214
         '#f)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t)))
    (define gerbil-ascent/candidate/nonmembership#make-positive-nonmembership
      (lambda _%$args29703%_
        (apply make-instance
               gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
               _%$args29703%_)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#certificate-size-valid?
      (lambda (_%closure29687%_)
        (let ((_%relation-count29689%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                  _%closure29687%_
                  gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)))
              (_%rows29690%_ '0)
              (_%cells29691%_ '0))
          (if _%relation-count29689%_
              (let ((__tmp38216
                     (lambda (_%entry29693%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry29693%_
                                      '3))
                                   '3)
                           (let* ((_%row-list29695%_ (caddr _%entry29693%_))
                                  (_%count29697%_
                                   (let ((__tmp38217
                                          (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                             _%rows29690%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%row-list29695%_
                                      __tmp38217))))
                             (if _%count29697%_
                                 (if (begin
                                       (set! _%rows29690%_
                                             (+ _%rows29690%_ _%count29697%_))
                                       '#t)
                                     (let ((__tmp38218
                                            (lambda (_%row29699%_)
                                              (let ((_%width29701%_
                                                     (let ((__tmp38219
                                                            (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                            _%cells29691%_))))
               (declare (not safe))
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row29699%_
                __tmp38219))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%width29701%_
                                                    (begin
                                                      (set! _%cells29691%_
                                                            (+ _%cells29691%_
                                                               _%width29701%_))
                                                      '#t)
                                                    '#f)))))
                                       (declare (not safe))
                                       (andmap__0
                                        __tmp38218
                                        _%row-list29695%_))
                                     '#f)
                                 '#f))
                           '#f))))
                (declare (not safe))
                (andmap__0 __tmp38216 _%closure29687%_))
              '#f))))
    (define gerbil-ascent/candidate/nonmembership#ground-query?
      (lambda (_%query29683%_)
        (if (list? _%query29683%_)
            (if (pair? _%query29683%_)
                (let ((__tmp38221
                       (lambda (_%term29685%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term29685%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term29685%_))
                                 '#f
                                 (not (eq? _%term29685%_ '?_)))
                             '#f)))
                      (__tmp38220
                       (let () (declare (not safe)) (##cdr _%query29683%_))))
                  (declare (not safe))
                  (andmap__0 __tmp38221 __tmp38220))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/nonmembership#certificate-schema-of
      (lambda (_%snapshot29678%_ _%spec29679%_)
        (let ((__tmp38223
               (lambda (_%entry29681%_)
                 (list (car _%entry29681%_) (cdr _%entry29681%_))))
              (__tmp38222
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/funs#candidate-schema-of
                  _%snapshot29678%_
                  _%spec29679%_))))
          (declare (not safe))
          (##map __tmp38223 __tmp38222))))
    (define gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
      (lambda (_%snapshot29628%_
               _%spec29629%_
               _%candidate-digest29630%_
               _%native-status29631%_
               _%native-rows29632%_
               _%max-steps29633%_)
        (if (and (exact-integer? _%max-steps29633%_) (> _%max-steps29633%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership work budget" _%max-steps29633%_)))
        (let ((_%query29635%_
               (vector-ref
                (##structure-ref
                 _%spec29629%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29637%_
                    (lambda (_%status29675%_ _%closure29676%_)
                      (let ((__tmp38228
                             (##structure-ref
                              _%snapshot29628%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp38227
                             (##structure-ref
                              _%snapshot29628%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp38226
                             (##structure-ref
                              _%snapshot29628%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp38225
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                                _%spec29629%_)))
                            (__tmp38224
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29635%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
                         _%status29675%_
                         __tmp38228
                         __tmp38227
                         __tmp38226
                         _%candidate-digest29630%_
                         __tmp38225
                         __tmp38224
                         _%max-steps29633%_
                         _%closure29676%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29628%_)))
                    (not (eq? _%native-status29631%_ 'complete))
                    (pair? _%native-rows29632%_)
                    (not (gerbil-ascent/candidate/nonmembership#ground-query?
                          _%query29635%_))
                    (not (let ((__tmp38229
                                (##structure-ref
                                 _%spec29629%_
                                 '3
                                 gerbil-ascent/candidate/types#reasoning-candidate::t
                                 '#f)))
                           (declare (not safe))
                           (andmap__0
                            gerbil-ascent/candidate/provenance#positive-rule-body?
                            __tmp38229))))
                (_%result29637%_ 'unsupported '())
                (if (> (let ((__tmp38230
                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                               _%snapshot29628%_
                               _%spec29629%_)))
                         (declare (not safe))
                         (##length __tmp38230))
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                    (_%result29637%_ 'bounded '())
                    (let* ((_%witness29651%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
                               _%snapshot29628%_
                               _%spec29629%_
                               _%candidate-digest29630%_
                               _%native-status29631%_
                               _%native-rows29632%_
                               _%max-steps29633%_)))
                           (_%status29653%_
                            (##structure-ref
                             _%witness29651%_
                             '1
                             gerbil-ascent/candidate/provenance#positive-proof::t
                             '#f))
                           (_%$e29656%_ _%status29653%_))
                      (if (eq? 'bounded _%$e29656%_)
                          (_%result29637%_ 'bounded '())
                          (if (eq? 'closed-absent _%$e29656%_)
                              (let ((_%grouped29659%_
                                     (let ()
                                       (declare (not safe))
                                       (make-hash-table-eq))))
                                (for-each
                                 (lambda (_%node29661%_)
                                   (let* ((_%name29663%_
                                           (##structure-ref
                                            _%node29661%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f))
                                          (__tmp38231
                                           (cons (##structure-ref
                                                  _%node29661%_
                                                  '4
                                                  gerbil-ascent/candidate/provenance#proof-node::t
                                                  '#f)
                                                 (let ((_%$e29665%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-get
                                                           _%grouped29659%_
                                                           _%name29663%_))))
                                                   (if _%$e29665%_
                                                       _%$e29665%_
                                                       '())))))
                                     (declare (not safe))
                                     (__hash-put!
                                      _%grouped29659%_
                                      _%name29663%_
                                      __tmp38231)))
                                 (##structure-ref
                                  _%witness29651%_
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))
                                (let ((_%closure29673%_
                                       (let ((__tmp38233
                                              (lambda (_%declaration29668%_)
                                                (list (car _%declaration29668%_)
                                                      (cadr _%declaration29668%_)
                                                      (let ((__tmp38234
                                                             (reverse (let ((_%$e29670%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     (let ((__tmp38235
                                            (car _%declaration29668%_)))
                                       (declare (not safe))
                                       (__hash-get
                                        _%grouped29659%_
                                        __tmp38235))))
                                (if _%$e29670%_ _%$e29670%_ '())))))
                (declare (not safe))
                (##map gerbil-ascent/candidate/datum#candidate-copy-pairs
                       __tmp38234)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (__tmp38232
                                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                                               _%snapshot29628%_
                                               _%spec29629%_)))
                                         (declare (not safe))
                                         (##map __tmp38233 __tmp38232))))
                                  (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                                       _%closure29673%_)
                                      (_%result29637%_
                                       'complete
                                       _%closure29673%_)
                                      (_%result29637%_ 'bounded '()))))
                              (_%result29637%_ 'unsupported '()))))))))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__%
      (lambda (_%terms29610%_ _%wildcards?29611%_)
        (map (lambda (_%term29613%_)
               (cons (if (and _%wildcards?29611%_ (eq? _%term29613%_ '?_))
                         'wildcard
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-variable?
                                _%term29613%_))
                             'variable
                             'literal))
                     _%term29613%_))
             _%terms29610%_)))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__0
      (lambda (_%terms29621%_)
        (let ((_%wildcards?29623%_ '#t))
          (gerbil-ascent/candidate/nonmembership#binding-patterns__%
           _%terms29621%_
           _%wildcards?29623%_))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns
      (lambda _g38236_
        (let ((_g38237_ (let () (declare (not safe)) (##length _g38236_))))
          (cond ((let () (declare (not safe)) (##fx= _g38237_ 1))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__0
                        _g38236_))
                ((let () (declare (not safe)) (##fx= _g38237_ 2))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__%
                        _g38236_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/nonmembership#binding-patterns
                  _g38236_))))))
    (define gerbil-ascent/candidate/nonmembership#head-row
      (lambda (_%head29604%_ _%bindings29605%_)
        (map (lambda (_%term29607%_)
               (if (eq? (car _%term29607%_) 'variable)
                   (cdr (assq (cdr _%term29607%_) _%bindings29605%_))
                   (cdr _%term29607%_)))
             _%head29604%_)))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
      (lambda (_%snapshot29429%_
               _%spec29430%_
               _%candidate-digest29431%_
               _%native-status29432%_
               _%native-rows29433%_
               _%certificate29434%_
               _%max-checks29435%_)
        (if (and (exact-integer? _%max-checks29435%_)
                 (> _%max-checks29435%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership verification budget"
                     _%max-checks29435%_)))
        (let* ((_%query29437%_
                (vector-ref
                 (##structure-ref
                  _%spec29430%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%schema29439%_
                (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                 _%snapshot29429%_
                 _%spec29430%_))
               (_%closure29441%_
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%certificate29434%_
                       'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%certificate29434%_
                       '9
                       '#f
                       '#f))
                    '#f))
               (_%preflight29449%_
                (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                     _%closure29441%_)
                    (if (= (length _%closure29441%_)
                           (let ()
                             (declare (not safe))
                             (##length _%schema29439%_)))
                        (if (let ((__tmp38238
                                   (lambda (_%entry29443%_)
                                     (and (list? _%entry29443%_)
                                          (= (let ()
                                               (declare (not safe))
                                               (##length _%entry29443%_))
                                             '3)
                                          (list? (caddr _%entry29443%_))))))
                              (declare (not safe))
                              (andmap__0 __tmp38238 _%closure29441%_))
                            (+ '1
                               (let ((__tmp38239
                                      (map (lambda (_%entry29445%_)
                                             (length (caddr _%entry29445%_)))
                                           _%closure29441%_)))
                                 (declare (not safe))
                                 (##apply + __tmp38239))
                               (let ((__tmp38240
                                      (map (lambda (_%entry29447%_)
                                             (length (caddr _%entry29447%_)))
                                           (##structure-ref
                                            _%snapshot29429%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f))))
                                 (declare (not safe))
                                 (##apply + __tmp38240))
                               (length (##structure-ref
                                        _%spec29430%_
                                        '2
                                        gerbil-ascent/candidate/types#reasoning-candidate::t
                                        '#f)))
                            '#f)
                        '#f)
                    '#f)))
          (if (and (let ()
                     (declare (not safe))
                     (##structure-instance-of?
                      _%certificate29434%_
                      'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                      _%snapshot29429%_))
                   (eq? (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%certificate29434%_
                           '1
                           '#f
                           '#f))
                        'complete)
                   (eq? _%native-status29432%_ 'complete)
                   (null? _%native-rows29433%_)
                   (gerbil-ascent/candidate/nonmembership#ground-query?
                    _%query29437%_)
                   (let ((__tmp38241
                          (##structure-ref
                           _%spec29430%_
                           '3
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)))
                     (declare (not safe))
                     (andmap__0
                      gerbil-ascent/candidate/provenance#positive-rule-body?
                      __tmp38241))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '2
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '3
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '4
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29429%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '5
                              '#f
                              '#f))
                           _%candidate-digest29431%_)
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '6
                              '#f
                              '#f))
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                              _%spec29430%_)))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29434%_
                              '7
                              '#f
                              '#f))
                           _%query29437%_)
                   _%preflight29449%_
                   (equal? (map (lambda (_%entry29452%_)
                                  (list (car _%entry29452%_)
                                        (cadr _%entry29452%_)))
                                _%closure29441%_)
                           _%schema29439%_))
              (if (> _%preflight29449%_ _%max-checks29435%_)
                  'bounded
                  (if (let ((__tmp38242
                             (lambda (_%entry29456%_)
                               (and (let ((__tmp38243 (caddr _%entry29456%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                       __tmp38243))
                                    (let ((__tmp38245
                                           (lambda (_%row29458%_)
                                             (and (list? _%row29458%_)
                                                  (= (let ()
                                                       (declare (not safe))
                                                       (##length _%row29458%_))
                                                     (cadr _%entry29456%_))
                                                  (let ()
                                                    (declare (not safe))
                                                    (andmap__0
                                                     gerbil-ascent/candidate/program#scalar?
                                                     _%row29458%_)))))
                                          (__tmp38244 (caddr _%entry29456%_)))
                                      (declare (not safe))
                                      (andmap__0 __tmp38245 __tmp38244))))))
                        (declare (not safe))
                        (andmap__0 __tmp38242 _%closure29441%_))
                      (let* ((_%steps29462%_ _%preflight29449%_)
                             (_%bounded?29464%_ '#f)
                             (_%invalid?29466%_ '#f)
                             (_%direct?29523%_
                              (let* ((_%$%closure2946729483%_ _%closure29441%_)
                                     (_%$%else2947129491%_ (lambda () '#f)))
                                (let ((_%$%K2948129520%_ (lambda () '#t))
                                      (_%$%K2947829510%_ (lambda () '#t))
                                      (_%$%K2947329496%_ (lambda () '#t)))
                                  (let ((_%$%try-match2946929516%_
                                         (lambda ()
                                           (if (pair? _%$%closure2946729483%_)
                                               (let ((_%$%tl2948029513%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%closure2946729483%_))))
                                                 (if (null? _%$%tl2948029513%_)
                                                     (_%$%K2947829510%_)
                                                     (if (pair? _%$%tl2948029513%_)
                                                         (let ((_%$%tl2947729502%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##cdr _%$%tl2948029513%_))))
                   (if (null? _%$%tl2947729502%_)
                       (_%$%K2947329496%_)
                       (_%$%else2947129491%_)))
                 (_%$%else2947129491%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%$%else2947129491%_)))))
                                    (if (null? _%$%closure2946729483%_)
                                        (_%$%K2948129520%_)
                                        (_%$%try-match2946929516%_))))))
                             (_%index29525%_
                              (if _%direct?29523%_
                                  '()
                                  (let ((__tmp38246 (length _%closure29441%_)))
                                    (declare (not safe))
                                    (make-hash-table-eq 'size: __tmp38246)))))
                        (letrec* ((_%relation-entry29528%_
                                   (lambda (_%name29600%_)
                                     (if _%direct?29523%_
                                         (let ((_%entry29602%_
                                                (assq _%name29600%_
                                                      _%index29525%_)))
                                           (if _%entry29602%_
                                               (cdr _%entry29602%_)
                                               '#f))
                                         (let ()
                                           (declare (not safe))
                                           (hash-get
                                            _%index29525%_
                                            _%name29600%_)))))
                                  (_g38247_
                                   (let ((_g38248_
                                          (for-each
                                           (lambda (_%entry29530%_)
                                             (let ((_%present29532%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (make-hash-table__%
                                                       '#f
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value))))
                                               (for-each
                                                (lambda (_%row29534%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%present29532%_
                                                     _%row29534%_
                                                     '#t)))
                                                (caddr _%entry29530%_))
                                               (if (_%relation-entry29528%_
                                                    (car _%entry29530%_))
                                                   '#!void
                                                   (let ((_%value29536%_
                                                          (cons (caddr _%entry29530%_)
                                                                _%present29532%_)))
                                                     (if _%direct?29523%_
                                                         (set! _%index29525%_
                                                               (cons (cons (car _%entry29530%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                   _%value29536%_)
                             _%index29525%_))
                 (let ((__tmp38326 (car _%entry29530%_)))
                   (declare (not safe))
                   (hash-put! _%index29525%_ __tmp38326 _%value29536%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           _%closure29441%_)))
                                     #!void
                                     _g38248_))
                                  (_%rows29537%_
                                   (lambda (_%name29596%_)
                                     (let ((_%entry29598%_
                                            (_%relation-entry29528%_
                                             _%name29596%_)))
                                       (if _%entry29598%_
                                           (car _%entry29598%_)
                                           '()))))
                                  (_%contains?29538%_
                                   (lambda (_%name29591%_ _%row29592%_)
                                     (let ((_%entry29594%_
                                            (_%relation-entry29528%_
                                             _%name29591%_)))
                                       (if _%entry29594%_
                                           (let ((__tmp38327
                                                  (cdr _%entry29594%_)))
                                             (declare (not safe))
                                             (hash-get
                                              __tmp38327
                                              _%row29592%_))
                                           '#f)))))
                          (begin
                            (if _%bounded?29464%_
                                '#!void
                                (for-each
                                 (lambda (_%entry29540%_)
                                   (for-each
                                    (lambda (_%row29542%_)
                                      (if (_%contains?29538%_
                                           (car _%entry29540%_)
                                           _%row29542%_)
                                          '#!void
                                          (set! _%invalid?29466%_ '#t)))
                                    (caddr _%entry29540%_)))
                                 (##structure-ref
                                  _%snapshot29429%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f)))
                            (if _%bounded?29464%_
                                '#!void
                                (for-each
                                 (lambda (_%fact29544%_)
                                   (if (_%contains?29538%_
                                        (vector-ref _%fact29544%_ '0)
                                        (vector-ref _%fact29544%_ '1))
                                       '#!void
                                       (set! _%invalid?29466%_ '#t)))
                                 (##structure-ref
                                  _%spec29430%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if (if _%bounded?29464%_
                                    '#f
                                    (_%contains?29538%_
                                     (car _%query29437%_)
                                     (cdr _%query29437%_)))
                                (set! _%invalid?29466%_ '#t)
                                '#!void)
                            (if (or _%bounded?29464%_ _%invalid?29466%_)
                                '#!void
                                (for-each
                                 (lambda (_%rule29549%_)
                                   (let* ((_%head29551%_
                                           (vector-ref _%rule29549%_ '0))
                                          (_%covered-head?29555%_
                                           (if (memq '?_ (cdr _%head29551%_))
                                               '#f
                                               (let ((__tmp38329
                                                      (lambda (_%clause29553%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                               _%clause29553%_))
                                                            '#f
                                                            (equal? _%head29551%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%clause29553%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp38328
                                                      (vector-ref
                                                       _%rule29549%_
                                                       '1)))
                                                 (declare (not safe))
                                                 (ormap__0
                                                  __tmp38329
                                                  __tmp38328))))
                                          (_%head-patterns29557%_
                                           (if _%covered-head?29555%_
                                               '()
                                               (gerbil-ascent/candidate/nonmembership#binding-patterns__%
                                                (cdr _%head29551%_)
                                                '#f)))
                                          (_%head-entry29559%_
                                           (if _%covered-head?29555%_
                                               '#f
                                               (_%relation-entry29528%_
                                                (car _%head29551%_))))
                                          (_%body29563%_
                                           (map (lambda (_%clause29561%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                         _%clause29561%_))
                                                      (vector '#t
                                                              _%clause29561%_
                                                              '())
                                                      (vector '#f
                                                              (gerbil-ascent/candidate/nonmembership#binding-patterns__0
                                                               (cdr _%clause29561%_))
                                                              (_%rows29537%_
                                                               (car _%clause29561%_)))))
                                                (vector-ref
                                                 _%rule29549%_
                                                 '1))))
                                     (letrec ((_%walk29566%_
                                               (lambda (_%remaining29568%_
                                                        _%bindings29569%_)
                                                 (if (or _%bounded?29464%_
                                                         _%invalid?29466%_)
                                                     '#!void
                                                     (if (null? _%remaining29568%_)
                                                         (if (or _%covered-head?29555%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (and _%head-entry29559%_
                              (let ((__tmp38331 (cdr _%head-entry29559%_))
                                    (__tmp38330
                                     (gerbil-ascent/candidate/nonmembership#head-row
                                      _%head-patterns29557%_
                                      _%bindings29569%_)))
                                (declare (not safe))
                                (hash-get __tmp38331 __tmp38330))))
                     '#!void
                     (set! _%invalid?29466%_ '#t))
                 (let ((_%clause29577%_ (car _%remaining29568%_)))
                   (if (vector-ref _%clause29577%_ '0)
                       (begin
                         (set! _%steps29462%_ (+ _%steps29462%_ '1))
                         (if (> _%steps29462%_ _%max-checks29435%_)
                             (set! _%bounded?29464%_ '#t)
                             (let ((_%next29579%_
                                    (let ((__tmp38332
                                           (vector-ref _%clause29577%_ '1)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                       __tmp38332
                                       _%bindings29569%_))))
                               (if _%next29579%_
                                   (_%walk29566%_
                                    (cdr _%remaining29568%_)
                                    _%next29579%_)
                                   '#!void))))
                       (for-each
                        (lambda (_%row29581%_)
                          (if (or _%bounded?29464%_ _%invalid?29466%_)
                              '#!void
                              (begin
                                (set! _%steps29462%_ (+ _%steps29462%_ '1))
                                (if (> _%steps29462%_ _%max-checks29435%_)
                                    (set! _%bounded?29464%_ '#t)
                                    (let ((_%next29586%_
                                           (let ((__tmp38333
                                                  (vector-ref
                                                   _%clause29577%_
                                                   '1)))
                                             (declare (not safe))
                                             (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                              __tmp38333
                                              _%row29581%_
                                              _%bindings29569%_))))
                                      (if _%next29586%_
                                          (_%walk29566%_
                                           (cdr _%remaining29568%_)
                                           _%next29586%_)
                                          '#!void))))))
                        (vector-ref _%clause29577%_ '2)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29566%_ _%body29563%_ '()))))
                                 (##structure-ref
                                  _%spec29430%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if _%invalid?29466%_
                                'invalid
                                (if _%bounded?29464%_ 'bounded 'valid)))))
                      'invalid))
              'invalid))))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership
      (lambda (_%snapshot29421%_
               _%spec29422%_
               _%candidate-digest29423%_
               _%native-status29424%_
               _%native-rows29425%_
               _%certificate29426%_
               _%max-checks29427%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29421%_))
            (gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
             _%snapshot29421%_
             _%spec29422%_
             _%candidate-digest29423%_
             _%native-status29424%_
             _%native-rows29425%_
             _%certificate29426%_
             _%max-checks29427%_)
            'invalid)))))
