(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "std/encoding/json")
    (load-module "std/error")
    (load-module "clan/poo/object")
    (load-module "gerbil-ascent/program/scheme-language")
    (load-module "gerbil-ascent/program/session")
    (load-module "poo-flow/modules/temporal-causality/time/objects")
    (load-module "poo-flow/modules/temporal-causality/revisions/objects")
    (load-module "poo-flow/modules/temporal-causality/revisions/funs")
    (load-module
     "poo-flow/modules/temporal-causality/truth-maintenance/objects")
    (load-module "poo-flow/modules/temporal-causality/truth-maintenance/funs")
    (load-module "gerbil-ascent/candidate/evidence-store")
    (load-module "gerbil-ascent/candidate/reasoning"))
  (load-module "gerbil-ascent/tools/research/evidence-search~0"))
