(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34124_|
    (##structure
     gx#syntax-quote::t
     'certificate-material::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34126_|
    (##structure
     gx#syntax-quote::t
     'make-certificate-material
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34128_|
    (##structure
     gx#syntax-quote::t
     'certificate-material?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34130_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34131_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34133_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34134_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34136_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34137_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34139_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34140_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[:0:]#certificate-material|
    (let ((__obj34028
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34028
         'gerbil-ascent/candidate/certificate-limits#certificate-material::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34028
         'certificate-material
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '(rows cells) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '(rows cells) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '#f '13 '#f '#f))
      (let ((__tmp34123
             |gerbil-ascent/candidate/certificate-limits[1]#_g34124_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34123 '4 '#f '#f))
      (let ((__tmp34125
             |gerbil-ascent/candidate/certificate-limits[1]#_g34126_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34125 '14 '#f '#f))
      (let ((__tmp34127
             |gerbil-ascent/candidate/certificate-limits[1]#_g34128_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34127 '15 '#f '#f))
      (let ((__tmp34129
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34130_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34131_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34129 '16 '#f '#f))
      (let ((__tmp34132
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34133_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34134_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34132 '17 '#f '#f))
      (let ((__tmp34135
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34136_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34137_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34135 '18 '#f '#f))
      (let ((__tmp34138
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34139_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34140_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 __tmp34138 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34028 '() '21 '#f '#f))
      __obj34028)))
