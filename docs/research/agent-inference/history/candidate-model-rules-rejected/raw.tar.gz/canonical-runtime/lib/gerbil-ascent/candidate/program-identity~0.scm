(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/program-identity::timestamp 1791687877)
  (begin
    (define gerbil-ascent/candidate/program-identity#entry-datum
      (lambda (_%entry27269%_)
        (list (vector-ref _%entry27269%_ '0)
              (vector-ref _%entry27269%_ '1)
              (vector-ref _%entry27269%_ '2))))
    (define gerbil-ascent/candidate/program-identity#program-shape
      (lambda (_%spec27267%_)
        (list (##structure-ref
               _%spec27267%_
               '1
               gerbil-ascent/candidate/types#reasoning-candidate::t
               '#f)
              (map gerbil-ascent/candidate/program-identity#entry-datum
                   (##structure-ref
                    _%spec27267%_
                    '2
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f))
              (map gerbil-ascent/candidate/program-identity#entry-datum
                   (##structure-ref
                    _%spec27267%_
                    '3
                    gerbil-ascent/candidate/types#reasoning-candidate::t
                    '#f))
              (vector-ref
               (##structure-ref
                _%spec27267%_
                '4
                gerbil-ascent/candidate/types#reasoning-candidate::t
                '#f)
               '0)
              (##structure-ref
               _%spec27267%_
               '5
               gerbil-ascent/candidate/types#reasoning-candidate::t
               '#f))))
    (define gerbil-ascent/candidate/program-identity#datum-fingerprint
      (lambda (_%datum27197%_)
        (let* ((_%bytes27218%_
                (let* ((_%bytes27201%_
                        (let ((__tmp35064
                               (call-with-output-string
                                '""
                                (lambda (_%port27199%_)
                                  (write _%datum27197%_ _%port27199%_)))))
                          (declare (not safe))
                          (##string->utf8 __tmp35064)))
                       (_%bytes27206%_ _%bytes27201%_))
                  (declare (not safe))
                  (std/crypto/digest#__sha256 _%bytes27206%_)))
               (_%start27221%_ '0)
               (_%end27224%_
                (let ()
                  (declare (not safe))
                  (##u8vector-length _%bytes27218%_)))
               (_%bytes27229%_ _%bytes27218%_))
          (if (and (let () (declare (not safe)) (##fx>= _%start27221%_ '0))
                   (let ((__tmp35065
                          (let ((__tmp35066
                                 (let ()
                                   (declare (not safe))
                                   (##u8vector-length _%bytes27229%_))))
                            (declare (not safe))
                            (##fxmax __tmp35066 '1))))
                     (declare (not safe))
                     (##fx< _%start27221%_ __tmp35065)))
              (let ((_%start27244%_ _%start27221%_))
                (if (let ((__tmp35067
                           (let ()
                             (declare (not safe))
                             (##u8vector-length _%bytes27229%_))))
                      (declare (not safe))
                      (##fx<= _%start27244%_ _%end27224%_ __tmp35067))
                    (let ((_%end27257%_ _%end27224%_))
                      (declare (not safe))
                      (std/encoding/hex#__hex-encode__%
                       _%bytes27229%_
                       _%start27244%_
                       _%end27257%_))
                    (begin
                      (raise-contract-violation-error
                       '"contract violation"
                       'context:
                       'gerbil-ascent/candidate/program-identity
                       'contract:
                       '(in-range-inclusive? start (u8vector-length bytes))
                       'value:
                       _%end27224%_)
                      '#!void)))
              (begin
                (raise-contract-violation-error
                 '"contract violation"
                 'context:
                 'gerbil-ascent/candidate/program-identity
                 'contract:
                 '(in-range? 0 (fxmax (u8vector-length bytes) 1))
                 'value:
                 _%start27221%_)
                '#!void)))))
    (define gerbil-ascent/candidate/program-identity#candidate-finite-program-fingerprint
      (lambda (_%spec27195%_)
        (gerbil-ascent/candidate/program-identity#datum-fingerprint
         (gerbil-ascent/candidate/program-identity#program-shape
          _%spec27195%_))))
    (define gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
      (lambda (_%spec27193%_)
        (gerbil-ascent/candidate/program-identity#datum-fingerprint
         (cons 'positive-program-v1
               (gerbil-ascent/candidate/program-identity#program-shape
                _%spec27193%_)))))))
