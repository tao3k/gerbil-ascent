(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/core/rule-semantics[1]#_g34879_|
    (##structure
     gx#syntax-quote::t
     'rule-read::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34881_|
    (##structure
     gx#syntax-quote::t
     'make-rule-read
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34883_|
    (##structure
     gx#syntax-quote::t
     'rule-read?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34885_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34886_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34888_|
    (##structure
     gx#syntax-quote::t
     'rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34889_|
    (##structure
     gx#syntax-quote::t
     'rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34891_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34892_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34894_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/core/rule-semantics[1]#_g34895_|
    (##structure
     gx#syntax-quote::t
     '&rule-read-source-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/core/rule-semantics[:0:]#rule-read|
      (let ((__obj34746
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj34746
           'gerbil-ascent/core/rule-semantics#rule-read::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 'rule-read '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '(kind source) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '(kind source) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '#f '13 '#f '#f))
        (let ((__tmp34878 |gerbil-ascent/core/rule-semantics[1]#_g34879_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34878 '4 '#f '#f))
        (let ((__tmp34880 |gerbil-ascent/core/rule-semantics[1]#_g34881_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34880 '14 '#f '#f))
        (let ((__tmp34882 |gerbil-ascent/core/rule-semantics[1]#_g34883_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34882 '15 '#f '#f))
        (let ((__tmp34884
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g34885_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g34886_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34884 '16 '#f '#f))
        (let ((__tmp34887
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g34888_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g34889_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34887 '17 '#f '#f))
        (let ((__tmp34890
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g34891_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g34892_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34890 '18 '#f '#f))
        (let ((__tmp34893
               (cons (cons 'kind
                           |gerbil-ascent/core/rule-semantics[1]#_g34894_|)
                     (cons (cons 'source
                                 |gerbil-ascent/core/rule-semantics[1]#_g34895_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 __tmp34893 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj34746 '() '21 '#f '#f))
        __obj34746))
    (define |gerbil-ascent/core/rule-semantics[:0:]#for-rule-reads|
      (lambda (_%$stx7407%_)
        (let* ((_%$%g74117446%_
                (lambda (_%$%g74127442%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g74127442%_))))
               (_%$%g74107570%_
                (lambda (_%$%g74127450%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g74127450%_))
                      (let ((_%$%e74177453%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g74127450%_))))
                        (let ((_%$%hd74187457%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e74177453%_)))
                              (_%$%tl74197460%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e74177453%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl74197460%_))
                              (let ((_%$%e74207463%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl74197460%_))))
                                (let ((_%$%hd74217467%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e74207463%_)))
                                      (_%$%tl74227470%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e74207463%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl74227470%_))
                                      (let ((_%$%e74237473%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl74227470%_))))
                                        (let ((_%$%hd74247477%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e74237473%_)))
                                              (_%$%tl74257480%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e74237473%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd74247477%_))
                                              (let ((_%$%e74267483%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd74247477%_))))
                                                (let ((_%$%hd74277487%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e74267483%_)))
                                                      (_%$%tl74287490%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e74267483%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl74287490%_))
                                                      (let ((_%$%e74297493%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl74287490%_))))
                (let ((_%$%hd74307497%_
                       (let () (declare (not safe)) (##car _%$%e74297493%_)))
                      (_%$%tl74317500%_
                       (let () (declare (not safe)) (##cdr _%$%e74297493%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl74317500%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl74257480%_))
                          (let ((_g34896_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl74257480%_
                                    '0))))
                            (begin
                              (let ((_g34897_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g34896_)
                                           (##values-length _g34896_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g34897_ 2)))
                                    (error "Context expects 2 values"
                                           _g34897_)))
                              (let ((_%$%target74327503%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g34896_ 0)))
                                    (_%$%tl74347506%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g34896_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl74347506%_))
                                    (letrec ((_%$%loop74357509%_
                                              (lambda (_%$%hd74337513%_
                                                       _%$%body74397516%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd74337513%_))
                                                    (let ((_%$%e74367518%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd74337513%_))))
                                                      (let ((_%$%lp-hd74377522%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e74367518%_)))
                    (_%$%lp-tl74387525%_
                     (let () (declare (not safe)) (##cdr _%$%e74367518%_))))
                (_%$%loop74357509%_
                 _%$%lp-tl74387525%_
                 (cons _%$%lp-hd74377522%_ _%$%body74397516%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body74407528%_
                                                           (reverse _%$%body74397516%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'for-each))
                                                            (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  (declare (not safe))
                                  (gx#datum->syntax__0 '#f 'lambda))
                                (cons (cons (let ()
                                              (declare (not safe))
                                              (gx#datum->syntax__0
                                               '#f
                                               'clause))
                                            '())
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'let))
                                                  (cons (cons _%$%hd74277487%_
                                                              (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                    (declare (not safe))
                                    (gx#datum->syntax__0 '#f 'vector-ref))
                                  (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'clause))
                                        (cons '0 '())))
                            '()))
                (cons (cons (let ()
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'when))
                            (cons (cons (let ()
                                          (declare (not safe))
                                          (gx#datum->syntax__0 '#f 'memq))
                                        (cons _%$%hd74277487%_
                                              (cons (cons (let ()
                                                            (declare
                                                              (not safe))
                                                            (gx#datum->syntax__0
                                                             '#f
                                                             'quote))
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'atom))
                              (cons (let ()
                                      (declare (not safe))
                                      (gx#datum->syntax__0 '#f 'negation))
                                    (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'aggregate))
                                          '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '())))
                                  (cons (cons (let ()
                                                (declare (not safe))
                                                (gx#datum->syntax__0 '#f 'let))
                                              (cons (cons _%$%hd74307497%_
                                                          (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                (declare (not safe))
                                (gx#datum->syntax__0 '#f 'vector-ref))
                              (cons (cons (let ()
                                            (declare (not safe))
                                            (gx#datum->syntax__0
                                             '#f
                                             'vector-ref))
                                          (cons (let ()
                                                  (declare (not safe))
                                                  (gx#datum->syntax__0
                                                   '#f
                                                   'clause))
                                                (cons '1 '())))
                                    (cons '0 '())))
                        '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((__tmp34898
                                                           (lambda (_%$%g75617564%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$%g75627567%_)
                     (cons _%$%g75617564%_ _%$%g75627567%_))))
              (declare (not safe))
              (foldr__0 __tmp34898 '() _%$%body74407528%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        '())))
                      '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            '())))
                          (cons _%$%hd74217467%_ '()))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop74357509%_
                                       _%$%target74327503%_
                                       '()))
                                    (_%$%g74117446%_ _%$%g74127450%_)))))
                          (_%$%g74117446%_ _%$%g74127450%_))
                      (_%$%g74117446%_ _%$%g74127450%_))))
              (_%$%g74117446%_ _%$%g74127450%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g74117446%_
                                               _%$%g74127450%_))))
                                      (_%$%g74117446%_ _%$%g74127450%_))))
                              (_%$%g74117446%_ _%$%g74127450%_))))
                      (_%$%g74117446%_ _%$%g74127450%_)))))
          (_%$%g74107570%_ _%$stx7407%_))))
    (define |gerbil-ascent/core/rule-semantics[:0:]#with-rule-reads|
      (lambda (_%$stx7575%_)
        (let* ((_%$%g75797614%_
                (lambda (_%$%g75807610%_)
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%$%g75807610%_))))
               (_%$%g75787737%_
                (lambda (_%$%g75807618%_)
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-pair? _%$%g75807618%_))
                      (let ((_%$%e75857621%_
                             (let ()
                               (declare (not safe))
                               (gx#syntax-e _%$%g75807618%_))))
                        (let ((_%$%hd75867625%_
                               (let ()
                                 (declare (not safe))
                                 (##car _%$%e75857621%_)))
                              (_%$%tl75877628%_
                               (let ()
                                 (declare (not safe))
                                 (##cdr _%$%e75857621%_))))
                          (if (let ()
                                (declare (not safe))
                                (gx#stx-pair? _%$%tl75877628%_))
                              (let ((_%$%e75887631%_
                                     (let ()
                                       (declare (not safe))
                                       (gx#syntax-e _%$%tl75877628%_))))
                                (let ((_%$%hd75897635%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%e75887631%_)))
                                      (_%$%tl75907638%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%e75887631%_))))
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%tl75907638%_))
                                      (let ((_%$%e75917641%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%tl75907638%_))))
                                        (let ((_%$%hd75927645%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e75917641%_)))
                                              (_%$%tl75937648%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e75917641%_))))
                                          (if (let ()
                                                (declare (not safe))
                                                (gx#stx-pair?
                                                 _%$%hd75927645%_))
                                              (let ((_%$%e75947651%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (gx#syntax-e
                                                        _%$%hd75927645%_))))
                                                (let ((_%$%hd75957655%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##car _%$%e75947651%_)))
                                                      (_%$%tl75967658%_
                                                       (let ()
                                                         (declare (not safe))
                                                         (##cdr _%$%e75947651%_))))
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gx#stx-pair?
                                                         _%$%tl75967658%_))
                                                      (let ((_%$%e75977661%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#syntax-e _%$%tl75967658%_))))
                (let ((_%$%hd75987665%_
                       (let () (declare (not safe)) (##car _%$%e75977661%_)))
                      (_%$%tl75997668%_
                       (let () (declare (not safe)) (##cdr _%$%e75977661%_))))
                  (if (let ()
                        (declare (not safe))
                        (gx#stx-null? _%$%tl75997668%_))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl75937648%_))
                          (let ((_g34899_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice
                                    _%$%tl75937648%_
                                    '0))))
                            (begin
                              (let ((_g34900_
                                     (let ()
                                       (declare (not safe))
                                       (if (##values? _g34899_)
                                           (##values-length _g34899_)
                                           1))))
                                (if (not (let ()
                                           (declare (not safe))
                                           (##fx= _g34900_ 2)))
                                    (error "Context expects 2 values"
                                           _g34900_)))
                              (let ((_%$%target76007671%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g34899_ 0)))
                                    (_%$%tl76027674%_
                                     (let ()
                                       (declare (not safe))
                                       (##values-ref _g34899_ 1))))
                                (if (let ()
                                      (declare (not safe))
                                      (gx#stx-null? _%$%tl76027674%_))
                                    (letrec ((_%$%loop76037677%_
                                              (lambda (_%$%hd76017681%_
                                                       _%$%body76077684%_)
                                                (if (let ()
                                                      (declare (not safe))
                                                      (gx#stx-pair?
                                                       _%$%hd76017681%_))
                                                    (let ((_%$%e76047686%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (gx#syntax-e
                                                              _%$%hd76017681%_))))
                                                      (let ((_%$%lp-hd76057690%_
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##car _%$%e76047686%_)))
                    (_%$%lp-tl76067693%_
                     (let () (declare (not safe)) (##cdr _%$%e76047686%_))))
                (_%$%loop76037677%_
                 _%$%lp-tl76067693%_
                 (cons _%$%lp-hd76057690%_ _%$%body76077684%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (let ((_%$%body76087696%_
                                                           (reverse _%$%body76077684%_)))
                                                      (cons (let ()
                                                              (declare
                                                                (not safe))
                                                              (gx#datum->syntax__0
                                                               '#f
                                                               'let))
                                                            (cons (cons (cons _%$%hd75957655%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                      (cons (cons (let ()
                                                    (declare (not safe))
                                                    (gx#datum->syntax__0
                                                     '#f
                                                     'vector-ref))
                                                  (cons _%$%hd75897635%_
                                                        (cons '0 '())))
                                            '()))
                                (cons (cons _%$%hd75987665%_
                                            (cons (cons (let ()
                                                          (declare (not safe))
                                                          (gx#datum->syntax__0
                                                           '#f
                                                           'prepare-rule-reads))
                                                        (cons (cons (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (declare (not safe))
                              (gx#datum->syntax__0 '#f 'vector-ref))
                            (cons _%$%hd75897635%_ (cons '1 '())))
                      '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                  '()))
                                      '()))
                          (let ((__tmp34901
                                 (lambda (_%$%g77287731%_ _%$%g77297734%_)
                                   (cons _%$%g77287731%_ _%$%g77297734%_))))
                            (declare (not safe))
                            (foldr__0
                             __tmp34901
                             '()
                             _%$%body76087696%_)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                      (_%$%loop76037677%_
                                       _%$%target76007671%_
                                       '()))
                                    (_%$%g75797614%_ _%$%g75807618%_)))))
                          (_%$%g75797614%_ _%$%g75807618%_))
                      (_%$%g75797614%_ _%$%g75807618%_))))
              (_%$%g75797614%_ _%$%g75807618%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                              (_%$%g75797614%_
                                               _%$%g75807618%_))))
                                      (_%$%g75797614%_ _%$%g75807618%_))))
                              (_%$%g75797614%_ _%$%g75807618%_))))
                      (_%$%g75797614%_ _%$%g75807618%_)))))
          (_%$%g75787737%_ _%$stx7575%_))))))
