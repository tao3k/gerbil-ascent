(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/nonmembership::timestamp 1791692691)
  (begin
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
      (let ((__tmp34105 (list)) (__tmp34104 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'positive-nonmembership
         __tmp34105
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         __tmp34104
         '#f)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t)))
    (define gerbil-ascent/candidate/nonmembership#make-positive-nonmembership
      (lambda _%$args29983%_
        (apply make-instance
               gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
               _%$args29983%_)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'status)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-identity-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-identity)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-generation-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-generation)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-snapshot-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'snapshot-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-candidate-digest-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'candidate-digest)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-program-fingerprint-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'program-fingerprint)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-query-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'query)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-work-budget-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'work-budget)))
    (define gerbil-ascent/candidate/nonmembership#&positive-nonmembership-closure-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         'closure)))
    (define gerbil-ascent/candidate/nonmembership#certificate-size-valid?
      (lambda (_%closure29967%_)
        (let ((_%relation-count29969%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                  _%closure29967%_
                  gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)))
              (_%rows29970%_ '0)
              (_%cells29971%_ '0))
          (if _%relation-count29969%_
              (let ((__tmp34106
                     (lambda (_%entry29973%_)
                       (if (equal? (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%entry29973%_
                                      '3))
                                   '3)
                           (let* ((_%row-list29975%_ (caddr _%entry29973%_))
                                  (_%count29977%_
                                   (let ((__tmp34107
                                          (- gerbil-ascent/candidate/certificate-limits#+max-certificate-rows+
                                             _%rows29970%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                                      _%row-list29975%_
                                      __tmp34107))))
                             (if _%count29977%_
                                 (if (begin
                                       (set! _%rows29970%_
                                             (+ _%rows29970%_ _%count29977%_))
                                       '#t)
                                     (let ((__tmp34108
                                            (lambda (_%row29979%_)
                                              (let ((_%width29981%_
                                                     (let ((__tmp34109
                                                            (min gerbil-ascent/candidate/certificate-limits#+max-certificate-row-arity+
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (- gerbil-ascent/candidate/certificate-limits#+max-certificate-cells+
                            _%cells29971%_))))
               (declare (not safe))
               (gerbil-ascent/candidate/certificate-limits#bounded-list-length
                _%row29979%_
                __tmp34109))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%width29981%_
                                                    (begin
                                                      (set! _%cells29971%_
                                                            (+ _%cells29971%_
                                                               _%width29981%_))
                                                      '#t)
                                                    '#f)))))
                                       (declare (not safe))
                                       (andmap__0
                                        __tmp34108
                                        _%row-list29975%_))
                                     '#f)
                                 '#f))
                           '#f))))
                (declare (not safe))
                (andmap__0 __tmp34106 _%closure29967%_))
              '#f))))
    (define gerbil-ascent/candidate/nonmembership#ground-query?
      (lambda (_%query29963%_)
        (if (list? _%query29963%_)
            (if (pair? _%query29963%_)
                (let ((__tmp34111
                       (lambda (_%term29965%_)
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#scalar?
                                _%term29965%_))
                             (if (let ()
                                   (declare (not safe))
                                   (gerbil-ascent/candidate/program#candidate-variable?
                                    _%term29965%_))
                                 '#f
                                 (not (eq? _%term29965%_ '?_)))
                             '#f)))
                      (__tmp34110
                       (let () (declare (not safe)) (##cdr _%query29963%_))))
                  (declare (not safe))
                  (andmap__0 __tmp34111 __tmp34110))
                '#f)
            '#f)))
    (define gerbil-ascent/candidate/nonmembership#certificate-schema-of
      (lambda (_%snapshot29958%_ _%spec29959%_)
        (let ((__tmp34113
               (lambda (_%entry29961%_)
                 (list (car _%entry29961%_) (cdr _%entry29961%_))))
              (__tmp34112
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/funs#candidate-schema-of
                  _%snapshot29958%_
                  _%spec29959%_))))
          (declare (not safe))
          (##map __tmp34113 __tmp34112))))
    (define gerbil-ascent/candidate/nonmembership#candidate-positive-nonmembership
      (lambda (_%snapshot29908%_
               _%spec29909%_
               _%candidate-digest29910%_
               _%native-status29911%_
               _%native-rows29912%_
               _%max-steps29913%_)
        (if (and (exact-integer? _%max-steps29913%_) (> _%max-steps29913%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership work budget" _%max-steps29913%_)))
        (let ((_%query29915%_
               (vector-ref
                (##structure-ref
                 _%spec29909%_
                 '4
                 gerbil-ascent/candidate/types#reasoning-candidate::t
                 '#f)
                '0)))
          (letrec ((_%result29917%_
                    (lambda (_%status29955%_ _%closure29956%_)
                      (let ((__tmp34118
                             (##structure-ref
                              _%snapshot29908%_
                              '1
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34117
                             (##structure-ref
                              _%snapshot29908%_
                              '2
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34116
                             (##structure-ref
                              _%snapshot29908%_
                              '3
                              gerbil-ascent/candidate/types#reasoning-snapshot::t
                              '#f))
                            (__tmp34115
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                                _%spec29909%_)))
                            (__tmp34114
                             (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                _%query29915%_))))
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
                         _%status29955%_
                         __tmp34118
                         __tmp34117
                         __tmp34116
                         _%candidate-digest29910%_
                         __tmp34115
                         __tmp34114
                         _%max-steps29913%_
                         _%closure29956%_)))))
            (if (or (not (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                            _%snapshot29908%_)))
                    (not (eq? _%native-status29911%_ 'complete))
                    (pair? _%native-rows29912%_)
                    (not (gerbil-ascent/candidate/nonmembership#ground-query?
                          _%query29915%_))
                    (not (let ((__tmp34119
                                (##structure-ref
                                 _%spec29909%_
                                 '3
                                 gerbil-ascent/candidate/types#reasoning-candidate::t
                                 '#f)))
                           (declare (not safe))
                           (andmap__0
                            gerbil-ascent/candidate/provenance#positive-rule-body?
                            __tmp34119))))
                (_%result29917%_ 'unsupported '())
                (if (> (let ((__tmp34120
                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                               _%snapshot29908%_
                               _%spec29909%_)))
                         (declare (not safe))
                         (##length __tmp34120))
                       gerbil-ascent/candidate/certificate-limits#+max-certificate-relations+)
                    (_%result29917%_ 'bounded '())
                    (let* ((_%witness29931%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/candidate/provenance#candidate-positive-closed-absence
                               _%snapshot29908%_
                               _%spec29909%_
                               _%candidate-digest29910%_
                               _%native-status29911%_
                               _%native-rows29912%_
                               _%max-steps29913%_)))
                           (_%status29933%_
                            (##structure-ref
                             _%witness29931%_
                             '1
                             gerbil-ascent/candidate/provenance#positive-proof::t
                             '#f))
                           (_%$e29936%_ _%status29933%_))
                      (if (eq? 'bounded _%$e29936%_)
                          (_%result29917%_ 'bounded '())
                          (if (eq? 'closed-absent _%$e29936%_)
                              (let ((_%grouped29939%_
                                     (let ()
                                       (declare (not safe))
                                       (make-hash-table-eq))))
                                (for-each
                                 (lambda (_%node29941%_)
                                   (let* ((_%name29943%_
                                           (##structure-ref
                                            _%node29941%_
                                            '3
                                            gerbil-ascent/candidate/provenance#proof-node::t
                                            '#f))
                                          (__tmp34121
                                           (cons (##structure-ref
                                                  _%node29941%_
                                                  '4
                                                  gerbil-ascent/candidate/provenance#proof-node::t
                                                  '#f)
                                                 (let ((_%$e29945%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-get
                                                           _%grouped29939%_
                                                           _%name29943%_))))
                                                   (if _%$e29945%_
                                                       _%$e29945%_
                                                       '())))))
                                     (declare (not safe))
                                     (__hash-put!
                                      _%grouped29939%_
                                      _%name29943%_
                                      __tmp34121)))
                                 (##structure-ref
                                  _%witness29931%_
                                  '8
                                  gerbil-ascent/candidate/provenance#positive-proof::t
                                  '#f))
                                (let ((_%closure29953%_
                                       (let ((__tmp34123
                                              (lambda (_%declaration29948%_)
                                                (list (car _%declaration29948%_)
                                                      (cadr _%declaration29948%_)
                                                      (let ((__tmp34124
                                                             (reverse (let ((_%$e29950%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     (let ((__tmp34125
                                            (car _%declaration29948%_)))
                                       (declare (not safe))
                                       (__hash-get
                                        _%grouped29939%_
                                        __tmp34125))))
                                (if _%$e29950%_ _%$e29950%_ '())))))
                (declare (not safe))
                (##map gerbil-ascent/candidate/datum#candidate-copy-pairs
                       __tmp34124)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                             (__tmp34122
                                              (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                                               _%snapshot29908%_
                                               _%spec29909%_)))
                                         (declare (not safe))
                                         (##map __tmp34123 __tmp34122))))
                                  (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                                       _%closure29953%_)
                                      (_%result29917%_
                                       'complete
                                       _%closure29953%_)
                                      (_%result29917%_ 'bounded '()))))
                              (_%result29917%_ 'unsupported '()))))))))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__%
      (lambda (_%terms29890%_ _%wildcards?29891%_)
        (map (lambda (_%term29893%_)
               (cons (if (and _%wildcards?29891%_ (eq? _%term29893%_ '?_))
                         'wildcard
                         (if (let ()
                               (declare (not safe))
                               (gerbil-ascent/candidate/program#candidate-variable?
                                _%term29893%_))
                             'variable
                             'literal))
                     _%term29893%_))
             _%terms29890%_)))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns__0
      (lambda (_%terms29901%_)
        (let ((_%wildcards?29903%_ '#t))
          (gerbil-ascent/candidate/nonmembership#binding-patterns__%
           _%terms29901%_
           _%wildcards?29903%_))))
    (define gerbil-ascent/candidate/nonmembership#binding-patterns
      (lambda _g34126_
        (let ((_g34127_ (let () (declare (not safe)) (##length _g34126_))))
          (cond ((let () (declare (not safe)) (##fx= _g34127_ 1))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__0
                        _g34126_))
                ((let () (declare (not safe)) (##fx= _g34127_ 2))
                 (apply gerbil-ascent/candidate/nonmembership#binding-patterns__%
                        _g34126_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/nonmembership#binding-patterns
                  _g34126_))))))
    (define gerbil-ascent/candidate/nonmembership#head-row
      (lambda (_%head29884%_ _%bindings29885%_)
        (map (lambda (_%term29887%_)
               (if (eq? (car _%term29887%_) 'variable)
                   (cdr (assq (cdr _%term29887%_) _%bindings29885%_))
                   (cdr _%term29887%_)))
             _%head29884%_)))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
      (lambda (_%snapshot29709%_
               _%spec29710%_
               _%candidate-digest29711%_
               _%native-status29712%_
               _%native-rows29713%_
               _%certificate29714%_
               _%max-checks29715%_)
        (if (and (exact-integer? _%max-checks29715%_)
                 (> _%max-checks29715%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid nonmembership verification budget"
                     _%max-checks29715%_)))
        (let* ((_%query29717%_
                (vector-ref
                 (##structure-ref
                  _%spec29710%_
                  '4
                  gerbil-ascent/candidate/types#reasoning-candidate::t
                  '#f)
                 '0))
               (_%schema29719%_
                (gerbil-ascent/candidate/nonmembership#certificate-schema-of
                 _%snapshot29709%_
                 _%spec29710%_))
               (_%closure29721%_
                (if (let ()
                      (declare (not safe))
                      (##structure-instance-of?
                       _%certificate29714%_
                       'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                    (let ()
                      (declare (not safe))
                      (##unchecked-structure-ref
                       _%certificate29714%_
                       '9
                       '#f
                       '#f))
                    '#f))
               (_%preflight29729%_
                (if (gerbil-ascent/candidate/nonmembership#certificate-size-valid?
                     _%closure29721%_)
                    (if (= (length _%closure29721%_)
                           (let ()
                             (declare (not safe))
                             (##length _%schema29719%_)))
                        (if (let ((__tmp34128
                                   (lambda (_%entry29723%_)
                                     (and (list? _%entry29723%_)
                                          (= (let ()
                                               (declare (not safe))
                                               (##length _%entry29723%_))
                                             '3)
                                          (list? (caddr _%entry29723%_))))))
                              (declare (not safe))
                              (andmap__0 __tmp34128 _%closure29721%_))
                            (+ '1
                               (let ((__tmp34129
                                      (map (lambda (_%entry29725%_)
                                             (length (caddr _%entry29725%_)))
                                           _%closure29721%_)))
                                 (declare (not safe))
                                 (##apply + __tmp34129))
                               (let ((__tmp34130
                                      (map (lambda (_%entry29727%_)
                                             (length (caddr _%entry29727%_)))
                                           (##structure-ref
                                            _%snapshot29709%_
                                            '4
                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                            '#f))))
                                 (declare (not safe))
                                 (##apply + __tmp34130))
                               (length (##structure-ref
                                        _%spec29710%_
                                        '2
                                        gerbil-ascent/candidate/types#reasoning-candidate::t
                                        '#f)))
                            '#f)
                        '#f)
                    '#f)))
          (if (and (let ()
                     (declare (not safe))
                     (##structure-instance-of?
                      _%certificate29714%_
                      'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t))
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
                      _%snapshot29709%_))
                   (eq? (let ()
                          (declare (not safe))
                          (##unchecked-structure-ref
                           _%certificate29714%_
                           '1
                           '#f
                           '#f))
                        'complete)
                   (eq? _%native-status29712%_ 'complete)
                   (null? _%native-rows29713%_)
                   (gerbil-ascent/candidate/nonmembership#ground-query?
                    _%query29717%_)
                   (let ((__tmp34131
                          (##structure-ref
                           _%spec29710%_
                           '3
                           gerbil-ascent/candidate/types#reasoning-candidate::t
                           '#f)))
                     (declare (not safe))
                     (andmap__0
                      gerbil-ascent/candidate/provenance#positive-rule-body?
                      __tmp34131))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '2
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29709%_
                            '1
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '3
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29709%_
                            '2
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '4
                              '#f
                              '#f))
                           (##structure-ref
                            _%snapshot29709%_
                            '3
                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                            '#f))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '5
                              '#f
                              '#f))
                           _%candidate-digest29711%_)
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '6
                              '#f
                              '#f))
                           (let ()
                             (declare (not safe))
                             (gerbil-ascent/candidate/program-identity#candidate-positive-program-fingerprint
                              _%spec29710%_)))
                   (equal? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref
                              _%certificate29714%_
                              '7
                              '#f
                              '#f))
                           _%query29717%_)
                   _%preflight29729%_
                   (equal? (map (lambda (_%entry29732%_)
                                  (list (car _%entry29732%_)
                                        (cadr _%entry29732%_)))
                                _%closure29721%_)
                           _%schema29719%_))
              (if (> _%preflight29729%_ _%max-checks29715%_)
                  'bounded
                  (if (let ((__tmp34132
                             (lambda (_%entry29736%_)
                               (and (let ((__tmp34133 (caddr _%entry29736%_)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/certificate-limits#unique-rows?
                                       __tmp34133))
                                    (let ((__tmp34135
                                           (lambda (_%row29738%_)
                                             (and (list? _%row29738%_)
                                                  (= (let ()
                                                       (declare (not safe))
                                                       (##length _%row29738%_))
                                                     (cadr _%entry29736%_))
                                                  (let ()
                                                    (declare (not safe))
                                                    (andmap__0
                                                     gerbil-ascent/candidate/program#scalar?
                                                     _%row29738%_)))))
                                          (__tmp34134 (caddr _%entry29736%_)))
                                      (declare (not safe))
                                      (andmap__0 __tmp34135 __tmp34134))))))
                        (declare (not safe))
                        (andmap__0 __tmp34132 _%closure29721%_))
                      (let* ((_%steps29742%_ _%preflight29729%_)
                             (_%bounded?29744%_ '#f)
                             (_%invalid?29746%_ '#f)
                             (_%direct?29803%_
                              (let* ((_%$%closure2974729763%_ _%closure29721%_)
                                     (_%$%else2975129771%_ (lambda () '#f)))
                                (let ((_%$%K2976129800%_ (lambda () '#t))
                                      (_%$%K2975829790%_ (lambda () '#t))
                                      (_%$%K2975329776%_ (lambda () '#t)))
                                  (let ((_%$%try-match2974929796%_
                                         (lambda ()
                                           (if (pair? _%$%closure2974729763%_)
                                               (let ((_%$%tl2976029793%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (##cdr _%$%closure2974729763%_))))
                                                 (if (null? _%$%tl2976029793%_)
                                                     (_%$%K2975829790%_)
                                                     (if (pair? _%$%tl2976029793%_)
                                                         (let ((_%$%tl2975729782%_
                                                                (let ()
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (declare (not safe))
                          (##cdr _%$%tl2976029793%_))))
                   (if (null? _%$%tl2975729782%_)
                       (_%$%K2975329776%_)
                       (_%$%else2975129771%_)))
                 (_%$%else2975129771%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                               (_%$%else2975129771%_)))))
                                    (if (null? _%$%closure2974729763%_)
                                        (_%$%K2976129800%_)
                                        (_%$%try-match2974929796%_))))))
                             (_%index29805%_
                              (if _%direct?29803%_
                                  '()
                                  (let ((__tmp34136 (length _%closure29721%_)))
                                    (declare (not safe))
                                    (make-hash-table-eq 'size: __tmp34136)))))
                        (letrec* ((_%relation-entry29808%_
                                   (lambda (_%name29880%_)
                                     (if _%direct?29803%_
                                         (let ((_%entry29882%_
                                                (assq _%name29880%_
                                                      _%index29805%_)))
                                           (if _%entry29882%_
                                               (cdr _%entry29882%_)
                                               '#f))
                                         (let ()
                                           (declare (not safe))
                                           (hash-get
                                            _%index29805%_
                                            _%name29880%_)))))
                                  (_g34137_
                                   (let ((_g34138_
                                          (for-each
                                           (lambda (_%entry29810%_)
                                             (let ((_%present29812%_
                                                    (let ()
                                                      (declare (not safe))
                                                      (make-hash-table__%
                                                       '#f
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value
                                                       absent-value))))
                                               (for-each
                                                (lambda (_%row29814%_)
                                                  (let ()
                                                    (declare (not safe))
                                                    (__hash-put!
                                                     _%present29812%_
                                                     _%row29814%_
                                                     '#t)))
                                                (caddr _%entry29810%_))
                                               (if (_%relation-entry29808%_
                                                    (car _%entry29810%_))
                                                   '#!void
                                                   (let ((_%value29816%_
                                                          (cons (caddr _%entry29810%_)
                                                                _%present29812%_)))
                                                     (if _%direct?29803%_
                                                         (set! _%index29805%_
                                                               (cons (cons (car _%entry29810%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                   _%value29816%_)
                             _%index29805%_))
                 (let ((__tmp34140 (car _%entry29810%_)))
                   (declare (not safe))
                   (hash-put! _%index29805%_ __tmp34140 _%value29816%_)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                           _%closure29721%_)))
                                     #!void
                                     _g34138_))
                                  (_%rows29817%_
                                   (lambda (_%name29876%_)
                                     (let ((_%entry29878%_
                                            (_%relation-entry29808%_
                                             _%name29876%_)))
                                       (if _%entry29878%_
                                           (car _%entry29878%_)
                                           '()))))
                                  (_%contains?29818%_
                                   (lambda (_%name29871%_ _%row29872%_)
                                     (let ((_%entry29874%_
                                            (_%relation-entry29808%_
                                             _%name29871%_)))
                                       (if _%entry29874%_
                                           (let ((__tmp34141
                                                  (cdr _%entry29874%_)))
                                             (declare (not safe))
                                             (hash-get
                                              __tmp34141
                                              _%row29872%_))
                                           '#f)))))
                          (begin
                            (if _%bounded?29744%_
                                '#!void
                                (for-each
                                 (lambda (_%entry29820%_)
                                   (for-each
                                    (lambda (_%row29822%_)
                                      (if (_%contains?29818%_
                                           (car _%entry29820%_)
                                           _%row29822%_)
                                          '#!void
                                          (set! _%invalid?29746%_ '#t)))
                                    (caddr _%entry29820%_)))
                                 (##structure-ref
                                  _%snapshot29709%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f)))
                            (if _%bounded?29744%_
                                '#!void
                                (for-each
                                 (lambda (_%fact29824%_)
                                   (if (_%contains?29818%_
                                        (vector-ref _%fact29824%_ '0)
                                        (vector-ref _%fact29824%_ '1))
                                       '#!void
                                       (set! _%invalid?29746%_ '#t)))
                                 (##structure-ref
                                  _%spec29710%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if (if _%bounded?29744%_
                                    '#f
                                    (_%contains?29818%_
                                     (car _%query29717%_)
                                     (cdr _%query29717%_)))
                                (set! _%invalid?29746%_ '#t)
                                '#!void)
                            (if (or _%bounded?29744%_ _%invalid?29746%_)
                                '#!void
                                (for-each
                                 (lambda (_%rule29829%_)
                                   (let* ((_%head29831%_
                                           (vector-ref _%rule29829%_ '0))
                                          (_%covered-head?29835%_
                                           (if (memq '?_ (cdr _%head29831%_))
                                               '#f
                                               (let ((__tmp34143
                                                      (lambda (_%clause29833%_)
                                                        (if (let ()
                                                              (declare
                                                                (not safe))
                                                              (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                               _%clause29833%_))
                                                            '#f
                                                            (equal? _%head29831%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%clause29833%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (__tmp34142
                                                      (vector-ref
                                                       _%rule29829%_
                                                       '1)))
                                                 (declare (not safe))
                                                 (ormap__0
                                                  __tmp34143
                                                  __tmp34142))))
                                          (_%head-patterns29837%_
                                           (if _%covered-head?29835%_
                                               '()
                                               (gerbil-ascent/candidate/nonmembership#binding-patterns__%
                                                (cdr _%head29831%_)
                                                '#f)))
                                          (_%head-entry29839%_
                                           (if _%covered-head?29835%_
                                               '#f
                                               (_%relation-entry29808%_
                                                (car _%head29831%_))))
                                          (_%body29843%_
                                           (map (lambda (_%clause29841%_)
                                                  (if (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/provenance#positive-fixed-clause?
                                                         _%clause29841%_))
                                                      (vector '#t
                                                              _%clause29841%_
                                                              '())
                                                      (vector '#f
                                                              (gerbil-ascent/candidate/nonmembership#binding-patterns__0
                                                               (cdr _%clause29841%_))
                                                              (_%rows29817%_
                                                               (car _%clause29841%_)))))
                                                (vector-ref
                                                 _%rule29829%_
                                                 '1))))
                                     (letrec ((_%walk29846%_
                                               (lambda (_%remaining29848%_
                                                        _%bindings29849%_)
                                                 (if (or _%bounded?29744%_
                                                         _%invalid?29746%_)
                                                     '#!void
                                                     (if (null? _%remaining29848%_)
                                                         (if (or _%covered-head?29835%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (and _%head-entry29839%_
                              (let ((__tmp34145 (cdr _%head-entry29839%_))
                                    (__tmp34144
                                     (gerbil-ascent/candidate/nonmembership#head-row
                                      _%head-patterns29837%_
                                      _%bindings29849%_)))
                                (declare (not safe))
                                (hash-get __tmp34145 __tmp34144))))
                     '#!void
                     (set! _%invalid?29746%_ '#t))
                 (let ((_%clause29857%_ (car _%remaining29848%_)))
                   (if (vector-ref _%clause29857%_ '0)
                       (begin
                         (set! _%steps29742%_ (+ _%steps29742%_ '1))
                         (if (> _%steps29742%_ _%max-checks29715%_)
                             (set! _%bounded?29744%_ '#t)
                             (let ((_%next29859%_
                                    (let ((__tmp34146
                                           (vector-ref _%clause29857%_ '1)))
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                       __tmp34146
                                       _%bindings29849%_))))
                               (if _%next29859%_
                                   (_%walk29846%_
                                    (cdr _%remaining29848%_)
                                    _%next29859%_)
                                   '#!void))))
                       (for-each
                        (lambda (_%row29861%_)
                          (if (or _%bounded?29744%_ _%invalid?29746%_)
                              '#!void
                              (begin
                                (set! _%steps29742%_ (+ _%steps29742%_ '1))
                                (if (> _%steps29742%_ _%max-checks29715%_)
                                    (set! _%bounded?29744%_ '#t)
                                    (let ((_%next29866%_
                                           (let ((__tmp34147
                                                  (vector-ref
                                                   _%clause29857%_
                                                   '1)))
                                             (declare (not safe))
                                             (gerbil-ascent/core/rule-bindings#gerbil-ascent-bind-row
                                              __tmp34147
                                              _%row29861%_
                                              _%bindings29849%_))))
                                      (if _%next29866%_
                                          (_%walk29846%_
                                           (cdr _%remaining29848%_)
                                           _%next29866%_)
                                          '#!void))))))
                        (vector-ref _%clause29857%_ '2)))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                       (_%walk29846%_ _%body29843%_ '()))))
                                 (##structure-ref
                                  _%spec29710%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f)))
                            (if _%invalid?29746%_
                                'invalid
                                (if _%bounded?29744%_ 'bounded 'valid)))))
                      'invalid))
              'invalid))))
    (define gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership
      (lambda (_%snapshot29701%_
               _%spec29702%_
               _%candidate-digest29703%_
               _%native-status29704%_
               _%native-rows29705%_
               _%certificate29706%_
               _%max-checks29707%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot29701%_))
            (gerbil-ascent/candidate/nonmembership#candidate-verify-positive-nonmembership/valid-snapshot
             _%snapshot29701%_
             _%spec29702%_
             _%candidate-digest29703%_
             _%native-status29704%_
             _%native-rows29705%_
             _%certificate29706%_
             _%max-checks29707%_)
            'invalid)))))
