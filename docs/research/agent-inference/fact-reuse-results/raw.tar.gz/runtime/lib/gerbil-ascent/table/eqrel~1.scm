(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/eqrel[1]#_g6325_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6327_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6329_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6331_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6332_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6334_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6335_|
    (##structure
     gx#syntax-quote::t
     'eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6337_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6338_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6340_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6341_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-component-size-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6343_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6345_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-cut
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6347_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6349_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6350_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6352_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6353_|
    (##structure
     gx#syntax-quote::t
     'eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6355_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6356_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6358_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6359_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-cut-view-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6361_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6363_|
    (##structure
     gx#syntax-quote::t
     'make-eqrel-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6365_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6367_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6368_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6369_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6370_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6372_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6373_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6374_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6375_|
    (##structure
     gx#syntax-quote::t
     'eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6377_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6378_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6379_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6380_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6382_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-components-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6383_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6384_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-published-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6385_|
    (##structure
     gx#syntax-quote::t
     '&eqrel-state-origin-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6387_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6389_|
    (##structure
     gx#syntax-quote::t
     'make-coordinate-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6391_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6393_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6394_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6395_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6397_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6398_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6399_|
    (##structure
     gx#syntax-quote::t
     'coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6401_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6402_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6403_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6405_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-bound?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6406_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-value-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/eqrel[1]#_g6407_|
    (##structure
     gx#syntax-quote::t
     '&coordinate-key-coherent?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-component|
      (let ((__obj6289
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6289
           'gerbil-ascent/table/eqrel#eqrel-component::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 'eqrel-component '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '(members size) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '(members size) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '#f '13 '#f '#f))
        (let ((__tmp6324 |gerbil-ascent/table/eqrel[1]#_g6325_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6324 '4 '#f '#f))
        (let ((__tmp6326 |gerbil-ascent/table/eqrel[1]#_g6327_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6326 '14 '#f '#f))
        (let ((__tmp6328 |gerbil-ascent/table/eqrel[1]#_g6329_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6328 '15 '#f '#f))
        (let ((__tmp6330
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g6331_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g6332_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6330 '16 '#f '#f))
        (let ((__tmp6333
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g6334_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g6335_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6333 '17 '#f '#f))
        (let ((__tmp6336
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g6337_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g6338_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6336 '18 '#f '#f))
        (let ((__tmp6339
               (cons (cons 'members |gerbil-ascent/table/eqrel[1]#_g6340_|)
                     (cons (cons 'size |gerbil-ascent/table/eqrel[1]#_g6341_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 __tmp6339 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6289 '() '21 '#f '#f))
        __obj6289))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-cut|
      (let ((__obj6290
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6290
           'gerbil-ascent/table/eqrel#eqrel-cut::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 'eqrel-cut '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '(count view) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '(count view) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '#f '13 '#f '#f))
        (let ((__tmp6342 |gerbil-ascent/table/eqrel[1]#_g6343_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6342 '4 '#f '#f))
        (let ((__tmp6344 |gerbil-ascent/table/eqrel[1]#_g6345_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6344 '14 '#f '#f))
        (let ((__tmp6346 |gerbil-ascent/table/eqrel[1]#_g6347_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6346 '15 '#f '#f))
        (let ((__tmp6348
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6349_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g6350_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6348 '16 '#f '#f))
        (let ((__tmp6351
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6352_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g6353_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6351 '17 '#f '#f))
        (let ((__tmp6354
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6355_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g6356_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6354 '18 '#f '#f))
        (let ((__tmp6357
               (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6358_|)
                     (cons (cons 'view |gerbil-ascent/table/eqrel[1]#_g6359_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 __tmp6357 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6290 '() '21 '#f '#f))
        __obj6290))
    (define |gerbil-ascent/table/eqrel[:0:]#eqrel-state|
      (let ((__obj6291
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6291
           'gerbil-ascent/table/eqrel#eqrel-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 'eqrel-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6291
           '(components count published origin)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6291
           '(components count published origin)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '#f '13 '#f '#f))
        (let ((__tmp6360 |gerbil-ascent/table/eqrel[1]#_g6361_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6360 '4 '#f '#f))
        (let ((__tmp6362 |gerbil-ascent/table/eqrel[1]#_g6363_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6362 '14 '#f '#f))
        (let ((__tmp6364 |gerbil-ascent/table/eqrel[1]#_g6365_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6364 '15 '#f '#f))
        (let ((__tmp6366
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g6367_|)
                     (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6368_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g6369_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g6370_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6366 '16 '#f '#f))
        (let ((__tmp6371
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g6372_|)
                     (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6373_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g6374_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g6375_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6371 '17 '#f '#f))
        (let ((__tmp6376
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g6377_|)
                     (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6378_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g6379_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g6380_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6376 '18 '#f '#f))
        (let ((__tmp6381
               (cons (cons 'components |gerbil-ascent/table/eqrel[1]#_g6382_|)
                     (cons (cons 'count |gerbil-ascent/table/eqrel[1]#_g6383_|)
                           (cons (cons 'published
                                       |gerbil-ascent/table/eqrel[1]#_g6384_|)
                                 (cons (cons 'origin
                                             |gerbil-ascent/table/eqrel[1]#_g6385_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 __tmp6381 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6291 '() '21 '#f '#f))
        __obj6291))
    (define |gerbil-ascent/table/eqrel[:0:]#coordinate-key|
      (let ((__obj6292
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6292
           'gerbil-ascent/table/eqrel#coordinate-key::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 'coordinate-key '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6292
           '(bound? value coherent?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj6292
           '(bound? value coherent?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '#f '13 '#f '#f))
        (let ((__tmp6386 |gerbil-ascent/table/eqrel[1]#_g6387_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6386 '4 '#f '#f))
        (let ((__tmp6388 |gerbil-ascent/table/eqrel[1]#_g6389_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6388 '14 '#f '#f))
        (let ((__tmp6390 |gerbil-ascent/table/eqrel[1]#_g6391_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6390 '15 '#f '#f))
        (let ((__tmp6392
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g6393_|)
                     (cons (cons 'value |gerbil-ascent/table/eqrel[1]#_g6394_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g6395_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6392 '16 '#f '#f))
        (let ((__tmp6396
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g6397_|)
                     (cons (cons 'value |gerbil-ascent/table/eqrel[1]#_g6398_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g6399_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6396 '17 '#f '#f))
        (let ((__tmp6400
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g6401_|)
                     (cons (cons 'value |gerbil-ascent/table/eqrel[1]#_g6402_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g6403_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6400 '18 '#f '#f))
        (let ((__tmp6404
               (cons (cons 'bound? |gerbil-ascent/table/eqrel[1]#_g6405_|)
                     (cons (cons 'value |gerbil-ascent/table/eqrel[1]#_g6406_|)
                           (cons (cons 'coherent?
                                       |gerbil-ascent/table/eqrel[1]#_g6407_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 __tmp6404 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj6292 '() '21 '#f '#f))
        __obj6292))))
