(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-checked::timestamp 1791687882)
  (begin
    (define gerbil-ascent/program/scheme-checked#+stable-procedures+
      (let ((__tmp36325 (make-mutex)))
        (declare (not safe))
        (make-hash-table__%
         '#f
         absent-value
         absent-value
         eq?
         absent-value
         __tmp36325
         absent-value
         '#t
         absent-value)))
    (define gerbil-ascent/program/scheme-checked#relational-stable
      (lambda (_%procedure11886%_)
        (let ()
          (declare (not safe))
          (__hash-put!
           gerbil-ascent/program/scheme-checked#+stable-procedures+
           _%procedure11886%_
           '#t))
        _%procedure11886%_))
    (define gerbil-ascent/program/scheme-checked#relational-stable-procedure?
      (lambda (_%procedure11884%_)
        (if (procedure? _%procedure11884%_)
            (if (let ()
                  (declare (not safe))
                  (__hash-get
                   gerbil-ascent/program/scheme-checked#+stable-procedures+
                   _%procedure11884%_))
                '#t
                '#f)
            '#f)))
    (define gerbil-ascent/program/scheme-checked#relational-scalar?
      (lambda (_%value11873%_)
        (let ((_%$e11875%_ (exact-integer? _%value11873%_)))
          (if _%$e11875%_
              _%$e11875%_
              (let ((_%$e11878%_ (boolean? _%value11873%_)))
                (if _%$e11878%_
                    _%$e11878%_
                    (let ((_%$e11881%_ (symbol? _%value11873%_)))
                      (if _%$e11881%_
                          _%$e11881%_
                          (char? _%value11873%_)))))))))
    (define gerbil-ascent/program/scheme-checked#relational-check-row-shape!
      (lambda (_%row11870%_ _%arity11871%_)
        (if (and (list? _%row11870%_)
                 (= (let () (declare (not safe)) (##length _%row11870%_))
                    _%arity11871%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational row has wrong arity or non-scalar value"
                     _%row11870%_)))
        _%row11870%_))
    (define gerbil-ascent/program/scheme-checked#relational-check-row!
      (lambda (_%row11867%_ _%arity11868%_)
        (gerbil-ascent/program/scheme-checked#relational-check-row-shape!
         _%row11867%_
         _%arity11868%_)
        (if (let ()
              (declare (not safe))
              (andmap__0
               gerbil-ascent/program/scheme-checked#relational-scalar?
               _%row11867%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational row has wrong arity or non-scalar value"
                     _%row11867%_)))
        _%row11867%_))
    (define gerbil-ascent/program/scheme-checked#relational-copy-row
      (lambda (_%row11862%_ _%arity11863%_)
        (gerbil-ascent/program/scheme-checked#relational-check-row-shape!
         _%row11862%_
         _%arity11863%_)
        (map (lambda (_%value11865%_)
               (if (gerbil-ascent/program/scheme-checked#relational-scalar?
                    _%value11865%_)
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"relational row has wrong arity or non-scalar value"
                            _%row11862%_)))
               _%value11865%_)
             _%row11862%_)))
    (define gerbil-ascent/program/scheme-checked#relational-copy-rows
      (lambda (_%rows11857%_ _%arity11858%_)
        (if (and (exact-integer? _%arity11858%_)
                 (<= '0 _%arity11858%_)
                 (list? _%rows11857%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid relational row signature" _%arity11858%_)))
        (map (lambda (_%row11860%_)
               (gerbil-ascent/program/scheme-checked#relational-copy-row
                _%row11860%_
                _%arity11858%_))
             _%rows11857%_)))
    (define gerbil-ascent/program/scheme-checked#relational-finite-rows
      (lambda (_%input-arity11849%_ _%output-arity11850%_ _%entries11851%_)
        (if (and (exact-integer? _%input-arity11849%_)
                 (<= '0 _%input-arity11849%_)
                 (exact-integer? _%output-arity11850%_)
                 (<= '0 _%output-arity11850%_)
                 (list? _%entries11851%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid finite view signature")))
        (map (lambda (_%entry11853%_)
               (if (and (list? _%entry11853%_)
                        (= (let ()
                             (declare (not safe))
                             (##length _%entry11853%_))
                           '2))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"finite view entry needs input and output rows"
                            _%entry11853%_)))
               (let* ((_%input11855%_
                       (gerbil-ascent/program/scheme-checked#relational-check-row!
                        (car _%entry11853%_)
                        _%input-arity11849%_))
                      (__tmp36326
                       (gerbil-ascent/program/scheme-checked#relational-copy-row
                        (cadr _%entry11853%_)
                        _%output-arity11850%_)))
                 (declare (not safe))
                 (##append _%input11855%_ __tmp36326)))
             _%entries11851%_)))
    (define gerbil-ascent/program/scheme-checked#relational-source
      (lambda (_%name11845%_ _%arity11846%_ _%rows11847%_)
        (gerbil-ascent/program/scheme-checked#relational-owned-source
         _%name11845%_
         _%arity11846%_
         (gerbil-ascent/program/scheme-checked#relational-copy-rows
          _%rows11847%_
          _%arity11846%_))))
    (define gerbil-ascent/program/scheme-checked#relational-owned-source
      (lambda (_%name11841%_ _%arity11842%_ _%rows11843%_)
        (let ((__tmp36327
               (make-list
                _%arity11842%_
                gerbil-ascent/program/scheme-checked#relational-scalar?)))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-relation__3
           _%name11841%_
           _%arity11842%_
           _%rows11843%_
           gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
           gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
           __tmp36327))))
    (define gerbil-ascent/program/scheme-checked#relational-domain-copy
      (lambda (_%arity11836%_ _%domains11837%_)
        (if (and (list? _%domains11837%_)
                 (= (let () (declare (not safe)) (##length _%domains11837%_))
                    _%arity11836%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite domain column count mismatch")))
        (map (lambda (_%atoms11839%_)
               (if (and (list? _%atoms11839%_)
                        (<= (let ()
                              (declare (not safe))
                              (##length _%atoms11839%_))
                            '4096)
                        (let ()
                          (declare (not safe))
                          (andmap__0
                           gerbil-ascent/program/scheme-checked#relational-scalar?
                           _%atoms11839%_)))
                   '#!void
                   (let ()
                     (declare (not safe))
                     (error '"invalid finite scalar domain")))
               (map identity _%atoms11839%_))
             _%domains11837%_)))
    (define gerbil-ascent/program/scheme-checked#relational-domain-predicates
      (lambda (_%domains11830%_)
        (map (lambda (_%atoms11832%_)
               (lambda (_%value11834%_)
                 (if (member _%value11834%_ _%atoms11832%_) '#t '#f)))
             _%domains11830%_)))
    (define gerbil-ascent/program/scheme-checked#relational-finite-source
      (lambda (_%name11823%_ _%arity11824%_ _%rows11825%_ _%domains11826%_)
        (let ((_%copied11828%_
               (gerbil-ascent/program/scheme-checked#relational-domain-copy
                _%arity11824%_
                _%domains11826%_)))
          (let ((__tmp36330
                 (gerbil-ascent/program/scheme-checked#relational-copy-rows
                  _%rows11825%_
                  _%arity11824%_))
                (__tmp36329
                 (gerbil-ascent/program/scheme-checked#relational-domain-predicates
                  _%copied11828%_))
                (__tmp36328 (vector 'finite-domain _%copied11828%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-relation__%
             _%name11823%_
             _%arity11824%_
             __tmp36330
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             gerbil-ascent/table/storage#gerbil-ascent-set-storage-provider
             __tmp36329
             __tmp36328)))))
    (define gerbil-ascent/program/scheme-checked#relational-finite-lattice
      (lambda (_%name11815%_
               _%arity11816%_
               _%rows11817%_
               _%mode11818%_
               _%domains11819%_)
        (if (> _%arity11816%_ '0)
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite lattice needs a value column")))
        (let ((_%copied11821%_
               (gerbil-ascent/program/scheme-checked#relational-domain-copy
                _%arity11816%_
                _%domains11819%_)))
          (if (let ((__tmp36331 (last _%copied11821%_)))
                (declare (not safe))
                (andmap__0 exact-integer? __tmp36331))
              '#!void
              (let ()
                (declare (not safe))
                (error '"finite lattice value domain must contain exact integers")))
          (let ((__tmp36336
                 (gerbil-ascent/program/scheme-checked#relational-copy-rows
                  _%rows11817%_
                  _%arity11816%_))
                (__tmp36335
                 (gerbil-ascent/program/scheme-checked#relational-lattice-join
                  _%mode11818%_))
                (__tmp36334
                 (gerbil-ascent/program/scheme-checked#relational-domain-predicates
                  _%copied11821%_))
                (__tmp36333 (vector 'lattice _%mode11818%_))
                (__tmp36332 (vector 'finite-domain _%copied11821%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-lattice__%
             _%name11815%_
             _%arity11816%_
             __tmp36336
             __tmp36335
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             __tmp36334
             __tmp36333
             __tmp36332)))))
    (define gerbil-ascent/program/scheme-checked#relational-lattice-join
      (lambda (_%mode11804%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let ((_%$e11806%_ _%mode11804%_))
           (if (eq? 'max _%$e11806%_)
               (lambda (_%left11809%_ _%right11810%_)
                 (if (and (exact-integer? _%left11809%_)
                          (exact-integer? _%right11810%_))
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"max lattice needs exact integer values")))
                 (max _%left11809%_ _%right11810%_))
               (if (eq? 'min _%$e11806%_)
                   (lambda (_%left11812%_ _%right11813%_)
                     (if (and (exact-integer? _%left11812%_)
                              (exact-integer? _%right11813%_))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"min lattice needs exact integer values")))
                     (min _%left11812%_ _%right11813%_))
                   (let ()
                     (declare (not safe))
                     (error '"unknown checked lattice join"
                            _%mode11804%_))))))))
    (define gerbil-ascent/program/scheme-checked#relational-checked-lattice
      (lambda (_%name11795%_ _%arity11796%_ _%rows11797%_ _%mode11798%_)
        (if (and (exact-integer? _%arity11796%_)
                 (> _%arity11796%_ '0)
                 (list? _%rows11797%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid checked lattice signature"
                     _%name11795%_
                     _%arity11796%_)))
        (let ((_%copied11800%_
               (gerbil-ascent/program/scheme-checked#relational-copy-rows
                _%rows11797%_
                _%arity11796%_)))
          (let ((__tmp36337
                 (lambda (_%row11802%_)
                   (if (exact-integer? (last _%row11802%_))
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"checked lattice needs exact integer value"
                                _%row11802%_))))))
            (declare (not safe))
            (##for-each __tmp36337 _%copied11800%_))
          (let ((__tmp36342
                 (gerbil-ascent/program/scheme-checked#relational-lattice-join
                  _%mode11798%_))
                (__tmp36339
                 (let ((__tmp36341
                        (make-list
                         (- _%arity11796%_ '1)
                         gerbil-ascent/program/scheme-checked#relational-scalar?))
                       (__tmp36340 (list exact-integer?)))
                   (declare (not safe))
                   (##append __tmp36341 __tmp36340)))
                (__tmp36338 (vector 'lattice _%mode11798%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-lattice__3
             _%name11795%_
             _%arity11796%_
             _%copied11800%_
             __tmp36342
             gerbil-ascent/table/provider#gerbil-ascent-hash-index-provider
             __tmp36339
             __tmp36338)))))
    (define gerbil-ascent/program/scheme-checked#relational-lattice-fragment
      (lambda (_%label11788%_ _%arity11789%_ _%rows11790%_ _%mode11791%_)
        (if (symbol? _%label11788%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"lattice fragment label must be a symbol"
                     _%label11788%_)))
        (let ((_%handle11793%_
               (let () (declare (not safe)) (##gensym 'lattice))))
          (let ((__tmp36345
                 (list (gerbil-ascent/program/scheme-checked#relational-checked-lattice
                        _%handle11793%_
                        _%arity11789%_
                        _%rows11790%_
                        _%mode11791%_)))
                (__tmp36344 (list (cons _%label11788%_ _%handle11793%_)))
                (__tmp36343 (list _%handle11793%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
             __tmp36345
             '()
             __tmp36344
             __tmp36343)))))
    (define gerbil-ascent/program/scheme-checked#relational-finite-view
      (lambda (_%label11781%_
               _%input-arity11782%_
               _%output-arity11783%_
               _%entries11784%_)
        (if (symbol? _%label11781%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"finite view label must be a symbol" _%label11781%_)))
        (let ((_%handle11786%_ (let () (declare (not safe)) (##gensym 'view))))
          (let ((__tmp36348
                 (list (gerbil-ascent/program/scheme-checked#relational-owned-source
                        _%handle11786%_
                        (+ _%input-arity11782%_ _%output-arity11783%_)
                        (gerbil-ascent/program/scheme-checked#relational-finite-rows
                         _%input-arity11782%_
                         _%output-arity11783%_
                         _%entries11784%_))))
                (__tmp36347 (list (cons _%label11781%_ _%handle11786%_)))
                (__tmp36346 (list _%handle11786%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-fragment__%
             __tmp36348
             '()
             __tmp36347
             __tmp36346)))))
    (define gerbil-ascent/program/scheme-checked#relational-captured-value
      (lambda (_%value11779%_)
        (if (gerbil-ascent/program/scheme-checked#relational-scalar?
             _%value11779%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational value capture requires an immutable scalar"
                     _%value11779%_)))
        (let ()
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-literal
           _%value11779%_))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-literal
      (lambda (_%value11777%_)
        (if (gerbil-ascent/program/scheme-checked#relational-scalar?
             _%value11777%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational operator literal requires a scalar"
                     _%value11777%_)))
        (vector 'literal _%value11777%_)))
    (define gerbil-ascent/program/scheme-checked#relational-copy-operand
      (lambda (_%operand11769%_)
        (if (symbol? _%operand11769%_)
            (vector 'variable _%operand11769%_)
            (if (and (vector? _%operand11769%_)
                     (= (let ()
                          (declare (not safe))
                          (##vector-length _%operand11769%_))
                        '2))
                (let ((_%$e11773%_ (vector-ref _%operand11769%_ '0)))
                  (if (eq? 'variable _%$e11773%_)
                      (begin
                        (if (symbol? (vector-ref _%operand11769%_ '1))
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"invalid relational operator variable"
                                     _%operand11769%_)))
                        (vector 'variable (vector-ref _%operand11769%_ '1)))
                      (if (eq? 'literal _%$e11773%_)
                          (gerbil-ascent/program/scheme-checked#relational-operator-literal
                           (vector-ref _%operand11769%_ '1))
                          (let ()
                            (declare (not safe))
                            (error '"invalid relational operator operand"
                                   _%operand11769%_)))))
                (let ()
                  (declare (not safe))
                  (error '"invalid relational operator operand"
                         _%operand11769%_))))))
    (define gerbil-ascent/program/scheme-checked#relational-operand-variables
      (lambda (_%operands11765%_)
        (if (list? _%operands11765%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational operator operands must be a list"
                     _%operands11765%_)))
        (let ((__tmp36349
               (lambda (_%operand11767%_)
                 (if (vector? _%operand11767%_)
                     (if (= (let ()
                              (declare (not safe))
                              (##vector-length _%operand11767%_))
                            '2)
                         (if (eq? (vector-ref _%operand11767%_ '0) 'variable)
                             (vector-ref _%operand11767%_ '1)
                             '#f)
                         '#f)
                     '#f))))
          (declare (not safe))
          (filter-map__0 __tmp36349 _%operands11765%_))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-call
      (lambda (_%operation-procedure11471%_ _%operands11472%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let* ((_%$%operands1147311488%_ _%operands11472%_)
                (_%$%E1147711492%_
                 (lambda ()
                   (let ()
                     (declare (not safe))
                     (error '"No clause matching"
                            _%$%operands1147311488%_
                            '([operand])
                            '([left right])
                            '(_)))
                   '#!void)))
           (let ((_%$%K1148411755%_
                  (lambda (_%operand11685%_)
                    (if (eq? (vector-ref _%operand11685%_ '0) 'variable)
                        (lambda _%values11687%_
                          (let* ((_%$%values1168911698%_ _%values11687%_)
                                 (_%$%E1169211702%_
                                  (lambda ()
                                    (let ()
                                      (declare (not safe))
                                      (error '"No clause matching"
                                             _%$%values1168911698%_
                                             '([value])
                                             '(_)))
                                    '#!void)))
                            (let ((_%$%K1169411715%_
                                   (lambda (_%value11713%_)
                                     (_%operation-procedure11471%_
                                      _%value11713%_)))
                                  (_%$%K1169311707%_
                                   (lambda ()
                                     (let ()
                                       (declare (not safe))
                                       (error '"relational operator argument mismatch")))))
                              (if (pair? _%$%values1168911698%_)
                                  (let ((_%$%tl1169611720%_
                                         (let ()
                                           (declare (not safe))
                                           (##cdr _%$%values1168911698%_)))
                                        (_%$%hd1169511718%_
                                         (let ()
                                           (declare (not safe))
                                           (##car _%$%values1168911698%_))))
                                    (if (null? _%$%tl1169611720%_)
                                        (let ((_%value11723%_
                                               _%$%hd1169511718%_))
                                          (declare (not safe))
                                          (_%operation-procedure11471%_
                                           _%value11723%_))
                                        (_%$%K1169311707%_)))
                                  (_%$%K1169311707%_)))))
                        (let ((_%value11725%_
                               (vector-ref _%operand11685%_ '1)))
                          (lambda _%values11727%_
                            (let* ((_%$%values1172911736%_ _%values11727%_)
                                   (_%$%E1173211740%_
                                    (lambda ()
                                      (let ()
                                        (declare (not safe))
                                        (error '"No clause matching"
                                               _%$%values1172911736%_
                                               '([])
                                               '(_)))
                                      '#!void)))
                              (let ((_%$%K1173411752%_
                                     (lambda ()
                                       (_%operation-procedure11471%_
                                        _%value11725%_)))
                                    (_%$%K1173311745%_
                                     (lambda ()
                                       (let ()
                                         (declare (not safe))
                                         (error '"relational operator argument mismatch")))))
                                (if (null? _%$%values1172911736%_)
                                    (_%$%K1173411752%_)
                                    (_%$%K1173311745%_)))))))))
                 (_%$%K1147911665%_
                  (lambda (_%right11504%_ _%left11505%_)
                    (if (eq? (vector-ref _%left11505%_ '0) 'variable)
                        (if (eq? (vector-ref _%right11504%_ '0) 'variable)
                            (lambda _%values11507%_
                              (let* ((_%$%values1150911520%_ _%values11507%_)
                                     (_%$%E1151211524%_
                                      (lambda ()
                                        (let ()
                                          (declare (not safe))
                                          (error '"No clause matching"
                                                 _%$%values1150911520%_
                                                 '([a b])
                                                 '(_)))
                                        '#!void)))
                                (let ((_%$%K1151411538%_
                                       (lambda (_%b11535%_ _%a11536%_)
                                         (_%operation-procedure11471%_
                                          _%a11536%_
                                          _%b11535%_)))
                                      (_%$%K1151311529%_
                                       (lambda ()
                                         (let ()
                                           (declare (not safe))
                                           (error '"relational operator argument mismatch")))))
                                  (if (pair? _%$%values1150911520%_)
                                      (let ((_%$%tl1151611543%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%values1150911520%_)))
                                            (_%$%hd1151511541%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%values1150911520%_))))
                                        (if (pair? _%$%tl1151611543%_)
                                            (let ((_%$%tl1151811550%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##cdr _%$%tl1151611543%_)))
                                                  (_%$%hd1151711548%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##car _%$%tl1151611543%_))))
                                              (if (null? _%$%tl1151811550%_)
                                                  (let ((_%a11546%_
                                                         _%$%hd1151511541%_)
                                                        (_%b11553%_
                                                         _%$%hd1151711548%_))
                                                    (_%$%K1151411538%_
                                                     _%b11553%_
                                                     _%a11546%_))
                                                  (_%$%K1151311529%_)))
                                            (_%$%K1151311529%_)))
                                      (_%$%K1151311529%_)))))
                            (let ((_%b11555%_ (vector-ref _%right11504%_ '1)))
                              (lambda _%values11557%_
                                (let* ((_%$%values1155911568%_ _%values11557%_)
                                       (_%$%E1156211572%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%values1155911568%_
                                                   '([a])
                                                   '(_)))
                                          '#!void)))
                                  (let ((_%$%K1156411585%_
                                         (lambda (_%a11583%_)
                                           (_%operation-procedure11471%_
                                            _%a11583%_
                                            _%b11555%_)))
                                        (_%$%K1156311577%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"relational operator argument mismatch")))))
                                    (if (pair? _%$%values1155911568%_)
                                        (let ((_%$%tl1156611590%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%values1155911568%_)))
                                              (_%$%hd1156511588%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%values1155911568%_))))
                                          (if (null? _%$%tl1156611590%_)
                                              (let ((_%a11593%_
                                                     _%$%hd1156511588%_))
                                                (_%$%K1156411585%_ _%a11593%_))
                                              (_%$%K1156311577%_)))
                                        (_%$%K1156311577%_)))))))
                        (let ((_%a11595%_ (vector-ref _%left11505%_ '1)))
                          (if (eq? (vector-ref _%right11504%_ '0) 'variable)
                              (lambda _%values11597%_
                                (let* ((_%$%values1159911608%_ _%values11597%_)
                                       (_%$%E1160211612%_
                                        (lambda ()
                                          (let ()
                                            (declare (not safe))
                                            (error '"No clause matching"
                                                   _%$%values1159911608%_
                                                   '([b])
                                                   '(_)))
                                          '#!void)))
                                  (let ((_%$%K1160411625%_
                                         (lambda (_%b11623%_)
                                           (_%operation-procedure11471%_
                                            _%a11595%_
                                            _%b11623%_)))
                                        (_%$%K1160311617%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"relational operator argument mismatch")))))
                                    (if (pair? _%$%values1159911608%_)
                                        (let ((_%$%tl1160611630%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%values1159911608%_)))
                                              (_%$%hd1160511628%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%values1159911608%_))))
                                          (if (null? _%$%tl1160611630%_)
                                              (let ((_%b11633%_
                                                     _%$%hd1160511628%_))
                                                (_%$%K1160411625%_ _%b11633%_))
                                              (_%$%K1160311617%_)))
                                        (_%$%K1160311617%_)))))
                              (let ((_%b11635%_
                                     (vector-ref _%right11504%_ '1)))
                                (lambda _%values11637%_
                                  (let* ((_%$%values1163911646%_
                                          _%values11637%_)
                                         (_%$%E1164211650%_
                                          (lambda ()
                                            (let ()
                                              (declare (not safe))
                                              (error '"No clause matching"
                                                     _%$%values1163911646%_
                                                     '([])
                                                     '(_)))
                                            '#!void)))
                                    (let ((_%$%K1164411662%_
                                           (lambda ()
                                             (_%operation-procedure11471%_
                                              _%a11595%_
                                              _%b11635%_)))
                                          (_%$%K1164311655%_
                                           (lambda ()
                                             (let ()
                                               (declare (not safe))
                                               (error '"relational operator argument mismatch")))))
                                      (if (null? _%$%values1163911646%_)
                                          (_%$%K1164411662%_)
                                          (_%$%K1164311655%_)))))))))))
                 (_%$%K1147811497%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"unsupported relational operator arity")))))
             (if (pair? _%$%operands1147311488%_)
                 (let ((_%$%tl1148611760%_
                        (let ()
                          (declare (not safe))
                          (##cdr _%$%operands1147311488%_)))
                       (_%$%hd1148511758%_
                        (let ()
                          (declare (not safe))
                          (##car _%$%operands1147311488%_))))
                   (if (null? _%$%tl1148611760%_)
                       (let ((_%operand11763%_ _%$%hd1148511758%_))
                         (_%$%K1148411755%_ _%operand11763%_))
                       (if (pair? _%$%tl1148611760%_)
                           (let ((_%$%tl1148311677%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%tl1148611760%_)))
                                 (_%$%hd1148211675%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%tl1148611760%_))))
                             (if (null? _%$%tl1148311677%_)
                                 (let ((_%left11673%_ _%$%hd1148511758%_)
                                       (_%right11680%_ _%$%hd1148211675%_))
                                   (_%$%K1147911665%_
                                    _%right11680%_
                                    _%left11673%_))
                                 (_%$%K1147811497%_)))
                           (_%$%K1147811497%_))))
                 (_%$%K1147811497%_)))))))
    (define gerbil-ascent/program/scheme-checked#relational-term-fingerprint
      (lambda (_%terms11467%_)
        (map (lambda (_%term11469%_)
               (cons (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term11469%_ 'kind))
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%term11469%_ 'value))))
             _%terms11467%_)))
    (define gerbil-ascent/program/scheme-checked#relational-reducer-procedure
      (lambda (_%mode11446%_ _%inputs11447%_)
        (gerbil-ascent/program/scheme-checked#relational-stable
         (let ((_%$e11449%_ _%mode11446%_))
           (if (eq? 'count _%$e11449%_)
               (begin
                 (if (null? _%inputs11447%_)
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"checked count takes no value variable")))
                 gerbil-ascent/program/aggregators#gerbil-ascent-count)
               (if (or (eq? 'sum _%$e11449%_)
                       (eq? 'min _%$e11449%_)
                       (eq? 'max _%$e11449%_))
                   (begin
                     (if (= (length _%inputs11447%_) '1)
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"checked numeric reduction needs one value variable")))
                     (let ((_%reducer11461%_
                            (let ((_%$e11458%_ _%mode11446%_))
                              (if (eq? 'sum _%$e11458%_)
                                  gerbil-ascent/program/aggregators#gerbil-ascent-sum
                                  (if (eq? 'min _%$e11458%_)
                                      gerbil-ascent/program/aggregators#gerbil-ascent-min
                                      (if (eq? 'max _%$e11458%_)
                                          gerbil-ascent/program/aggregators#gerbil-ascent-max
                                          '#!void))))))
                       (lambda (_%tuples11463%_)
                         (for-each
                          (lambda (_%tuple11465%_)
                            (if (and (list? _%tuple11465%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##length _%tuple11465%_))
                                        '1)
                                     (exact-integer? (car _%tuple11465%_)))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"numeric reduction needs exact integer rows"))))
                          _%tuples11463%_)
                         (_%reducer11461%_ _%tuples11463%_))))
                   (let ()
                     (declare (not safe))
                     (error '"unknown checked reducer" _%mode11446%_))))))))
    (define gerbil-ascent/program/scheme-checked#relational-reducer
      (lambda (_%output11440%_
               _%mode11441%_
               _%inputs11442%_
               _%relation11443%_
               _%terms11444%_)
        (let ((__tmp36351
               (gerbil-ascent/program/scheme-checked#relational-reducer-procedure
                _%mode11441%_
                _%inputs11442%_))
              (__tmp36350
               (vector 'reduce
                       _%mode11441%_
                       _%output11440%_
                       _%relation11443%_
                       (map identity _%inputs11442%_)
                       (gerbil-ascent/program/scheme-checked#relational-term-fingerprint
                        _%terms11444%_))))
          (declare (not safe))
          (gerbil-ascent/program/objects#gerbil-ascent-aggregate__%
           _%output11440%_
           _%relation11443%_
           _%terms11444%_
           _%inputs11442%_
           __tmp36351
           '#f
           __tmp36350))))
    (define gerbil-ascent/program/scheme-checked#relational-operator-procedure
      (lambda (_%mode11417%_ _%operation11418%_ _%arity11419%_)
        (let ((_%$e11421%_ _%mode11417%_))
          (if (eq? 'where _%$e11421%_)
              (let ((_%$e11424%_ _%operation11418%_))
                (if (eq? 'even? _%$e11424%_)
                    (begin
                      (if (= _%arity11419%_ '1)
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"even? expects one relational input")))
                      (lambda (_%value11427%_)
                        (if (exact-integer? _%value11427%_)
                            '#!void
                            (let ()
                              (declare (not safe))
                              (error '"even? expects an exact integer"
                                     _%value11427%_)))
                        (even? _%value11427%_)))
                    (if (eq? '< _%$e11424%_)
                        (begin
                          (if (= _%arity11419%_ '2)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"< expects two relational inputs")))
                          (lambda (_%left11429%_ _%right11430%_)
                            (if (and (exact-integer? _%left11429%_)
                                     (exact-integer? _%right11430%_))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"< expects exact integers"
                                         _%left11429%_
                                         _%right11430%_)))
                            (< _%left11429%_ _%right11430%_)))
                        (let ()
                          (declare (not safe))
                          (error '"unknown relational filter operator"
                                 _%operation11418%_)))))
              (if (eq? 'compute _%$e11421%_)
                  (let ((_%$e11432%_ _%operation11418%_))
                    (if (eq? '+ _%$e11432%_)
                        (begin
                          (if (= _%arity11419%_ '2)
                              '#!void
                              (let ()
                                (declare (not safe))
                                (error '"+ expects two relational inputs")))
                          (lambda (_%left11435%_ _%right11436%_)
                            (if (and (exact-integer? _%left11435%_)
                                     (exact-integer? _%right11436%_))
                                '#!void
                                (let ()
                                  (declare (not safe))
                                  (error '"+ expects exact integers"
                                         _%left11435%_
                                         _%right11436%_)))
                            (+ _%left11435%_ _%right11436%_)))
                        (if (eq? 'identity _%$e11432%_)
                            (begin
                              (if (= _%arity11419%_ '1)
                                  '#!void
                                  (let ()
                                    (declare (not safe))
                                    (error '"identity expects one relational input")))
                              (lambda (_%value11438%_) _%value11438%_))
                            (let ()
                              (declare (not safe))
                              (error '"unknown relational projection operator"
                                     _%operation11418%_)))))
                  (let ()
                    (declare (not safe))
                    (error '"unknown relational operator mode"
                           _%mode11417%_)))))))
    (define gerbil-ascent/program/scheme-checked#relational-where
      (lambda (_%operation11409%_ _%variables11410%_)
        (let* ((_%operands11412%_
                (map gerbil-ascent/program/scheme-checked#relational-copy-operand
                     _%variables11410%_))
               (_%inputs11414%_
                (gerbil-ascent/program/scheme-checked#relational-operand-variables
                 _%operands11412%_)))
          (let ((__tmp36353
                 (gerbil-ascent/program/scheme-checked#relational-operator-call
                  (gerbil-ascent/program/scheme-checked#relational-operator-procedure
                   'where
                   _%operation11409%_
                   (let () (declare (not safe)) (##length _%operands11412%_)))
                  _%operands11412%_))
                (__tmp36352
                 (vector 'where _%operation11409%_ _%operands11412%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-guard__%
             _%inputs11414%_
             __tmp36353
             __tmp36352)))))
    (define gerbil-ascent/program/scheme-checked#relational-compute
      (lambda (_%output11400%_ _%operation11401%_ _%variables11402%_)
        (let* ((_%operands11404%_
                (map gerbil-ascent/program/scheme-checked#relational-copy-operand
                     _%variables11402%_))
               (_%inputs11406%_
                (gerbil-ascent/program/scheme-checked#relational-operand-variables
                 _%operands11404%_)))
          (let ((__tmp36355
                 (gerbil-ascent/program/scheme-checked#relational-operator-call
                  (gerbil-ascent/program/scheme-checked#relational-operator-procedure
                   'compute
                   _%operation11401%_
                   (let () (declare (not safe)) (##length _%operands11404%_)))
                  _%operands11404%_))
                (__tmp36354
                 (vector 'compute
                         _%operation11401%_
                         _%operands11404%_
                         _%output11400%_)))
            (declare (not safe))
            (gerbil-ascent/program/objects#gerbil-ascent-binding__%
             _%output11400%_
             _%inputs11406%_
             __tmp36355
             __tmp36354)))))))
