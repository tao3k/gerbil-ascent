(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/provenance[1]#_g33961_|
    (##structure
     gx#syntax-quote::t
     'positive-proof::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33963_|
    (##structure
     gx#syntax-quote::t
     'make-positive-proof
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33965_|
    (##structure
     gx#syntax-quote::t
     'positive-proof?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33967_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33968_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33969_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33970_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33971_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33972_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33973_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33974_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33975_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33977_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33978_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33979_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33980_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33981_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33982_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33983_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33984_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33985_|
    (##structure
     gx#syntax-quote::t
     'positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33987_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33988_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33989_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33990_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33991_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33992_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33993_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33994_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33995_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33997_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33998_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g33999_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34000_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34001_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34002_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34003_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34004_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34005_|
    (##structure
     gx#syntax-quote::t
     '&positive-proof-roots-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34007_|
    (##structure
     gx#syntax-quote::t
     'proof-node::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34009_|
    (##structure
     gx#syntax-quote::t
     'make-proof-node
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34011_|
    (##structure
     gx#syntax-quote::t
     'proof-node?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34013_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34014_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34015_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34016_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34017_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34018_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34020_|
    (##structure
     gx#syntax-quote::t
     'proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34021_|
    (##structure
     gx#syntax-quote::t
     'proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34022_|
    (##structure
     gx#syntax-quote::t
     'proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34023_|
    (##structure
     gx#syntax-quote::t
     'proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34024_|
    (##structure
     gx#syntax-quote::t
     'proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34025_|
    (##structure
     gx#syntax-quote::t
     'proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34027_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34028_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34029_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34030_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34031_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34032_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34034_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34035_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34036_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34037_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-row-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34038_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-label-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34039_|
    (##structure
     gx#syntax-quote::t
     '&proof-node-inputs-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34041_|
    (##structure
     gx#syntax-quote::t
     'proof-relation::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34043_|
    (##structure
     gx#syntax-quote::t
     'make-proof-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34045_|
    (##structure
     gx#syntax-quote::t
     'proof-relation?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34047_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34048_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34049_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34051_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34052_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34053_|
    (##structure
     gx#syntax-quote::t
     'proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34055_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34056_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34057_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34059_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-nodes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34060_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-tail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34061_|
    (##structure
     gx#syntax-quote::t
     '&proof-relation-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34063_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34065_|
    (##structure
     gx#syntax-quote::t
     'make-positive-rule-replay
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34067_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34069_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34070_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-input-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34071_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-execute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34073_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34074_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-input-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34075_|
    (##structure
     gx#syntax-quote::t
     'positive-rule-replay-execute-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34077_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-relation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34078_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-input-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34079_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-execute
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34081_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-relation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34082_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-input-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/provenance[1]#_g34083_|
    (##structure
     gx#syntax-quote::t
     '&positive-rule-replay-execute-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-proof|
      (let ((__obj33896
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33896
           'gerbil-ascent/candidate/provenance#positive-proof::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 'positive-proof '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33896
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33896
           '(status snapshot-identity
                    snapshot-generation
                    snapshot-digest
                    candidate-digest
                    query
                    work-budget
                    nodes
                    roots)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '#f '13 '#f '#f))
        (let ((__tmp33960 |gerbil-ascent/candidate/provenance[1]#_g33961_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33960 '4 '#f '#f))
        (let ((__tmp33962 |gerbil-ascent/candidate/provenance[1]#_g33963_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33962 '14 '#f '#f))
        (let ((__tmp33964 |gerbil-ascent/candidate/provenance[1]#_g33965_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33964 '15 '#f '#f))
        (let ((__tmp33966
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g33967_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g33968_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g33969_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g33970_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g33971_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g33972_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g33973_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g33974_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g33975_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33966 '16 '#f '#f))
        (let ((__tmp33976
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g33977_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g33978_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g33979_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g33980_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g33981_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g33982_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g33983_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g33984_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g33985_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33976 '17 '#f '#f))
        (let ((__tmp33986
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g33987_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g33988_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g33989_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g33990_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g33991_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g33992_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g33993_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g33994_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g33995_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33986 '18 '#f '#f))
        (let ((__tmp33996
               (cons (cons 'status
                           |gerbil-ascent/candidate/provenance[1]#_g33997_|)
                     (cons (cons 'snapshot-identity
                                 |gerbil-ascent/candidate/provenance[1]#_g33998_|)
                           (cons (cons 'snapshot-generation
                                       |gerbil-ascent/candidate/provenance[1]#_g33999_|)
                                 (cons (cons 'snapshot-digest
                                             |gerbil-ascent/candidate/provenance[1]#_g34000_|)
                                       (cons (cons 'candidate-digest
                                                   |gerbil-ascent/candidate/provenance[1]#_g34001_|)
                                             (cons (cons 'query
                                                         |gerbil-ascent/candidate/provenance[1]#_g34002_|)
                                                   (cons (cons 'work-budget
                                                               |gerbil-ascent/candidate/provenance[1]#_g34003_|)
                                                         (cons (cons 'nodes
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/candidate/provenance[1]#_g34004_|)
                       (cons (cons 'roots
                                   |gerbil-ascent/candidate/provenance[1]#_g34005_|)
                             '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 __tmp33996 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33896 '() '21 '#f '#f))
        __obj33896))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-node|
      (let ((__obj33897
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33897
           'gerbil-ascent/candidate/provenance#proof-node::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 'proof-node '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33897
           '(id kind relation row label inputs)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33897
           '(id kind relation row label inputs)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '#f '13 '#f '#f))
        (let ((__tmp34006 |gerbil-ascent/candidate/provenance[1]#_g34007_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34006 '4 '#f '#f))
        (let ((__tmp34008 |gerbil-ascent/candidate/provenance[1]#_g34009_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34008 '14 '#f '#f))
        (let ((__tmp34010 |gerbil-ascent/candidate/provenance[1]#_g34011_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34010 '15 '#f '#f))
        (let ((__tmp34012
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34013_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34014_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34015_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34016_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34017_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34018_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34012 '16 '#f '#f))
        (let ((__tmp34019
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34020_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34021_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34022_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34023_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34024_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34025_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34019 '17 '#f '#f))
        (let ((__tmp34026
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34027_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34028_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34029_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34030_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34031_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34032_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34026 '18 '#f '#f))
        (let ((__tmp34033
               (cons (cons 'id
                           |gerbil-ascent/candidate/provenance[1]#_g34034_|)
                     (cons (cons 'kind
                                 |gerbil-ascent/candidate/provenance[1]#_g34035_|)
                           (cons (cons 'relation
                                       |gerbil-ascent/candidate/provenance[1]#_g34036_|)
                                 (cons (cons 'row
                                             |gerbil-ascent/candidate/provenance[1]#_g34037_|)
                                       (cons (cons 'label
                                                   |gerbil-ascent/candidate/provenance[1]#_g34038_|)
                                             (cons (cons 'inputs
                                                         |gerbil-ascent/candidate/provenance[1]#_g34039_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 __tmp34033 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33897 '() '21 '#f '#f))
        __obj33897))
    (define |gerbil-ascent/candidate/provenance[:0:]#proof-relation|
      (let ((__obj33898
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33898
           'gerbil-ascent/candidate/provenance#proof-relation::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 'proof-relation '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33898
           '(nodes tail members)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33898
           '(nodes tail members)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '#f '13 '#f '#f))
        (let ((__tmp34040 |gerbil-ascent/candidate/provenance[1]#_g34041_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34040 '4 '#f '#f))
        (let ((__tmp34042 |gerbil-ascent/candidate/provenance[1]#_g34043_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34042 '14 '#f '#f))
        (let ((__tmp34044 |gerbil-ascent/candidate/provenance[1]#_g34045_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34044 '15 '#f '#f))
        (let ((__tmp34046
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34047_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34048_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34049_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34046 '16 '#f '#f))
        (let ((__tmp34050
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34051_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34052_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34053_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34050 '17 '#f '#f))
        (let ((__tmp34054
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34055_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34056_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34057_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34054 '18 '#f '#f))
        (let ((__tmp34058
               (cons (cons 'nodes
                           |gerbil-ascent/candidate/provenance[1]#_g34059_|)
                     (cons (cons 'tail
                                 |gerbil-ascent/candidate/provenance[1]#_g34060_|)
                           (cons (cons 'members
                                       |gerbil-ascent/candidate/provenance[1]#_g34061_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 __tmp34058 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33898 '() '21 '#f '#f))
        __obj33898))
    (define |gerbil-ascent/candidate/provenance[:0:]#positive-rule-replay|
      (let ((__obj33899
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33899
           'gerbil-ascent/candidate/provenance#positive-rule-replay::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33899
           'positive-rule-replay
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33899
           '(relation input-count execute)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33899
           '(relation input-count execute)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '#f '13 '#f '#f))
        (let ((__tmp34062 |gerbil-ascent/candidate/provenance[1]#_g34063_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34062 '4 '#f '#f))
        (let ((__tmp34064 |gerbil-ascent/candidate/provenance[1]#_g34065_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34064 '14 '#f '#f))
        (let ((__tmp34066 |gerbil-ascent/candidate/provenance[1]#_g34067_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34066 '15 '#f '#f))
        (let ((__tmp34068
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34069_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34070_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34071_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34068 '16 '#f '#f))
        (let ((__tmp34072
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34073_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34074_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34075_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34072 '17 '#f '#f))
        (let ((__tmp34076
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34077_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34078_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34079_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34076 '18 '#f '#f))
        (let ((__tmp34080
               (cons (cons 'relation
                           |gerbil-ascent/candidate/provenance[1]#_g34081_|)
                     (cons (cons 'input-count
                                 |gerbil-ascent/candidate/provenance[1]#_g34082_|)
                           (cons (cons 'execute
                                       |gerbil-ascent/candidate/provenance[1]#_g34083_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 __tmp34080 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33899 '() '21 '#f '#f))
        __obj33899))))
