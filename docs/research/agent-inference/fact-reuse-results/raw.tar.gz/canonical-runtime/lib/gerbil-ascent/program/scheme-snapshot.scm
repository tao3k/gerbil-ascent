(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/program/objects")
    (load-module "gerbil-ascent/program/scheme-checked")
    (load-module "gerbil-ascent/program/types")
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop"))
  (load-module "gerbil-ascent/program/scheme-snapshot~0"))
