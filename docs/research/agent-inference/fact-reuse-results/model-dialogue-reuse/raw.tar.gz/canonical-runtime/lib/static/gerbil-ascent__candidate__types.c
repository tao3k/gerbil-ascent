#ifdef ___LINKER_INFO
; File: "gerbil-ascent__candidate__types.c", produced by Gambit v4.9.8
(
409008
(C)
"gerbil-ascent__candidate__types"
("gerbil-ascent__candidate__types")
()
(("gerbil-ascent__candidate__types"))
( #|*/"*/"symbols|#
"bytes"
"candidate-rejection"
"code"
"detail"
"diagnostic"
"digest"
"facts"
"fxmax"
"generation"
"gerbil-ascent/candidate/types"
"gerbil-ascent/candidate/types#candidate-rejection::t"
"gerbil-ascent/candidate/types#make-candidate-rejection"
"gerbil-ascent/candidate/types#make-reasoning-candidate"
"gerbil-ascent/candidate/types#make-reasoning-diagnostic"
"gerbil-ascent/candidate/types#make-reasoning-snapshot"
"gerbil-ascent/candidate/types#reasoning-candidate::t"
"gerbil-ascent/candidate/types#reasoning-diagnostic::t"
"gerbil-ascent/candidate/types#reasoning-snapshot-content-digest"
"gerbil-ascent/candidate/types#reasoning-snapshot-valid?"
"gerbil-ascent/candidate/types#reasoning-snapshot::t"
"gerbil-ascent/candidate/types#snapshot-relation-valid?"
"gerbil-ascent/candidate/types#snapshot-row-valid?"
"gerbil-ascent/candidate/types#snapshot-scalar?"
"gerbil-ascent__candidate__types"
"gerbil-ascent__candidate__types#"
"identity"
"in-range-inclusive?"
"in-range?"
"limits"
"path"
"query"
"reasoning-candidate"
"reasoning-diagnostic"
"reasoning-snapshot"
"reasoning-snapshot-v1"
"relations"
"rules"
"start"
"u8vector-length"
) #|*/"*/"symbols|#
( #|*/"*/"keywords|#
"context"
"contract"
"struct"
"value"
) #|*/"*/"keywords|#
( #|*/"*/"globals-s-d|#
"gerbil-ascent/candidate/types#candidate-rejection::t"
"gerbil-ascent/candidate/types#reasoning-candidate::t"
"gerbil-ascent/candidate/types#reasoning-diagnostic::t"
"gerbil-ascent/candidate/types#reasoning-snapshot-content-digest"
"gerbil-ascent/candidate/types#reasoning-snapshot::t"
"gerbil-ascent/candidate/types#snapshot-relation-valid?"
"gerbil-ascent/candidate/types#snapshot-scalar?"
"gerbil-ascent__candidate__types#"
) #|*/"*/"globals-s-d|#
( #|*/"*/"globals-s-nd|#
"gerbil-ascent/candidate/types#&candidate-rejection-diagnostic"
"gerbil-ascent/candidate/types#&candidate-rejection-diagnostic-set!"
"gerbil-ascent/candidate/types#&reasoning-candidate-facts"
"gerbil-ascent/candidate/types#&reasoning-candidate-facts-set!"
"gerbil-ascent/candidate/types#&reasoning-candidate-limits"
"gerbil-ascent/candidate/types#&reasoning-candidate-limits-set!"
"gerbil-ascent/candidate/types#&reasoning-candidate-query"
"gerbil-ascent/candidate/types#&reasoning-candidate-query-set!"
"gerbil-ascent/candidate/types#&reasoning-candidate-relations"
"gerbil-ascent/candidate/types#&reasoning-candidate-relations-set!"
"gerbil-ascent/candidate/types#&reasoning-candidate-rules"
"gerbil-ascent/candidate/types#&reasoning-candidate-rules-set!"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-code"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-code-set!"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-detail"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-detail-set!"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-path"
"gerbil-ascent/candidate/types#&reasoning-diagnostic-path-set!"
"gerbil-ascent/candidate/types#&reasoning-snapshot-digest"
"gerbil-ascent/candidate/types#&reasoning-snapshot-digest-set!"
"gerbil-ascent/candidate/types#&reasoning-snapshot-generation"
"gerbil-ascent/candidate/types#&reasoning-snapshot-generation-set!"
"gerbil-ascent/candidate/types#&reasoning-snapshot-identity"
"gerbil-ascent/candidate/types#&reasoning-snapshot-identity-set!"
"gerbil-ascent/candidate/types#&reasoning-snapshot-relations"
"gerbil-ascent/candidate/types#&reasoning-snapshot-relations-set!"
"gerbil-ascent/candidate/types#+max-derived-facts+"
"gerbil-ascent/candidate/types#+max-input-facts+"
"gerbil-ascent/candidate/types#+max-output-facts+"
"gerbil-ascent/candidate/types#+max-relations+"
"gerbil-ascent/candidate/types#+max-rules+"
"gerbil-ascent/candidate/types#candidate-rejection-diagnostic"
"gerbil-ascent/candidate/types#candidate-rejection-diagnostic-set!"
"gerbil-ascent/candidate/types#candidate-rejection?"
"gerbil-ascent/candidate/types#make-candidate-rejection"
"gerbil-ascent/candidate/types#make-reasoning-candidate"
"gerbil-ascent/candidate/types#make-reasoning-diagnostic"
"gerbil-ascent/candidate/types#make-reasoning-snapshot"
"gerbil-ascent/candidate/types#reasoning-candidate-facts"
"gerbil-ascent/candidate/types#reasoning-candidate-facts-set!"
"gerbil-ascent/candidate/types#reasoning-candidate-limits"
"gerbil-ascent/candidate/types#reasoning-candidate-limits-set!"
"gerbil-ascent/candidate/types#reasoning-candidate-query"
"gerbil-ascent/candidate/types#reasoning-candidate-query-set!"
"gerbil-ascent/candidate/types#reasoning-candidate-relations"
"gerbil-ascent/candidate/types#reasoning-candidate-relations-set!"
"gerbil-ascent/candidate/types#reasoning-candidate-rules"
"gerbil-ascent/candidate/types#reasoning-candidate-rules-set!"
"gerbil-ascent/candidate/types#reasoning-candidate?"
"gerbil-ascent/candidate/types#reasoning-diagnostic-code"
"gerbil-ascent/candidate/types#reasoning-diagnostic-code-set!"
"gerbil-ascent/candidate/types#reasoning-diagnostic-detail"
"gerbil-ascent/candidate/types#reasoning-diagnostic-detail-set!"
"gerbil-ascent/candidate/types#reasoning-diagnostic-path"
"gerbil-ascent/candidate/types#reasoning-diagnostic-path-set!"
"gerbil-ascent/candidate/types#reasoning-diagnostic?"
"gerbil-ascent/candidate/types#reasoning-snapshot-digest"
"gerbil-ascent/candidate/types#reasoning-snapshot-digest-set!"
"gerbil-ascent/candidate/types#reasoning-snapshot-generation"
"gerbil-ascent/candidate/types#reasoning-snapshot-generation-set!"
"gerbil-ascent/candidate/types#reasoning-snapshot-identity"
"gerbil-ascent/candidate/types#reasoning-snapshot-identity-set!"
"gerbil-ascent/candidate/types#reasoning-snapshot-relations"
"gerbil-ascent/candidate/types#reasoning-snapshot-relations-set!"
"gerbil-ascent/candidate/types#reasoning-snapshot-valid?"
"gerbil-ascent/candidate/types#reasoning-snapshot?"
"gerbil-ascent/candidate/types#snapshot-row-valid?"
"gerbil-ascent/candidate/types::timestamp"
) #|*/"*/"globals-s-nd|#
( #|*/"*/"globals-ns|#
"##dead-end"
"##length"
"##list?"
"##string->utf8"
"##structure-instance-of?"
"+"
"-"
"<="
"="
"__make-class-predicate"
"__make-class-slot-accessor"
"__make-class-slot-mutator"
"__make-class-slot-unchecked-accessor"
"__make-class-slot-unchecked-mutator"
"absent-value"
"andmap__0"
"apply"
"caddr"
"cadr"
"call-with-output-string"
"car"
"equal?"
"gerbil-ascent/candidate/datum#reasoning-bounded-data?"
"hash-get"
"hash-put!"
"length"
"make-class-type"
"make-hash-table__%"
"make-instance"
"raise-contract-violation-error"
"std/crypto/digest#__sha256"
"std/encoding/hex#__hex-encode__%"
"write"
) #|*/"*/"globals-ns|#
( #|*/"*/"meta-info|#
) #|*/"*/"meta-info|#
)
#else
#define ___VERSION 409008
#define ___MODULE_NAME "gerbil-ascent__candidate__types"
#define ___LINKER_ID ___LNK_gerbil_2d_ascent____candidate____types
#define ___MH_PROC ___H_gerbil_2d_ascent____candidate____types
#define ___SCRIPT_LINE 0
#define ___SYMCOUNT 39
#define ___KEYCOUNT 4
#define ___GLOCOUNT 109
#define ___SUPCOUNT 76
#define ___CNSCOUNT 26
#define ___SUBCOUNT 7
#define ___LBLCOUNT 146
#define ___OFDCOUNT 1
#define ___MODDESCR ___REF_SUB(4)
#include "gambit.h"

___NEED_SYM(___S_bytes)
___NEED_SYM(___S_candidate_2d_rejection)
___NEED_SYM(___S_code)
___NEED_SYM(___S_detail)
___NEED_SYM(___S_diagnostic)
___NEED_SYM(___S_digest)
___NEED_SYM(___S_facts)
___NEED_SYM(___S_fxmax)
___NEED_SYM(___S_generation)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___NEED_SYM(___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
___NEED_SYM(___S_gerbil_2d_ascent____candidate____types)
___NEED_SYM(___S_gerbil_2d_ascent____candidate____types_23_)
___NEED_SYM(___S_identity)
___NEED_SYM(___S_in_2d_range_2d_inclusive_3f_)
___NEED_SYM(___S_in_2d_range_3f_)
___NEED_SYM(___S_limits)
___NEED_SYM(___S_path)
___NEED_SYM(___S_query)
___NEED_SYM(___S_reasoning_2d_candidate)
___NEED_SYM(___S_reasoning_2d_diagnostic)
___NEED_SYM(___S_reasoning_2d_snapshot)
___NEED_SYM(___S_reasoning_2d_snapshot_2d_v1)
___NEED_SYM(___S_relations)
___NEED_SYM(___S_rules)
___NEED_SYM(___S_start)
___NEED_SYM(___S_u8vector_2d_length)

___NEED_KEY(___K_context)
___NEED_KEY(___K_contract)
___NEED_KEY(___K_struct)
___NEED_KEY(___K_value)

___NEED_GLO(___G__23__23_dead_2d_end)
___NEED_GLO(___G__23__23_length)
___NEED_GLO(___G__23__23_list_3f_)
___NEED_GLO(___G__23__23_string_2d__3e_utf8)
___NEED_GLO(___G__23__23_structure_2d_instance_2d_of_3f_)
___NEED_GLO(___G__2b_)
___NEED_GLO(___G__2d_)
___NEED_GLO(___G__3c__3d_)
___NEED_GLO(___G__3d_)
___NEED_GLO(___G_____make_2d_class_2d_predicate)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_accessor)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_mutator)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___NEED_GLO(___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___NEED_GLO(___G_absent_2d_value)
___NEED_GLO(___G_andmap____0)
___NEED_GLO(___G_apply)
___NEED_GLO(___G_caddr)
___NEED_GLO(___G_cadr)
___NEED_GLO(___G_call_2d_with_2d_output_2d_string)
___NEED_GLO(___G_car)
___NEED_GLO(___G_equal_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
___NEED_GLO(___G_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp)
___NEED_GLO(___G_gerbil_2d_ascent____candidate____types_23_)
___NEED_GLO(___G_hash_2d_get)
___NEED_GLO(___G_hash_2d_put_21_)
___NEED_GLO(___G_length)
___NEED_GLO(___G_make_2d_class_2d_type)
___NEED_GLO(___G_make_2d_hash_2d_table_____25_)
___NEED_GLO(___G_make_2d_instance)
___NEED_GLO(___G_raise_2d_contract_2d_violation_2d_error)
___NEED_GLO(___G_std_2f_crypto_2f_digest_23_____sha256)
___NEED_GLO(___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
___NEED_GLO(___G_write)

___BEGIN_SYM
___DEF_SYM(0,___S_bytes,"bytes")
___DEF_SYM(1,___S_candidate_2d_rejection,"candidate-rejection")
___DEF_SYM(2,___S_code,"code")
___DEF_SYM(3,___S_detail,"detail")
___DEF_SYM(4,___S_diagnostic,"diagnostic")
___DEF_SYM(5,___S_digest,"digest")
___DEF_SYM(6,___S_facts,"facts")
___DEF_SYM(7,___S_fxmax,"fxmax")
___DEF_SYM(8,___S_generation,"generation")
___DEF_SYM(9,___S_gerbil_2d_ascent_2f_candidate_2f_types,"gerbil-ascent/candidate/types")

___DEF_SYM(10,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t,"gerbil-ascent/candidate/types#candidate-rejection::t")

___DEF_SYM(11,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,"gerbil-ascent/candidate/types#make-candidate-rejection")

___DEF_SYM(12,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,"gerbil-ascent/candidate/types#make-reasoning-candidate")

___DEF_SYM(13,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,"gerbil-ascent/candidate/types#make-reasoning-diagnostic")

___DEF_SYM(14,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,"gerbil-ascent/candidate/types#make-reasoning-snapshot")

___DEF_SYM(15,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-candidate::t")

___DEF_SYM(16,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-diagnostic::t")

___DEF_SYM(17,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,"gerbil-ascent/candidate/types#reasoning-snapshot-content-digest")

___DEF_SYM(18,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,"gerbil-ascent/candidate/types#reasoning-snapshot-valid?")

___DEF_SYM(19,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-snapshot::t")

___DEF_SYM(20,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,"gerbil-ascent/candidate/types#snapshot-relation-valid?")

___DEF_SYM(21,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,"gerbil-ascent/candidate/types#snapshot-row-valid?")

___DEF_SYM(22,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,"gerbil-ascent/candidate/types#snapshot-scalar?")

___DEF_SYM(23,___S_gerbil_2d_ascent____candidate____types,"gerbil-ascent__candidate__types")

___DEF_SYM(24,___S_gerbil_2d_ascent____candidate____types_23_,"gerbil-ascent__candidate__types#")

___DEF_SYM(25,___S_identity,"identity")
___DEF_SYM(26,___S_in_2d_range_2d_inclusive_3f_,"in-range-inclusive?")
___DEF_SYM(27,___S_in_2d_range_3f_,"in-range?")
___DEF_SYM(28,___S_limits,"limits")
___DEF_SYM(29,___S_path,"path")
___DEF_SYM(30,___S_query,"query")
___DEF_SYM(31,___S_reasoning_2d_candidate,"reasoning-candidate")
___DEF_SYM(32,___S_reasoning_2d_diagnostic,"reasoning-diagnostic")
___DEF_SYM(33,___S_reasoning_2d_snapshot,"reasoning-snapshot")
___DEF_SYM(34,___S_reasoning_2d_snapshot_2d_v1,"reasoning-snapshot-v1")
___DEF_SYM(35,___S_relations,"relations")
___DEF_SYM(36,___S_rules,"rules")
___DEF_SYM(37,___S_start,"start")
___DEF_SYM(38,___S_u8vector_2d_length,"u8vector-length")
___END_SYM

#define ___SYM_bytes ___SYM(0,___S_bytes)
#define ___SYM_candidate_2d_rejection ___SYM(1,___S_candidate_2d_rejection)
#define ___SYM_code ___SYM(2,___S_code)
#define ___SYM_detail ___SYM(3,___S_detail)
#define ___SYM_diagnostic ___SYM(4,___S_diagnostic)
#define ___SYM_digest ___SYM(5,___S_digest)
#define ___SYM_facts ___SYM(6,___S_facts)
#define ___SYM_fxmax ___SYM(7,___S_fxmax)
#define ___SYM_generation ___SYM(8,___S_generation)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types ___SYM(9,___S_gerbil_2d_ascent_2f_candidate_2f_types)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t ___SYM(10,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection ___SYM(11,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate ___SYM(12,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic ___SYM(13,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot ___SYM(14,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t ___SYM(15,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t ___SYM(16,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest ___SYM(17,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_ ___SYM(18,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t ___SYM(19,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_ ___SYM(20,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_ ___SYM(21,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
#define ___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_ ___SYM(22,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
#define ___SYM_gerbil_2d_ascent____candidate____types ___SYM(23,___S_gerbil_2d_ascent____candidate____types)
#define ___SYM_gerbil_2d_ascent____candidate____types_23_ ___SYM(24,___S_gerbil_2d_ascent____candidate____types_23_)
#define ___SYM_identity ___SYM(25,___S_identity)
#define ___SYM_in_2d_range_2d_inclusive_3f_ ___SYM(26,___S_in_2d_range_2d_inclusive_3f_)
#define ___SYM_in_2d_range_3f_ ___SYM(27,___S_in_2d_range_3f_)
#define ___SYM_limits ___SYM(28,___S_limits)
#define ___SYM_path ___SYM(29,___S_path)
#define ___SYM_query ___SYM(30,___S_query)
#define ___SYM_reasoning_2d_candidate ___SYM(31,___S_reasoning_2d_candidate)
#define ___SYM_reasoning_2d_diagnostic ___SYM(32,___S_reasoning_2d_diagnostic)
#define ___SYM_reasoning_2d_snapshot ___SYM(33,___S_reasoning_2d_snapshot)
#define ___SYM_reasoning_2d_snapshot_2d_v1 ___SYM(34,___S_reasoning_2d_snapshot_2d_v1)
#define ___SYM_relations ___SYM(35,___S_relations)
#define ___SYM_rules ___SYM(36,___S_rules)
#define ___SYM_start ___SYM(37,___S_start)
#define ___SYM_u8vector_2d_length ___SYM(38,___S_u8vector_2d_length)

___BEGIN_KEY
___DEF_KEY(0,___K_context,"context")
___DEF_KEY(1,___K_contract,"contract")
___DEF_KEY(2,___K_struct,"struct")
___DEF_KEY(3,___K_value,"value")
___END_KEY

#define ___KEY_context ___KEY(0,___K_context)
#define ___KEY_contract ___KEY(1,___K_contract)
#define ___KEY_struct ___KEY(2,___K_struct)
#define ___KEY_value ___KEY(3,___K_value)

___BEGIN_GLO
___DEF_GLO(0,"gerbil-ascent/candidate/types#&candidate-rejection-diagnostic")

___DEF_GLO(1,"gerbil-ascent/candidate/types#&candidate-rejection-diagnostic-set!")

___DEF_GLO(2,"gerbil-ascent/candidate/types#&reasoning-candidate-facts")

___DEF_GLO(3,"gerbil-ascent/candidate/types#&reasoning-candidate-facts-set!")

___DEF_GLO(4,"gerbil-ascent/candidate/types#&reasoning-candidate-limits")

___DEF_GLO(5,"gerbil-ascent/candidate/types#&reasoning-candidate-limits-set!")

___DEF_GLO(6,"gerbil-ascent/candidate/types#&reasoning-candidate-query")

___DEF_GLO(7,"gerbil-ascent/candidate/types#&reasoning-candidate-query-set!")

___DEF_GLO(8,"gerbil-ascent/candidate/types#&reasoning-candidate-relations")

___DEF_GLO(9,"gerbil-ascent/candidate/types#&reasoning-candidate-relations-set!")

___DEF_GLO(10,"gerbil-ascent/candidate/types#&reasoning-candidate-rules")

___DEF_GLO(11,"gerbil-ascent/candidate/types#&reasoning-candidate-rules-set!")

___DEF_GLO(12,"gerbil-ascent/candidate/types#&reasoning-diagnostic-code")

___DEF_GLO(13,"gerbil-ascent/candidate/types#&reasoning-diagnostic-code-set!")

___DEF_GLO(14,"gerbil-ascent/candidate/types#&reasoning-diagnostic-detail")

___DEF_GLO(15,"gerbil-ascent/candidate/types#&reasoning-diagnostic-detail-set!")

___DEF_GLO(16,"gerbil-ascent/candidate/types#&reasoning-diagnostic-path")

___DEF_GLO(17,"gerbil-ascent/candidate/types#&reasoning-diagnostic-path-set!")

___DEF_GLO(18,"gerbil-ascent/candidate/types#&reasoning-snapshot-digest")

___DEF_GLO(19,"gerbil-ascent/candidate/types#&reasoning-snapshot-digest-set!")

___DEF_GLO(20,"gerbil-ascent/candidate/types#&reasoning-snapshot-generation")

___DEF_GLO(21,"gerbil-ascent/candidate/types#&reasoning-snapshot-generation-set!")

___DEF_GLO(22,"gerbil-ascent/candidate/types#&reasoning-snapshot-identity")

___DEF_GLO(23,"gerbil-ascent/candidate/types#&reasoning-snapshot-identity-set!")

___DEF_GLO(24,"gerbil-ascent/candidate/types#&reasoning-snapshot-relations")

___DEF_GLO(25,"gerbil-ascent/candidate/types#&reasoning-snapshot-relations-set!")

___DEF_GLO(26,"gerbil-ascent/candidate/types#+max-derived-facts+")

___DEF_GLO(27,"gerbil-ascent/candidate/types#+max-input-facts+")

___DEF_GLO(28,"gerbil-ascent/candidate/types#+max-output-facts+")

___DEF_GLO(29,"gerbil-ascent/candidate/types#+max-relations+")

___DEF_GLO(30,"gerbil-ascent/candidate/types#+max-rules+")

___DEF_GLO(31,"gerbil-ascent/candidate/types#candidate-rejection-diagnostic")

___DEF_GLO(32,"gerbil-ascent/candidate/types#candidate-rejection-diagnostic-set!")

___DEF_GLO(33,"gerbil-ascent/candidate/types#candidate-rejection::t")

___DEF_GLO(34,"gerbil-ascent/candidate/types#candidate-rejection?")

___DEF_GLO(35,"gerbil-ascent/candidate/types#make-candidate-rejection")

___DEF_GLO(36,"gerbil-ascent/candidate/types#make-reasoning-candidate")

___DEF_GLO(37,"gerbil-ascent/candidate/types#make-reasoning-diagnostic")

___DEF_GLO(38,"gerbil-ascent/candidate/types#make-reasoning-snapshot")

___DEF_GLO(39,"gerbil-ascent/candidate/types#reasoning-candidate-facts")

___DEF_GLO(40,"gerbil-ascent/candidate/types#reasoning-candidate-facts-set!")

___DEF_GLO(41,"gerbil-ascent/candidate/types#reasoning-candidate-limits")

___DEF_GLO(42,"gerbil-ascent/candidate/types#reasoning-candidate-limits-set!")

___DEF_GLO(43,"gerbil-ascent/candidate/types#reasoning-candidate-query")

___DEF_GLO(44,"gerbil-ascent/candidate/types#reasoning-candidate-query-set!")

___DEF_GLO(45,"gerbil-ascent/candidate/types#reasoning-candidate-relations")

___DEF_GLO(46,"gerbil-ascent/candidate/types#reasoning-candidate-relations-set!")

___DEF_GLO(47,"gerbil-ascent/candidate/types#reasoning-candidate-rules")

___DEF_GLO(48,"gerbil-ascent/candidate/types#reasoning-candidate-rules-set!")

___DEF_GLO(49,"gerbil-ascent/candidate/types#reasoning-candidate::t")

___DEF_GLO(50,"gerbil-ascent/candidate/types#reasoning-candidate?")

___DEF_GLO(51,"gerbil-ascent/candidate/types#reasoning-diagnostic-code")

___DEF_GLO(52,"gerbil-ascent/candidate/types#reasoning-diagnostic-code-set!")

___DEF_GLO(53,"gerbil-ascent/candidate/types#reasoning-diagnostic-detail")

___DEF_GLO(54,"gerbil-ascent/candidate/types#reasoning-diagnostic-detail-set!")

___DEF_GLO(55,"gerbil-ascent/candidate/types#reasoning-diagnostic-path")

___DEF_GLO(56,"gerbil-ascent/candidate/types#reasoning-diagnostic-path-set!")

___DEF_GLO(57,"gerbil-ascent/candidate/types#reasoning-diagnostic::t")

___DEF_GLO(58,"gerbil-ascent/candidate/types#reasoning-diagnostic?")

___DEF_GLO(59,"gerbil-ascent/candidate/types#reasoning-snapshot-content-digest")

___DEF_GLO(60,"gerbil-ascent/candidate/types#reasoning-snapshot-digest")

___DEF_GLO(61,"gerbil-ascent/candidate/types#reasoning-snapshot-digest-set!")

___DEF_GLO(62,"gerbil-ascent/candidate/types#reasoning-snapshot-generation")

___DEF_GLO(63,"gerbil-ascent/candidate/types#reasoning-snapshot-generation-set!")

___DEF_GLO(64,"gerbil-ascent/candidate/types#reasoning-snapshot-identity")

___DEF_GLO(65,"gerbil-ascent/candidate/types#reasoning-snapshot-identity-set!")

___DEF_GLO(66,"gerbil-ascent/candidate/types#reasoning-snapshot-relations")

___DEF_GLO(67,"gerbil-ascent/candidate/types#reasoning-snapshot-relations-set!")

___DEF_GLO(68,"gerbil-ascent/candidate/types#reasoning-snapshot-valid?")

___DEF_GLO(69,"gerbil-ascent/candidate/types#reasoning-snapshot::t")

___DEF_GLO(70,"gerbil-ascent/candidate/types#reasoning-snapshot?")

___DEF_GLO(71,"gerbil-ascent/candidate/types#snapshot-relation-valid?")

___DEF_GLO(72,"gerbil-ascent/candidate/types#snapshot-row-valid?")

___DEF_GLO(73,"gerbil-ascent/candidate/types#snapshot-scalar?")

___DEF_GLO(74,"gerbil-ascent/candidate/types::timestamp")

___DEF_GLO(75,"gerbil-ascent__candidate__types#")
___DEF_GLO(76,"##dead-end")
___DEF_GLO(77,"##length")
___DEF_GLO(78,"##list?")
___DEF_GLO(79,"##string->utf8")
___DEF_GLO(80,"##structure-instance-of?")
___DEF_GLO(81,"+")
___DEF_GLO(82,"-")
___DEF_GLO(83,"<=")
___DEF_GLO(84,"=")
___DEF_GLO(85,"__make-class-predicate")
___DEF_GLO(86,"__make-class-slot-accessor")
___DEF_GLO(87,"__make-class-slot-mutator")
___DEF_GLO(88,"__make-class-slot-unchecked-accessor")

___DEF_GLO(89,"__make-class-slot-unchecked-mutator")

___DEF_GLO(90,"absent-value")
___DEF_GLO(91,"andmap__0")
___DEF_GLO(92,"apply")
___DEF_GLO(93,"caddr")
___DEF_GLO(94,"cadr")
___DEF_GLO(95,"call-with-output-string")
___DEF_GLO(96,"car")
___DEF_GLO(97,"equal?")
___DEF_GLO(98,"gerbil-ascent/candidate/datum#reasoning-bounded-data?")

___DEF_GLO(99,"hash-get")
___DEF_GLO(100,"hash-put!")
___DEF_GLO(101,"length")
___DEF_GLO(102,"make-class-type")
___DEF_GLO(103,"make-hash-table__%")
___DEF_GLO(104,"make-instance")
___DEF_GLO(105,"raise-contract-violation-error")
___DEF_GLO(106,"std/crypto/digest#__sha256")
___DEF_GLO(107,"std/encoding/hex#__hex-encode__%")
___DEF_GLO(108,"write")
___END_GLO

#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic ___GLO(0,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic ___PRM(0,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_ ___GLO(1,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_ ___PRM(1,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts ___GLO(2,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts ___PRM(2,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_ ___GLO(3,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_ ___PRM(3,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits ___GLO(4,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits ___PRM(4,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_ ___GLO(5,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_ ___PRM(5,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query ___GLO(6,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query ___PRM(6,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_ ___GLO(7,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_ ___PRM(7,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations ___GLO(8,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations ___PRM(8,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_ ___GLO(9,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_ ___PRM(9,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules ___GLO(10,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules ___PRM(10,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_ ___GLO(11,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_ ___PRM(11,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code ___GLO(12,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code ___PRM(12,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_ ___GLO(13,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_ ___PRM(13,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail ___GLO(14,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail ___PRM(14,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_ ___GLO(15,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_ ___PRM(15,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path ___GLO(16,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path ___PRM(16,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_ ___GLO(17,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_ ___PRM(17,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest ___GLO(18,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest ___PRM(18,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_ ___GLO(19,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_ ___PRM(19,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation ___GLO(20,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation ___PRM(20,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_ ___GLO(21,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_ ___PRM(21,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity ___GLO(22,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity ___PRM(22,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_ ___GLO(23,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_ ___PRM(23,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations ___GLO(24,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations ___PRM(24,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_ ___GLO(25,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_ ___PRM(25,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_ ___GLO(26,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_ ___PRM(26,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_ ___GLO(27,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_ ___PRM(27,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_ ___GLO(28,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_ ___PRM(28,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_ ___GLO(29,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_ ___PRM(29,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_ ___GLO(30,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_ ___PRM(30,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic ___GLO(31,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic ___PRM(31,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_ ___GLO(32,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_ ___PRM(32,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t ___GLO(33,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t ___PRM(33,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_ ___GLO(34,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_ ___PRM(34,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection ___GLO(35,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection ___PRM(35,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate ___GLO(36,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate ___PRM(36,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic ___GLO(37,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic ___PRM(37,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot ___GLO(38,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot ___PRM(38,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts ___GLO(39,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts ___PRM(39,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_ ___GLO(40,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_ ___PRM(40,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits ___GLO(41,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits ___PRM(41,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_ ___GLO(42,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_ ___PRM(42,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query ___GLO(43,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query ___PRM(43,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_ ___GLO(44,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_ ___PRM(44,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations ___GLO(45,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations ___PRM(45,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_ ___GLO(46,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_ ___PRM(46,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules ___GLO(47,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules ___PRM(47,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_ ___GLO(48,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_ ___PRM(48,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t ___GLO(49,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t ___PRM(49,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_ ___GLO(50,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_ ___PRM(50,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code ___GLO(51,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code ___PRM(51,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_ ___GLO(52,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_ ___PRM(52,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail ___GLO(53,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail ___PRM(53,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_ ___GLO(54,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_ ___PRM(54,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path ___GLO(55,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path ___PRM(55,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_ ___GLO(56,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_ ___PRM(56,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t ___GLO(57,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t ___PRM(57,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_ ___GLO(58,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_ ___PRM(58,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest ___GLO(59,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest ___PRM(59,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest ___GLO(60,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest ___PRM(60,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_ ___GLO(61,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_ ___PRM(61,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation ___GLO(62,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation ___PRM(62,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_ ___GLO(63,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_ ___PRM(63,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity ___GLO(64,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity ___PRM(64,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_ ___GLO(65,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_ ___PRM(65,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations ___GLO(66,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations ___PRM(66,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_ ___GLO(67,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_ ___PRM(67,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_ ___GLO(68,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_ ___PRM(68,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t ___GLO(69,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t ___PRM(69,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_ ___GLO(70,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_ ___PRM(70,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_ ___GLO(71,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_ ___PRM(71,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_ ___GLO(72,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_ ___PRM(72,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_ ___GLO(73,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_ ___PRM(73,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp ___GLO(74,___G_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp ___PRM(74,___G_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp)
#define ___GLO_gerbil_2d_ascent____candidate____types_23_ ___GLO(75,___G_gerbil_2d_ascent____candidate____types_23_)
#define ___PRM_gerbil_2d_ascent____candidate____types_23_ ___PRM(75,___G_gerbil_2d_ascent____candidate____types_23_)
#define ___GLO__23__23_dead_2d_end ___GLO(76,___G__23__23_dead_2d_end)
#define ___PRM__23__23_dead_2d_end ___PRM(76,___G__23__23_dead_2d_end)
#define ___GLO__23__23_length ___GLO(77,___G__23__23_length)
#define ___PRM__23__23_length ___PRM(77,___G__23__23_length)
#define ___GLO__23__23_list_3f_ ___GLO(78,___G__23__23_list_3f_)
#define ___PRM__23__23_list_3f_ ___PRM(78,___G__23__23_list_3f_)
#define ___GLO__23__23_string_2d__3e_utf8 ___GLO(79,___G__23__23_string_2d__3e_utf8)
#define ___PRM__23__23_string_2d__3e_utf8 ___PRM(79,___G__23__23_string_2d__3e_utf8)
#define ___GLO__23__23_structure_2d_instance_2d_of_3f_ ___GLO(80,___G__23__23_structure_2d_instance_2d_of_3f_)
#define ___PRM__23__23_structure_2d_instance_2d_of_3f_ ___PRM(80,___G__23__23_structure_2d_instance_2d_of_3f_)
#define ___GLO__2b_ ___GLO(81,___G__2b_)
#define ___PRM__2b_ ___PRM(81,___G__2b_)
#define ___GLO__2d_ ___GLO(82,___G__2d_)
#define ___PRM__2d_ ___PRM(82,___G__2d_)
#define ___GLO__3c__3d_ ___GLO(83,___G__3c__3d_)
#define ___PRM__3c__3d_ ___PRM(83,___G__3c__3d_)
#define ___GLO__3d_ ___GLO(84,___G__3d_)
#define ___PRM__3d_ ___PRM(84,___G__3d_)
#define ___GLO_____make_2d_class_2d_predicate ___GLO(85,___G_____make_2d_class_2d_predicate)
#define ___PRM_____make_2d_class_2d_predicate ___PRM(85,___G_____make_2d_class_2d_predicate)
#define ___GLO_____make_2d_class_2d_slot_2d_accessor ___GLO(86,___G_____make_2d_class_2d_slot_2d_accessor)
#define ___PRM_____make_2d_class_2d_slot_2d_accessor ___PRM(86,___G_____make_2d_class_2d_slot_2d_accessor)
#define ___GLO_____make_2d_class_2d_slot_2d_mutator ___GLO(87,___G_____make_2d_class_2d_slot_2d_mutator)
#define ___PRM_____make_2d_class_2d_slot_2d_mutator ___PRM(87,___G_____make_2d_class_2d_slot_2d_mutator)
#define ___GLO_____make_2d_class_2d_slot_2d_unchecked_2d_accessor ___GLO(88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
#define ___PRM_____make_2d_class_2d_slot_2d_unchecked_2d_accessor ___PRM(88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
#define ___GLO_____make_2d_class_2d_slot_2d_unchecked_2d_mutator ___GLO(89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
#define ___PRM_____make_2d_class_2d_slot_2d_unchecked_2d_mutator ___PRM(89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
#define ___GLO_absent_2d_value ___GLO(90,___G_absent_2d_value)
#define ___PRM_absent_2d_value ___PRM(90,___G_absent_2d_value)
#define ___GLO_andmap____0 ___GLO(91,___G_andmap____0)
#define ___PRM_andmap____0 ___PRM(91,___G_andmap____0)
#define ___GLO_apply ___GLO(92,___G_apply)
#define ___PRM_apply ___PRM(92,___G_apply)
#define ___GLO_caddr ___GLO(93,___G_caddr)
#define ___PRM_caddr ___PRM(93,___G_caddr)
#define ___GLO_cadr ___GLO(94,___G_cadr)
#define ___PRM_cadr ___PRM(94,___G_cadr)
#define ___GLO_call_2d_with_2d_output_2d_string ___GLO(95,___G_call_2d_with_2d_output_2d_string)
#define ___PRM_call_2d_with_2d_output_2d_string ___PRM(95,___G_call_2d_with_2d_output_2d_string)
#define ___GLO_car ___GLO(96,___G_car)
#define ___PRM_car ___PRM(96,___G_car)
#define ___GLO_equal_3f_ ___GLO(97,___G_equal_3f_)
#define ___PRM_equal_3f_ ___PRM(97,___G_equal_3f_)
#define ___GLO_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_ ___GLO(98,___G_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_)
#define ___PRM_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_ ___PRM(98,___G_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_)
#define ___GLO_hash_2d_get ___GLO(99,___G_hash_2d_get)
#define ___PRM_hash_2d_get ___PRM(99,___G_hash_2d_get)
#define ___GLO_hash_2d_put_21_ ___GLO(100,___G_hash_2d_put_21_)
#define ___PRM_hash_2d_put_21_ ___PRM(100,___G_hash_2d_put_21_)
#define ___GLO_length ___GLO(101,___G_length)
#define ___PRM_length ___PRM(101,___G_length)
#define ___GLO_make_2d_class_2d_type ___GLO(102,___G_make_2d_class_2d_type)
#define ___PRM_make_2d_class_2d_type ___PRM(102,___G_make_2d_class_2d_type)
#define ___GLO_make_2d_hash_2d_table_____25_ ___GLO(103,___G_make_2d_hash_2d_table_____25_)
#define ___PRM_make_2d_hash_2d_table_____25_ ___PRM(103,___G_make_2d_hash_2d_table_____25_)
#define ___GLO_make_2d_instance ___GLO(104,___G_make_2d_instance)
#define ___PRM_make_2d_instance ___PRM(104,___G_make_2d_instance)
#define ___GLO_raise_2d_contract_2d_violation_2d_error ___GLO(105,___G_raise_2d_contract_2d_violation_2d_error)
#define ___PRM_raise_2d_contract_2d_violation_2d_error ___PRM(105,___G_raise_2d_contract_2d_violation_2d_error)
#define ___GLO_std_2f_crypto_2f_digest_23_____sha256 ___GLO(106,___G_std_2f_crypto_2f_digest_23_____sha256)
#define ___PRM_std_2f_crypto_2f_digest_23_____sha256 ___PRM(106,___G_std_2f_crypto_2f_digest_23_____sha256)
#define ___GLO_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_ ___GLO(107,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
#define ___PRM_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_ ___PRM(107,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
#define ___GLO_write ___GLO(108,___G_write)
#define ___PRM_write ___PRM(108,___G_write)

___BEGIN_CNS
 ___DEF_CNS(___REF_SYM(25,___S_identity),___REF_CNS(1))
,___DEF_CNS(___REF_SYM(8,___S_generation),___REF_CNS(2))
,___DEF_CNS(___REF_SYM(5,___S_digest),___REF_CNS(3))
,___DEF_CNS(___REF_SYM(35,___S_relations),___REF_NUL)
,___DEF_CNS(___REF_SYM(2,___S_code),___REF_CNS(5))
,___DEF_CNS(___REF_SYM(29,___S_path),___REF_CNS(6))
,___DEF_CNS(___REF_SYM(3,___S_detail),___REF_NUL)
,___DEF_CNS(___REF_SYM(35,___S_relations),___REF_CNS(8))
,___DEF_CNS(___REF_SYM(6,___S_facts),___REF_CNS(9))
,___DEF_CNS(___REF_SYM(36,___S_rules),___REF_CNS(10))
,___DEF_CNS(___REF_SYM(30,___S_query),___REF_CNS(11))
,___DEF_CNS(___REF_SYM(28,___S_limits),___REF_NUL)
,___DEF_CNS(___REF_SYM(4,___S_diagnostic),___REF_NUL)
,___DEF_CNS(___REF_SYM(26,___S_in_2d_range_2d_inclusive_3f_),___REF_CNS(14))
,___DEF_CNS(___REF_SYM(37,___S_start),___REF_CNS(15))
,___DEF_CNS(___REF_CNS(16),___REF_NUL)
,___DEF_CNS(___REF_SYM(38,___S_u8vector_2d_length),___REF_CNS(17))
,___DEF_CNS(___REF_SYM(0,___S_bytes),___REF_NUL)
,___DEF_CNS(___REF_SYM(27,___S_in_2d_range_3f_),___REF_CNS(19))
,___DEF_CNS(___REF_FIX(0),___REF_CNS(20))
,___DEF_CNS(___REF_CNS(21),___REF_NUL)
,___DEF_CNS(___REF_SYM(7,___S_fxmax),___REF_CNS(22))
,___DEF_CNS(___REF_CNS(23),___REF_CNS(25))
,___DEF_CNS(___REF_SYM(38,___S_u8vector_2d_length),___REF_CNS(24))
,___DEF_CNS(___REF_SYM(0,___S_bytes),___REF_NUL)
,___DEF_CNS(___REF_FIX(1),___REF_NUL)
___END_CNS

___DEF_SUB_BIGFIX(___X0,1UL)
               ___BIGFIX1(0x6acb08fbL)
___DEF_SUB_STR(___X1,0UL)
               ___STR0
___DEF_SUB_STR(___X2,18UL)
               ___STR8(99,111,110,116,114,97,99,116)
               ___STR8(32,118,105,111,108,97,116,105)
               ___STR2(111,110)
___DEF_SUB_STR(___X3,18UL)
               ___STR8(99,111,110,116,114,97,99,116)
               ___STR8(32,118,105,111,108,97,116,105)
               ___STR2(111,110)
___DEF_SUB_VEC(___X4,6UL)
               ___VEC1(___REF_SUB(5))
               ___VEC1(___REF_SUB(6))
               ___VEC1(___REF_NUL)
               ___VEC1(___REF_FIX(1))
               ___VEC1(___REF_PRC(1))
               ___VEC1(___REF_FAL)
               ___VEC0
___DEF_SUB_VEC(___X5,1UL)
               ___VEC1(___REF_SYM(23,___S_gerbil_2d_ascent____candidate____types))
               ___VEC0
___DEF_SUB_VEC(___X6,0UL)
               ___VEC0

___BEGIN_SUB
 ___DEF_SUB(___X0)
,___DEF_SUB(___X1)
,___DEF_SUB(___X2)
,___DEF_SUB(___X3)
,___DEF_SUB(___X4)
,___DEF_SUB(___X5)
,___DEF_SUB(___X6)
___END_SUB



#undef ___MD_ALL
#define ___MD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___MR_ALL
#define ___MR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___MW_ALL
#define ___MW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_M_COD
___BEGIN_M_HLBL
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L16_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L17_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L18_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L19_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L20_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L21_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L22_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L23_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L24_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L25_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L26_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L27_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L28_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L29_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L30_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L31_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L32_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L33_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L34_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L35_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L36_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L37_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L38_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L39_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L40_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L41_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L42_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L43_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L44_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L45_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L46_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L47_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L48_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L49_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L50_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L51_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L52_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L53_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L54_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L55_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L56_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L57_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L58_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L59_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L60_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L61_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L62_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L63_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L64_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL(___L65_gerbil_2d_ascent____candidate____types_23_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_M_HLBL_INTRO
___DEF_M_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_M_HLBL(___L22_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___END_M_HLBL

___BEGIN_M_SW

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent____candidate____types_23_
#undef ___PH_LBL0
#define ___PH_LBL0 1
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L16_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L17_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L18_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L19_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L20_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L21_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L22_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L23_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L24_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L25_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L26_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L27_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L28_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L29_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L30_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L31_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L32_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L33_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L34_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L35_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L36_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L37_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L38_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L39_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L40_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L41_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L42_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L43_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L44_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L45_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L46_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L47_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L48_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L49_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L50_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L51_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L52_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L53_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L54_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L55_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L56_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L57_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L58_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L59_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L60_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L61_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L62_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L63_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L64_gerbil_2d_ascent____candidate____types_23_)
___DEF_P_HLBL(___L65_gerbil_2d_ascent____candidate____types_23_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent____candidate____types_23_)
   ___IF_NARGS_EQ(0,___NOTHING)
   ___WRONG_NARGS(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(74,___G_gerbil_2d_ascent_2f_candidate_2f_types_3a__3a_timestamp,___BIGFIX(0,1791691003LL))
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___R0)
   ___SET_STK(5,___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_STK(6,___SYM_reasoning_2d_snapshot)
   ___SET_STK(7,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(0))
   ___ADJFP(7)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent____candidate____types_23_)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent____candidate____types_23_)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(6),102,___G_make_2d_class_2d_type)
___DEF_SLBL(3,___L3_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(69,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(4))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),85,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(4,___L4_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(70,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3f_,___R1)
   ___SET_R2(___SYM_identity)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(5,___L5_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(64,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity,___R1)
   ___SET_R2(___SYM_generation)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(6))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(6,___L6_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(62,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation,___R1)
   ___SET_R2(___SYM_digest)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(7))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(7,___L7_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(60,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(8))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(8,___L8_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(66,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations,___R1)
   ___SET_R2(___SYM_identity)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(9))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(9,___L9_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(65,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_identity_2d_set_21_,___R1)
   ___SET_R2(___SYM_generation)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(10))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(10,___L10_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(63,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_generation_2d_set_21_,___R1)
   ___SET_R2(___SYM_digest)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(11))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(11,___L11_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(61,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_digest_2d_set_21_,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(12))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(12,___L12_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(67,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_relations_2d_set_21_,___R1)
   ___SET_R2(___SYM_identity)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(13))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(13,___L13_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(22,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity,___R1)
   ___SET_R2(___SYM_generation)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(14))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(14,___L14_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(20,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation,___R1)
   ___SET_R2(___SYM_digest)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(15))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(15,___L15_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(18,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(16))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(16,___L16_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(24,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations,___R1)
   ___SET_R2(___SYM_identity)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(17))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(17,___L17_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(23,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_identity_2d_set_21_,___R1)
   ___SET_R2(___SYM_generation)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(18))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(18,___L18_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(21,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_generation_2d_set_21_,___R1)
   ___SET_R2(___SYM_digest)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(19))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(19,___L19_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(19,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_digest_2d_set_21_,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(20))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(20,___L20_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(25,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_snapshot_2d_relations_2d_set_21_,___R1)
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_STK(2,___SYM_reasoning_2d_diagnostic)
   ___SET_STK(3,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(4))
   ___SET_R0(___LBL(22))
   ___ADJFP(3)
   ___CHECK_HEAP(21,4096)
___DEF_SLBL(21,___L21_gerbil_2d_ascent____candidate____types_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(6),102,___G_make_2d_class_2d_type)
___DEF_SLBL(22,___L22_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(57,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(23))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),85,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(23,___L23_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(58,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3f_,___R1)
   ___SET_R2(___SYM_code)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(24))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(24,___L24_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(51,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code,___R1)
   ___SET_R2(___SYM_path)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(25))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(25,___L25_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(55,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path,___R1)
   ___SET_R2(___SYM_detail)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(26))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(26,___L26_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(53,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail,___R1)
   ___SET_R2(___SYM_code)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(27))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(27,___L27_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(52,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_code_2d_set_21_,___R1)
   ___SET_R2(___SYM_path)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(28))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(28,___L28_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(56,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_path_2d_set_21_,___R1)
   ___SET_R2(___SYM_detail)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(29))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(29,___L29_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(54,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_2d_detail_2d_set_21_,___R1)
   ___SET_R2(___SYM_code)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(30))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(30,___L30_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(12,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code,___R1)
   ___SET_R2(___SYM_path)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(31))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(31,___L31_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(16,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path,___R1)
   ___SET_R2(___SYM_detail)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(32))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(32,___L32_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(14,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail,___R1)
   ___SET_R2(___SYM_code)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(33))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(33,___L33_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(13,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_code_2d_set_21_,___R1)
   ___SET_R2(___SYM_path)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(34))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(34,___L34_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(17,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_path_2d_set_21_,___R1)
   ___SET_R2(___SYM_detail)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R0(___LBL(35))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(35,___L35_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(15,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_diagnostic_2d_detail_2d_set_21_,___R1)
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_STK(2,___SYM_reasoning_2d_candidate)
   ___SET_STK(3,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(7))
   ___SET_R0(___LBL(37))
   ___ADJFP(3)
   ___CHECK_HEAP(36,4096)
___DEF_SLBL(36,___L36_gerbil_2d_ascent____candidate____types_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(6),102,___G_make_2d_class_2d_type)
___DEF_SLBL(37,___L37_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(49,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(38))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),85,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(38,___L38_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(50,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3f_,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(39))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(39,___L39_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(45,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations,___R1)
   ___SET_R2(___SYM_facts)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(40))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(40,___L40_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(39,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts,___R1)
   ___SET_R2(___SYM_rules)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(41))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(41,___L41_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(47,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules,___R1)
   ___SET_R2(___SYM_query)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(42))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(42,___L42_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(43,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query,___R1)
   ___SET_R2(___SYM_limits)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(43))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(43,___L43_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(41,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(44))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(44,___L44_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(46,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_relations_2d_set_21_,___R1)
   ___SET_R2(___SYM_facts)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(45))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(45,___L45_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(40,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_facts_2d_set_21_,___R1)
   ___SET_R2(___SYM_rules)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(46))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(46,___L46_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(48,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_rules_2d_set_21_,___R1)
   ___SET_R2(___SYM_query)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(47))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(47,___L47_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(44,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_query_2d_set_21_,___R1)
   ___SET_R2(___SYM_limits)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(48))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(48,___L48_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(42,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_2d_limits_2d_set_21_,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(49))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(49,___L49_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(8,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations,___R1)
   ___SET_R2(___SYM_facts)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(50))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(50,___L50_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(2,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts,___R1)
   ___SET_R2(___SYM_rules)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(51))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(51,___L51_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(10,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules,___R1)
   ___SET_R2(___SYM_query)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(52))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(52,___L52_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(6,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query,___R1)
   ___SET_R2(___SYM_limits)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(53))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(53,___L53_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(4,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits,___R1)
   ___SET_R2(___SYM_relations)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(54))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(54,___L54_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(9,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_relations_2d_set_21_,___R1)
   ___SET_R2(___SYM_facts)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(55))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(55,___L55_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(3,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_facts_2d_set_21_,___R1)
   ___SET_R2(___SYM_rules)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(56))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(56,___L56_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(11,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_rules_2d_set_21_,___R1)
   ___SET_R2(___SYM_query)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(57))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(57,___L57_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(7,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_query_2d_set_21_,___R1)
   ___SET_R2(___SYM_limits)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R0(___LBL(58))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(58,___L58_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(5,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_reasoning_2d_candidate_2d_limits_2d_set_21_,___R1)
   ___SET_R1(___NUL)
   ___SET_R2(___CONS(___KEY_struct,___TRU))
   ___SET_R2(___CONS(___R2,___NUL))
   ___SET_STK(1,___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_STK(2,___SYM_candidate_2d_rejection)
   ___SET_STK(3,___R1)
   ___SET_R3(___FAL)
   ___SET_R1(___CNS(12))
   ___SET_R0(___LBL(60))
   ___ADJFP(3)
   ___CHECK_HEAP(59,4096)
___DEF_SLBL(59,___L59_gerbil_2d_ascent____candidate____types_23_)
   ___JUMPGLONOTSAFE(___SET_NARGS(6),102,___G_make_2d_class_2d_type)
___DEF_SLBL(60,___L60_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(33,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t,___R1)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R0(___LBL(61))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),85,___G_____make_2d_class_2d_predicate)
___DEF_SLBL(61,___L61_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(34,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3f_,___R1)
   ___SET_R2(___SYM_diagnostic)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R0(___LBL(62))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),86,___G_____make_2d_class_2d_slot_2d_accessor)
___DEF_SLBL(62,___L62_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(31,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic,___R1)
   ___SET_R2(___SYM_diagnostic)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R0(___LBL(63))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),87,___G_____make_2d_class_2d_slot_2d_mutator)
___DEF_SLBL(63,___L63_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(32,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_2d_diagnostic_2d_set_21_,___R1)
   ___SET_R2(___SYM_diagnostic)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R0(___LBL(64))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),88,___G_____make_2d_class_2d_slot_2d_unchecked_2d_accessor)
___DEF_SLBL(64,___L64_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(0,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic,___R1)
   ___SET_R2(___SYM_diagnostic)
   ___SET_R1(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R0(___LBL(65))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),89,___G_____make_2d_class_2d_slot_2d_unchecked_2d_mutator)
___DEF_SLBL(65,___L65_gerbil_2d_ascent____candidate____types_23_)
   ___SET_GLO(1,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__26_candidate_2d_rejection_2d_diagnostic_2d_set_21_,___R1)
   ___SET_GLO(29,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_relations_2b_,___FIX(64L))
   ___SET_GLO(30,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_rules_2b_,___FIX(64L))
   ___SET_GLO(27,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_input_2d_facts_2b_,___FIX(1024L))
   ___SET_GLO(26,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_derived_2d_facts_2b_,___FIX(4096L))
   ___SET_GLO(28,___G_gerbil_2d_ascent_2f_candidate_2f_types_23__2b_max_2d_output_2d_facts_2b_,___FIX(4096L))
   ___SET_R1(___VOID)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot
#undef ___PH_LBL0
#define ___PH_LBL0 68
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic
#undef ___PH_LBL0
#define ___PH_LBL0 71
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate
#undef ___PH_LBL0
#define ___PH_LBL0 74
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection
#undef ___PH_LBL0
#define ___PH_LBL0 77
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R1 ___D_R2 ___D_R3
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R1 ___R_R2 ___R_R3
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2 ___W_R3
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
   ___IF_NARGS_EQ(0,___SET_R1(___NUL))
   ___GET_REST(0,0,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
   ___SET_R3(___R1)
   ___SET_R2(___GLO_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t)
   ___SET_R1(___GLO_make_2d_instance)
   ___POLL(1)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection)
   ___JUMPPRM(___SET_NARGS(3),___PRM_apply)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest
#undef ___PH_LBL0
#define ___PH_LBL0 80
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___ALLOC_CLO(3UL))
   ___BEGIN_SETUP_CLO(3,___STK(2),8)
   ___ADD_CLO_ELEM(0,___R2)
   ___ADD_CLO_ELEM(1,___R1)
   ___ADD_CLO_ELEM(2,___R3)
   ___END_SETUP_CLO(3)
   ___SET_R2(___STK(2))
   ___SET_R1(___SUB(1))
   ___ADJFP(4)
   ___CHECK_HEAP(1,4096)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_R0(___LBL(3))
   ___JUMPGLOSAFE(___SET_NARGS(2),95,___G_call_2d_with_2d_output_2d_string)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_R0(___LBL(4))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_string_2d__3e_utf8)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(1),106,___G_std_2f_crypto_2f_digest_23_____sha256)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_R2(___U8VECTORLENGTH(___R1))
   ___SET_R3(___U8VECTORLENGTH(___R1))
   ___SET_R3(___FIXMAX(___R3,___FIX(1L)))
   ___IF(___NOT(___FIXLT(___FIX(0L),___R3)))
   ___GOTO(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___END_IF
   ___SET_R3(___U8VECTORLENGTH(___R1))
   ___IF(___NOT(___AND(___FIXLE(___FIX(0L),___R2),___FIXLE(___R2,___R3))))
   ___GOTO(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___END_IF
   ___SET_R3(___R2)
   ___SET_R2(___FIX(0L))
   ___SET_R0(___STK(-3))
   ___POLL(6)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),107,___G_std_2f_encoding_2f_hex_23_____hex_2d_encode_____25_)
___DEF_GLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_STK(1,___SUB(2))
   ___SET_STK(2,___KEY_context)
   ___SET_STK(3,___SYM_gerbil_2d_ascent_2f_candidate_2f_types)
   ___SET_STK(4,___KEY_contract)
   ___SET_R3(___R2)
   ___SET_R2(___KEY_value)
   ___SET_R1(___CNS(13))
   ___SET_R0(___LBL(7))
   ___ADJFP(4)
   ___JUMPGLOSAFE(___SET_NARGS(7),105,___G_raise_2d_contract_2d_violation_2d_error)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_R1(___VOID)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___SET_STK(1,___SUB(3))
   ___SET_STK(2,___KEY_context)
   ___SET_STK(3,___SYM_gerbil_2d_ascent_2f_candidate_2f_types)
   ___SET_STK(4,___KEY_contract)
   ___SET_R3(___FIX(0L))
   ___SET_R2(___KEY_value)
   ___SET_R1(___CNS(18))
   ___SET_R0(___LBL(7))
   ___ADJFP(4)
   ___JUMPGLOSAFE(___SET_NARGS(7),105,___G_raise_2d_contract_2d_violation_2d_error)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(8,1,0,0)
   ___SET_R3(___CLO(___R4,3))
   ___SET_R2(___CLO(___R4,1))
   ___SET_R4(___CLO(___R4,2))
   ___BEGIN_ALLOC_LIST(4UL,___R3)
   ___ADD_LIST_ELEM(1,___R2)
   ___ADD_LIST_ELEM(2,___R4)
   ___ADD_LIST_ELEM(3,___SYM_reasoning_2d_snapshot_2d_v1)
   ___END_ALLOC_LIST(4)
   ___SET_R2(___GET_LIST(4))
   ___SET_STK(1,___R1)
   ___SET_R1(___R2)
   ___SET_R2(___STK(1))
   ___ADJFP(1)
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___POLL(10)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
   ___ADJFP(-1)
   ___JUMPPRM(___SET_NARGS(2),___PRM_write)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 92
#undef ___PD_ALL
#define ___PD_ALL ___D_R0 ___D_R1 ___D_R2
#undef ___PR_ALL
#define ___PR_ALL ___R_R0 ___R_R1 ___R_R2
#undef ___PW_ALL
#define ___PW_ALL ___W_R1 ___W_R2
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___SET_R2(___BOOLEAN(___EXACTINTP(___R1)))
   ___IF(___NOTFALSEP(___R2))
   ___GOTO(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___END_IF
   ___SET_R2(___BOOLEAN(___BOOLEANP(___R1)))
   ___IF(___NOTFALSEP(___R2))
   ___GOTO(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___END_IF
   ___SET_R2(___BOOLEAN(___SYMBOLP(___R1)))
   ___IF(___NOT(___NOTFALSEP(___R2)))
   ___GOTO(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___END_IF
___DEF_GLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___SET_R1(___R2)
   ___JUMPRET(___R0)
___DEF_GLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_)
   ___SET_R1(___BOOLEAN(___CHARP(___R1)))
   ___JUMPRET(___R0)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 94
#undef ___PD_ALL
#define ___PD_ALL ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R4 ___D_F64(___F64V1) ___D_F64(___F64V2)
#undef ___PR_ALL
#define ___PR_ALL ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___IF_NARGS_EQ(2,___NOTHING)
   ___WRONG_NARGS(0,2,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(2))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-5)))))
   ___GOTO(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
   ___IF(___FIXEQ(___R1,___STK(-5)))
   ___GOTO(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___SET_R2(___STK(-6))
   ___SET_R1(___PRC(92))
   ___SET_R0(___STK(-7))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___ADJFP(-8)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),91,___G_andmap____0)
___DEF_GLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-5)))))
   ___GOTO(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-5)))
   ___IF(___F64EQ(___F64V1,___F64V2))
   ___GOTO(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_)
   ___SET_R2(___STK(-5))
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 100
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF_NARGS_EQ(3,___NOTHING)
   ___WRONG_NARGS(0,3,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_STK(4,___R3)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(2))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L56_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___FIXEQ(___R1,___FIX(3L)))
   ___GOTO(___L22_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L22_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L55_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CAR(___STK(-6)))
   ___IF(___NOT(___SYMBOLP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L55_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CAR(___STK(-6)))
   ___SET_R2(___R1)
   ___SET_R1(___STK(-5))
   ___POLL(4)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R0(___LBL(5))
   ___JUMPGLONOTSAFE(___SET_NARGS(2),99,___G_hash_2d_get)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L23_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L24_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L54_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L23_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L54_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L24_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___IF(___NOT(___EXACTINTP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L53_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L54_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L52_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___FIXLE(___FIX(0L),___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L50_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L51_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CDR(___R1))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L49_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___SET_R0(___LBL(6))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L29_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L30_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L48_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L48_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CDR(___R1))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L49_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___SET_R0(___LBL(7))
   ___JUMPPRM(___SET_NARGS(1),___PRM_length)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-4)))))
   ___GOTO(___L46_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___FIXLE(___R1,___STK(-4)))
   ___GOTO(___L32_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L43_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L44_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CDR(___R1))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L45_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___SET_STK(-4,___ALLOC_CLO(1UL))
   ___BEGIN_SETUP_CLO(1,___STK(-4),16)
   ___ADD_CLO_ELEM(0,___STK(-6))
   ___END_SETUP_CLO(1)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(10))
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),91,___G_andmap____0)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___PAIRP(___STK(-6)))
   ___GOTO(___L35_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(11))
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R0(___LBL(11))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___CAR(___STK(-6)))
   ___SET_R2(___R1)
   ___SET_R1(___STK(-5))
   ___SET_R3(___TRU)
   ___SET_R0(___LBL(12))
   ___ADJFP(-4)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),100,___G_hash_2d_put_21_)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___TRU)
   ___ADJFP(-4)
   ___JUMPRET(___STK(1))
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L37_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___R1),___STK(-5))))
   ___GOTO(___L38_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-5)))))
   ___GOTO(___L39_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-5)))
   ___IF(___NOT(___F64EQ(___F64V1,___F64V2)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___STK(-6))
   ___SET_R1(___PRC(92))
   ___SET_R0(___STK(-7))
   ___POLL(15)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___ADJFP(-8)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),91,___G_andmap____0)
___DEF_GLBL(___L38_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___FIXEQ(___R1,___STK(-5)))
   ___GOTO(___L37_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L39_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___STK(-5))
   ___SET_R0(___LBL(13))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(16,1,0,0)
   ___SET_R3(___CLO(___R4,1))
   ___IF(___NOT(___PAIRP(___R3)))
   ___GOTO(___L40_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R3(___CLO(___R4,1))
   ___SET_R2(___CDR(___R3))
   ___IF(___PAIRP(___R2))
   ___GOTO(___L41_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L42_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L40_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___FAL)
   ___IF(___NOT(___PAIRP(___R2)))
   ___GOTO(___L42_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L41_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___CAR(___R2))
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R2)
   ___SET_R0(___LBL(17))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(14))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_GLBL(___L42_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R1(___CLO(___R4,1))
   ___SET_R0(___LBL(18))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(1),___PRM_cadr)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R0(___LBL(18))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L43_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L33_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L44_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L34_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L45_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(19))
   ___JUMPPRM(___SET_NARGS(1),___PRM_caddr)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R0(___LBL(19))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L46_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___R1),___STK(-4)))))
   ___GOTO(___L47_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___R1))
   ___SET_F64(___F64V2,___F64UNBOXI(___STK(-4)))
   ___IF(___F64LE(___F64V1,___F64V2))
   ___GOTO(___L32_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L47_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___STK(-4))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3c__3d_)
___DEF_GLBL(___L48_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L31_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L49_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(1),___PRM_caddr)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L50_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L27_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L51_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L28_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L49_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L52_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___R1)
   ___SET_R1(___FIX(0L))
   ___SET_R0(___LBL(21))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3c__3d_)
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_GLBL(___L53_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L25_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L54_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(1),___PRM_cadr)
___DEF_GLBL(___L55_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(1),___PRM_car)
___DEF_GLBL(___L56_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
   ___SET_R2(___FIX(3L))
   ___SET_R0(___LBL(3))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3d_)
___END_P_SW
___END_P_COD

#undef ___PH_PROC
#define ___PH_PROC ___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_
#undef ___PH_LBL0
#define ___PH_LBL0 123
#undef ___PD_ALL
#define ___PD_ALL ___D_HEAP ___D_FP ___D_R0 ___D_R1 ___D_R2 ___D_R3 ___D_R4 ___D_F64(___F64V1) ___D_F64( \
___F64V2) ___D_F64(___F64V3)
#undef ___PR_ALL
#define ___PR_ALL ___R_HEAP ___R_FP ___R_R0 ___R_R1 ___R_R2 ___R_R3 ___R_R4
#undef ___PW_ALL
#define ___PW_ALL ___W_HEAP ___W_FP ___W_R0 ___W_R1 ___W_R2 ___W_R3 ___W_R4
___BEGIN_P_COD
___BEGIN_P_HLBL
___DEF_P_HLBL_INTRO
___DEF_P_HLBL(___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_P_HLBL(___L22_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___END_P_HLBL
___BEGIN_P_SW
___DEF_SLBL(0,___L0_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(0,1,0,0)
___DEF_GLBL(___L_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_R2(___SYM_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t)
   ___SET_R0(___LBL(1))
   ___ADJFP(8)
   ___JUMPPRM(___SET_NARGS(2),___PRM__23__23_structure_2d_instance_2d_of_3f_)
___DEF_SLBL(1,___L1_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(1L),___FAL,___FAL))
   ___IF(___SYMBOLP(___R1))
   ___GOTO(___L23_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(1L),___FAL,___FAL))
   ___IF(___NOT(___STRINGP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L23_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(2L),___FAL,___FAL))
   ___IF(___NOT(___EXACTINTP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(2L),___FAL,___FAL))
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L41_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___FIXLE(___FIX(0L),___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L24_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(4L),___FAL,___FAL))
   ___SET_STK(-5,___R1)
   ___SET_STK(1,___FAL)
   ___SET_STK(2,___GLO_absent_2d_value)
   ___SET_STK(3,___GLO_absent_2d_value)
   ___SET_STK(4,___GLO_absent_2d_value)
   ___SET_STK(5,___GLO_absent_2d_value)
   ___SET_STK(6,___GLO_absent_2d_value)
   ___SET_R3(___GLO_absent_2d_value)
   ___SET_R2(___GLO_absent_2d_value)
   ___SET_R1(___GLO_absent_2d_value)
   ___ADJFP(6)
   ___POLL(2)
___DEF_SLBL(2,___L2_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R0(___LBL(3))
   ___JUMPGLONOTSAFE(___SET_NARGS(9),103,___G_make_2d_hash_2d_table_____25_)
___DEF_SLBL(3,___L3_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___BOX(___FIX(0L)))
   ___SET_STK(-4,___R1)
   ___SET_STK(-3,___R2)
   ___SET_R1(___STK(-5))
   ___SET_R3(___FIX(128L))
   ___SET_R2(___FIX(131072L))
   ___SET_R0(___LBL(5))
   ___CHECK_HEAP(4,4096)
___DEF_SLBL(4,___L4_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___JUMPGLONOTSAFE(___SET_NARGS(3),98,___G_gerbil_2d_ascent_2f_candidate_2f_datum_23_reasoning_2d_bounded_2d_data_3f_)
___DEF_SLBL(5,___L5_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(6))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_list_3f_)
___DEF_SLBL(6,___L6_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___STK(-5))
   ___SET_R0(___LBL(7))
   ___JUMPPRM(___SET_NARGS(1),___PRM__23__23_length)
___DEF_SLBL(7,___L7_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L40_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___IF(___FIXLE(___R1,___FIX(64L)))
   ___GOTO(___L25_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_SLBL(8,___L8_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L25_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_STK(-2,___ALLOC_CLO(2UL))
   ___BEGIN_SETUP_CLO(2,___STK(-2),14)
   ___ADD_CLO_ELEM(0,___STK(-3))
   ___ADD_CLO_ELEM(1,___STK(-4))
   ___END_SETUP_CLO(2)
   ___SET_R2(___STK(-5))
   ___SET_R1(___STK(-2))
   ___SET_R0(___LBL(10))
   ___CHECK_HEAP(9,4096)
___DEF_SLBL(9,___L9_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___JUMPGLONOTSAFE(___SET_NARGS(2),91,___G_andmap____0)
___DEF_SLBL(10,___L10_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(3L),___FAL,___FAL))
   ___SET_STK(-4,___R1)
   ___SET_R3(___STK(-5))
   ___SET_R2(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(2L),___FAL,___FAL))
   ___SET_R1(___UNCHECKEDSTRUCTUREREF(___STK(-6),___FIX(1L),___FAL,___FAL))
   ___SET_R0(___LBL(11))
   ___JUMPINT(___SET_NARGS(3),___PRC(80),___L_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest)
___DEF_SLBL(11,___L11_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___EQP(___STK(-4),___R1))
   ___GOTO(___L27_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___POSSIBLYEQUALP(___STK(-4),___R1)))
   ___GOTO(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R2(___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___STK(-7))
   ___POLL(12)
___DEF_SLBL(12,___L12_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___ADJFP(-8)
   ___JUMPPRM(___SET_NARGS(2),___PRM_equal_3f_)
___DEF_SLBL(13,___L13_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOTFALSEP(___R1))
   ___GOTO(___L24_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L26_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L27_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___TRU)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_SLBL(14,___L14_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF_NARGS_EQ(1,___NOTHING)
   ___WRONG_NARGS(14,1,0,0)
   ___SET_STK(1,___R0)
   ___SET_STK(2,___R1)
   ___SET_STK(3,___R4)
   ___SET_R0(___CLO(___R4,1))
   ___SET_R1(___UNBOX(___R0))
   ___ADJFP(3)
   ___IF(___NOT(___FIXNUMP(___R1)))
   ___GOTO(___L39_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___IF(___NOT(___FIXSUBP_NOTFALSEP(___R2,___FIX(1024L),___R1)))
   ___SET_R2(___FAL)
   ___GOTO(___L39_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_STK(0,___R4)
   ___GOTO(___L28_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_SLBL(15,___L15_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
   ___ADJFP(-5)
___DEF_GLBL(___L28_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R3(___R2)
   ___SET_R2(___CLO(___STK(0),2))
   ___SET_R1(___STK(-1))
   ___ADJFP(5)
   ___POLL(16)
___DEF_SLBL(16,___L16_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R0(___LBL(17))
   ___JUMPINT(___SET_NARGS(3),___PRC(100),___L_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_)
___DEF_SLBL(17,___L17_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___NOTFALSEP(___R1)))
   ___GOTO(___L38_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R0(___CLO(___STK(-5),1))
   ___SET_R1(___UNBOX(___R0))
   ___SET_STK(-4,___R1)
   ___IF(___NOT(___PAIRP(___STK(-6))))
   ___GOTO(___L29_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R1(___CDR(___STK(-6)))
   ___IF(___PAIRP(___R1))
   ___GOTO(___L30_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_GLBL(___L29_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L30_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___CDR(___R1))
   ___IF(___NOT(___PAIRP(___R1)))
   ___GOTO(___L37_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L31_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___CAR(___R1))
   ___SET_R0(___LBL(18))
   ___JUMPPRM(___SET_NARGS(1),___PRM_length)
___DEF_SLBL(18,___L18_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___FIXNUMSP(___FIXNUMSP2(___FIXNUMSP1(___STK(-4)),___R1))))
   ___GOTO(___L34_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___IF(___FIXADDP_NOTFALSEP(___R2,___STK(-4),___R1))
   ___GOTO(___L33_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_R2(___FAL)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(19))
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_SLBL(19,___L19_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
   ___GOTO(___L33_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_SLBL(20,___L20_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_GLBL(___L32_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
___DEF_GLBL(___L33_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R0(___CLO(___STK(-5),1))
   ___SETBOX(___R0,___R2)
   ___SET_R1(___TRU)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L34_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___IF(___NOT(___IFLONUMSP(___IFLONUMSP2(___IFLONUMSP1(___STK(-4)),___R1))))
   ___GOTO(___L35_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
   ___SET_F64(___F64V1,___F64UNBOXI(___STK(-4)))
   ___SET_F64(___F64V2,___F64UNBOXI(___R1))
   ___SET_F64(___F64V3,___F64ADD(___F64V1,___F64V2))
   ___SET_R1(___F64BOX(___F64V3))
   ___CHECK_HEAP_FLO(21,4096)
___DEF_SLBL(21,___L21_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___GOTO(___L32_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
___DEF_GLBL(___L35_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
   ___SET_R1(___STK(-4))
   ___SET_R0(___LBL(20))
   ___JUMPPRM(___SET_NARGS(2),___PRM__2b_)
___DEF_GLBL(___L36_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___FAL)
   ___IF(___PAIRP(___R1))
   ___GOTO(___L31_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___END_IF
___DEF_GLBL(___L37_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R1(___STK(-6))
   ___SET_R0(___LBL(22))
   ___JUMPPRM(___SET_NARGS(1),___PRM_caddr)
___DEF_SLBL(22,___L22_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R0(___LBL(22))
   ___JUMPPRM(___SET_NARGS(0),___PRM__23__23_dead_2d_end)
___DEF_GLBL(___L38_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___ADJFP(-8)
   ___JUMPRET(___STK(1))
___DEF_GLBL(___L39_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
   ___SET_R1(___FIX(1024L))
   ___SET_R0(___LBL(15))
   ___ADJFP(5)
   ___JUMPPRM(___SET_NARGS(2),___PRM__2d_)
___DEF_GLBL(___L40_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___FIX(64L))
   ___SET_R0(___LBL(8))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3c__3d_)
___DEF_GLBL(___L41_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_)
   ___SET_R2(___R1)
   ___SET_R1(___FIX(0L))
   ___SET_R0(___LBL(13))
   ___JUMPPRM(___SET_NARGS(2),___PRM__3c__3d_)
___END_P_SW
___END_P_COD

___END_M_SW
___END_M_COD

___BEGIN_LBL
 ___DEF_LBL_INTRO(___H_gerbil_2d_ascent____candidate____types_23_,___REF_SYM(24,___S_gerbil_2d_ascent____candidate____types_23_),___REF_FAL,66,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent____candidate____types_23_,0,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETI,7,0,0x3f71L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent____candidate____types_23_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,___REF_SYM(14,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,___REF_SYM(13,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,___REF_SYM(12,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,___REF_SYM(11,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection),___REF_FAL,2,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,___IFD(___RETI,0,0,0x3fL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___REF_SYM(17,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest),___REF_FAL,11,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETI,4,0,0x3f1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETI,4,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,1,3)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETI,1,4,0x3f0L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,___IFD(___RETI,1,4,0x3f0L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,___REF_SYM(22,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_),___REF_FAL,1,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,1,-1)
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,___REF_SYM(21,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_),___REF_FAL,5,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,2,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___REF_SYM(20,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_),___REF_FAL,22,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,3,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETI,8,0,0x3f0fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,1,0,0x1L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,1,1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,___IFD(___RETN,5,0,0xfL))
,___DEF_LBL_INTRO(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___REF_SYM(18,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_),___REF_FAL,23,0)
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,1,-1)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___OFD(___RETI,14,0,0x3f3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETI,8,0,0x3f1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x1fL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x9L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETI,8,8,0x3f00L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x3L))
,___DEF_LBL_PROC(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,1,2)
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETI,8,0,0x3f07L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x7L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0xdL))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0x5L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETI,8,0,0x3f05L))
,___DEF_LBL_RET(___H_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,___IFD(___RETN,5,0,0xdL))
___END_LBL

___BEGIN_OFD
 ___DEF_OFD(___RETI,14,0)
               ___GCMAP1(0x3f3f07L)
___END_OFD

___BEGIN_MOD_PRM
___DEF_MOD_PRM(75,___G_gerbil_2d_ascent____candidate____types_23_,1)
___DEF_MOD_PRM(38,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,68)
___DEF_MOD_PRM(37,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,71)
___DEF_MOD_PRM(36,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,74)
___DEF_MOD_PRM(35,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,77)
___DEF_MOD_PRM(59,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,80)
___DEF_MOD_PRM(73,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,92)
___DEF_MOD_PRM(72,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,94)
___DEF_MOD_PRM(71,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,100)
___DEF_MOD_PRM(68,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,123)
___END_MOD_PRM

___BEGIN_MOD_C_INIT
___END_MOD_C_INIT

___BEGIN_MOD_GLO
___DEF_MOD_GLO(75,___G_gerbil_2d_ascent____candidate____types_23_,1)
___DEF_MOD_GLO(38,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,68)
___DEF_MOD_GLO(37,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,71)
___DEF_MOD_GLO(36,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,74)
___DEF_MOD_GLO(35,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,77)
___DEF_MOD_GLO(59,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,80)
___DEF_MOD_GLO(73,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,92)
___DEF_MOD_GLO(72,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,94)
___DEF_MOD_GLO(71,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,100)
___DEF_MOD_GLO(68,___G_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,123)
___END_MOD_GLO

___BEGIN_MOD_SYM_KEY
___DEF_MOD_SYM(0,___S_bytes,"bytes")
___DEF_MOD_SYM(1,___S_candidate_2d_rejection,"candidate-rejection")
___DEF_MOD_SYM(2,___S_code,"code")
___DEF_MOD_SYM(3,___S_detail,"detail")
___DEF_MOD_SYM(4,___S_diagnostic,"diagnostic")
___DEF_MOD_SYM(5,___S_digest,"digest")
___DEF_MOD_SYM(6,___S_facts,"facts")
___DEF_MOD_SYM(7,___S_fxmax,"fxmax")
___DEF_MOD_SYM(8,___S_generation,"generation")
___DEF_MOD_SYM(9,___S_gerbil_2d_ascent_2f_candidate_2f_types,"gerbil-ascent/candidate/types")

___DEF_MOD_SYM(10,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_candidate_2d_rejection_3a__3a_t,"gerbil-ascent/candidate/types#candidate-rejection::t")

___DEF_MOD_SYM(11,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_candidate_2d_rejection,"gerbil-ascent/candidate/types#make-candidate-rejection")

___DEF_MOD_SYM(12,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_candidate,"gerbil-ascent/candidate/types#make-reasoning-candidate")

___DEF_MOD_SYM(13,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_diagnostic,"gerbil-ascent/candidate/types#make-reasoning-diagnostic")

___DEF_MOD_SYM(14,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_make_2d_reasoning_2d_snapshot,"gerbil-ascent/candidate/types#make-reasoning-snapshot")

___DEF_MOD_SYM(15,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_candidate_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-candidate::t")

___DEF_MOD_SYM(16,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_diagnostic_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-diagnostic::t")

___DEF_MOD_SYM(17,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_content_2d_digest,"gerbil-ascent/candidate/types#reasoning-snapshot-content-digest")

___DEF_MOD_SYM(18,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_2d_valid_3f_,"gerbil-ascent/candidate/types#reasoning-snapshot-valid?")

___DEF_MOD_SYM(19,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_reasoning_2d_snapshot_3a__3a_t,"gerbil-ascent/candidate/types#reasoning-snapshot::t")

___DEF_MOD_SYM(20,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_relation_2d_valid_3f_,"gerbil-ascent/candidate/types#snapshot-relation-valid?")

___DEF_MOD_SYM(21,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_row_2d_valid_3f_,"gerbil-ascent/candidate/types#snapshot-row-valid?")

___DEF_MOD_SYM(22,___S_gerbil_2d_ascent_2f_candidate_2f_types_23_snapshot_2d_scalar_3f_,"gerbil-ascent/candidate/types#snapshot-scalar?")

___DEF_MOD_SYM(23,___S_gerbil_2d_ascent____candidate____types,"gerbil-ascent__candidate__types")

___DEF_MOD_SYM(24,___S_gerbil_2d_ascent____candidate____types_23_,"gerbil-ascent__candidate__types#")

___DEF_MOD_SYM(25,___S_identity,"identity")
___DEF_MOD_SYM(26,___S_in_2d_range_2d_inclusive_3f_,"in-range-inclusive?")
___DEF_MOD_SYM(27,___S_in_2d_range_3f_,"in-range?")
___DEF_MOD_SYM(28,___S_limits,"limits")
___DEF_MOD_SYM(29,___S_path,"path")
___DEF_MOD_SYM(30,___S_query,"query")
___DEF_MOD_SYM(31,___S_reasoning_2d_candidate,"reasoning-candidate")
___DEF_MOD_SYM(32,___S_reasoning_2d_diagnostic,"reasoning-diagnostic")
___DEF_MOD_SYM(33,___S_reasoning_2d_snapshot,"reasoning-snapshot")
___DEF_MOD_SYM(34,___S_reasoning_2d_snapshot_2d_v1,"reasoning-snapshot-v1")
___DEF_MOD_SYM(35,___S_relations,"relations")
___DEF_MOD_SYM(36,___S_rules,"rules")
___DEF_MOD_SYM(37,___S_start,"start")
___DEF_MOD_SYM(38,___S_u8vector_2d_length,"u8vector-length")
___DEF_MOD_KEY(0,___K_context,"context")
___DEF_MOD_KEY(1,___K_contract,"contract")
___DEF_MOD_KEY(2,___K_struct,"struct")
___DEF_MOD_KEY(3,___K_value,"value")
___END_MOD_SYM_KEY

#endif
