(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/types[1]#_g35190_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35192_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35194_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35196_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35197_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35198_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35199_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35201_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35202_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35203_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35204_|
    (##structure
     gx#syntax-quote::t
     'reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35206_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35207_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35208_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35209_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35211_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35212_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35213_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35214_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-snapshot-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35216_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35218_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35220_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35222_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35223_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35224_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35226_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35227_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35228_|
    (##structure
     gx#syntax-quote::t
     'reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35230_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35231_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35232_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35234_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-code-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35235_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-path-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35236_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-diagnostic-detail-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35238_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35240_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-candidate
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35242_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35244_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35245_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35246_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35247_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35248_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35250_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35251_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35252_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35253_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35254_|
    (##structure
     gx#syntax-quote::t
     'reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35256_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35257_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35258_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35259_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35260_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35262_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-relations-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35263_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-facts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35264_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35265_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35266_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-candidate-limits-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35268_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35270_|
    (##structure
     gx#syntax-quote::t
     'make-candidate-rejection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35272_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35274_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35276_|
    (##structure
     gx#syntax-quote::t
     'candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35278_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/types[1]#_g35280_|
    (##structure
     gx#syntax-quote::t
     '&candidate-rejection-diagnostic-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-snapshot|
      (let ((__obj35151
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35151
           'gerbil-ascent/candidate/types#reasoning-snapshot::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35151
           'reasoning-snapshot
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35151
           '(identity generation digest relations)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35151
           '(identity generation digest relations)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '#f '13 '#f '#f))
        (let ((__tmp35189 |gerbil-ascent/candidate/types[1]#_g35190_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35189 '4 '#f '#f))
        (let ((__tmp35191 |gerbil-ascent/candidate/types[1]#_g35192_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35191 '14 '#f '#f))
        (let ((__tmp35193 |gerbil-ascent/candidate/types[1]#_g35194_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35193 '15 '#f '#f))
        (let ((__tmp35195
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g35196_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g35197_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g35198_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g35199_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35195 '16 '#f '#f))
        (let ((__tmp35200
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g35201_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g35202_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g35203_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g35204_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35200 '17 '#f '#f))
        (let ((__tmp35205
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g35206_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g35207_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g35208_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g35209_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35205 '18 '#f '#f))
        (let ((__tmp35210
               (cons (cons 'identity
                           |gerbil-ascent/candidate/types[1]#_g35211_|)
                     (cons (cons 'generation
                                 |gerbil-ascent/candidate/types[1]#_g35212_|)
                           (cons (cons 'digest
                                       |gerbil-ascent/candidate/types[1]#_g35213_|)
                                 (cons (cons 'relations
                                             |gerbil-ascent/candidate/types[1]#_g35214_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 __tmp35210 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35151 '() '21 '#f '#f))
        __obj35151))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-diagnostic|
      (let ((__obj35152
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35152
           'gerbil-ascent/candidate/types#reasoning-diagnostic::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35152
           'reasoning-diagnostic
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35152
           '(code path detail)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35152
           '(code path detail)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '#f '13 '#f '#f))
        (let ((__tmp35215 |gerbil-ascent/candidate/types[1]#_g35216_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35215 '4 '#f '#f))
        (let ((__tmp35217 |gerbil-ascent/candidate/types[1]#_g35218_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35217 '14 '#f '#f))
        (let ((__tmp35219 |gerbil-ascent/candidate/types[1]#_g35220_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35219 '15 '#f '#f))
        (let ((__tmp35221
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g35222_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g35223_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g35224_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35221 '16 '#f '#f))
        (let ((__tmp35225
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g35226_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g35227_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g35228_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35225 '17 '#f '#f))
        (let ((__tmp35229
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g35230_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g35231_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g35232_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35229 '18 '#f '#f))
        (let ((__tmp35233
               (cons (cons 'code |gerbil-ascent/candidate/types[1]#_g35234_|)
                     (cons (cons 'path
                                 |gerbil-ascent/candidate/types[1]#_g35235_|)
                           (cons (cons 'detail
                                       |gerbil-ascent/candidate/types[1]#_g35236_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 __tmp35233 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35152 '() '21 '#f '#f))
        __obj35152))
    (define |gerbil-ascent/candidate/types[:0:]#reasoning-candidate|
      (let ((__obj35153
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35153
           'gerbil-ascent/candidate/types#reasoning-candidate::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35153
           'reasoning-candidate
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35153
           '(relations facts rules query limits)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35153
           '(relations facts rules query limits)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '#f '13 '#f '#f))
        (let ((__tmp35237 |gerbil-ascent/candidate/types[1]#_g35238_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35237 '4 '#f '#f))
        (let ((__tmp35239 |gerbil-ascent/candidate/types[1]#_g35240_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35239 '14 '#f '#f))
        (let ((__tmp35241 |gerbil-ascent/candidate/types[1]#_g35242_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35241 '15 '#f '#f))
        (let ((__tmp35243
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g35244_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g35245_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g35246_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g35247_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g35248_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35243 '16 '#f '#f))
        (let ((__tmp35249
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g35250_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g35251_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g35252_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g35253_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g35254_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35249 '17 '#f '#f))
        (let ((__tmp35255
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g35256_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g35257_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g35258_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g35259_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g35260_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35255 '18 '#f '#f))
        (let ((__tmp35261
               (cons (cons 'relations
                           |gerbil-ascent/candidate/types[1]#_g35262_|)
                     (cons (cons 'facts
                                 |gerbil-ascent/candidate/types[1]#_g35263_|)
                           (cons (cons 'rules
                                       |gerbil-ascent/candidate/types[1]#_g35264_|)
                                 (cons (cons 'query
                                             |gerbil-ascent/candidate/types[1]#_g35265_|)
                                       (cons (cons 'limits
                                                   |gerbil-ascent/candidate/types[1]#_g35266_|)
                                             '())))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 __tmp35261 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35153 '() '21 '#f '#f))
        __obj35153))
    (define |gerbil-ascent/candidate/types[:0:]#candidate-rejection|
      (let ((__obj35154
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35154
           'gerbil-ascent/candidate/types#candidate-rejection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35154
           'candidate-rejection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '(diagnostic) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '(diagnostic) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '#f '13 '#f '#f))
        (let ((__tmp35267 |gerbil-ascent/candidate/types[1]#_g35268_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35267 '4 '#f '#f))
        (let ((__tmp35269 |gerbil-ascent/candidate/types[1]#_g35270_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35269 '14 '#f '#f))
        (let ((__tmp35271 |gerbil-ascent/candidate/types[1]#_g35272_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35271 '15 '#f '#f))
        (let ((__tmp35273
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g35274_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35273 '16 '#f '#f))
        (let ((__tmp35275
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g35276_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35275 '17 '#f '#f))
        (let ((__tmp35277
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g35278_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35277 '18 '#f '#f))
        (let ((__tmp35279
               (cons (cons 'diagnostic
                           |gerbil-ascent/candidate/types[1]#_g35280_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 __tmp35279 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35154 '() '21 '#f '#f))
        __obj35154))))
