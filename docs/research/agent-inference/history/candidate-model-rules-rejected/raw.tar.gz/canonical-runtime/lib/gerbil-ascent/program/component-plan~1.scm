(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-plan[1]#_g35664_|
    (##structure
     gx#syntax-quote::t
     'positive-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35666_|
    (##structure
     gx#syntax-quote::t
     'make-positive-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35668_|
    (##structure
     gx#syntax-quote::t
     'positive-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35670_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35671_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35672_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35673_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35675_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35676_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35677_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35678_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35680_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35681_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35682_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35683_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35685_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35686_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35687_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35688_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[:0:]#positive-component|
    (let ((__obj35526
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35526
         'gerbil-ascent/program/component-plan#positive-component::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 'positive-component '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35526
         '(id members rules predecessors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35526
         '(id members rules predecessors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '#f '13 '#f '#f))
      (let ((__tmp35663 |gerbil-ascent/program/component-plan[1]#_g35664_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35663 '4 '#f '#f))
      (let ((__tmp35665 |gerbil-ascent/program/component-plan[1]#_g35666_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35665 '14 '#f '#f))
      (let ((__tmp35667 |gerbil-ascent/program/component-plan[1]#_g35668_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35667 '15 '#f '#f))
      (let ((__tmp35669
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35670_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35671_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35672_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35673_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35669 '16 '#f '#f))
      (let ((__tmp35674
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35675_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35676_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35677_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35678_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35674 '17 '#f '#f))
      (let ((__tmp35679
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35680_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35681_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35682_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35683_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35679 '18 '#f '#f))
      (let ((__tmp35684
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35685_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35686_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35687_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35688_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 __tmp35684 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35526 '() '21 '#f '#f))
      __obj35526)))
