prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-class
   gerbil-ascent/program/reuse#native-reuse::t
   (@class gerbil-ascent/program/reuse#native-reuse::t
           ()
           (object::t t::t)
           (result affected reader publication source-only)
           (result affected reader publication source-only)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/reuse#native-reuse::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse?
   (@predicate gerbil-ascent/program/reuse#native-reuse::t))
  (declare-type
   gerbil-ascent/program/reuse#make-native-reuse
   (@constructor gerbil-ascent/program/reuse#native-reuse::t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-result
   (@accessor gerbil-ascent/program/reuse#native-reuse::t result #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-affected
   (@accessor gerbil-ascent/program/reuse#native-reuse::t affected #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-reader
   (@accessor gerbil-ascent/program/reuse#native-reuse::t reader #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-publication
   (@accessor gerbil-ascent/program/reuse#native-reuse::t publication #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-source-only
   (@accessor gerbil-ascent/program/reuse#native-reuse::t source-only #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-result-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t result #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-affected-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t affected #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-reader-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t reader #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-publication-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t publication #t))
  (declare-type
   gerbil-ascent/program/reuse#native-reuse-source-only-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t source-only #t))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-result
   (@accessor gerbil-ascent/program/reuse#native-reuse::t result #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-affected
   (@accessor gerbil-ascent/program/reuse#native-reuse::t affected #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-reader
   (@accessor gerbil-ascent/program/reuse#native-reuse::t reader #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-publication
   (@accessor gerbil-ascent/program/reuse#native-reuse::t publication #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-source-only
   (@accessor gerbil-ascent/program/reuse#native-reuse::t source-only #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-result-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t result #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-affected-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t affected #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-reader-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t reader #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-publication-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t publication #f))
  (declare-type
   gerbil-ascent/program/reuse#&native-reuse-source-only-set!
   (@mutator gerbil-ascent/program/reuse#native-reuse::t source-only #f))
  (declare-type
   gerbil-ascent/program/reuse#source-only-relations
   (@lambda 2
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
   (@lambda 6
            #f
            signature:
            (return:
             (nullable gerbil-ascent/program/reuse#native-reuse::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
   (@lambda 4
            #f
            signature:
            (return:
             (nullable gerbil-ascent/program/reuse#native-reuse::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
   (@lambda 5
            #f
            signature:
            (return:
             (nullable gerbil-ascent/program/reuse#native-reuse::t)
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse
   (@case-lambda
    (4
     gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__0
     signature:
     (return:
      (nullable gerbil-ascent/program/reuse#native-reuse::t)
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/reuse))
    (5
     gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__1
     signature:
     (return:
      (nullable gerbil-ascent/program/reuse#native-reuse::t)
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/reuse))
    (6
     gerbil-ascent/program/reuse#gerbil-ascent-prepare-native-reuse__%
     signature:
     (return:
      (nullable gerbil-ascent/program/reuse#native-reuse::t)
      effect:
      #f
      arguments:
      #f
      unchecked:
      #f
      origin:
      gerbil-ascent/program/reuse))))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-activate-rules
   (@lambda 1
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-activate-selected-rules
   (@lambda 2
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-reuse-active-rules
   (@lambda 2
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse)))
  (declare-class
   gerbil-ascent/program/reuse#closure-seed-state::t
   (@class gerbil-ascent/program/reuse#closure-seed-state::t
           ()
           (object::t t::t)
           (all seen delta all-size delta-size lattice-rows)
           (all seen delta all-size delta-size lattice-rows)
           #f
           #t
           #f
           #f
           #f
           #f))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state::t
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/program/reuse#closure-seed-state::t)
    'class::t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state?
   (@predicate gerbil-ascent/program/reuse#closure-seed-state::t))
  (declare-type
   gerbil-ascent/program/reuse#make-closure-seed-state
   (@constructor gerbil-ascent/program/reuse#closure-seed-state::t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-all
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t all #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-seen
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t seen #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-delta
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t delta #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-all-size
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t all-size #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-delta-size
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t delta-size #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-lattice-rows
   (@accessor
    gerbil-ascent/program/reuse#closure-seed-state::t
    lattice-rows
    #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-all-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t all #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-seen-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t seen #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-delta-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t delta #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-all-size-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t all-size #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-delta-size-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t delta-size #t))
  (declare-type
   gerbil-ascent/program/reuse#closure-seed-state-lattice-rows-set!
   (@mutator
    gerbil-ascent/program/reuse#closure-seed-state::t
    lattice-rows
    #t))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-all
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t all #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-seen
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t seen #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-delta
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t delta #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-all-size
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t all-size #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-delta-size
   (@accessor gerbil-ascent/program/reuse#closure-seed-state::t delta-size #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows
   (@accessor
    gerbil-ascent/program/reuse#closure-seed-state::t
    lattice-rows
    #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-all-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t all #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-seen-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t seen #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-delta-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t delta #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-all-size-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t all-size #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-delta-size-set!
   (@mutator gerbil-ascent/program/reuse#closure-seed-state::t delta-size #f))
  (declare-type
   gerbil-ascent/program/reuse#&closure-seed-state-lattice-rows-set!
   (@mutator
    gerbil-ascent/program/reuse#closure-seed-state::t
    lattice-rows
    #f))
  (declare-type
   gerbil-ascent/program/reuse#gerbil-ascent-seed-native-reuse!
   (@lambda 6
            #f
            signature:
            (return:
             number::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/reuse))))
