(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "gerbil-ascent/candidate/grounding-plan")
    (load-module "gerbil-ascent/candidate/funs"))
  (load-module "gerbil-ascent/candidate/finite-plan~0"))
