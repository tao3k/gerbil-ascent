(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/table/funs::timestamp 1791687557)
  (begin
    (define gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot
      (lambda (_%rows9353%_)
        (map (lambda (_%row9355%_) (map values _%row9355%_)) _%rows9353%_)))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-row-snapshot/arity
      (lambda (_%rows9306%_ _%width9307%_)
        (letrec ((_%wrong-arity9309%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"ASCENT index provider returned wrong row arity"
                             _%width9307%_))))
                 (_%copy9310%_
                  (lambda (_%row9316%_ _%left9317%_)
                    (if (zero? _%left9317%_)
                        (if (null? _%row9316%_) '() (_%wrong-arity9309%_))
                        (let* ((_%$%row93189326%_ _%row9316%_)
                               (_%$%else93209334%_
                                (lambda () (_%wrong-arity9309%_)))
                               (_%$%K93229340%_
                                (lambda (_%rest9337%_ _%value9338%_)
                                  (cons _%value9338%_
                                        (_%copy9310%_
                                         _%rest9337%_
                                         (- _%left9317%_ '1))))))
                          (if (pair? _%$%row93189326%_)
                              (let ((_%$%hd93239343%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%row93189326%_)))
                                    (_%$%tl93249345%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%row93189326%_))))
                                (let* ((_%value9348%_ _%$%hd93239343%_)
                                       (_%rest9350%_ _%$%tl93249345%_))
                                  (_%$%K93229340%_
                                   _%rest9350%_
                                   _%value9348%_)))
                              (_%wrong-arity9309%_)))))))
          (map (lambda (_%$%g93119313%_)
                 (_%copy9310%_ _%$%g93119313%_ _%width9307%_))
               _%rows9306%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-build
      (lambda (_%rows9301%_ _%columns9302%_)
        (let ((_%index9304%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value))))
          (gerbil-ascent/table/funs#gerbil-ascent-index-extend!
           _%index9304%_
           _%rows9301%_
           _%columns9302%_)
          (gerbil-ascent/table/funs#gerbil-ascent-index-order!
           _%index9304%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-order!
      (lambda (_%index9240%_)
        (let* ((_%proc9271%_
                (lambda (_%key9242%_ _%rows9243%_)
                  (if (pair? (cdr _%rows9243%_))
                      (let* ((_%h9245%_ _%index9240%_)
                             (_%key9248%_ _%key9242%_)
                             (_%value9251%_ (reverse! _%rows9243%_))
                             (_%h9255%_
                              (let ()
                                (declare (not safe))
                                (cast HashTable::interface _%h9245%_)))
                             (_%h9257%_ _%h9255%_))
                        (declare (not safe))
                        (__hash-put! _%h9257%_ _%key9248%_ _%value9251%_))
                      '#!void)))
               (_%h9274%_ _%index9240%_)
               (_%proc9279%_ _%proc9271%_)
               (_%h9289%_
                (let ()
                  (declare (not safe))
                  (cast HashTable::interface _%h9274%_)))
               (_%h9291%_ _%h9289%_))
          (declare (not safe))
          (__hash-for-each _%proc9279%_ _%h9291%_))
        _%index9240%_))
    (define gerbil-ascent/table/funs#forward-column-steps
      (lambda (_%columns9190%_)
        (let _%step9192%_ ((_%remaining9194%_ _%columns9190%_)
                           (_%position9195%_ '0))
          (let* ((_%$%remaining91969205%_ _%remaining9194%_)
                 (_%$%E91999209%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%remaining91969205%_
                             '([])
                             '([column . rest])))
                    '#!void)))
            (let ((_%$%K92039237%_ (lambda () '()))
                  (_%$%K92009221%_
                   (lambda (_%rest9213%_ _%column9214%_)
                     (if (>= _%column9214%_ _%position9195%_)
                         (let ((_%$%steps92159217%_
                                (_%step9192%_ _%rest9213%_ _%column9214%_)))
                           (if _%$%steps92159217%_
                               (let ((_%steps9219%_ _%$%steps92159217%_))
                                 (cons (inexact->exact
                                        (- _%column9214%_ _%position9195%_))
                                       _%steps9219%_))
                               '#f))
                         '#f))))
              (let ((_%$%try-match91989233%_
                     (lambda ()
                       (if (pair? _%$%remaining91969205%_)
                           (let ((_%$%tl92029226%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%remaining91969205%_)))
                                 (_%$%hd92019224%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%remaining91969205%_))))
                             (let ((_%column9229%_ _%$%hd92019224%_)
                                   (_%rest9231%_ _%$%tl92029226%_))
                               (_%$%K92009221%_ _%rest9231%_ _%column9229%_)))
                           (_%$%E91999209%_)))))
                (if (null? _%$%remaining91969205%_)
                    (_%$%K92039237%_)
                    (_%$%try-match91989233%_))))))))
    (define gerbil-ascent/table/funs#nondecreasing-columns?
      (lambda (_%columns9145%_)
        (let _%ordered9147%_ ((_%remaining9149%_ _%columns9145%_)
                              (_%position9150%_ '0))
          (let* ((_%$%remaining91519160%_ _%remaining9149%_)
                 (_%$%E91549164%_
                  (lambda ()
                    (let ()
                      (declare (not safe))
                      (error '"No clause matching"
                             _%$%remaining91519160%_
                             '([])
                             '([column . rest])))
                    '#!void)))
            (let ((_%$%K91589187%_ (lambda () '#t))
                  (_%$%K91559171%_
                   (lambda (_%rest9168%_ _%column9169%_)
                     (if (>= _%column9169%_ _%position9150%_)
                         (_%ordered9147%_ _%rest9168%_ _%column9169%_)
                         '#f))))
              (let ((_%$%try-match91539183%_
                     (lambda ()
                       (if (pair? _%$%remaining91519160%_)
                           (let ((_%$%tl91579176%_
                                  (let ()
                                    (declare (not safe))
                                    (##cdr _%$%remaining91519160%_)))
                                 (_%$%hd91569174%_
                                  (let ()
                                    (declare (not safe))
                                    (##car _%$%remaining91519160%_))))
                             (let ((_%column9179%_ _%$%hd91569174%_)
                                   (_%rest9181%_ _%$%tl91579176%_))
                               (_%$%K91559171%_ _%rest9181%_ _%column9179%_)))
                           (_%$%E91549164%_)))))
                (if (null? _%$%remaining91519160%_)
                    (_%$%K91589187%_)
                    (_%$%try-match91539183%_))))))))
    (define gerbil-ascent/table/funs#stepped-key
      (lambda (_%row9102%_ _%steps9103%_)
        (let* ((_%$%steps91049113%_ _%steps9103%_)
               (_%$%E91079117%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%steps91049113%_
                           '([])
                           '([distance . rest])))
                  '#!void)))
          (let ((_%$%K91119142%_ (lambda () '()))
                (_%$%K91089126%_
                 (lambda (_%rest9121%_ _%distance9122%_)
                   (let ((_%selected9124%_
                          (list-tail _%row9102%_ _%distance9122%_)))
                     (cons (car _%selected9124%_)
                           (gerbil-ascent/table/funs#stepped-key
                            _%selected9124%_
                            _%rest9121%_))))))
            (let ((_%$%try-match91069138%_
                   (lambda ()
                     (if (pair? _%$%steps91049113%_)
                         (let ((_%$%tl91109131%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%steps91049113%_)))
                               (_%$%hd91099129%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%steps91049113%_))))
                           (let ((_%distance9134%_ _%$%hd91099129%_)
                                 (_%rest9136%_ _%$%tl91109131%_))
                             (_%$%K91089126%_ _%rest9136%_ _%distance9134%_)))
                         (_%$%E91079117%_)))))
              (if (null? _%$%steps91049113%_)
                  (_%$%K91119142%_)
                  (_%$%try-match91069138%_)))))))
    (define gerbil-ascent/table/funs#column-key
      (lambda (_%row9058%_ _%columns9059%_ _%position9060%_)
        (let* ((_%$%columns90619070%_ _%columns9059%_)
               (_%$%E90649074%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%columns90619070%_
                           '([])
                           '([column . rest])))
                  '#!void)))
          (let ((_%$%K90689099%_ (lambda () '()))
                (_%$%K90659083%_
                 (lambda (_%rest9078%_ _%column9079%_)
                   (let ((_%selected9081%_
                          (list-tail
                           _%row9058%_
                           (inexact->exact
                            (- _%column9079%_ _%position9060%_)))))
                     (cons (car _%selected9081%_)
                           (gerbil-ascent/table/funs#column-key
                            _%selected9081%_
                            _%rest9078%_
                            _%column9079%_))))))
            (let ((_%$%try-match90639095%_
                   (lambda ()
                     (if (pair? _%$%columns90619070%_)
                         (let ((_%$%tl90679088%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%columns90619070%_)))
                               (_%$%hd90669086%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%columns90619070%_))))
                           (let ((_%column9091%_ _%$%hd90669086%_)
                                 (_%rest9093%_ _%$%tl90679088%_))
                             (_%$%K90659083%_ _%rest9093%_ _%column9091%_)))
                         (_%$%E90649074%_)))))
              (if (null? _%$%columns90619070%_)
                  (_%$%K90689099%_)
                  (_%$%try-match90639095%_)))))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-key
      (lambda (_%row9053%_ _%columns9054%_)
        (if (gerbil-ascent/table/funs#nondecreasing-columns? _%columns9054%_)
            (gerbil-ascent/table/funs#column-key
             _%row9053%_
             _%columns9054%_
             '0)
            (map (lambda (_%column9056%_)
                   (list-ref _%row9053%_ _%column9056%_))
                 _%columns9054%_))))
    (define gerbil-ascent/table/funs#gerbil-ascent-index-extend!
      (lambda (_%index8927%_ _%new-rows8928%_ _%columns8929%_)
        (let ((_%$e8931%_
               (gerbil-ascent/table/funs#forward-column-steps
                _%columns8929%_)))
          (if _%$e8931%_
              (let* ((_%target8936%_ _%index8927%_)
                     (_%row-slot8939%_ (vector '#f))
                     (_%prepend-row8948%_
                      (lambda (_%bucket8942%_)
                        (cons (vector-ref _%row-slot8939%_ '0)
                              (let ((_%$e8945%_ _%bucket8942%_))
                                (if _%$e8945%_ _%$e8945%_ '()))))))
                (for-each
                 (lambda (_%row8952%_)
                   (let ((_%selected8954%_
                          (gerbil-ascent/table/funs#stepped-key
                           _%row8952%_
                           _%$e8931%_)))
                     (vector-set! _%row-slot8939%_ '0 _%row8952%_)
                     (let* ((_%h8957%_ _%target8936%_)
                            (_%key8960%_ _%selected8954%_)
                            (_%update8963%_ _%prepend-row8948%_)
                            (_%default8966%_ '#f)
                            (_%h8970%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h8957%_)))
                            (_%h8972%_ _%h8970%_))
                       (declare (not safe))
                       (__hash-update!__%
                        _%h8972%_
                        _%key8960%_
                        _%update8963%_
                        _%default8966%_))))
                 _%new-rows8928%_)
                _%target8936%_)
              (let* ((_%target8995%_ _%index8927%_)
                     (_%row-slot8998%_ (vector '#f))
                     (_%prepend-row9007%_
                      (lambda (_%bucket9001%_)
                        (cons (vector-ref _%row-slot8998%_ '0)
                              (let ((_%$e9004%_ _%bucket9001%_))
                                (if _%$e9004%_ _%$e9004%_ '()))))))
                (for-each
                 (lambda (_%row9011%_)
                   (let ((_%selected9015%_
                          (map (lambda (_%column9013%_)
                                 (list-ref _%row9011%_ _%column9013%_))
                               _%columns8929%_)))
                     (vector-set! _%row-slot8998%_ '0 _%row9011%_)
                     (let* ((_%h9018%_ _%target8995%_)
                            (_%key9021%_ _%selected9015%_)
                            (_%update9024%_ _%prepend-row9007%_)
                            (_%default9027%_ '#f)
                            (_%h9031%_
                             (let ()
                               (declare (not safe))
                               (cast HashTable::interface _%h9018%_)))
                            (_%h9033%_ _%h9031%_))
                       (declare (not safe))
                       (__hash-update!__%
                        _%h9033%_
                        _%key9021%_
                        _%update9024%_
                        _%default9027%_))))
                 _%new-rows8928%_)
                _%target8995%_)))))))
