(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/feedback[1]#_g39426_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39428_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-feedback
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39430_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39432_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39433_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39434_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39435_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39437_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39438_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39439_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39440_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39442_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39443_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39444_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39445_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39447_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39448_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39449_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39450_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[:0:]#reasoning-feedback|
    (let ((__obj39416
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39416
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 'reasoning-feedback '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39416
         '(status reason missing extra)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39416
         '(status reason missing extra)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '#f '13 '#f '#f))
      (let ((__tmp39425 |gerbil-ascent/candidate/feedback[1]#_g39426_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39425 '4 '#f '#f))
      (let ((__tmp39427 |gerbil-ascent/candidate/feedback[1]#_g39428_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39427 '14 '#f '#f))
      (let ((__tmp39429 |gerbil-ascent/candidate/feedback[1]#_g39430_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39429 '15 '#f '#f))
      (let ((__tmp39431
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39432_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39433_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39434_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39435_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39431 '16 '#f '#f))
      (let ((__tmp39436
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39437_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39438_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39439_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39440_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39436 '17 '#f '#f))
      (let ((__tmp39441
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39442_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39443_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39444_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39445_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39441 '18 '#f '#f))
      (let ((__tmp39446
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39447_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39448_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39449_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39450_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 __tmp39446 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39416 '() '21 '#f '#f))
      __obj39416)))
