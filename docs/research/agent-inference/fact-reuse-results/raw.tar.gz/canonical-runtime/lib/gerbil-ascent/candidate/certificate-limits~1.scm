(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34567_|
    (##structure
     gx#syntax-quote::t
     'certificate-material::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34569_|
    (##structure
     gx#syntax-quote::t
     'make-certificate-material
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34571_|
    (##structure
     gx#syntax-quote::t
     'certificate-material?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34573_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34574_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34576_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34577_|
    (##structure
     gx#syntax-quote::t
     'certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34579_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34580_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34582_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[1]#_g34583_|
    (##structure
     gx#syntax-quote::t
     '&certificate-material-cells-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/certificate-limits[:0:]#certificate-material|
    (let ((__obj34449
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34449
         'gerbil-ascent/candidate/certificate-limits#certificate-material::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj34449
         'certificate-material
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '(rows cells) '6 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '(rows cells) '8 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '#f '13 '#f '#f))
      (let ((__tmp34566
             |gerbil-ascent/candidate/certificate-limits[1]#_g34567_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34566 '4 '#f '#f))
      (let ((__tmp34568
             |gerbil-ascent/candidate/certificate-limits[1]#_g34569_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34568 '14 '#f '#f))
      (let ((__tmp34570
             |gerbil-ascent/candidate/certificate-limits[1]#_g34571_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34570 '15 '#f '#f))
      (let ((__tmp34572
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34573_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34574_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34572 '16 '#f '#f))
      (let ((__tmp34575
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34576_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34577_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34575 '17 '#f '#f))
      (let ((__tmp34578
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34579_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34580_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34578 '18 '#f '#f))
      (let ((__tmp34581
             (cons (cons 'rows
                         |gerbil-ascent/candidate/certificate-limits[1]#_g34582_|)
                   (cons (cons 'cells
                               |gerbil-ascent/candidate/certificate-limits[1]#_g34583_|)
                         '()))))
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 __tmp34581 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj34449 '() '21 '#f '#f))
      __obj34449)))
