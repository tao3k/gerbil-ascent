(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/view-state[1]#_g36046_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36048_|
    (##structure
     gx#syntax-quote::t
     'make-staged-frontier-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36050_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36052_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36054_|
    (##structure
     gx#syntax-quote::t
     'staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36056_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36058_|
    (##structure
     gx#syntax-quote::t
     '&staged-frontier-count-count-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36060_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36062_|
    (##structure
     gx#syntax-quote::t
     'make-view-routing-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36064_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36066_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36067_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36068_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36069_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36070_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36071_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36072_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36073_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36075_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36076_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36077_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36078_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36079_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36080_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36081_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36082_|
    (##structure
     gx#syntax-quote::t
     'view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36084_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36085_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36086_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36087_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36088_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36089_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36090_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36091_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36093_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-storage-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36094_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-all-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36095_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-delta-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36096_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-versions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36097_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-names-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36098_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36099_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-journals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36100_|
    (##structure
     gx#syntax-quote::t
     '&view-routing-state-routing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36102_|
    (##structure
     gx#syntax-quote::t
     'view-event::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36104_|
    (##structure
     gx#syntax-quote::t
     'make-view-event
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36106_|
    (##structure
     gx#syntax-quote::t
     'view-event?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36108_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36109_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36110_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36112_|
    (##structure
     gx#syntax-quote::t
     'view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36113_|
    (##structure
     gx#syntax-quote::t
     'view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36114_|
    (##structure
     gx#syntax-quote::t
     'view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36116_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36117_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36118_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36120_|
    (##structure
     gx#syntax-quote::t
     '&view-event-kind-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36121_|
    (##structure
     gx#syntax-quote::t
     '&view-event-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/view-state[1]#_g36122_|
    (##structure
     gx#syntax-quote::t
     '&view-event-eqrel?-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/view-state[:0:]#staged-frontier-count|
      (let ((__obj35764
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35764
           'gerbil-ascent/program/view-state#staged-frontier-count::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35764
           'staged-frontier-count
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '(count) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '(count) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '#f '13 '#f '#f))
        (let ((__tmp36045 |gerbil-ascent/program/view-state[1]#_g36046_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36045 '4 '#f '#f))
        (let ((__tmp36047 |gerbil-ascent/program/view-state[1]#_g36048_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36047 '14 '#f '#f))
        (let ((__tmp36049 |gerbil-ascent/program/view-state[1]#_g36050_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36049 '15 '#f '#f))
        (let ((__tmp36051
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36052_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36051 '16 '#f '#f))
        (let ((__tmp36053
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36054_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36053 '17 '#f '#f))
        (let ((__tmp36055
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36056_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36055 '18 '#f '#f))
        (let ((__tmp36057
               (cons (cons 'count
                           |gerbil-ascent/program/view-state[1]#_g36058_|)
                     '())))
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 __tmp36057 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35764 '() '21 '#f '#f))
        __obj35764))
    (define |gerbil-ascent/program/view-state[:0:]#view-routing-state|
      (let ((__obj35765
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35765
           'gerbil-ascent/program/view-state#view-routing-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35765
           'view-routing-state
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35765
           '(storage all delta versions names generation journals routing)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35765
           '(storage all delta versions names generation journals routing)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '#f '13 '#f '#f))
        (let ((__tmp36059 |gerbil-ascent/program/view-state[1]#_g36060_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36059 '4 '#f '#f))
        (let ((__tmp36061 |gerbil-ascent/program/view-state[1]#_g36062_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36061 '14 '#f '#f))
        (let ((__tmp36063 |gerbil-ascent/program/view-state[1]#_g36064_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36063 '15 '#f '#f))
        (let ((__tmp36065
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36066_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36067_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36068_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36069_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36070_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36071_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36072_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36073_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36065 '16 '#f '#f))
        (let ((__tmp36074
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36075_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36076_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36077_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36078_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36079_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36080_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36081_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36082_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36074 '17 '#f '#f))
        (let ((__tmp36083
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36084_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36085_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36086_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36087_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36088_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36089_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36090_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36091_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36083 '18 '#f '#f))
        (let ((__tmp36092
               (cons (cons 'storage
                           |gerbil-ascent/program/view-state[1]#_g36093_|)
                     (cons (cons 'all
                                 |gerbil-ascent/program/view-state[1]#_g36094_|)
                           (cons (cons 'delta
                                       |gerbil-ascent/program/view-state[1]#_g36095_|)
                                 (cons (cons 'versions
                                             |gerbil-ascent/program/view-state[1]#_g36096_|)
                                       (cons (cons 'names
                                                   |gerbil-ascent/program/view-state[1]#_g36097_|)
                                             (cons (cons 'generation
                                                         |gerbil-ascent/program/view-state[1]#_g36098_|)
                                                   (cons (cons 'journals
                                                               |gerbil-ascent/program/view-state[1]#_g36099_|)
                                                         (cons (cons 'routing
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             |gerbil-ascent/program/view-state[1]#_g36100_|)
                       '()))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 __tmp36092 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35765 '() '21 '#f '#f))
        __obj35765))
    (define |gerbil-ascent/program/view-state[:0:]#view-event|
      (let ((__obj35766
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35766
           'gerbil-ascent/program/view-state#view-event::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 'view-event '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35766
           '(kind rows eqrel?)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35766
           '(kind rows eqrel?)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '#f '13 '#f '#f))
        (let ((__tmp36101 |gerbil-ascent/program/view-state[1]#_g36102_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36101 '4 '#f '#f))
        (let ((__tmp36103 |gerbil-ascent/program/view-state[1]#_g36104_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36103 '14 '#f '#f))
        (let ((__tmp36105 |gerbil-ascent/program/view-state[1]#_g36106_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36105 '15 '#f '#f))
        (let ((__tmp36107
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36108_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36109_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36110_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36107 '16 '#f '#f))
        (let ((__tmp36111
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36112_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36113_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36114_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36111 '17 '#f '#f))
        (let ((__tmp36115
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36116_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36117_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36118_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36115 '18 '#f '#f))
        (let ((__tmp36119
               (cons (cons 'kind
                           |gerbil-ascent/program/view-state[1]#_g36120_|)
                     (cons (cons 'rows
                                 |gerbil-ascent/program/view-state[1]#_g36121_|)
                           (cons (cons 'eqrel?
                                       |gerbil-ascent/program/view-state[1]#_g36122_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 __tmp36119 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35766 '() '21 '#f '#f))
        __obj35766))))
