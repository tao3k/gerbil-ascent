prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-type
   gerbil-ascent/candidate/stratified-producer#+maximum-nodes+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/stratified-producer#+maximum-nodes+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
   (@lambda 8
            #f
            signature:
            (return:
             values::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/stratified-producer))))
