(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/stratified-producer::timestamp 1791689712)
  (begin
    (define gerbil-ascent/candidate/stratified-producer#+maximum-nodes+ '4096)
    (define gerbil-ascent/candidate/stratified-producer#candidate-produce-stratified-proof
      (lambda (_%snapshot28800%_
               _%spec28801%_
               _%candidate-digest28802%_
               _%native-status28803%_
               _%native-rows28804%_
               _%certificate28805%_
               _%finite-work-budget28806%_
               _%proof-work-budget28807%_)
        (if (and (exact-integer? _%proof-work-budget28807%_)
                 (> _%proof-work-budget28807%_ '0))
            '#!void
            (let ()
              (declare (not safe))
              (error '"stratified producer needs positive work budget"
                     _%proof-work-budget28807%_)))
        (let ((_g38021_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/candidate/finite-evidence#candidate-verified-finite-closure
                  _%snapshot28800%_
                  _%spec28801%_
                  _%candidate-digest28802%_
                  _%native-status28803%_
                  _%native-rows28804%_
                  _%certificate28805%_
                  _%finite-work-budget28806%_))))
          (begin
            (let ((_g38022_
                   (let ()
                     (declare (not safe))
                     (if (##values? _g38021_) (##values-length _g38021_) 1))))
              (if (not (let () (declare (not safe)) (##fx= _g38022_ 2)))
                  (error "Context expects 2 values" _g38022_)))
            (let ((_%finite-verdict28809%_
                   (let () (declare (not safe)) (##values-ref _g38021_ 0)))
                  (_%closure28810%_
                   (let () (declare (not safe)) (##values-ref _g38021_ 1))))
              (if (eq? _%finite-verdict28809%_ 'valid)
                  (if (null? _%native-rows28804%_)
                      (values 'unsupported '())
                      (let* ((_%schema28812%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-schema-of
                                 _%snapshot28800%_
                                 _%spec28801%_)))
                             (_%rules28814%_
                              (##structure-ref
                               _%spec28801%_
                               '3
                               gerbil-ascent/candidate/types#reasoning-candidate::t
                               '#f))
                             (_%levels28816%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/funs#candidate-strata-of
                                 _%schema28812%_
                                 _%rules28814%_)))
                             (_%model28818%_
                              (let ()
                                (declare (not safe))
                                (gerbil-ascent/candidate/closure-index#make-closure-index__0
                                 _%closure28810%_)))
                             (_%nodes28820%_
                              (let ()
                                (declare (not safe))
                                (##make-vector
                                 gerbil-ascent/candidate/stratified-producer#+maximum-nodes+
                                 '#f)))
                             (_%by-row28822%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table__%
                                 '#f
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value
                                 absent-value)))
                             (_%by-relation28824%_
                              (let ()
                                (declare (not safe))
                                (make-hash-table-eq)))
                             (_%node-count28826%_ '0)
                             (_%steps28828%_ '0)
                             (_%bounded?28830%_ '#f)
                             (_%added?28832%_ '#f))
                        (letrec ((_%step!28835%_
                                  (lambda ()
                                    (set! _%steps28828%_ (+ _%steps28828%_ '1))
                                    (if (> _%steps28828%_
                                           _%proof-work-budget28807%_)
                                        (set! _%bounded?28830%_ '#t)
                                        '#!void)
                                    (not _%bounded?28830%_)))
                                 (_%rows28836%_
                                  (lambda (_%name29051%_)
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/closure-index#closure-index-rows
                                       _%model28818%_
                                       _%name29051%_))))
                                 (_%level28837%_
                                  (lambda (_%name29049%_)
                                    (cdr (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/funs#candidate-required-entry
                                            _%name29049%_
                                            _%levels28816%_)))))
                                 (_%node-id28838%_
                                  (lambda (_%name29046%_ _%row29047%_)
                                    (let ((__tmp38023
                                           (cons _%name29046%_ _%row29047%_)))
                                      (declare (not safe))
                                      (__hash-get
                                       _%by-row28822%_
                                       __tmp38023))))
                                 (_%add-node!28839%_
                                  (lambda (_%kind28968%_
                                           _%name28969%_
                                           _%row28970%_
                                           _%label28971%_
                                           _%witnesses28972%_)
                                    (if (if _%bounded?28830%_
                                            '#f
                                            (if (_%node-id28838%_
                                                 _%name28969%_
                                                 _%row28970%_)
                                                '#f
                                                (let ()
                                                  (declare (not safe))
                                                  (gerbil-ascent/candidate/closure-index#closure-index-member?
                                                   _%model28818%_
                                                   _%name28969%_
                                                   _%row28970%_))))
                                        (if (>= _%node-count28826%_
                                                gerbil-ascent/candidate/stratified-producer#+maximum-nodes+)
                                            (set! _%bounded?28830%_ '#t)
                                            (let ((_%id28974%_
                                                   _%node-count28826%_)
                                                  (_%copy28975%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/datum#candidate-copy-pairs
                                                      _%row28970%_))))
                                              (vector-set!
                                               _%nodes28820%_
                                               _%id28974%_
                                               (list _%kind28968%_
                                                     _%name28969%_
                                                     _%copy28975%_
                                                     _%label28971%_
                                                     _%witnesses28972%_))
                                              (let ((__tmp38024
                                                     (cons _%name28969%_
                                                           _%copy28975%_)))
                                                (declare (not safe))
                                                (__hash-put!
                                                 _%by-row28822%_
                                                 __tmp38024
                                                 _%id28974%_))
                                              (let* ((_%table28977%_
                                                      _%by-relation28824%_)
                                                     (_%key28980%_
                                                      _%name28969%_)
                                                     (_%default28984%_
                                                      (lambda () '()))
                                                     (_%function28989%_
                                                      (lambda (_%ids28987%_)
                                                        (cons _%id28974%_
                                                              _%ids28987%_)))
                                                     (_%table28993%_
                                                      _%table28977%_)
                                                     (_%table28995%_
                                                      _%table28993%_)
                                                     (_%default29026%_
                                                      _%default28984%_)
                                                     (_%function29036%_
                                                      _%function28989%_))
                                                (declare (not safe))
                                                (std/hash/misc#__hash-ensure-modify!
                                                 _%table28995%_
                                                 _%key28980%_
                                                 _%default29026%_
                                                 _%function29036%_))
                                              (set! _%node-count28826%_
                                                    (+ _%node-count28826%_ '1))
                                              (set! _%added?28832%_ '#t)))
                                        '#!void)))
                                 (_%reduction28840%_
                                  (lambda (_%clause28938%_
                                           _%bindings28939%_
                                           _%head28940%_)
                                    (let* ((_%output28942%_
                                            (cadr _%clause28938%_))
                                           (_%operator28944%_
                                            (caddr _%clause28938%_))
                                           (_%atom28946%_
                                            (cadddr _%clause28938%_))
                                           (_%name28948%_ (car _%atom28946%_))
                                           (_%ids28950%_ '())
                                           (_%values28952%_ '())
                                           (_%ready?28954%_
                                            (> (_%level28837%_ _%head28940%_)
                                               (_%level28837%_
                                                _%name28948%_))))
                                      (if _%ready?28954%_
                                          (for-each
                                           (lambda (_%row28957%_)
                                             (if (_%step!28835%_)
                                                 (let ((_%next28959%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                           _%atom28946%_
                                                           _%row28957%_
                                                           _%bindings28939%_))))
                                                   (if _%next28959%_
                                                       (let ((_%id28961%_
                                                              (_%node-id28838%_
                                                               _%name28948%_
                                                               _%row28957%_)))
                                                         (if _%id28961%_
                                                             (begin
                                                               (set! _%ids28950%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                             (cons _%id28961%_ _%ids28950%_))
                       (if (eq? (car _%operator28944%_) 'count)
                           '#!void
                           (set! _%values28952%_
                                 (cons (cdr (let ((__tmp38025
                                                   (cadr _%operator28944%_)))
                                              (declare (not safe))
                                              (gerbil-ascent/candidate/funs#candidate-required-entry
                                               __tmp38025
                                               _%next28959%_)))
                                       _%values28952%_))))
                     (set! _%ready?28954%_ '#f)))
               '#!void))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 '#!void))
                                           (_%rows28836%_ _%name28948%_))
                                          '#!void)
                                      (if _%bounded?28830%_
                                          '#f
                                          (if _%ready?28954%_
                                              (let ((_%value28966%_
                                                     (let ((_%$e28963%_
                                                            (car _%operator28944%_)))
                                                       (if (eq? 'count
                                                                _%$e28963%_)
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##length
                                                              _%ids28950%_))
                                                           (if (eq? 'sum
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%$e28963%_)
                       (if (let ()
                             (declare (not safe))
                             (andmap__0 exact-integer? _%values28952%_))
                           (apply + '0 _%values28952%_)
                           '#f)
                       (if (eq? 'min _%$e28963%_)
                           (if (pair? _%values28952%_)
                               (if (let ()
                                     (declare (not safe))
                                     (andmap__0
                                      exact-integer?
                                      _%values28952%_))
                                   (let ()
                                     (declare (not safe))
                                     (##apply min _%values28952%_))
                                   '#f)
                               '#f)
                           (if (eq? 'max _%$e28963%_)
                               (if (pair? _%values28952%_)
                                   (if (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          exact-integer?
                                          _%values28952%_))
                                       (let ()
                                         (declare (not safe))
                                         (##apply max _%values28952%_))
                                       '#f)
                                   '#f)
                               '#f)))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (if _%value28966%_
                                                    (cons (cons (cons _%output28942%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              _%value28966%_)
                        _%bindings28939%_)
                  (list 'reduce
                        (let ()
                          (declare (not safe))
                          (##reverse _%ids28950%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    '#f))
                                              '#f)))))
                                 (_%evaluate-rule28841%_
                                  (lambda (_%rule28886%_)
                                    (let* ((_%head28888%_
                                            (vector-ref _%rule28886%_ '0))
                                           (_%head-name28890%_
                                            (car _%head28888%_))
                                           (_%body28892%_
                                            (vector-ref _%rule28886%_ '1))
                                           (_%label28894%_
                                            (vector-ref _%rule28886%_ '2)))
                                      (letrec ((_%walk28897%_
                                                (lambda (_%clauses28899%_
                                                         _%bindings28900%_
                                                         _%evidence28901%_)
                                                  (if _%bounded?28830%_
                                                      '#!void
                                                      (if (null? _%clauses28899%_)
                                                          (let ((_%row28905%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (map (lambda (_%term28903%_)
                                (if (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/candidate/program#candidate-variable?
                                       _%term28903%_))
                                    (cdr (let ()
                                           (declare (not safe))
                                           (gerbil-ascent/candidate/funs#candidate-required-entry
                                            _%term28903%_
                                            _%bindings28900%_)))
                                    _%term28903%_))
                              (cdr _%head28888%_))))
                    (if (_%step!28835%_)
                        (_%add-node!28839%_
                         'rule
                         _%head-name28890%_
                         _%row28905%_
                         _%label28894%_
                         (reverse _%evidence28901%_))
                        '#!void))
                  (let* ((_%clause28907%_ (car _%clauses28899%_))
                         (_%$e28909%_ (car _%clause28907%_)))
                    (if (or (eq? 'where _%$e28909%_)
                            (eq? 'compute _%$e28909%_))
                        (if (_%step!28835%_)
                            (let ((_%next28915%_
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/candidate/funs#candidate-fixed-clause
                                      _%clause28907%_
                                      _%bindings28900%_))))
                              (if _%next28915%_
                                  (_%walk28897%_
                                   (cdr _%clauses28899%_)
                                   _%next28915%_
                                   (cons '(fixed) _%evidence28901%_))
                                  '#!void))
                            '#!void)
                        (if (eq? 'not _%$e28909%_)
                            (let* ((_%atom28917%_ (cadr _%clause28907%_))
                                   (_%name28919%_ (car _%atom28917%_))
                                   (_%absent?28921%_
                                    (> (_%level28837%_ _%head-name28890%_)
                                       (_%level28837%_ _%name28919%_))))
                              (if _%absent?28921%_
                                  (for-each
                                   (lambda (_%row28924%_)
                                     (if (_%step!28835%_)
                                         (if (let ()
                                               (declare (not safe))
                                               (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                _%atom28917%_
                                                _%row28924%_
                                                _%bindings28900%_))
                                             (set! _%absent?28921%_ '#f)
                                             '#!void)
                                         '#!void))
                                   (_%rows28836%_ _%name28919%_))
                                  '#!void)
                              (if (if _%bounded?28830%_ '#f _%absent?28921%_)
                                  (_%walk28897%_
                                   (cdr _%clauses28899%_)
                                   _%bindings28900%_
                                   (cons '(not) _%evidence28901%_))
                                  '#!void))
                            (if (eq? 'reduce _%$e28909%_)
                                (let ((_%result28926%_
                                       (_%reduction28840%_
                                        _%clause28907%_
                                        _%bindings28900%_
                                        _%head-name28890%_)))
                                  (if _%result28926%_
                                      (_%walk28897%_
                                       (cdr _%clauses28899%_)
                                       (let ()
                                         (declare (not safe))
                                         (##car _%result28926%_))
                                       (cons (let ()
                                               (declare (not safe))
                                               (##cdr _%result28926%_))
                                             _%evidence28901%_))
                                      '#!void))
                                (for-each
                                 (lambda (_%id28928%_)
                                   (if (_%step!28835%_)
                                       (let* ((_%node28930%_
                                               (vector-ref
                                                _%nodes28820%_
                                                _%id28928%_))
                                              (_%next28932%_
                                               (let ((__tmp38026
                                                      (caddr _%node28930%_)))
                                                 (declare (not safe))
                                                 (gerbil-ascent/candidate/funs#candidate-bind-atom
                                                  _%clause28907%_
                                                  __tmp38026
                                                  _%bindings28900%_))))
                                         (if _%next28932%_
                                             (_%walk28897%_
                                              (cdr _%clauses28899%_)
                                              _%next28932%_
                                              (cons (list 'atom _%id28928%_)
                                                    _%evidence28901%_))
                                             '#!void))
                                       '#!void))
                                 (let ((_%$e28935%_
                                        (let ((__tmp38027
                                               (car _%clause28907%_)))
                                          (declare (not safe))
                                          (__hash-get
                                           _%by-relation28824%_
                                           __tmp38027))))
                                   (if _%$e28935%_ _%$e28935%_ '()))))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (_%walk28897%_
                                         _%body28892%_
                                         '()
                                         '()))))))
                          (if _%levels28816%_
                              (begin
                                (for-each
                                 (lambda (_%entry28843%_)
                                   (let ((_%name28845%_ (car _%entry28843%_))
                                         (_%position28846%_ '0))
                                     (for-each
                                      (lambda (_%row28848%_)
                                        (set! _%position28846%_
                                              (+ _%position28846%_ '1))
                                        (if (_%step!28835%_)
                                            (_%add-node!28839%_
                                             'source
                                             _%name28845%_
                                             _%row28848%_
                                             _%position28846%_
                                             '())
                                            '#!void))
                                      (caddr _%entry28843%_))))
                                 (##structure-ref
                                  _%snapshot28800%_
                                  '4
                                  gerbil-ascent/candidate/types#reasoning-snapshot::t
                                  '#f))
                                (for-each
                                 (lambda (_%fact28850%_)
                                   (if (_%step!28835%_)
                                       (_%add-node!28839%_
                                        'candidate
                                        (vector-ref _%fact28850%_ '0)
                                        (vector-ref _%fact28850%_ '1)
                                        (vector-ref _%fact28850%_ '2)
                                        '())
                                       '#!void))
                                 (##structure-ref
                                  _%spec28801%_
                                  '2
                                  gerbil-ascent/candidate/types#reasoning-candidate::t
                                  '#f))
                                (let _%stratum28852%_ ((_%current28854%_ '0)
                                                       (_%maximum28855%_
                                                        (let ((__tmp38028
                                                               (map cdr
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            _%levels28816%_)))
                  (declare (not safe))
                  (##apply max __tmp38028))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                  (if (and (<= _%current28854%_
                                               _%maximum28855%_)
                                           (not _%bounded?28830%_))
                                      (begin
                                        (let _%repeat28857%_ ()
                                          (set! _%added?28832%_ '#f)
                                          (for-each
                                           (lambda (_%rule28860%_)
                                             (if (if _%bounded?28830%_
                                                     '#f
                                                     (= (_%level28837%_
                                                         (car (vector-ref
                                                               _%rule28860%_
                                                               '0)))
                                                        _%current28854%_))
                                                 (_%evaluate-rule28841%_
                                                  _%rule28860%_)
                                                 '#!void))
                                           _%rules28814%_)
                                          (if (and _%added?28832%_
                                                   (not _%bounded?28830%_))
                                              (_%repeat28857%_)
                                              '#!void))
                                        (_%stratum28852%_
                                         (+ _%current28854%_ '1)
                                         _%maximum28855%_))
                                      '#!void))
                                (if _%bounded?28830%_
                                    (values 'bounded '())
                                    (let* ((_%query28862%_
                                            (vector-ref
                                             (##structure-ref
                                              _%spec28801%_
                                              '4
                                              gerbil-ascent/candidate/types#reasoning-candidate::t
                                              '#f)
                                             '0))
                                           (_%roots28866%_
                                            (map (lambda (_%row28864%_)
                                                   (_%node-id28838%_
                                                    (car _%query28862%_)
                                                    _%row28864%_))
                                                 _%native-rows28804%_)))
                                      (if (let ((__tmp38029
                                                 (lambda (_%id28869%_)
                                                   (and _%id28869%_ '#t))))
                                            (declare (not safe))
                                            (andmap__0
                                             __tmp38029
                                             _%roots28866%_))
                                          (let* ((_%ordered28876%_
                                                  (let _%loop28871%_ ((_%index28873%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (- _%node-count28826%_ '1))
                              (_%result28874%_ '()))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (if (< _%index28873%_ '0)
                                                        _%result28874%_
                                                        (_%loop28871%_
                                                         (- _%index28873%_ '1)
                                                         (cons (vector-ref
                                                                _%nodes28820%_
                                                                _%index28873%_)
                                                               _%result28874%_)))))
                                                 (_%proof28878%_
                                                  (list 'stratified-proof-v1
                                                        _%ordered28876%_
                                                        _%roots28866%_))
                                                 (_%verdict28880%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
                                                     _%snapshot28800%_
                                                     _%spec28801%_
                                                     _%candidate-digest28802%_
                                                     _%native-status28803%_
                                                     _%native-rows28804%_
                                                     _%certificate28805%_
                                                     _%finite-work-budget28806%_
                                                     _%proof28878%_
                                                     _%proof-work-budget28807%_)))
                                                 (_%$e28883%_
                                                  _%verdict28880%_))
                                            (if (eq? 'valid _%$e28883%_)
                                                (values 'complete
                                                        _%proof28878%_)
                                                (if (eq? 'bounded _%$e28883%_)
                                                    (values 'bounded '())
                                                    (values 'invalid '()))))
                                          (values 'unsupported '())))))
                              (values 'invalid '())))))
                  (values _%finite-verdict28809%_ '())))))))))
