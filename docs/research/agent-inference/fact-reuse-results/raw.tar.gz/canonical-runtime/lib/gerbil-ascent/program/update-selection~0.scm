(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/update-selection::timestamp 1791691019)
  (begin
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
      (lambda (_%candidate13771%_ _%source-cut13772%_)
        (letrec ((_%pure-terms?13774%_
                  (lambda (_%terms13842%_)
                    (let ((__tmp37206
                           (lambda (_%term13844%_)
                             (let ((_%kind13846%_
                                    (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%term13844%_
                                       'kind))))
                               (if (let ()
                                     (declare (not safe))
                                     (##memq _%kind13846%_
                                             '(variable wildcard literal)))
                                   (let ((_%$e13848%_
                                          (not (eq? _%kind13846%_ 'literal))))
                                     (if _%$e13848%_
                                         _%$e13848%_
                                         (let ((__tmp37207
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%term13844%_
                                                   'value))))
                                           (declare (not safe))
                                           (gerbil-ascent/program/scheme-checked#relational-scalar?
                                            __tmp37207))))
                                   '#f)))))
                      (declare (not safe))
                      (andmap__0 __tmp37206 _%terms13842%_))))
                 (_%trusted-field?13775%_
                  (lambda (_%predicate13837%_)
                    (let ((_%$e13839%_
                           (eq? _%predicate13837%_
                                gerbil-ascent/program/scheme-checked#relational-scalar?)))
                      (if _%$e13839%_
                          _%$e13839%_
                          (eq? _%predicate13837%_ exact-integer?)))))
                 (_%scalar-source?13776%_
                  (lambda (_%relation13794%_ _%index13795%_)
                    (let ((_%predicates13797%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation13794%_
                              'field-predicates))))
                      (if (let ()
                            (declare (not safe))
                            (andmap__0
                             _%trusted-field?13775%_
                             _%predicates13797%_))
                          (let ((_%$e13799%_ (pair? _%predicates13797%_)))
                            (if _%$e13799%_
                                _%$e13799%_
                                (let ((_%$e13832%_
                                       (if _%source-cut13772%_
                                           (let* ((_%snapshot13802%_
                                                   _%source-cut13772%_)
                                                  (_%candidate13805%_
                                                   _%candidate13771%_)
                                                  (_%index13808%_
                                                   _%index13795%_)
                                                  (_%rows13811%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (clan/poo/object#.ref
                                                      _%relation13794%_
                                                      'rows)))
                                                  (_%snapshot13815%_
                                                   _%snapshot13802%_))
                                             (declare (not safe))
                                             (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-snapshot-scalar?
                                              _%snapshot13815%_
                                              _%candidate13805%_
                                              _%index13808%_
                                              _%rows13811%_))
                                           '#f)))
                                  (if _%$e13832%_
                                      _%$e13832%_
                                      (let ((__tmp37209
                                             (lambda (_%row13835%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (andmap__0
                                                  gerbil-ascent/program/scheme-checked#relational-scalar?
                                                  _%row13835%_))))
                                            (__tmp37208
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%relation13794%_
                                                'rows))))
                                        (declare (not safe))
                                        (andmap__0 __tmp37209 __tmp37208))))))
                          '#f))))
                 (_%stable-clause?13777%_
                  (lambda (_%clause13786%_)
                    (let ((_%$e13788%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%clause13786%_
                              'ascent-clause-kind))))
                      (if (or (eq? 'atom _%$e13788%_)
                              (eq? 'negation _%$e13788%_))
                          (_%pure-terms?13774%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%clause13786%_ 'terms)))
                          (if (eq? 'aggregate _%$e13788%_)
                              (if (_%pure-terms?13774%_
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%clause13786%_
                                      'terms)))
                                  (if (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%clause13786%_
                                         'output-pattern))
                                      '#f
                                      (let ((__tmp37210
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause13786%_
                                                'aggregate))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                         __tmp37210)))
                                  '#f)
                              (if (eq? 'guard _%$e13788%_)
                                  (let ((__tmp37211
                                         (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%clause13786%_
                                            'predicate))))
                                    (declare (not safe))
                                    (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                     __tmp37211))
                                  (if (eq? 'binding _%$e13788%_)
                                      (let ((__tmp37212
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%clause13786%_
                                                'compute))))
                                        (declare (not safe))
                                        (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                         __tmp37212))
                                      '#f))))))))
          (if (let ((__tmp37216
                     (lambda (_%relation13779%_ _%index13780%_)
                       (and (_%scalar-source?13776%_
                             _%relation13779%_
                             _%index13780%_)
                            (let ((__tmp37217
                                   (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%relation13779%_
                                      'index-provider))))
                              (declare (not safe))
                              (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                               __tmp37217))
                            (if (eq? (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%relation13779%_
                                        'storage-kind))
                                     'lattice)
                                (let ((__tmp37218
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation13779%_
                                          'join))))
                                  (declare (not safe))
                                  (gerbil-ascent/program/scheme-checked#relational-stable-procedure?
                                   __tmp37218))
                                (let ((__tmp37219
                                       (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%relation13779%_
                                          'storage-provider))))
                                  (declare (not safe))
                                  (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                   __tmp37219))))))
                    (__tmp37215
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%candidate13771%_ 'relations)))
                    (__tmp37213
                     (let ((__tmp37214
                            (length (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%candidate13771%_
                                       'relations)))))
                       (declare (not safe))
                       (##iota __tmp37214))))
                (declare (not safe))
                (andmap__1 __tmp37216 __tmp37215 __tmp37213))
              (let ((__tmp37221
                     (lambda (_%rule13782%_)
                       (if (let ((__tmp37223
                                  (lambda (_%head13784%_)
                                    (_%pure-terms?13774%_
                                     (let ()
                                       (declare (not safe))
                                       (clan/poo/object#.ref
                                        _%head13784%_
                                        'terms)))))
                                 (__tmp37222
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%rule13782%_
                                     'heads))))
                             (declare (not safe))
                             (andmap__0 __tmp37223 __tmp37222))
                           (let ((__tmp37224
                                  (let ()
                                    (declare (not safe))
                                    (clan/poo/object#.ref
                                     _%rule13782%_
                                     'body))))
                             (declare (not safe))
                             (andmap__0 _%stable-clause?13777%_ __tmp37224))
                           '#f)))
                    (__tmp37220
                     (let ()
                       (declare (not safe))
                       (clan/poo/object#.ref _%candidate13771%_ 'rules))))
                (declare (not safe))
                (andmap__0 __tmp37221 __tmp37220))
              '#f))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
      (lambda (_%candidate13854%_)
        (let ((_%source-cut13856%_ '#f))
          (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
           _%candidate13854%_
           _%source-cut13856%_))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?
      (lambda _g37225_
        (let ((_g37226_ (let () (declare (not safe)) (##length _g37225_))))
          (cond ((let () (declare (not safe)) (##fx= _g37226_ 1))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
                        _g37225_))
                ((let () (declare (not safe)) (##fx= _g37226_ 2))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
                        _g37225_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?
                  _g37225_))))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
      (lambda (_%previous13693%_
               _%candidate13694%_
               _%analysis13695%_
               _%source-cut13696%_)
        (let* ((_%relations13698%_
                (let ()
                  (declare (not safe))
                  (clan/poo/object#.ref _%candidate13694%_ 'relations)))
               (_%old-relations13700%_ (vector->list _%previous13693%_))
               (_%count13702%_ (length _%relations13698%_))
               (_%affected13704%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count13702%_ '#f)))
               (_%eligible?13707%_
                (if (= _%count13702%_
                       (let ()
                         (declare (not safe))
                         (##length _%old-relations13700%_)))
                    (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__%
                     _%candidate13694%_
                     _%source-cut13696%_)
                    '#f)))
          (if _%eligible?13707%_
              (begin
                (let ((__tmp37228
                       (lambda (_%old13709%_ _%new13710%_ _%index13711%_)
                         (let ((_%rows13713%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref _%new13710%_ 'rows))))
                           (if (or (and _%source-cut13696%_
                                        (let* ((_%snapshot13715%_
                                                _%source-cut13696%_)
                                               (_%candidate13718%_
                                                _%candidate13694%_)
                                               (_%index13721%_ _%index13711%_)
                                               (_%log13724%_ _%old13709%_)
                                               (_%rows13727%_ _%rows13713%_)
                                               (_%snapshot13731%_
                                                _%snapshot13715%_))
                                          (declare (not safe))
                                          (gerbil-ascent/program/source-snapshot#__gerbil-ascent-source-log-snapshot-equal?
                                           _%snapshot13731%_
                                           _%candidate13718%_
                                           _%index13721%_
                                           _%log13724%_
                                           _%rows13727%_)))
                                   (let ((__tmp37230 (car _%old13709%_))
                                         (__tmp37229 (cdr _%old13709%_)))
                                     (declare (not safe))
                                     (gerbil-ascent/program/source-log#gerbil-ascent-source-log-equal?
                                      __tmp37230
                                      __tmp37229
                                      _%rows13713%_)))
                               '#!void
                               (vector-set!
                                _%affected13704%_
                                _%index13711%_
                                '#t)))))
                      (__tmp37227
                       (let () (declare (not safe)) (##iota _%count13702%_))))
                  (declare (not safe))
                  (##for-each
                   __tmp37228
                   _%old-relations13700%_
                   _%relations13698%_
                   __tmp37227))
                (let ((__tmp37231 (vector-ref _%analysis13695%_ '6)))
                  (declare (not safe))
                  (gerbil-ascent/core/dependency-graph#gerbil-ascent-graph-close!
                   __tmp37231
                   _%affected13704%_))
                _%affected13704%_)
              '#f))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__0
      (lambda (_%previous13759%_ _%candidate13760%_ _%analysis13761%_)
        (let ((_%source-cut13763%_ '#f))
          (gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
           _%previous13759%_
           _%candidate13760%_
           _%analysis13761%_
           _%source-cut13763%_))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-selection
      (lambda _g37232_
        (let ((_g37233_ (let () (declare (not safe)) (##length _g37232_))))
          (cond ((let () (declare (not safe)) (##fx= _g37233_ 3))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__0
                        _g37232_))
                ((let () (declare (not safe)) (##fx= _g37233_ 4))
                 (apply gerbil-ascent/program/update-selection#gerbil-ascent-update-selection__%
                        _g37232_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/update-selection#gerbil-ascent-update-selection
                  _g37232_))))))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
      (lambda (_%full-active-by-stratum13166%_ _%affected13167%_)
        (vector-map
         (lambda (_%rules13169%_)
           (let ((__tmp37234
                  (lambda (_%rule13171%_)
                    (let ((_%heads13430%_
                           (let ((_%bitmap13173%_ _%affected13167%_)
                                 (_%source13175%_
                                  (vector-ref _%rule13171%_ '0)))
                             (letrec ((_%keep?13178%_
                                       (lambda (_%head13428%_)
                                         (vector-ref
                                          _%bitmap13173%_
                                          (vector-ref _%head13428%_ '0)))))
                               (let _%scan13181%_ ((_%remaining13184%_
                                                    _%source13175%_))
                                 (let* ((_%$%remaining1318613195%_
                                         _%remaining13184%_)
                                        (_%$%E1318913199%_
                                         (lambda ()
                                           (let ()
                                             (declare (not safe))
                                             (error '"No clause matching"
                                                    _%$%remaining1318613195%_
                                                    '([])
                                                    '([head . rest])))
                                           '#!void)))
                                   (let ((_%$%K1319313425%_
                                          (lambda () _%source13175%_))
                                         (_%$%K1319013409%_
                                          (lambda (_%rest13203%_ _%head13205%_)
                                            (if (_%keep?13178%_ _%head13205%_)
                                                (_%scan13181%_ _%rest13203%_)
                                                (if (eq? _%remaining13184%_
                                                         _%source13175%_)
                                                    (filter _%keep?13178%_
                                                            _%rest13203%_)
                                                    (let* ((_%head13210%_
                                                            (cons '#f '()))
                                                           (_%tail13213%_
                                                            _%head13210%_))
                                                      (let _%prefix13395%_ ((_%pending13398%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                     _%source13175%_))
                (if (eq? _%pending13398%_ _%remaining13184%_)
                    '#!void
                    (begin
                      (let ((_%new-tail13401%_
                             (cons (car _%pending13398%_) '())))
                        (let ()
                          (declare (not safe))
                          (##set-cdr! _%tail13213%_ _%new-tail13401%_))
                        (set! _%tail13213%_ _%new-tail13401%_))
                      (_%prefix13395%_ (cdr _%pending13398%_)))))
              (for-each
               (lambda (_%head13404%_)
                 (if (_%keep?13178%_ _%head13404%_)
                     (let ((_%new-tail13406%_ (cons _%head13404%_ '())))
                       (let ()
                         (declare (not safe))
                         (##set-cdr! _%tail13213%_ _%new-tail13406%_))
                       (set! _%tail13213%_ _%new-tail13406%_))
                     '#!void))
               _%rest13203%_)
              (let () (declare (not safe)) (##cdr _%head13210%_))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (let ((_%$%try-match1318813421%_
                                            (lambda ()
                                              (if (pair? _%$%remaining1318613195%_)
                                                  (let ((_%$%tl1319213414%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##cdr _%$%remaining1318613195%_)))
                                                        (_%$%hd1319113412%_
                                                         (let ()
                                                           (declare (not safe))
                                                           (##car _%$%remaining1318613195%_))))
                                                    (let ((_%head13417%_
                                                           _%$%hd1319113412%_)
                                                          (_%rest13419%_
                                                           _%$%tl1319213414%_))
                                                      (_%$%K1319013409%_
                                                       _%rest13419%_
                                                       _%head13417%_)))
                                                  (_%$%E1318913199%_)))))
                                       (if (null? _%$%remaining1318613195%_)
                                           (_%$%K1319313425%_)
                                           (_%$%try-match1318813421%_))))))))))
                      (if (pair? _%heads13430%_)
                          (if (eq? _%heads13430%_
                                   (vector-ref _%rule13171%_ '0))
                              _%rule13171%_
                              (let* ((_%full-plan13432%_
                                      (vector-ref _%rule13171%_ '5))
                                     (_%plan13689%_
                                      (if _%full-plan13432%_
                                          (let ((__tmp37235
                                                 (let ((_%bitmap13434%_
                                                        _%affected13167%_)
                                                       (_%source13436%_
                                                        (vector-ref
                                                         _%full-plan13432%_
                                                         '0)))
                                                   (letrec ((_%keep?13439%_
                                                             (lambda (_%output13687%_)
                                                               (vector-ref
                                                                _%bitmap13434%_
                                                                (vector-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (vector-ref _%output13687%_ '0)
                         '0)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (let _%scan13442%_ ((_%remaining13445%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                  _%source13436%_))
               (let* ((_%$%remaining1344713456%_ _%remaining13445%_)
                      (_%$%E1345013460%_
                       (lambda ()
                         (let ()
                           (declare (not safe))
                           (error '"No clause matching"
                                  _%$%remaining1344713456%_
                                  '([])
                                  '([output . rest])))
                         '#!void)))
                 (let ((_%$%K1345413684%_ (lambda () _%source13436%_))
                       (_%$%K1345113668%_
                        (lambda (_%rest13464%_ _%output13466%_)
                          (if (_%keep?13439%_ _%output13466%_)
                              (_%scan13442%_ _%rest13464%_)
                              (if (eq? _%remaining13445%_ _%source13436%_)
                                  (filter _%keep?13439%_ _%rest13464%_)
                                  (let* ((_%head13471%_ (cons '#f '()))
                                         (_%tail13474%_ _%head13471%_))
                                    (let _%prefix13654%_ ((_%pending13657%_
                                                           _%source13436%_))
                                      (if (eq? _%pending13657%_
                                               _%remaining13445%_)
                                          '#!void
                                          (begin
                                            (let ((_%new-tail13660%_
                                                   (cons (car _%pending13657%_)
                                                         '())))
                                              (let ()
                                                (declare (not safe))
                                                (##set-cdr!
                                                 _%tail13474%_
                                                 _%new-tail13660%_))
                                              (set! _%tail13474%_
                                                    _%new-tail13660%_))
                                            (_%prefix13654%_
                                             (cdr _%pending13657%_)))))
                                    (for-each
                                     (lambda (_%output13663%_)
                                       (if (_%keep?13439%_ _%output13663%_)
                                           (let ((_%new-tail13665%_
                                                  (cons _%output13663%_ '())))
                                             (let ()
                                               (declare (not safe))
                                               (##set-cdr!
                                                _%tail13474%_
                                                _%new-tail13665%_))
                                             (set! _%tail13474%_
                                                   _%new-tail13665%_))
                                           '#!void))
                                     _%rest13464%_)
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%head13471%_))))))))
                   (let ((_%$%try-match1344913680%_
                          (lambda ()
                            (if (pair? _%$%remaining1344713456%_)
                                (let ((_%$%tl1345313673%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%remaining1344713456%_)))
                                      (_%$%hd1345213671%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%remaining1344713456%_))))
                                  (let ((_%output13676%_ _%$%hd1345213671%_)
                                        (_%rest13678%_ _%$%tl1345313673%_))
                                    (_%$%K1345113668%_
                                     _%rest13678%_
                                     _%output13676%_)))
                                (_%$%E1345013460%_)))))
                     (if (null? _%$%remaining1344713456%_)
                         (_%$%K1345413684%_)
                         (_%$%try-match1344913680%_))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (declare (not safe))
                                            (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
                                             _%full-plan13432%_
                                             __tmp37235))
                                          (let ((__tmp37236
                                                 (vector _%heads13430%_
                                                         (vector-ref
                                                          _%rule13171%_
                                                          '1)
                                                         (vector-ref
                                                          _%rule13171%_
                                                          '2)
                                                         (vector-ref
                                                          _%rule13171%_
                                                          '3))))
                                            (declare (not safe))
                                            (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
                                             __tmp37236)))))
                                (vector _%heads13430%_
                                        (vector-ref _%rule13171%_ '1)
                                        (vector-ref _%rule13171%_ '2)
                                        (vector-ref _%rule13171%_ '3)
                                        (vector-ref _%rule13171%_ '4)
                                        _%plan13689%_)))
                          '#f)))))
             (declare (not safe))
             (filter-map__0 __tmp37234 _%rules13169%_)))
         _%full-active-by-stratum13166%_)))
    (define gerbil-ascent/program/update-selection#gerbil-ascent-update-active-plans
      (lambda (_%full-active-by-stratum13159%_ _%affected13160%_)
        (vector-map
         (lambda (_%rules13162%_)
           (map (lambda (_%rule13164%_)
                  (if (= (vector-length _%rule13164%_) '7)
                      _%rule13164%_
                      (let ()
                        (declare (not safe))
                        (gerbil-ascent/program/activation#gerbil-ascent-activate-rule
                         _%rule13164%_))))
                _%rules13162%_))
         (gerbil-ascent/program/update-selection#gerbil-ascent-select-rule-plans
          _%full-active-by-stratum13159%_
          _%affected13160%_))))))
