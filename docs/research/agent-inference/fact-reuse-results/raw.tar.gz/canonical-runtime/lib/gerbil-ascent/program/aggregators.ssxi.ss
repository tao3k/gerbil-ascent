prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/aggregators#single-column-value
   (@lambda 1
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators)))
  (declare-type
   gerbil-ascent/program/aggregators#gerbil-ascent-count
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators)))
  (declare-type
   gerbil-ascent/program/aggregators#gerbil-ascent-sum
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators)))
  (declare-type
   gerbil-ascent/program/aggregators#gerbil-ascent-min
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators)))
  (declare-type
   gerbil-ascent/program/aggregators#gerbil-ascent-max
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators)))
  (declare-type
   gerbil-ascent/program/aggregators#gerbil-ascent-mean
   (@lambda 1
            #f
            signature:
            (return:
             list::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/aggregators))))
