(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/session::timestamp 1791687891)
  (begin
    (define gerbil-ascent/program/session#Session.
      (let ()
        (declare (not safe))
        (clan/poo/object#.ref
         gerbil-ascent/program/types#GerbilAscentSessionContract
         'proto)))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session__%
      (lambda (_%@@keywords19719%_
               _%$%measure-rule-times?1971619720%_
               _%program19721%_)
        (let ((_%measure-rule-times?19723%_
               (if (eq? _%$%measure-rule-times?1971619720%_ absent-value)
                   '#f
                   _%$%measure-rule-times?1971619720%_)))
          (if (boolean? _%measure-rule-times?19723%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"invalid ASCENT rule timing option"
                       _%measure-rule-times?19723%_)))
          (letrec ((_%copy-source-rows19725%_
                    (lambda (_%rows20107%_)
                      (if (list? _%rows20107%_)
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid ASCENT source rows"
                                   _%rows20107%_)))
                      (map (lambda (_%row20109%_)
                             (if (list? _%row20109%_)
                                 '#!void
                                 (let ()
                                   (declare (not safe))
                                   (error '"invalid ASCENT source row"
                                          _%row20109%_)))
                             (map identity _%row20109%_))
                           _%rows20107%_))))
            (let* ((_%relations19727%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%program19721%_ 'relations)))
                   (_%initial-relations19753%_
                    (map (lambda (_%relation19729%_)
                           (let ((__obj37815
                                  (let ()
                                    (declare (not safe))
                                    (##structure
                                     clan/poo/object#object::t
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f
                                     '#f))))
                             (let ((__tmp37819
                                    (list (cons 'rows
                                                (let ((__tmp37820
                                                       (lambda (_%@19747%_)
                                                         (_%copy-source-rows19725%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (clan/poo/object#.ref
                                                             _%relation19729%_
                                                             'rows))))))
                                                  (declare (not safe))
                                                  (##structure
                                                   clan/poo/object#$self-slot-spec::t
                                                   __tmp37820)))))
                                   (__tmp37818 (list)))
                               (declare (not safe))
                               (clan/poo/object#object:::init!__%
                                '#f
                                _%relation19729%_
                                __tmp37819
                                __tmp37818
                                __obj37815))
                             __obj37815))
                         _%relations19727%_))
                   (_%initial-program19772%_
                    (let ((__obj37816
                           (let ()
                             (declare (not safe))
                             (##structure
                              clan/poo/object#object::t
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f
                              '#f))))
                      (let ((__tmp37822
                             (list (cons 'relations
                                         (let ((__tmp37823
                                                (lambda (_%@19766%_)
                                                  _%initial-relations19753%_)))
                                           (declare (not safe))
                                           (##structure
                                            clan/poo/object#$self-slot-spec::t
                                            __tmp37823)))))
                            (__tmp37821 (list)))
                        (declare (not safe))
                        (clan/poo/object#object:::init!__%
                         '#f
                         _%program19721%_
                         __tmp37822
                         __tmp37821
                         __obj37816))
                      __obj37816))
                   (_%source-snapshot19774%_
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/program/source-snapshot#gerbil-ascent-source-snapshot
                       _%initial-program19772%_)))
                   (_%single-relation-name19776%_
                    (if (pair? _%relations19727%_)
                        (if (null? (let ()
                                     (declare (not safe))
                                     (##cdr _%relations19727%_)))
                            (let ((__tmp37824
                                   (let ()
                                     (declare (not safe))
                                     (##car _%relations19727%_))))
                              (declare (not safe))
                              (clan/poo/object#.ref __tmp37824 'name))
                            '#f)
                        '#f))
                   (_%positions19778%_
                    (let () (declare (not safe)) (make-hash-table-eq)))
                   (_%initial19782%_
                    (list->vector
                     (let ((__tmp37825
                            (lambda (_%relation19780%_)
                              (cons (let ()
                                      (declare (not safe))
                                      (clan/poo/object#.ref
                                       _%relation19780%_
                                       'rows))
                                    '()))))
                       (declare (not safe))
                       (##map __tmp37825 _%initial-relations19753%_))))
                   (_%safe-set-flush?19792%_
                    (let ((__tmp37826
                           (lambda (_%relation19784%_)
                             (let ((_%$e19786%_
                                    (eq? (let ()
                                           (declare (not safe))
                                           (clan/poo/object#.ref
                                            _%relation19784%_
                                            'storage-kind))
                                         'lattice)))
                               (if _%$e19786%_
                                   _%$e19786%_
                                   (let ((_%$e19789%_
                                          (not (let ((__tmp37827
                                                      (let ()
                                                        (declare (not safe))
                                                        (clan/poo/object#.ref
                                                         _%relation19784%_
                                                         'storage-provider))))
                                                 (declare (not safe))
                                                 (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                                  __tmp37827)))))
                                     (if _%$e19789%_
                                         _%$e19789%_
                                         (let ((__tmp37828
                                                (let ()
                                                  (declare (not safe))
                                                  (clan/poo/object#.ref
                                                   _%relation19784%_
                                                   'index-provider))))
                                           (declare (not safe))
                                           (gerbil-ascent/table/provider#gerbil-ascent-canonical-hash-index-provider?
                                            __tmp37828)))))))))
                      (declare (not safe))
                      (andmap__0 __tmp37826 _%relations19727%_)))
                   (_%atomic-appends19799%_
                    (list->vector
                     (map (lambda (_%relation19794%_)
                            (let ((_%$e19796%_
                                   (eq? (let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%relation19794%_
                                           'storage-kind))
                                        'lattice)))
                              (if _%$e19796%_
                                  _%$e19796%_
                                  (if _%safe-set-flush?19792%_
                                      (let ((__tmp37829
                                             (let ()
                                               (declare (not safe))
                                               (clan/poo/object#.ref
                                                _%relation19794%_
                                                'storage-provider))))
                                        (declare (not safe))
                                        (gerbil-ascent/table/storage#gerbil-ascent-canonical-set-storage-provider?
                                         __tmp37829))
                                      '#f))))
                          _%relations19727%_)))
                   (_%direct-appends?19803%_
                    (let ((__tmp37831 (lambda (_%safe?19801%_) _%safe?19801%_))
                          (__tmp37830
                           (let ()
                             (declare (not safe))
                             (##vector->list _%atomic-appends19799%_))))
                      (declare (not safe))
                      (andmap__0 __tmp37831 __tmp37830)))
                   (_%pending19805%_
                    (list->vector
                     (let ()
                       (declare (not safe))
                       (##vector->list _%initial19782%_))))
                   (_%committed19807%_
                    (list->vector
                     (let ()
                       (declare (not safe))
                       (##vector->list _%initial19782%_))))
                   (_%committed-result19809%_ '#f)
                   (_%initialized?19811%_ '#f)
                   (_%clean?19813%_ '#f)
                   (_%partial?19815%_ '#f)
                   (_%replay-on-timeout?19817%_ '#f)
                   (_%replacement-active?19819%_ '#f)
                   (_%last-result19821%_ '#f)
                   (_%engine19823%_
                    (let ()
                      (declare (not safe))
                      (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                       _%initial-program19772%_
                       '#t
                       '#f
                       '#f
                       _%measure-rule-times?19723%_)))
                   (_%engine-analysis19825%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19823%_ '.analysis)))
                   (_%engine-schema19827%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19823%_ '.schema)))
                   (_%engine-base-rows19831%_
                    (list->vector
                     (let ((__tmp37832
                            (lambda (_%relation19829%_)
                              (let ()
                                (declare (not safe))
                                (clan/poo/object#.ref
                                 _%relation19829%_
                                 'rows)))))
                       (declare (not safe))
                       (##map __tmp37832 _%initial-relations19753%_))))
                   (_%engine-append19833%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref _%engine19823%_ '.append-source!)))
                   (_%engine-additions19835%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref
                       _%engine19823%_
                       '.source-additions)))
                   (_%engine-overrides19837%_
                    (let ()
                      (declare (not safe))
                      (clan/poo/object#.ref
                       _%engine19823%_
                       '.source-overrides))))
              (for-each
               (lambda (_%relation19840%_ _%index19841%_)
                 (let ((__tmp37834
                        (let ()
                          (declare (not safe))
                          (clan/poo/object#.ref _%relation19840%_ 'name)))
                       (__tmp37833 (+ _%index19841%_ '1)))
                   (declare (not safe))
                   (__hash-put! _%positions19778%_ __tmp37834 __tmp37833)))
               _%relations19727%_
               (let ((__tmp37835 (length _%relations19727%_)))
                 (declare (not safe))
                 (##iota __tmp37835)))
              (letrec* ((_%snapshot-copy19843%_
                         (lambda (_%rows20103%_)
                           (vector-map
                            (lambda (_%state20105%_)
                              (cons (car _%state20105%_) (cdr _%state20105%_)))
                            _%rows20103%_)))
                        (_%copy-append-row19844%_
                         (lambda (_%index20097%_ _%name20098%_ _%row20099%_)
                           (if (and (list? _%row20099%_)
                                    (= (let ()
                                         (declare (not safe))
                                         (##length _%row20099%_))
                                       (vector-ref
                                        (vector-ref _%engine-schema19827%_ '2)
                                        _%index20097%_)))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT session source row"
                                        _%name20098%_
                                        _%row20099%_)))
                           (map (lambda (_%value20101%_) _%value20101%_)
                                _%row20099%_)))
                        (_%engine-source-snapshot19845%_
                         (lambda ()
                           (list->vector
                            (let ((__tmp37838
                                   (lambda (_%index20093%_)
                                     (let ((_%replacement20095%_
                                            (vector-ref
                                             _%engine-overrides19837%_
                                             _%index20093%_)))
                                       (if _%replacement20095%_
                                           (cons _%replacement20095%_ '())
                                           (cons (vector-ref
                                                  _%engine-base-rows19831%_
                                                  _%index20093%_)
                                                 (vector-ref
                                                  _%engine-additions19835%_
                                                  _%index20093%_))))))
                                  (__tmp37836
                                   (let ((__tmp37837
                                          (length _%relations19727%_)))
                                     (declare (not safe))
                                     (##iota __tmp37837))))
                              (declare (not safe))
                              (##map __tmp37838 __tmp37836)))))
                        (_%position-of19846%_
                         (lambda (_%name20088%_)
                           (if (and _%single-relation-name19776%_
                                    (eq? _%name20088%_
                                         _%single-relation-name19776%_))
                               '0
                               (let ((_%slot20090%_
                                      (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%positions19778%_
                                         _%name20088%_))))
                                 (if _%slot20090%_
                                     '#!void
                                     (let ()
                                       (declare (not safe))
                                       (error '"unknown ASCENT relation"
                                              _%name20088%_)))
                                 (- _%slot20090%_ '1)))))
                        (_%prepare-source-cut19847%_
                         (lambda (_%rows20068%_)
                           (let* ((_%snapshot20070%_ _%source-snapshot19774%_)
                                  (_%logs20073%_ _%rows20068%_)
                                  (_%snapshot20077%_ _%snapshot20070%_))
                             (declare (not safe))
                             (gerbil-ascent/program/source-snapshot#__gerbil-ascent-prepare-source-log-snapshot
                              _%snapshot20077%_
                              _%logs20073%_))))
                        (_%restore!19848%_
                         (lambda (_%rows20054%_)
                           (set! _%engine19823%_ '#f)
                           (let* ((_%cut20056%_
                                   (_%prepare-source-cut19847%_ _%rows20054%_))
                                  (_%candidate20058%_
                                   (##direct-structure-ref
                                    _%cut20056%_
                                    '2
                                    gerbil-ascent/program/source-snapshot#source-snapshot::t
                                    '#f))
                                  (_%fresh20060%_
                                   (let ()
                                     (declare (not safe))
                                     (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                      _%candidate20058%_
                                      '#t
                                      _%engine-analysis19825%_
                                      _%engine-schema19827%_
                                      _%measure-rule-times?19723%_)))
                                  (_%restored-result20062%_
                                   (if _%initialized?19811%_
                                       ((let ()
                                          (declare (not safe))
                                          (clan/poo/object#.ref
                                           _%fresh20060%_
                                           '.run)))
                                       '#f)))
                             (_%adopt-engine!19849%_
                              _%fresh20060%_
                              _%cut20056%_)
                             (set! _%pending19805%_
                                   (_%snapshot-copy19843%_ _%rows20054%_))
                             (set! _%partial?19815%_ '#f)
                             (set! _%clean?19813%_
                                   (if _%initialized?19811%_
                                       (equal? (vector->list _%rows20054%_)
                                               (let ()
                                                 (declare (not safe))
                                                 (##vector->list
                                                  _%committed19807%_)))
                                       '#f))
                             (set! _%replay-on-timeout?19817%_
                                   (if _%initialized?19811%_
                                       (not _%clean?19813%_)
                                       '#f))
                             (if _%clean?19813%_
                                 (set! _%last-result19821%_
                                       (let ((_%$e20065%_
                                              _%committed-result19809%_))
                                         (if _%$e20065%_
                                             _%$e20065%_
                                             _%restored-result20062%_)))
                                 '#!void))))
                        (_%adopt-engine!19849%_
                         (lambda (_%fresh20051%_ _%cut20052%_)
                           (set! _%source-snapshot19774%_ _%cut20052%_)
                           (set! _%engine19823%_ _%fresh20051%_)
                           (set! _%replay-on-timeout?19817%_ '#f)
                           (set! _%engine-append19833%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20051%_
                                    '.append-source!)))
                           (set! _%engine-additions19835%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20051%_
                                    '.source-additions)))
                           (set! _%engine-overrides19837%_
                                 (let ()
                                   (declare (not safe))
                                   (clan/poo/object#.ref
                                    _%fresh20051%_
                                    '.source-overrides)))
                           (set! _%engine-base-rows19831%_
                                 (##direct-structure-ref
                                  _%cut20052%_
                                  '4
                                  gerbil-ascent/program/source-snapshot#source-snapshot::t
                                  '#f))))
                        (_%attempt19850%_
                         (lambda (_%thunk20046%_)
                           (let ((__tmp37840
                                  (lambda (_%failure20048%_)
                                    (vector '#f _%failure20048%_)))
                                 (__tmp37839
                                  (lambda () (vector '#t (_%thunk20046%_)))))
                             (declare (not safe))
                             (__with-catch __tmp37840 __tmp37839))))
                        (_%recover!19851%_
                         (lambda (_%rows20040%_ _%failure20041%_)
                           (let ((_%restored20044%_
                                  (_%attempt19850%_
                                   (lambda ()
                                     (_%restore!19848%_ _%rows20040%_)))))
                             (if (vector-ref _%restored20044%_ '0)
                                 '#!void
                                 (_%restore!19848%_ _%committed19807%_)))
                           (let ()
                             (declare (not safe))
                             (raise _%failure20041%_))))
                        (_%record-append!19852%_
                         (lambda (_%index20035%_ _%source-state20036%_)
                           (let ((_%replacement20038%_
                                  (vector-ref
                                   _%engine-overrides19837%_
                                   _%index20035%_)))
                             (if _%replacement20038%_
                                 (begin
                                   (set-car!
                                    _%source-state20036%_
                                    _%replacement20038%_)
                                   (set-cdr! _%source-state20036%_ '()))
                                 (set-cdr!
                                  _%source-state20036%_
                                  (vector-ref
                                   _%engine-additions19835%_
                                   _%index20035%_))))
                           (set! _%clean?19813%_ '#f)))
                        (_%check-idle!19853%_
                         (lambda ()
                           (if _%replacement-active?19819%_
                               (let ()
                                 (declare (not safe))
                                 (error '"ASCENT session operation during replacement validation"))
                               '#!void)))
                        (_%append-source!19854%_
                         (lambda (_%name20021%_ _%row20022%_)
                           (_%check-idle!19853%_)
                           (if _%partial?19815%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (let* ((_%index20024%_
                                   (_%position-of19846%_ _%name20021%_))
                                  (_%source-state20026%_
                                   (vector-ref
                                    _%pending19805%_
                                    _%index20024%_))
                                  (_%owned-row20028%_
                                   (_%copy-append-row19844%_
                                    _%index20024%_
                                    _%name20021%_
                                    _%row20022%_)))
                             (if (vector-ref
                                  _%atomic-appends19799%_
                                  _%index20024%_)
                                 (begin
                                   (_%engine-append19833%_
                                    _%name20021%_
                                    _%owned-row20028%_)
                                   (_%record-append!19852%_
                                    _%index20024%_
                                    _%source-state20026%_))
                                 (let ((__tmp37842
                                        (lambda (_%failure20031%_)
                                          (_%recover!19851%_
                                           _%pending19805%_
                                           _%failure20031%_)))
                                       (__tmp37841
                                        (lambda ()
                                          (_%engine-append19833%_
                                           _%name20021%_
                                           _%owned-row20028%_)
                                          (_%record-append!19852%_
                                           _%index20024%_
                                           _%source-state20026%_))))
                                   (declare (not safe))
                                   (__with-catch __tmp37842 __tmp37841))))))
                        (_%direct-append-source!19855%_
                         (lambda (_%name20013%_ _%row20014%_)
                           (_%check-idle!19853%_)
                           (if _%partial?19815%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (let* ((_%index20016%_
                                   (_%position-of19846%_ _%name20013%_))
                                  (_%owned-row20018%_
                                   (_%copy-append-row19844%_
                                    _%index20016%_
                                    _%name20013%_
                                    _%row20014%_)))
                             (_%engine-append19833%_
                              _%name20013%_
                              _%owned-row20018%_))
                           (set! _%clean?19813%_ '#f)))
                        (_%replace-source!19856%_
                         (lambda (_%name19997%_ _%rows19998%_)
                           (_%check-idle!19853%_)
                           (if _%partial?19815%_
                               (let ()
                                 (declare (not safe))
                                 (error '"finish ASCENT partial run before changing sources"))
                               '#!void)
                           (if (and _%initialized?19811%_
                                    _%clean?19813%_
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/program/update-selection#gerbil-ascent-update-eligible?__0
                                       _%program19721%_)))
                               (let ((_%previous-committed20000%_
                                      _%committed19807%_)
                                     (_%previous-result20001%_
                                      _%committed-result19809%_))
                                 (_%replace-sources!__0__3781337814%_
                                  (list (cons _%name19997%_ _%rows19998%_)))
                                 (set! _%committed19807%_
                                       _%previous-committed20000%_)
                                 (set! _%committed-result19809%_
                                       _%previous-result20001%_)
                                 (set! _%last-result19821%_
                                       _%previous-result20001%_)
                                 (set! _%clean?19813%_ '#f)
                                 (set! _%replay-on-timeout?19817%_ '#t)
                                 '#!void)
                               (let* ((_%index20003%_
                                       (_%position-of19846%_ _%name19997%_))
                                      (_%source-state20005%_
                                       (vector-ref
                                        _%pending19805%_
                                        _%index20003%_))
                                      (_%owned-rows20007%_
                                       (_%copy-source-rows19725%_
                                        _%rows19998%_))
                                      (_%outcome20010%_
                                       (_%attempt19850%_
                                        (lambda ()
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19823%_
                                              '.replace-source!))
                                           _%name19997%_
                                           _%owned-rows20007%_)
                                          (vector-set!
                                           _%pending19805%_
                                           _%index20003%_
                                           (cons _%owned-rows20007%_ '()))))))
                                 (if (vector-ref _%outcome20010%_ '0)
                                     '#!void
                                     (begin
                                       (vector-set!
                                        _%pending19805%_
                                        _%index20003%_
                                        _%source-state20005%_)
                                       (_%recover!19851%_
                                        _%pending19805%_
                                        (vector-ref _%outcome20010%_ '1))))
                                 (set! _%clean?19813%_ '#f)
                                 (vector-ref _%outcome20010%_ '1)))))
                        (_%replace-sources!__3781137812%_
                         (lambda (_%replacements19978%_ _%accept-result19979%_)
                           (_%check-idle!19853%_)
                           (if (or (not _%accept-result19979%_)
                                   (procedure? _%accept-result19979%_))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT replacement acceptance procedure")))
                           (let ((__tmp37845
                                  (lambda ()
                                    (set! _%replacement-active?19819%_ '#t)))
                                 (__tmp37844
                                  (lambda ()
                                    (_%replace-sources/idle!19858%_
                                     _%replacements19978%_
                                     _%accept-result19979%_)))
                                 (__tmp37843
                                  (lambda ()
                                    (set! _%replacement-active?19819%_ '#f))))
                             (declare (not safe))
                             (##dynamic-wind
                              __tmp37845
                              __tmp37844
                              __tmp37843))))
                        (_%replace-sources!__0__3781337814%_
                         (lambda (_%replacements19990%_)
                           (let ((_%accept-result19992%_ '#f))
                             (_%replace-sources!__3781137812%_
                              _%replacements19990%_
                              _%accept-result19992%_))))
                        (_%replace-sources!19857%_
                         (lambda _g37846_
                           (let ((_g37847_
                                  (let ()
                                    (declare (not safe))
                                    (##length _g37846_))))
                             (cond ((let ()
                                      (declare (not safe))
                                      (##fx= _g37847_ 1))
                                    (apply _%replace-sources!__0__3781337814%_
                                           _g37846_))
                                   ((let ()
                                      (declare (not safe))
                                      (##fx= _g37847_ 2))
                                    (apply _%replace-sources!__3781137812%_
                                           _g37846_))
                                   (else
                                    (##raise-wrong-number-of-arguments-exception
                                     'case-lambda-dispatch
                                     _g37846_))))))
                        (_%replace-sources/idle!19858%_
                         (lambda (_%replacements19955%_ _%accept-result19956%_)
                           (if (and _%initialized?19811%_ _%clean?19813%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacement requires a completed clean session")))
                           (if (list? _%replacements19955%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacements must be a list"
                                        _%replacements19955%_)))
                           (if (null? _%replacements19955%_)
                               (let ()
                                 (declare (not safe))
                                 (error '"batch replacement requires at least one source"))
                               '#!void)
                           (let ((_%prospective19958%_
                                  (_%snapshot-copy19843%_ _%committed19807%_))
                                 (_%seen19959%_
                                  (let ()
                                    (declare (not safe))
                                    (make-hash-table-eq))))
                             (for-each
                              (lambda (_%replacement19961%_)
                                (if (and (pair? _%replacement19961%_)
                                         (symbol? (let ()
                                                    (declare (not safe))
                                                    (##car _%replacement19961%_))))
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"invalid source replacement"
                                             _%replacement19961%_)))
                                (let* ((_%name19963%_
                                        (car _%replacement19961%_))
                                       (_%index19965%_
                                        (_%position-of19846%_ _%name19963%_)))
                                  (if (let ()
                                        (declare (not safe))
                                        (__hash-get
                                         _%seen19959%_
                                         _%name19963%_))
                                      (let ()
                                        (declare (not safe))
                                        (error '"duplicate batch source"
                                               _%name19963%_))
                                      '#!void)
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%seen19959%_
                                     _%name19963%_
                                     '#t))
                                  (let ((__tmp37850 (cdr _%replacement19961%_))
                                        (__tmp37849
                                         (vector-ref
                                          (vector-ref
                                           _%engine-schema19827%_
                                           '2)
                                          _%index19965%_))
                                        (__tmp37848
                                         (vector-ref
                                          (vector-ref
                                           _%engine-schema19827%_
                                           '3)
                                          _%index19965%_)))
                                    (declare (not safe))
                                    (gerbil-ascent/program/admission#gerbil-ascent-check-replacement-rows!
                                     _%name19963%_
                                     __tmp37850
                                     __tmp37849
                                     __tmp37848))
                                  (vector-set!
                                   _%prospective19958%_
                                   _%index19965%_
                                   (cons (_%copy-source-rows19725%_
                                          (cdr _%replacement19961%_))
                                         '()))))
                              _%replacements19955%_)
                             (let* ((_%cut19968%_
                                     (_%prepare-source-cut19847%_
                                      _%prospective19958%_))
                                    (_%candidate19970%_
                                     (##direct-structure-ref
                                      _%cut19968%_
                                      '2
                                      gerbil-ascent/program/source-snapshot#source-snapshot::t
                                      '#f))
                                    (_%fresh19972%_
                                     (let ((__tmp37851
                                            (if _%engine19823%_
                                                ((let ()
                                                   (declare (not safe))
                                                   (clan/poo/object#.ref
                                                    _%engine19823%_
                                                    '.native-publication)))
                                                '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/program/evaluate#gerbil-ascent-make-updated-engine__%
                                        _%committed19807%_
                                        _%candidate19970%_
                                        _%committed-result19809%_
                                        _%engine-analysis19825%_
                                        _%engine-schema19827%_
                                        _%measure-rule-times?19723%_
                                        _%cut19968%_
                                        __tmp37851)))
                                    (_%result19974%_
                                     ((let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%fresh19972%_
                                         '.run)))))
                               (if (let ()
                                     (declare (not safe))
                                     (clan/poo/object#.ref
                                      _%result19974%_
                                      'finished))
                                   '#!void
                                   (let ()
                                     (declare (not safe))
                                     (error '"batch source replacement did not complete")))
                               (if (and _%accept-result19956%_
                                        (not (eq? '#t
                                                  (_%accept-result19956%_
                                                   _%result19974%_))))
                                   (let ()
                                     (declare (not safe))
                                     (error '"ASCENT replacement result was not accepted"))
                                   '#!void)
                               (_%adopt-engine!19849%_
                                _%fresh19972%_
                                _%cut19968%_)
                               (set! _%pending19805%_
                                     (_%snapshot-copy19843%_
                                      _%prospective19958%_))
                               (set! _%committed19807%_
                                     (_%snapshot-copy19843%_
                                      _%prospective19958%_))
                               (set! _%last-result19821%_ _%result19974%_)
                               (set! _%committed-result19809%_ _%result19974%_)
                               (set! _%clean?19813%_ '#t)
                               (set! _%partial?19815%_ '#f)
                               _%result19974%_))))
                        (_%run!19859%_
                         (lambda ()
                           (_%check-idle!19853%_)
                           (if _%clean?19813%_
                               _%last-result19821%_
                               (let* ((_%next-pending19949%_
                                       (if _%direct-appends?19803%_
                                           (_%engine-source-snapshot19845%_)
                                           _%pending19805%_))
                                      (_%outcome19952%_
                                       (_%attempt19850%_
                                        (lambda ()
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19823%_
                                              '.run)))))))
                                 (if (vector-ref _%outcome19952%_ '0)
                                     '#!void
                                     (_%recover!19851%_
                                      _%committed19807%_
                                      (vector-ref _%outcome19952%_ '1)))
                                 (set! _%initialized?19811%_ '#t)
                                 (set! _%pending19805%_ _%next-pending19949%_)
                                 (set! _%committed19807%_
                                       (_%snapshot-copy19843%_
                                        _%next-pending19949%_))
                                 (set! _%last-result19821%_
                                       (vector-ref _%outcome19952%_ '1))
                                 (set! _%committed-result19809%_
                                       _%last-result19821%_)
                                 (set! _%clean?19813%_ '#t)
                                 (set! _%partial?19815%_ '#f)
                                 (set! _%replay-on-timeout?19817%_ '#f)
                                 _%last-result19821%_))))
                        (_%run-timeout!19860%_
                         (lambda (_%duration-nanoseconds19928%_)
                           (_%check-idle!19853%_)
                           (if (and (exact-integer?
                                     _%duration-nanoseconds19928%_)
                                    (>= _%duration-nanoseconds19928%_ '0))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT timeout in nanoseconds"
                                        _%duration-nanoseconds19928%_)))
                           (if _%clean?19813%_
                               _%last-result19821%_
                               (let* ((_%next-pending19930%_
                                       (if _%direct-appends?19803%_
                                           (_%engine-source-snapshot19845%_)
                                           _%pending19805%_))
                                      (_%outcome19943%_
                                       (_%attempt19850%_
                                        (lambda ()
                                          (if (or _%replay-on-timeout?19817%_
                                                  ((let ()
                                                     (declare (not safe))
                                                     (clan/poo/object#.ref
                                                      _%engine19823%_
                                                      '.recomputed?))))
                                              (let* ((_%cut19936%_
                                                      (_%prepare-source-cut19847%_
                                                       _%next-pending19930%_))
                                                     (_%candidate19938%_
                                                      (##direct-structure-ref
                                                       _%cut19936%_
                                                       '2
                                                       gerbil-ascent/program/source-snapshot#source-snapshot::t
                                                       '#f))
                                                     (_%fresh19940%_
                                                      (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/program/evaluate#gerbil-ascent-make-engine__3
                                                         _%candidate19938%_
                                                         '#t
                                                         _%engine-analysis19825%_
                                                         _%engine-schema19827%_
                                                         _%measure-rule-times?19723%_))))
                                                (_%adopt-engine!19849%_
                                                 _%fresh19940%_
                                                 _%cut19936%_))
                                              '#!void)
                                          ((let ()
                                             (declare (not safe))
                                             (clan/poo/object#.ref
                                              _%engine19823%_
                                              '.run-timeout))
                                           _%duration-nanoseconds19928%_)))))
                                 (if (vector-ref _%outcome19943%_ '0)
                                     '#!void
                                     (_%recover!19851%_
                                      _%committed19807%_
                                      (vector-ref _%outcome19943%_ '1)))
                                 (let ((_%result19946%_
                                        (vector-ref _%outcome19943%_ '1)))
                                   (set! _%last-result19821%_ _%result19946%_)
                                   (set! _%pending19805%_
                                         _%next-pending19930%_)
                                   (if (let ()
                                         (declare (not safe))
                                         (clan/poo/object#.ref
                                          _%result19946%_
                                          'finished))
                                       (begin
                                         (set! _%initialized?19811%_ '#t)
                                         (set! _%committed19807%_
                                               (_%snapshot-copy19843%_
                                                _%next-pending19930%_))
                                         (set! _%committed-result19809%_
                                               _%result19946%_)
                                         (set! _%clean?19813%_ '#t)
                                         (set! _%partial?19815%_ '#f))
                                       (set! _%partial?19815%_ '#t))
                                   _%result19946%_))))))
                (let ((__tmp37852
                       (let ((__obj37817
                              (let ()
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#object::t
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f
                                 '#f))))
                         (let ((__tmp37854
                                (list (cons '.append-source!
                                            (let ((__tmp37855
                                                   (lambda (_%@19902%_)
                                                     (if _%direct-appends?19803%_
                                                         _%direct-append-source!19855%_
                                                         _%append-source!19854%_))))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37855)))
                                      (cons '.replace-source!
                                            (let ((__tmp37856
                                                   (lambda (_%@19908%_)
                                                     _%replace-source!19856%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37856)))
                                      (cons '.replace-sources!
                                            (let ((__tmp37857
                                                   (lambda (_%@19913%_)
                                                     _%replace-sources!19857%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37857)))
                                      (cons '.run
                                            (let ((__tmp37858
                                                   (lambda (_%@19918%_)
                                                     _%run!19859%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37858)))
                                      (cons '.run-timeout
                                            (let ((__tmp37859
                                                   (lambda (_%@19923%_)
                                                     _%run-timeout!19860%_)))
                                              (declare (not safe))
                                              (##structure
                                               clan/poo/object#$self-slot-spec::t
                                               __tmp37859)))))
                               (__tmp37853 (list)))
                           (declare (not safe))
                           (clan/poo/object#object:::init!__%
                            '#f
                            gerbil-ascent/program/session#Session.
                            __tmp37854
                            __tmp37853
                            __obj37817))
                         __obj37817)))
                  (declare (not safe))
                  (clan/poo/mop#validate
                   gerbil-ascent/program/types#GerbilAscentSessionContract
                   __tmp37852))))))))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session__@
      (lambda (_%@@keywords20114%_ . _%args20115%_)
        (apply gerbil-ascent/program/session#gerbil-ascent-open-session__%
               _%@@keywords20114%_
               (let ()
                 (declare (not safe))
                 (symbolic-table-ref
                  _%@@keywords20114%_
                  'measure-rule-times?:
                  absent-value))
               _%args20115%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-open-session
      (lambda _%$%args1971720121%_
        (apply keyword-dispatch
               '#(measure-rule-times?:)
               gerbil-ascent/program/session#gerbil-ascent-open-session__@
               _%$%args1971720121%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-append-source!
      (lambda (_%session19711%_ _%name19712%_ _%row19713%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19711%_ '.append-source!))
         _%name19712%_
         _%row19713%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-source!
      (lambda (_%session19707%_ _%name19708%_ _%rows19709%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19707%_ '.replace-source!))
         _%name19708%_
         _%rows19709%_)))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
      (lambda (_%session19691%_ _%replacements19692%_ _%accept-result19693%_)
        (if _%accept-result19693%_
            ((let ()
               (declare (not safe))
               (clan/poo/object#.ref _%session19691%_ '.replace-sources!))
             _%replacements19692%_
             _%accept-result19693%_)
            ((let ()
               (declare (not safe))
               (clan/poo/object#.ref _%session19691%_ '.replace-sources!))
             _%replacements19692%_))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
      (lambda (_%session19698%_ _%replacements19699%_)
        (let ((_%accept-result19701%_ '#f))
          (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
           _%session19698%_
           _%replacements19699%_
           _%accept-result19701%_))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!
      (lambda _g37860_
        (let ((_g37861_ (let () (declare (not safe)) (##length _g37860_))))
          (cond ((let () (declare (not safe)) (##fx= _g37861_ 2))
                 (apply gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                        _g37860_))
                ((let () (declare (not safe)) (##fx= _g37861_ 3))
                 (apply gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__%
                        _g37860_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!
                  _g37860_))))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-run
      (lambda (_%session19688%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19688%_ '.run)))))
    (define gerbil-ascent/program/session#gerbil-ascent-session-run-timeout
      (lambda (_%session19685%_ _%duration-nanoseconds19686%_)
        ((let ()
           (declare (not safe))
           (clan/poo/object#.ref _%session19685%_ '.run-timeout))
         _%duration-nanoseconds19686%_)))))
