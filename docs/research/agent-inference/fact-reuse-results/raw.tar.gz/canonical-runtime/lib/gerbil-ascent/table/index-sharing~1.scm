(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/index-sharing[1]#_g34055_|
    (##structure
     gx#syntax-quote::t
     'column-order::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34057_|
    (##structure
     gx#syntax-quote::t
     'make-column-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34059_|
    (##structure
     gx#syntax-quote::t
     'column-order?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34061_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34062_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34064_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34065_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34067_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34068_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34070_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34071_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34073_|
    (##structure
     gx#syntax-quote::t
     'shared-index::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34075_|
    (##structure
     gx#syntax-quote::t
     'make-shared-index
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34077_|
    (##structure
     gx#syntax-quote::t
     'shared-index?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34079_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34080_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34081_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34082_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34083_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34084_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34086_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34087_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34088_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34089_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34090_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34091_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34093_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34094_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34095_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34096_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34097_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34098_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34100_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34101_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34102_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34103_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34104_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34105_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34107_|
    (##structure
     gx#syntax-quote::t
     'column-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34109_|
    (##structure
     gx#syntax-quote::t
     'make-column-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34111_|
    (##structure
     gx#syntax-quote::t
     'column-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34113_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34114_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34115_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34117_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34118_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34119_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34121_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34122_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34123_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34125_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34126_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34127_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34129_|
    (##structure
     gx#syntax-quote::t
     'key-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34131_|
    (##structure
     gx#syntax-quote::t
     'make-key-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34133_|
    (##structure
     gx#syntax-quote::t
     'key-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34135_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34136_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34137_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34139_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34140_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34141_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34143_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34144_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34145_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34147_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34148_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g34149_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/index-sharing[:0:]#column-order|
      (let ((__obj33991
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33991
           'gerbil-ascent/table/index-sharing#column-order::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 'column-order '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33991
           '(sets successors)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33991
           '(sets successors)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '#f '13 '#f '#f))
        (let ((__tmp34054 |gerbil-ascent/table/index-sharing[1]#_g34055_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34054 '4 '#f '#f))
        (let ((__tmp34056 |gerbil-ascent/table/index-sharing[1]#_g34057_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34056 '14 '#f '#f))
        (let ((__tmp34058 |gerbil-ascent/table/index-sharing[1]#_g34059_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34058 '15 '#f '#f))
        (let ((__tmp34060
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g34061_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g34062_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34060 '16 '#f '#f))
        (let ((__tmp34063
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g34064_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g34065_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34063 '17 '#f '#f))
        (let ((__tmp34066
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g34067_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g34068_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34066 '18 '#f '#f))
        (let ((__tmp34069
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g34070_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g34071_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 __tmp34069 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33991 '() '21 '#f '#f))
        __obj33991))
    (define |gerbil-ascent/table/index-sharing[:0:]#shared-index|
      (let ((__obj33992
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33992
           'gerbil-ascent/table/index-sharing#shared-index::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 'shared-index '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33992
           '(columns root ordinal views projection key-plans)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33992
           '(columns root ordinal views projection key-plans)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '#f '13 '#f '#f))
        (let ((__tmp34072 |gerbil-ascent/table/index-sharing[1]#_g34073_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34072 '4 '#f '#f))
        (let ((__tmp34074 |gerbil-ascent/table/index-sharing[1]#_g34075_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34074 '14 '#f '#f))
        (let ((__tmp34076 |gerbil-ascent/table/index-sharing[1]#_g34077_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34076 '15 '#f '#f))
        (let ((__tmp34078
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34079_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g34080_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g34081_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g34082_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g34083_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g34084_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34078 '16 '#f '#f))
        (let ((__tmp34085
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34086_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g34087_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g34088_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g34089_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g34090_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g34091_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34085 '17 '#f '#f))
        (let ((__tmp34092
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34093_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g34094_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g34095_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g34096_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g34097_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g34098_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34092 '18 '#f '#f))
        (let ((__tmp34099
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34100_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g34101_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g34102_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g34103_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g34104_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g34105_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 __tmp34099 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33992 '() '21 '#f '#f))
        __obj33992))
    (define |gerbil-ascent/table/index-sharing[:0:]#column-projection|
      (let ((__obj33993
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33993
           'gerbil-ascent/table/index-sharing#column-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33993
           'column-projection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33993
           '(columns writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33993
           '(columns writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '#f '13 '#f '#f))
        (let ((__tmp34106 |gerbil-ascent/table/index-sharing[1]#_g34107_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34106 '4 '#f '#f))
        (let ((__tmp34108 |gerbil-ascent/table/index-sharing[1]#_g34109_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34108 '14 '#f '#f))
        (let ((__tmp34110 |gerbil-ascent/table/index-sharing[1]#_g34111_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34110 '15 '#f '#f))
        (let ((__tmp34112
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34113_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34114_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34115_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34112 '16 '#f '#f))
        (let ((__tmp34116
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34117_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34118_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34119_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34116 '17 '#f '#f))
        (let ((__tmp34120
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34121_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34122_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34123_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34120 '18 '#f '#f))
        (let ((__tmp34124
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g34125_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34126_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34127_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 __tmp34124 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33993 '() '21 '#f '#f))
        __obj33993))
    (define |gerbil-ascent/table/index-sharing[:0:]#key-projection|
      (let ((__obj33994
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33994
           'gerbil-ascent/table/index-sharing#key-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 'key-projection '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33994
           '(physical writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33994
           '(physical writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '#f '13 '#f '#f))
        (let ((__tmp34128 |gerbil-ascent/table/index-sharing[1]#_g34129_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34128 '4 '#f '#f))
        (let ((__tmp34130 |gerbil-ascent/table/index-sharing[1]#_g34131_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34130 '14 '#f '#f))
        (let ((__tmp34132 |gerbil-ascent/table/index-sharing[1]#_g34133_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34132 '15 '#f '#f))
        (let ((__tmp34134
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g34135_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34136_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34137_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34134 '16 '#f '#f))
        (let ((__tmp34138
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g34139_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34140_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34141_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34138 '17 '#f '#f))
        (let ((__tmp34142
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g34143_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34144_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34145_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34142 '18 '#f '#f))
        (let ((__tmp34146
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g34147_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g34148_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g34149_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 __tmp34146 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33994 '() '21 '#f '#f))
        __obj33994))))
