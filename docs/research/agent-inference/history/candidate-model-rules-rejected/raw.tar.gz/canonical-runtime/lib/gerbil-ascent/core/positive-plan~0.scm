(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/core/positive-plan::timestamp 1791687877)
  (begin
    (define gerbil-ascent/core/positive-plan#+positive-plans+
      (let ((__tmp35032 (make-mutex 'ascent-positive-plans)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35032)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
      (lambda (_%rule9890%_)
        (let ((_%entry9892%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/core/positive-plan#+positive-plans+
                  _%rule9890%_))))
          (if _%entry9892%_
              (cdr _%entry9892%_)
              (let ((_%plan9894%_
                     (gerbil-ascent/core/positive-plan#gerbil-ascent-compile-positive-plan
                      (vector-ref _%rule9890%_ '0)
                      (vector-ref _%rule9890%_ '1))))
                (let ((__tmp35033 (cons '#t _%plan9894%_)))
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/core/positive-plan#+positive-plans+
                   _%rule9890%_
                   __tmp35033))
                _%plan9894%_)))))
    (define gerbil-ascent/core/positive-plan#map-projected-terms
      (lambda (_%lower9816%_ _%original9817%_ _%slots9818%_ _%columns9819%_)
        (let* ((_%$%columns98209830%_ _%columns9819%_)
               (_%$%else98239867%_
                (lambda ()
                  (letrec ((_%increasing?9838%_
                            (lambda (_%remaining9861%_ _%prior9862%_)
                              (let ((_%$e9864%_ (null? _%remaining9861%_)))
                                (if _%$e9864%_
                                    _%$e9864%_
                                    (if (> (car _%remaining9861%_)
                                           _%prior9862%_)
                                        (_%increasing?9838%_
                                         (cdr _%remaining9861%_)
                                         (car _%remaining9861%_))
                                        '#f))))))
                    (if (_%increasing?9838%_ _%columns9819%_ '-1)
                        (let _%select9840%_ ((_%sources9842%_ _%original9817%_)
                                             (_%actions9843%_ _%slots9818%_)
                                             (_%selected9844%_ _%columns9819%_)
                                             (_%position9845%_ '0))
                          (if (null? _%selected9844%_)
                              '()
                              (let* ((_%distance9847%_
                                      (- (car _%selected9844%_)
                                         _%position9845%_))
                                     (_%source9849%_
                                      (list-tail
                                       _%sources9842%_
                                       _%distance9847%_))
                                     (_%action9851%_
                                      (list-tail
                                       _%actions9843%_
                                       _%distance9847%_))
                                     (_%key9853%_
                                      (_%lower9816%_
                                       (car _%source9849%_)
                                       (car _%action9851%_))))
                                (cons _%key9853%_
                                      (_%select9840%_
                                       (cdr _%source9849%_)
                                       (cdr _%action9851%_)
                                       (cdr _%selected9844%_)
                                       (+ (car _%selected9844%_) '1))))))
                        (let ((_%sources9856%_ (list->vector _%original9817%_))
                              (_%actions9857%_ (list->vector _%slots9818%_)))
                          (map (lambda (_%column9859%_)
                                 (_%lower9816%_
                                  (vector-ref _%sources9856%_ _%column9859%_)
                                  (vector-ref _%actions9857%_ _%column9859%_)))
                               _%columns9819%_)))))))
          (let ((_%$%K98289887%_ (lambda () '()))
                (_%$%K98259873%_
                 (lambda (_%column9871%_)
                   (list (_%lower9816%_
                          (list-ref _%original9817%_ _%column9871%_)
                          (list-ref _%slots9818%_ _%column9871%_))))))
            (let ((_%$%try-match98229883%_
                   (lambda ()
                     (if (pair? _%$%columns98209830%_)
                         (let ((_%$%tl98279878%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%columns98209830%_)))
                               (_%$%hd98269876%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%columns98209830%_))))
                           (if (null? _%$%tl98279878%_)
                               (let ((_%column9881%_ _%$%hd98269876%_))
                                 (_%$%K98259873%_ _%column9881%_))
                               (_%$%else98239867%_)))
                         (_%$%else98239867%_)))))
              (if (null? _%$%columns98209830%_)
                  (_%$%K98289887%_)
                  (_%$%try-match98229883%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-compile-positive-plan
      (lambda (_%heads9657%_ _%body9658%_)
        (let ((__tmp35034
               (lambda (_%unsupported9660%_)
                 (let ((_%slots9662%_
                        (let () (declare (not safe)) (make-hash-table-eq)))
                       (_%scope9663%_ '#f)
                       (_%count9664%_ '0)
                       (_%pure?9665%_ '#t))
                   (letrec* ((_%ensure-scope!9667%_
                              (lambda ()
                                (let ((_%$e9813%_ _%scope9663%_))
                                  (if _%$e9813%_
                                      _%$e9813%_
                                      (begin
                                        (set! _%scope9663%_
                                              (let ()
                                                (declare (not safe))
                                                (__hash->list _%slots9662%_)))
                                        _%scope9663%_)))))
                             (_%read-slot9668%_
                              (lambda (_%name9807%_)
                                (let ((_%$e9809%_
                                       (let ()
                                         (declare (not safe))
                                         (__hash-get
                                          _%slots9662%_
                                          _%name9807%_))))
                                  (if _%$e9809%_
                                      _%$e9809%_
                                      (_%unsupported9660%_ '#f)))))
                             (_%fresh-slot!9669%_
                              (lambda (_%name9803%_)
                                (let ((_%slot9805%_ _%count9664%_))
                                  (set! _%count9664%_ (+ _%count9664%_ '1))
                                  (let ()
                                    (declare (not safe))
                                    (__hash-put!
                                     _%slots9662%_
                                     _%name9803%_
                                     _%slot9805%_))
                                  (if _%scope9663%_
                                      (set! _%scope9663%_
                                            (cons (cons _%name9803%_
                                                        _%slot9805%_)
                                                  _%scope9663%_))
                                      '#!void)
                                  _%slot9805%_)))
                             (_%lower-call__3486134862%_
                              (lambda (_%names9753%_
                                       _%procedure9754%_
                                       _%diagnostic9755%_
                                       _%payload9756%_
                                       _%visible9757%_)
                                (if (and (list? _%names9753%_)
                                         (procedure? _%procedure9754%_))
                                    '#!void
                                    (_%unsupported9660%_ '#f))
                                (set! _%pure?9665%_ '#f)
                                (let ((_%fast9759%_
                                       (let ((__tmp35035
                                              (map _%read-slot9668%_
                                                   _%names9753%_)))
                                         (declare (not safe))
                                         (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-call
                                          _%procedure9754%_
                                          __tmp35035)))
                                      (_%stable-inputs?9760%_
                                       (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-input-guard
                                          _%names9753%_))))
                                  (letrec ((_%fallback9762%_
                                            (lambda (_%current-procedure9773%_
                                                     _%current-names9774%_
                                                     _%frame9775%_)
                                              (let ((__tmp35036
                                                     (map (lambda (_%entry9777%_)
                                                            (cons (car _%entry9777%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (vector-ref _%frame9775%_ (cdr _%entry9777%_))))
                  _%visible9757%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                (declare (not safe))
                                                (gerbil-ascent/core/rule-bindings#gerbil-ascent-call-with-bindings
                                                 _%current-procedure9773%_
                                                 _%current-names9774%_
                                                 __tmp35036
                                                 _%diagnostic9755%_)))))
                                    (if _%payload9756%_
                                        (lambda (_%frame9764%_)
                                          (let* ((_%current-procedure9766%_
                                                  (vector-ref
                                                   _%payload9756%_
                                                   '1))
                                                 (_%current-names9768%_
                                                  (vector-ref
                                                   _%payload9756%_
                                                   '0)))
                                            (if (and (eq? _%current-procedure9766%_
                                                          _%procedure9754%_)
                                                     (let ()
                                                       (declare (not safe))
                                                       (_%stable-inputs?9760%_
                                                        _%current-names9768%_)))
                                                (let ()
                                                  (declare (not safe))
                                                  (_%fast9759%_ _%frame9764%_))
                                                (_%fallback9762%_
                                                 _%current-procedure9766%_
                                                 _%current-names9768%_
                                                 _%frame9764%_))))
                                        (lambda (_%frame9771%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (_%stable-inputs?9760%_
                                                 _%names9753%_))
                                              (let ()
                                                (declare (not safe))
                                                (_%fast9759%_ _%frame9771%_))
                                              (_%fallback9762%_
                                               _%procedure9754%_
                                               _%names9753%_
                                               _%frame9771%_))))))))
                             (_%lower-call__0__3486334865%_
                              (lambda (_%names9782%_
                                       _%procedure9783%_
                                       _%diagnostic9784%_)
                                (let* ((_%payload9786%_ '#f)
                                       (_%visible9788%_
                                        (_%ensure-scope!9667%_)))
                                  (_%lower-call__3486134862%_
                                   _%names9782%_
                                   _%procedure9783%_
                                   _%diagnostic9784%_
                                   _%payload9786%_
                                   _%visible9788%_))))
                             (_%lower-call__1__3486434866%_
                              (lambda (_%names9790%_
                                       _%procedure9791%_
                                       _%diagnostic9792%_
                                       _%payload9793%_)
                                (let ((_%visible9795%_
                                       (_%ensure-scope!9667%_)))
                                  (_%lower-call__3486134862%_
                                   _%names9790%_
                                   _%procedure9791%_
                                   _%diagnostic9792%_
                                   _%payload9793%_
                                   _%visible9795%_))))
                             (_%lower-call9670%_
                              (lambda _g35037_
                                (let ((_g35038_
                                       (let ()
                                         (declare (not safe))
                                         (##length _g35037_))))
                                  (cond ((let ()
                                           (declare (not safe))
                                           (##fx= _g35038_ 3))
                                         (apply _%lower-call__0__3486334865%_
                                                _g35037_))
                                        ((let ()
                                           (declare (not safe))
                                           (##fx= _g35038_ 4))
                                         (apply _%lower-call__1__3486434866%_
                                                _g35037_))
                                        ((let ()
                                           (declare (not safe))
                                           (##fx= _g35038_ 5))
                                         (apply _%lower-call__3486134862%_
                                                _g35037_))
                                        (else
                                         (##raise-wrong-number-of-arguments-exception
                                          'case-lambda-dispatch
                                          _g35037_))))))
                             (_%lower9671%_
                              (lambda (_%term9736%_ _%head?9737%_)
                                (let ((_%$e9739%_ (car _%term9736%_)))
                                  (if (or (eq? 'literal _%$e9739%_)
                                          (eq? 'wildcard _%$e9739%_))
                                      _%term9736%_
                                      (if (eq? 'expression _%$e9739%_)
                                          (let ((_%payload9745%_
                                                 (cdr _%term9736%_)))
                                            (if (and (vector? _%payload9745%_)
                                                     (= (let ()
                                                          (declare (not safe))
                                                          (##vector-length
                                                           _%payload9745%_))
                                                        '2))
                                                '#!void
                                                (_%unsupported9660%_ '#f))
                                            (cons 'expression
                                                  (_%lower-call__1__3486434866%_
                                                   (vector-ref
                                                    _%payload9745%_
                                                    '0)
                                                   (vector-ref
                                                    _%payload9745%_
                                                    '1)
                                                   '"unbound ASCENT expression variable"
                                                   _%payload9745%_)))
                                          (if (eq? 'variable _%$e9739%_)
                                              (let ((_%slot9747%_
                                                     (let ((__tmp35039
                                                            (cdr _%term9736%_)))
                                                       (declare (not safe))
                                                       (__hash-get
                                                        _%slots9662%_
                                                        __tmp35039))))
                                                (if _%slot9747%_
                                                    (cons 'bound _%slot9747%_)
                                                    (if _%head?9737%_
                                                        (_%unsupported9660%_
                                                         '#f)
                                                        (cons 'fresh
                                                              (_%fresh-slot!9669%_
                                                               (cdr _%term9736%_))))))
                                              (_%unsupported9660%_ '#f))))))))
                     (let* ((_%actions9723%_
                             (map (lambda (_%clause9673%_)
                                    (let ((_%$e9675%_
                                           (vector-ref _%clause9673%_ '0)))
                                      (if (eq? 'atom _%$e9675%_)
                                          (let* ((_%atom9678%_
                                                  (vector-ref
                                                   _%clause9673%_
                                                   '1))
                                                 (_%original9680%_
                                                  (vector-ref _%atom9678%_ '1))
                                                 (_%columns9682%_
                                                  (vector-ref _%atom9678%_ '2))
                                                 (_%prior-count9684%_
                                                  _%count9664%_)
                                                 (_%_checked-columns9690%_
                                                  (if (and (list? _%columns9682%_)
                                                           (let* ((_%width9686%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           (length _%original9680%_))
                          (__tmp35040
                           (lambda (_%column9688%_)
                             (and (exact-integer? _%column9688%_)
                                  (<= '0 _%column9688%_)
                                  (< _%column9688%_ _%width9686%_)))))
                     (declare (not safe))
                     (andmap__0 __tmp35040 _%columns9682%_)))
              '#!void
              (_%unsupported9660%_ '#f)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%prior-scope9694%_
                                                  (if (let ((__tmp35041
                                                             (lambda (_%term9692%_)
                                                               (eq? (car _%term9692%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                            'expression))))
                (declare (not safe))
                (ormap__0 __tmp35041 _%original9680%_))
              (_%ensure-scope!9667%_)
              '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%terms9698%_
                                                  (map (lambda (_%term9696%_)
                                                         (_%lower9671%_
                                                          _%term9696%_
                                                          '#f))
                                                       _%original9680%_))
                                                 (_%keys9715%_
                                                  (gerbil-ascent/core/positive-plan#map-projected-terms
                                                   (lambda (_%source9700%_
                                                            _%action9701%_)
                                                     (if (or (eq? (car _%action9701%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          'literal)
                     (and (eq? (car _%action9701%_) 'bound)
                          (< (cdr _%action9701%_) _%prior-count9684%_))
                     (and (eq? (car _%source9700%_) 'expression)
                          (let ((__tmp35043
                                 (lambda (_%name9709%_)
                                   (let ((_%slot9711%_
                                          (let ()
                                            (declare (not safe))
                                            (__hash-get
                                             _%slots9662%_
                                             _%name9709%_))))
                                     (and _%slot9711%_
                                          (< _%slot9711%_
                                             _%prior-count9684%_)))))
                                (__tmp35042
                                 (vector-ref (cdr _%source9700%_) '0)))
                            (declare (not safe))
                            (andmap__0 __tmp35043 __tmp35042))))
                 '#!void
                 (_%unsupported9660%_ '#f))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (if (eq? (car _%source9700%_)
                                                              'expression)
                                                         (let ((_%payload9713%_
                                                                (cdr _%source9700%_)))
                                                           (cons 'expression
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (_%lower-call__3486134862%_
                          (vector-ref _%payload9713%_ '0)
                          (vector-ref _%payload9713%_ '1)
                          '"unbound ASCENT expression variable"
                          _%payload9713%_
                          _%prior-scope9694%_)))
                 _%action9701%_))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   _%original9680%_
                                                   _%terms9698%_
                                                   _%columns9682%_)))
                                            (vector _%atom9678%_
                                                    _%terms9698%_
                                                    _%keys9715%_
                                                    (gerbil-ascent/core/positive-plan#compile-parts-matcher
                                                     _%terms9698%_)
                                                    (gerbil-ascent/core/positive-plan#compile-selected-parts-matcher
                                                     _%terms9698%_
                                                     _%columns9682%_
                                                     _%keys9715%_)))
                                          (if (eq? 'guard _%$e9675%_)
                                              (vector 'guard
                                                      (_%lower-call__0__3486334865%_
                                                       (vector-ref
                                                        _%clause9673%_
                                                        '1)
                                                       (vector-ref
                                                        _%clause9673%_
                                                        '2)
                                                       '"unbound ASCENT clause variable"))
                                              (if (eq? 'binding _%$e9675%_)
                                                  (let* ((_%call9718%_
                                                          (_%lower-call__0__3486334865%_
                                                           (vector-ref
                                                            _%clause9673%_
                                                            '2)
                                                           (vector-ref
                                                            _%clause9673%_
                                                            '3)
                                                           '"unbound ASCENT clause variable"))
                                                         (_%slot9720%_
                                                          (_%fresh-slot!9669%_
                                                           (vector-ref
                                                            _%clause9673%_
                                                            '1))))
                                                    (vector 'binding
                                                            _%slot9720%_
                                                            _%call9718%_))
                                                  (_%unsupported9660%_
                                                   '#f))))))
                                  _%body9658%_))
                            (_%outputs9731%_
                             (map (lambda (_%head9725%_)
                                    (let ((_%terms9729%_
                                           (map (lambda (_%term9727%_)
                                                  (_%lower9671%_
                                                   _%term9727%_
                                                   '#t))
                                                (vector-ref _%head9725%_ '1))))
                                      (vector _%head9725%_
                                              _%terms9729%_
                                              (gerbil-ascent/core/positive-plan#compile-parts-output
                                               _%terms9729%_))))
                                  _%heads9657%_)))
                       (vector _%outputs9731%_
                               (gerbil-ascent/core/positive-plan#compile-action-segments
                                _%actions9723%_)
                               _%count9664%_
                               _%pure?9665%_
                               (let ((__tmp35044
                                      (let ((__tmp35045
                                             (lambda (_%action9734%_)
                                               (vector? (vector-ref
                                                         _%action9734%_
                                                         '0)))))
                                        (declare (not safe))
                                        (##filter
                                         __tmp35045
                                         _%actions9723%_))))
                                 (declare (not safe))
                                 (##length __tmp35044)))))))))
          (declare (not safe))
          (##call-with-current-continuation __tmp35034))))
    (define gerbil-ascent/core/positive-plan#callback-prefix
      (lambda (_%actions9614%_)
        (let* ((_%$%actions96159624%_ _%actions9614%_)
               (_%$%E96189628%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%actions96159624%_
                           '([])
                           '([action . remaining])))
                  '#!void)))
          (let ((_%$%K96229654%_ (lambda () (values '() '())))
                (_%$%K96199638%_
                 (lambda (_%remaining9632%_ _%action9633%_)
                   (if (vector? (vector-ref _%action9633%_ '0))
                       (values '() _%actions9614%_)
                       (let ((_g35046_
                              (gerbil-ascent/core/positive-plan#callback-prefix
                               _%remaining9632%_)))
                         (begin
                           (let ((_g35047_
                                  (let ()
                                    (declare (not safe))
                                    (if (##values? _g35046_)
                                        (##values-length _g35046_)
                                        1))))
                             (if (not (let ()
                                        (declare (not safe))
                                        (##fx= _g35047_ 2)))
                                 (error "Context expects 2 values" _g35047_)))
                           (let ((_%prefix9635%_
                                  (let ()
                                    (declare (not safe))
                                    (##values-ref _g35046_ 0)))
                                 (_%suffix9636%_
                                  (let ()
                                    (declare (not safe))
                                    (##values-ref _g35046_ 1))))
                             (values (cons _%action9633%_ _%prefix9635%_)
                                     _%suffix9636%_))))))))
            (let ((_%$%try-match96179650%_
                   (lambda ()
                     (if (pair? _%$%actions96159624%_)
                         (let ((_%$%tl96219643%_
                                (let ()
                                  (declare (not safe))
                                  (##cdr _%$%actions96159624%_)))
                               (_%$%hd96209641%_
                                (let ()
                                  (declare (not safe))
                                  (##car _%$%actions96159624%_))))
                           (let ((_%action9646%_ _%$%hd96209641%_)
                                 (_%remaining9648%_ _%$%tl96219643%_))
                             (_%$%K96199638%_
                              _%remaining9648%_
                              _%action9646%_)))
                         (_%$%E96189628%_)))))
              (if (null? _%$%actions96159624%_)
                  (_%$%K96229654%_)
                  (_%$%try-match96179650%_)))))))
    (define gerbil-ascent/core/positive-plan#compile-action-segments
      (lambda (_%actions9609%_)
        (if (null? _%actions9609%_)
            '()
            (if (vector? (vector-ref (car _%actions9609%_) '0))
                (cons (car _%actions9609%_)
                      (gerbil-ascent/core/positive-plan#compile-action-segments
                       (cdr _%actions9609%_)))
                (let ((_g35048_
                       (gerbil-ascent/core/positive-plan#callback-prefix
                        _%actions9609%_)))
                  (begin
                    (let ((_g35049_
                           (let ()
                             (declare (not safe))
                             (if (##values? _g35048_)
                                 (##values-length _g35048_)
                                 1))))
                      (if (not (let ()
                                 (declare (not safe))
                                 (##fx= _g35049_ 2)))
                          (error "Context expects 2 values" _g35049_)))
                    (let ((_%segment9611%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g35048_ 0)))
                          (_%remaining9612%_
                           (let ()
                             (declare (not safe))
                             (##values-ref _g35048_ 1))))
                      (cons (vector 'callbacks
                                    (let ()
                                      (declare (not safe))
                                      (gerbil-ascent/core/expression-plan#gerbil-ascent-compile-frame-sequence
                                       _%segment9611%_)))
                            (gerbil-ascent/core/positive-plan#compile-action-segments
                             _%remaining9612%_)))))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan-with-outputs
      (lambda (_%plan9606%_ _%outputs9607%_)
        (vector _%outputs9607%_
                (vector-ref _%plan9606%_ '1)
                (vector-ref _%plan9606%_ '2)
                (vector-ref _%plan9606%_ '3)
                (vector-ref _%plan9606%_ '4))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-pure-positive-plan?
      (lambda (_%plan9604%_)
        (if _%plan9604%_ (vector-ref _%plan9604%_ '3) '#f)))
    (define gerbil-ascent/core/positive-plan#match-row!
      (lambda (_%terms9592%_ _%row9593%_ _%frame9594%_)
        (if (null? _%terms9592%_)
            '#t
            (let* ((_%term9596%_ (car _%terms9592%_))
                   (_%value9598%_ (car _%row9593%_)))
              (if (let ((_%$e9601%_ (car _%term9596%_)))
                    (if (eq? 'fresh _%$e9601%_)
                        (begin
                          (vector-set!
                           _%frame9594%_
                           (cdr _%term9596%_)
                           _%value9598%_)
                          '#t)
                        (if (eq? 'bound _%$e9601%_)
                            (equal? (vector-ref
                                     _%frame9594%_
                                     (cdr _%term9596%_))
                                    _%value9598%_)
                            (if (eq? 'literal _%$e9601%_)
                                (equal? (cdr _%term9596%_) _%value9598%_)
                                (if (eq? 'expression _%$e9601%_)
                                    (equal? ((cdr _%term9596%_) _%frame9594%_)
                                            _%value9598%_)
                                    (if (eq? 'wildcard _%$e9601%_)
                                        '#t
                                        '#!void))))))
                  (gerbil-ascent/core/positive-plan#match-row!
                   (cdr _%terms9592%_)
                   (cdr _%row9593%_)
                   _%frame9594%_)
                  '#f)))))
    (define gerbil-ascent/core/positive-plan#match-parts!
      (lambda (_%terms9556%_
               _%prefix9557%_
               _%left9558%_
               _%right9559%_
               _%frame9560%_)
        (if (pair? _%prefix9557%_)
            (if (let ((_%selected9562%_ (car _%terms9556%_))
                      (_%stored9564%_
                       (let () (declare (not safe)) (##car _%prefix9557%_)))
                      (_%bindings9566%_ _%frame9560%_))
                  (let ((_%$e9569%_ (car _%selected9562%_)))
                    (if (eq? 'fresh _%$e9569%_)
                        (begin
                          (vector-set!
                           _%bindings9566%_
                           (cdr _%selected9562%_)
                           _%stored9564%_)
                          '#t)
                        (if (eq? 'bound _%$e9569%_)
                            (equal? (vector-ref
                                     _%bindings9566%_
                                     (cdr _%selected9562%_))
                                    _%stored9564%_)
                            (if (eq? 'literal _%$e9569%_)
                                (equal? (cdr _%selected9562%_) _%stored9564%_)
                                (if (eq? 'expression _%$e9569%_)
                                    (equal? ((cdr _%selected9562%_)
                                             _%bindings9566%_)
                                            _%stored9564%_)
                                    (if (eq? 'wildcard _%$e9569%_)
                                        '#t
                                        '#!void)))))))
                (gerbil-ascent/core/positive-plan#match-parts!
                 (cdr _%terms9556%_)
                 (let () (declare (not safe)) (##cdr _%prefix9557%_))
                 _%left9558%_
                 _%right9559%_
                 _%frame9560%_)
                '#f)
            (if (let ((_%selected9572%_ (car _%terms9556%_))
                      (_%stored9574%_ _%left9558%_)
                      (_%bindings9576%_ _%frame9560%_))
                  (let ((_%$e9579%_ (car _%selected9572%_)))
                    (if (eq? 'fresh _%$e9579%_)
                        (begin
                          (vector-set!
                           _%bindings9576%_
                           (cdr _%selected9572%_)
                           _%stored9574%_)
                          '#t)
                        (if (eq? 'bound _%$e9579%_)
                            (equal? (vector-ref
                                     _%bindings9576%_
                                     (cdr _%selected9572%_))
                                    _%stored9574%_)
                            (if (eq? 'literal _%$e9579%_)
                                (equal? (cdr _%selected9572%_) _%stored9574%_)
                                (if (eq? 'expression _%$e9579%_)
                                    (equal? ((cdr _%selected9572%_)
                                             _%bindings9576%_)
                                            _%stored9574%_)
                                    (if (eq? 'wildcard _%$e9579%_)
                                        '#t
                                        '#!void)))))))
                (let ((_%selected9582%_ (cadr _%terms9556%_))
                      (_%stored9584%_ _%right9559%_)
                      (_%bindings9586%_ _%frame9560%_))
                  (let ((_%$e9589%_ (car _%selected9582%_)))
                    (if (eq? 'fresh _%$e9589%_)
                        (begin
                          (vector-set!
                           _%bindings9586%_
                           (cdr _%selected9582%_)
                           _%stored9584%_)
                          '#t)
                        (if (eq? 'bound _%$e9589%_)
                            (equal? (vector-ref
                                     _%bindings9586%_
                                     (cdr _%selected9582%_))
                                    _%stored9584%_)
                            (if (eq? 'literal _%$e9589%_)
                                (equal? (cdr _%selected9582%_) _%stored9584%_)
                                (if (eq? 'expression _%$e9589%_)
                                    (equal? ((cdr _%selected9582%_)
                                             _%bindings9586%_)
                                            _%stored9584%_)
                                    (if (eq? 'wildcard _%$e9589%_)
                                        '#t
                                        '#!void)))))))
                '#f))))
    (define gerbil-ascent/core/positive-plan#compile-parts-matcher
      (lambda (_%terms9358%_)
        (let* ((_%$%terms93599401%_ _%terms9358%_)
               (_%$%else93639414%_
                (lambda ()
                  (lambda (_%prefix9409%_
                           _%left9410%_
                           _%right9411%_
                           _%frame9412%_)
                    (gerbil-ascent/core/positive-plan#match-parts!
                     _%terms9358%_
                     _%prefix9409%_
                     _%left9410%_
                     _%right9411%_
                     _%frame9412%_)))))
          (let ((_%$%K93919529%_
                 (lambda (_%b9521%_ _%a9522%_)
                   (lambda (_%prefix9524%_
                            _%left9525%_
                            _%right9526%_
                            _%frame9527%_)
                     (if (null? _%prefix9524%_)
                         (begin
                           (vector-set! _%frame9527%_ _%a9522%_ _%left9525%_)
                           (vector-set! _%frame9527%_ _%b9521%_ _%right9526%_)
                           '#t)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9358%_
                          _%prefix9524%_
                          _%left9525%_
                          _%right9526%_
                          _%frame9527%_)))))
                (_%$%K93789479%_
                 (lambda (_%c9470%_ _%b9471%_ _%a9472%_)
                   (lambda (_%prefix9474%_
                            _%left9475%_
                            _%right9476%_
                            _%frame9477%_)
                     (if (and (pair? _%prefix9474%_)
                              (null? (let ()
                                       (declare (not safe))
                                       (##cdr _%prefix9474%_))))
                         (begin
                           (vector-set!
                            _%frame9477%_
                            _%a9472%_
                            (car _%prefix9474%_))
                           (vector-set! _%frame9477%_ _%b9471%_ _%left9475%_)
                           (vector-set! _%frame9477%_ _%c9470%_ _%right9476%_)
                           '#t)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9358%_
                          _%prefix9474%_
                          _%left9475%_
                          _%right9476%_
                          _%frame9477%_)))))
                (_%$%K93659427%_
                 (lambda (_%c9418%_ _%b9419%_ _%a9420%_)
                   (lambda (_%prefix9422%_
                            _%left9423%_
                            _%right9424%_
                            _%frame9425%_)
                     (if (and (pair? _%prefix9422%_)
                              (null? (let ()
                                       (declare (not safe))
                                       (##cdr _%prefix9422%_))))
                         (if (equal? (vector-ref _%frame9425%_ _%a9420%_)
                                     (car _%prefix9422%_))
                             (if (equal? (vector-ref _%frame9425%_ _%b9419%_)
                                         _%left9423%_)
                                 (begin
                                   (vector-set!
                                    _%frame9425%_
                                    _%c9418%_
                                    _%right9424%_)
                                   '#t)
                                 '#f)
                             '#f)
                         (gerbil-ascent/core/positive-plan#match-parts!
                          _%terms9358%_
                          _%prefix9422%_
                          _%left9423%_
                          _%right9424%_
                          _%frame9425%_))))))
            (if (pair? _%$%terms93599401%_)
                (let ((_%$%tl93939534%_
                       (let ()
                         (declare (not safe))
                         (##cdr _%$%terms93599401%_)))
                      (_%$%hd93929532%_
                       (let ()
                         (declare (not safe))
                         (##car _%$%terms93599401%_))))
                  (if (pair? _%$%hd93929532%_)
                      (let ((_%$%tl93999539%_
                             (let ()
                               (declare (not safe))
                               (##cdr _%$%hd93929532%_)))
                            (_%$%hd93989537%_
                             (let ()
                               (declare (not safe))
                               (##car _%$%hd93929532%_))))
                        (if (let ()
                              (declare (not safe))
                              (##eq? _%$%hd93989537%_ 'fresh))
                            (if (pair? _%$%tl93939534%_)
                                (let ((_%$%tl93959546%_
                                       (let ()
                                         (declare (not safe))
                                         (##cdr _%$%tl93939534%_)))
                                      (_%$%hd93949544%_
                                       (let ()
                                         (declare (not safe))
                                         (##car _%$%tl93939534%_))))
                                  (if (pair? _%$%hd93949544%_)
                                      (let ((_%$%tl93979551%_
                                             (let ()
                                               (declare (not safe))
                                               (##cdr _%$%hd93949544%_)))
                                            (_%$%hd93969549%_
                                             (let ()
                                               (declare (not safe))
                                               (##car _%$%hd93949544%_))))
                                        (if (let ()
                                              (declare (not safe))
                                              (##eq? _%$%hd93969549%_ 'fresh))
                                            (if (null? _%$%tl93959546%_)
                                                (let ((_%a9542%_
                                                       _%$%tl93999539%_)
                                                      (_%b9554%_
                                                       _%$%tl93979551%_))
                                                  (_%$%K93919529%_
                                                   _%b9554%_
                                                   _%a9542%_))
                                                (if (pair? _%$%tl93959546%_)
                                                    (let ((_%$%tl93849508%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl93959546%_)))
                                                          (_%$%hd93839506%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl93959546%_))))
                                                      (if (pair? _%$%hd93839506%_)
                                                          (let ((_%$%tl93869513%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%hd93839506%_)))
                        (_%$%hd93859511%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%hd93839506%_))))
                    (if (let ()
                          (declare (not safe))
                          (##eq? _%$%hd93859511%_ 'fresh))
                        (if (null? _%$%tl93849508%_)
                            (let ((_%a9492%_ _%$%tl93999539%_)
                                  (_%b9504%_ _%$%tl93979551%_)
                                  (_%c9516%_ _%$%tl93869513%_))
                              (_%$%K93789479%_ _%c9516%_ _%b9504%_ _%a9492%_))
                            (_%$%else93639414%_))
                        (_%$%else93639414%_)))
                  (_%$%else93639414%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else93639414%_)))
                                            (_%$%else93639414%_)))
                                      (_%$%else93639414%_)))
                                (_%$%else93639414%_))
                            (if (let ()
                                  (declare (not safe))
                                  (##eq? _%$%hd93989537%_ 'bound))
                                (if (pair? _%$%tl93939534%_)
                                    (let ((_%$%tl93699444%_
                                           (let ()
                                             (declare (not safe))
                                             (##cdr _%$%tl93939534%_)))
                                          (_%$%hd93689442%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%tl93939534%_))))
                                      (if (pair? _%$%hd93689442%_)
                                          (let ((_%$%tl93759449%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##cdr _%$%hd93689442%_)))
                                                (_%$%hd93749447%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (##car _%$%hd93689442%_))))
                                            (if (let ()
                                                  (declare (not safe))
                                                  (##eq? _%$%hd93749447%_
                                                         'bound))
                                                (if (pair? _%$%tl93699444%_)
                                                    (let ((_%$%tl93719456%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%tl93699444%_)))
                                                          (_%$%hd93709454%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%tl93699444%_))))
                                                      (if (pair? _%$%hd93709454%_)
                                                          (let ((_%$%tl93739461%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (let ()
                           (declare (not safe))
                           (##cdr _%$%hd93709454%_)))
                        (_%$%hd93729459%_
                         (let ()
                           (declare (not safe))
                           (##car _%$%hd93709454%_))))
                    (if (let ()
                          (declare (not safe))
                          (##eq? _%$%hd93729459%_ 'fresh))
                        (if (null? _%$%tl93719456%_)
                            (let ((_%a9440%_ _%$%tl93999539%_)
                                  (_%b9452%_ _%$%tl93759449%_)
                                  (_%c9464%_ _%$%tl93739461%_))
                              (_%$%K93659427%_ _%c9464%_ _%b9452%_ _%a9440%_))
                            (_%$%else93639414%_))
                        (_%$%else93639414%_)))
                  (_%$%else93639414%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else93639414%_))
                                                (_%$%else93639414%_)))
                                          (_%$%else93639414%_)))
                                    (_%$%else93639414%_))
                                (_%$%else93639414%_))))
                      (_%$%else93639414%_)))
                (_%$%else93639414%_))))))
    (define gerbil-ascent/core/positive-plan#compile-selected-parts-matcher
      (lambda (_%terms9285%_ _%columns9286%_ _%keys9287%_)
        (let* ((_%$%terms92889306%_ _%terms9285%_)
               (_%$%else92909314%_ (lambda () '#f))
               (_%$%K92929327%_
                (lambda (_%slot9317%_)
                  (if (member '0 _%columns9286%_)
                      (if (member '1 _%columns9286%_)
                          (if (let ((__tmp35050
                                     (lambda (_%column9319%_ _%key9320%_)
                                       (equal? _%key9320%_
                                               (list-ref
                                                _%terms9285%_
                                                _%column9319%_)))))
                                (declare (not safe))
                                (andmap__1
                                 __tmp35050
                                 _%columns9286%_
                                 _%keys9287%_))
                              (lambda (_%prefix9322%_
                                       _%left9323%_
                                       _%right9324%_
                                       _%frame9325%_)
                                (if (and (pair? _%prefix9322%_)
                                         (null? (let ()
                                                  (declare (not safe))
                                                  (##cdr _%prefix9322%_))))
                                    (begin
                                      (vector-set!
                                       _%frame9325%_
                                       _%slot9317%_
                                       _%right9324%_)
                                      '#t)
                                    (gerbil-ascent/core/positive-plan#match-parts!
                                     _%terms9285%_
                                     _%prefix9322%_
                                     _%left9323%_
                                     _%right9324%_
                                     _%frame9325%_)))
                              '#f)
                          '#f)
                      '#f))))
          (if (pair? _%$%terms92889306%_)
              (let ((_%$%hd92939330%_
                     (let () (declare (not safe)) (##car _%$%terms92889306%_)))
                    (_%$%tl92949332%_
                     (let ()
                       (declare (not safe))
                       (##cdr _%$%terms92889306%_))))
                (if (pair? _%$%hd92939330%_)
                    (let ((_%$%hd93039335%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%hd92939330%_))))
                      (if (let ()
                            (declare (not safe))
                            (##eq? _%$%hd93039335%_ 'bound))
                          (if (pair? _%$%tl92949332%_)
                              (let ((_%$%hd92959338%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%$%tl92949332%_)))
                                    (_%$%tl92969340%_
                                     (let ()
                                       (declare (not safe))
                                       (##cdr _%$%tl92949332%_))))
                                (if (pair? _%$%hd92959338%_)
                                    (let ((_%$%hd93019343%_
                                           (let ()
                                             (declare (not safe))
                                             (##car _%$%hd92959338%_))))
                                      (if (let ()
                                            (declare (not safe))
                                            (##eq? _%$%hd93019343%_ 'bound))
                                          (if (pair? _%$%tl92969340%_)
                                              (let ((_%$%hd92979346%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##car _%$%tl92969340%_)))
                                                    (_%$%tl92989348%_
                                                     (let ()
                                                       (declare (not safe))
                                                       (##cdr _%$%tl92969340%_))))
                                                (if (pair? _%$%hd92979346%_)
                                                    (let ((_%$%hd92999351%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##car _%$%hd92979346%_)))
                                                          (_%$%tl93009353%_
                                                           (let ()
                                                             (declare
                                                               (not safe))
                                                             (##cdr _%$%hd92979346%_))))
                                                      (if (let ()
                                                            (declare
                                                              (not safe))
                                                            (##eq? _%$%hd92999351%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           'fresh))
                  (let ((_%slot9356%_ _%$%tl93009353%_))
                    (if (null? _%$%tl92989348%_)
                        (_%$%K92929327%_ _%slot9356%_)
                        (_%$%else92909314%_)))
                  (_%$%else92909314%_)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                    (_%$%else92909314%_)))
                                              (_%$%else92909314%_))
                                          (_%$%else92909314%_)))
                                    (_%$%else92909314%_)))
                              (_%$%else92909314%_))
                          (_%$%else92909314%_)))
                    (_%$%else92909314%_)))
              (_%$%else92909314%_)))))
    (define gerbil-ascent/core/positive-plan#term-value
      (lambda (_%term9279%_ _%frame9280%_)
        (let ((_%$e9282%_ (car _%term9279%_)))
          (if (eq? 'literal _%$e9282%_)
              (cdr _%term9279%_)
              (if (eq? 'expression _%$e9282%_)
                  ((cdr _%term9279%_) _%frame9280%_)
                  (vector-ref _%frame9280%_ (cdr _%term9279%_)))))))
    (define gerbil-ascent/core/positive-plan#compile-parts-output
      (lambda (_%terms9033%_)
        (if (and (<= (length _%terms9033%_) '4)
                 (let ((__tmp35051
                        (lambda (_%term9035%_)
                          (eq? (car _%term9035%_) 'bound))))
                   (declare (not safe))
                   (andmap__0 __tmp35051 _%terms9033%_)))
            (let* ((_%$%g90369070%_ (map cdr _%terms9033%_))
                   (_%$%else90429082%_
                    (lambda ()
                      (lambda (_%frame9078%_)
                        (let ((__tmp35052
                               (let ((__tmp35054
                                      (lambda (_%slot9080%_)
                                        (vector-ref
                                         _%frame9078%_
                                         _%slot9080%_)))
                                     (__tmp35053 (map cdr _%terms9033%_)))
                                 (declare (not safe))
                                 (##map __tmp35054 __tmp35053))))
                          (declare (not safe))
                          (##apply list __tmp35052))))))
              (let ((_%$%K90689272%_
                     (lambda () (lambda (_%frame9270%_) (list))))
                    (_%$%K90659256%_
                     (lambda (_%one9246%_)
                       (lambda (_%frame9248%_)
                         (let* ((_%slot9250%_ _%one9246%_)
                                (_%next9252%_
                                 (vector-ref _%frame9248%_ _%slot9250%_)))
                           (list _%next9252%_)))))
                    (_%$%K90609225%_
                     (lambda (_%two9208%_ _%one9209%_)
                       (lambda (_%frame9211%_)
                         (let* ((_%slot9213%_ _%one9209%_)
                                (_%next9215%_
                                 (vector-ref _%frame9211%_ _%slot9213%_))
                                (_%slot9219%_ _%two9208%_)
                                (_%next9221%_
                                 (vector-ref _%frame9211%_ _%slot9219%_)))
                           (list _%next9215%_ _%next9221%_)))))
                    (_%$%K90539180%_
                     (lambda (_%three9156%_ _%two9157%_ _%one9158%_)
                       (lambda (_%frame9160%_)
                         (let* ((_%slot9162%_ _%one9158%_)
                                (_%next9164%_
                                 (vector-ref _%frame9160%_ _%slot9162%_))
                                (_%slot9168%_ _%two9157%_)
                                (_%next9170%_
                                 (vector-ref _%frame9160%_ _%slot9168%_))
                                (_%slot9174%_ _%three9156%_)
                                (_%next9176%_
                                 (vector-ref _%frame9160%_ _%slot9174%_)))
                           (list _%next9164%_ _%next9170%_ _%next9176%_)))))
                    (_%$%K90449121%_
                     (lambda (_%four9086%_
                              _%three9088%_
                              _%two9090%_
                              _%one9092%_)
                       (lambda (_%frame9095%_)
                         (let* ((_%slot9097%_ _%one9092%_)
                                (_%next9099%_
                                 (vector-ref _%frame9095%_ _%slot9097%_))
                                (_%slot9103%_ _%two9090%_)
                                (_%next9105%_
                                 (vector-ref _%frame9095%_ _%slot9103%_))
                                (_%slot9109%_ _%three9088%_)
                                (_%next9111%_
                                 (vector-ref _%frame9095%_ _%slot9109%_))
                                (_%slot9115%_ _%four9086%_)
                                (_%next9117%_
                                 (vector-ref _%frame9095%_ _%slot9115%_)))
                           (list _%next9099%_
                                 _%next9105%_
                                 _%next9111%_
                                 _%next9117%_))))))
                (let ((_%$%try-match90389266%_
                       (lambda ()
                         (if (pair? _%$%g90369070%_)
                             (let ((_%$%tl90679261%_
                                    (let ()
                                      (declare (not safe))
                                      (##cdr _%$%g90369070%_)))
                                   (_%$%hd90669259%_
                                    (let ()
                                      (declare (not safe))
                                      (##car _%$%g90369070%_))))
                               (if (null? _%$%tl90679261%_)
                                   (let ((_%one9264%_ _%$%hd90669259%_))
                                     (_%$%K90659256%_ _%one9264%_))
                                   (if (pair? _%$%tl90679261%_)
                                       (let ((_%$%tl90649237%_
                                              (let ()
                                                (declare (not safe))
                                                (##cdr _%$%tl90679261%_)))
                                             (_%$%hd90639235%_
                                              (let ()
                                                (declare (not safe))
                                                (##car _%$%tl90679261%_))))
                                         (if (null? _%$%tl90649237%_)
                                             (let ((_%one9233%_
                                                    _%$%hd90669259%_)
                                                   (_%two9240%_
                                                    _%$%hd90639235%_))
                                               (_%$%K90609225%_
                                                _%two9240%_
                                                _%one9233%_))
                                             (if (pair? _%$%tl90649237%_)
                                                 (let ((_%$%tl90599199%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##cdr _%$%tl90649237%_)))
                                                       (_%$%hd90589197%_
                                                        (let ()
                                                          (declare (not safe))
                                                          (##car _%$%tl90649237%_))))
                                                   (if (null? _%$%tl90599199%_)
                                                       (let ((_%one9188%_
                                                              _%$%hd90669259%_)
                                                             (_%two9195%_
                                                              _%$%hd90639235%_)
                                                             (_%three9202%_
                                                              _%$%hd90589197%_))
                                                         (_%$%K90539180%_
                                                          _%three9202%_
                                                          _%two9195%_
                                                          _%one9188%_))
                                                       (if (pair? _%$%tl90599199%_)
                                                           (let ((_%$%tl90529147%_
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ()
                            (declare (not safe))
                            (##cdr _%$%tl90599199%_)))
                         (_%$%hd90519145%_
                          (let ()
                            (declare (not safe))
                            (##car _%$%tl90599199%_))))
                     (if (null? _%$%tl90529147%_)
                         (let ((_%one9129%_ _%$%hd90669259%_)
                               (_%two9136%_ _%$%hd90639235%_)
                               (_%three9143%_ _%$%hd90589197%_)
                               (_%four9150%_ _%$%hd90519145%_))
                           (_%$%K90449121%_
                            _%four9150%_
                            _%three9143%_
                            _%two9136%_
                            _%one9129%_))
                         (_%$%else90429082%_)))
                   (_%$%else90429082%_))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (_%$%else90429082%_))))
                                       (_%$%else90429082%_))))
                             (_%$%else90429082%_)))))
                  (if (null? _%$%g90369070%_)
                      (_%$%K90689272%_)
                      (_%$%try-match90389266%_)))))
            (lambda (_%frame9275%_)
              (map (lambda (_%term9277%_)
                     (gerbil-ascent/core/positive-plan#term-value
                      _%term9277%_
                      _%frame9275%_))
                   _%terms9033%_)))))
    (define gerbil-ascent/core/positive-plan#emit-parts-heads!
      (lambda (_%heads9025%_ _%frame9026%_ _%emit-row!9027%_)
        (if (null? _%heads9025%_)
            '#!void
            (begin
              (let ((_%head9029%_ (car _%heads9025%_)))
                (_%emit-row!9027%_
                 (vector-ref _%head9029%_ '0)
                 (if (> (vector-length _%head9029%_) '2)
                     ((vector-ref _%head9029%_ '2) _%frame9026%_)
                     (map (lambda (_%term9031%_)
                            (gerbil-ascent/core/positive-plan#term-value
                             _%term9031%_
                             _%frame9026%_))
                          (vector-ref _%head9029%_ '1)))))
              (gerbil-ascent/core/positive-plan#emit-parts-heads!
               (cdr _%heads9025%_)
               _%frame9026%_
               _%emit-row!9027%_)))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
      (lambda (_%plan8984%_
               _%frame8985%_
               _%delta-at8986%_
               _%rows-access8987%_
               _%emit-row!8988%_
               _%checkpoint!8989%_
               _%parts-access8990%_)
        (if (and (vector? _%frame8985%_)
                 (>= (let ()
                       (declare (not safe))
                       (##vector-length _%frame8985%_))
                     (vector-ref _%plan8984%_ '2)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT positive plan frame is smaller than compiled extent")))
        (if (and (exact-integer? _%delta-at8986%_)
                 (or (= _%delta-at8986%_ '-1)
                     (and (<= '0 _%delta-at8986%_)
                          (< _%delta-at8986%_ (vector-ref _%plan8984%_ '4)))))
            '#!void
            (let ()
              (declare (not safe))
              (error '"ASCENT positive plan delta selector outside compiled atom extent")))
        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
         (vector-ref _%plan8984%_ '1)
         (vector-ref _%plan8984%_ '0)
         _%frame8985%_
         _%delta-at8986%_
         '0
         _%rows-access8987%_
         _%emit-row!8988%_
         _%checkpoint!8989%_
         _%parts-access8990%_)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__0
      (lambda (_%plan8998%_
               _%frame8999%_
               _%delta-at9000%_
               _%rows-access9001%_
               _%emit-row!9002%_)
        (let* ((_%checkpoint!9004%_ '#f) (_%parts-access9006%_ '#f))
          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
           _%plan8998%_
           _%frame8999%_
           _%delta-at9000%_
           _%rows-access9001%_
           _%emit-row!9002%_
           _%checkpoint!9004%_
           _%parts-access9006%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
      (lambda (_%plan9008%_
               _%frame9009%_
               _%delta-at9010%_
               _%rows-access9011%_
               _%emit-row!9012%_
               _%checkpoint!9013%_)
        (let ((_%parts-access9015%_ '#f))
          (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
           _%plan9008%_
           _%frame9009%_
           _%delta-at9010%_
           _%rows-access9011%_
           _%emit-row!9012%_
           _%checkpoint!9013%_
           _%parts-access9015%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!
      (lambda _g35055_
        (let ((_g35056_ (let () (declare (not safe)) (##length _g35055_))))
          (cond ((let () (declare (not safe)) (##fx= _g35056_ 5))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__0
                        _g35055_))
                ((let () (declare (not safe)) (##fx= _g35056_ 6))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                        _g35055_))
                ((let () (declare (not safe)) (##fx= _g35056_ 7))
                 (apply gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__%
                        _g35055_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!
                  _g35055_))))))
    (define gerbil-ascent/core/positive-plan#visit-positive-atoms!
      (lambda (_%atoms8779%_
               _%heads8780%_
               _%frame8781%_
               _%delta-at8782%_
               _%depth8783%_
               _%rows-access8784%_
               _%emit-row!8785%_
               _%checkpoint!8786%_
               _%parts-access8787%_)
        (let* ((_%$%atoms89218930%_ _%atoms8779%_)
               (_%$%E89248934%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (error '"No clause matching"
                           _%$%atoms89218930%_
                           '([])
                           '([action . _])))
                  '#!void)))
          (let ((_%$%K89288980%_
                 (lambda ()
                   (gerbil-ascent/core/positive-plan#emit-parts-heads!
                    _%heads8780%_
                    _%frame8781%_
                    _%emit-row!8785%_)))
                (_%$%K89258968%_
                 (lambda (_%action8938%_)
                   (let ((_%$e8940%_ (vector-ref _%action8938%_ '0)))
                     (if (eq? 'callbacks _%$e8940%_)
                         (if ((vector-ref _%action8938%_ '1) _%frame8781%_)
                             (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                              (cdr _%atoms8779%_)
                              _%heads8780%_
                              _%frame8781%_
                              _%delta-at8782%_
                              _%depth8783%_
                              _%rows-access8784%_
                              _%emit-row!8785%_
                              _%checkpoint!8786%_
                              _%parts-access8787%_)
                             '#!void)
                         (if (and _%parts-access8787%_
                                  (_%parts-access8787%_
                                   (vector-ref _%action8938%_ '0)
                                   _%frame8781%_
                                   (= _%depth8783%_ _%delta-at8782%_)
                                   (vector-ref _%action8938%_ '2)
                                   (lambda (_%prefix8943%_
                                            _%left8944%_
                                            _%right8945%_)
                                     (if _%checkpoint!8786%_
                                         (_%checkpoint!8786%_)
                                         '#!void)
                                     (if ((or (vector-ref _%action8938%_ '4)
                                              (vector-ref _%action8938%_ '3))
                                          _%prefix8943%_
                                          _%left8944%_
                                          _%right8945%_
                                          _%frame8781%_)
                                         (if (null? (cdr _%atoms8779%_))
                                             (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                              _%heads8780%_
                                              _%frame8781%_
                                              _%emit-row!8785%_)
                                             (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                              (cdr _%atoms8779%_)
                                              _%heads8780%_
                                              _%frame8781%_
                                              _%delta-at8782%_
                                              (+ _%depth8783%_ '1)
                                              _%rows-access8784%_
                                              _%emit-row!8785%_
                                              _%checkpoint!8786%_
                                              _%parts-access8787%_))
                                         '#!void))))
                             '#!void
                             (let ((_%rows8950%_
                                    (_%rows-access8784%_
                                     (vector-ref _%action8938%_ '0)
                                     _%frame8781%_
                                     (= _%depth8783%_ _%delta-at8782%_)
                                     (vector-ref _%action8938%_ '2))))
                               (if (or (pair? _%rows8950%_)
                                       (null? _%rows8950%_))
                                   (let _%candidates8956%_ ((_%remaining8958%_
                                                             _%rows8950%_))
                                     (if (null? _%remaining8958%_)
                                         '#!void
                                         (begin
                                           (if _%checkpoint!8786%_
                                               (_%checkpoint!8786%_)
                                               '#!void)
                                           (if (gerbil-ascent/core/positive-plan#match-row!
                                                (vector-ref _%action8938%_ '1)
                                                (car _%remaining8958%_)
                                                _%frame8781%_)
                                               (if (null? (cdr _%atoms8779%_))
                                                   (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                    _%heads8780%_
                                                    _%frame8781%_
                                                    _%emit-row!8785%_)
                                                   (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                    (cdr _%atoms8779%_)
                                                    _%heads8780%_
                                                    _%frame8781%_
                                                    _%delta-at8782%_
                                                    (+ _%depth8783%_ '1)
                                                    _%rows-access8784%_
                                                    _%emit-row!8785%_
                                                    _%checkpoint!8786%_
                                                    _%parts-access8787%_))
                                               '#!void)
                                           (_%candidates8956%_
                                            (cdr _%remaining8958%_)))))
                                   (if (let ()
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-row-parts?
                                          _%rows8950%_))
                                       (let ((__tmp35057
                                              (lambda (_%prefix8961%_
                                                       _%left8962%_
                                                       _%right8963%_)
                                                (if _%checkpoint!8786%_
                                                    (_%checkpoint!8786%_)
                                                    '#!void)
                                                (if ((vector-ref
                                                      _%action8938%_
                                                      '3)
                                                     _%prefix8961%_
                                                     _%left8962%_
                                                     _%right8963%_
                                                     _%frame8781%_)
                                                    (if (null? (cdr _%atoms8779%_))
                                                        (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                         _%heads8780%_
                                                         _%frame8781%_
                                                         _%emit-row!8785%_)
                                                        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                         (cdr _%atoms8779%_)
                                                         _%heads8780%_
                                                         _%frame8781%_
                                                         _%delta-at8782%_
                                                         (+ _%depth8783%_ '1)
                                                         _%rows-access8784%_
                                                         _%emit-row!8785%_
                                                         _%checkpoint!8786%_
                                                         _%parts-access8787%_))
                                                    '#!void))))
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row-parts
                                          __tmp35057
                                          _%rows8950%_))
                                       (let ((__tmp35058
                                              (lambda (_%row8966%_)
                                                (if _%checkpoint!8786%_
                                                    (_%checkpoint!8786%_)
                                                    '#!void)
                                                (if (gerbil-ascent/core/positive-plan#match-row!
                                                     (vector-ref
                                                      _%action8938%_
                                                      '1)
                                                     _%row8966%_
                                                     _%frame8781%_)
                                                    (if (null? (cdr _%atoms8779%_))
                                                        (gerbil-ascent/core/positive-plan#emit-parts-heads!
                                                         _%heads8780%_
                                                         _%frame8781%_
                                                         _%emit-row!8785%_)
                                                        (gerbil-ascent/core/positive-plan#visit-positive-atoms!
                                                         (cdr _%atoms8779%_)
                                                         _%heads8780%_
                                                         _%frame8781%_
                                                         _%delta-at8782%_
                                                         (+ _%depth8783%_ '1)
                                                         _%rows-access8784%_
                                                         _%emit-row!8785%_
                                                         _%checkpoint!8786%_
                                                         _%parts-access8787%_))
                                                    '#!void))))
                                         (declare (not safe))
                                         (gerbil-ascent/core/relation-view#gerbil-ascent-for-each-row
                                          __tmp35058
                                          _%rows8950%_)))))))))))
            (let ((_%$%try-match89238976%_
                   (lambda ()
                     (if (pair? _%$%atoms89218930%_)
                         (let* ((_%$%hd89268971%_
                                 (let ()
                                   (declare (not safe))
                                   (##car _%$%atoms89218930%_)))
                                (_%action8974%_ _%$%hd89268971%_))
                           (_%$%K89258968%_ _%action8974%_))
                         (_%$%E89248934%_)))))
              (if (null? _%$%atoms89218930%_)
                  (_%$%K89288980%_)
                  (_%$%try-match89238976%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-key
      (lambda (_%terms8770%_
               _%columns8771%_
               _%environment8772%_
               _%slot-terms8773%_)
        (if _%slot-terms8773%_
            (map (lambda (_%term8775%_)
                   (gerbil-ascent/core/positive-plan#term-value
                    _%term8775%_
                    _%environment8772%_))
                 _%slot-terms8773%_)
            (map (lambda (_%column8777%_)
                   (gerbil-ascent/core/positive-plan#index-term-value
                    (list-ref _%terms8770%_ _%column8777%_)
                    _%environment8772%_))
                 _%columns8771%_))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-key/terms
      (lambda (_%key-terms8765%_ _%environment8766%_)
        (map (lambda (_%term8768%_)
               (gerbil-ascent/core/positive-plan#index-term-value
                _%term8768%_
                _%environment8766%_))
             _%key-terms8765%_)))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-index-value
      (lambda (_%term8761%_ _%environment8762%_ _%slot-term8763%_)
        (if _%slot-term8763%_
            (gerbil-ascent/core/positive-plan#term-value
             _%slot-term8763%_
             _%environment8762%_)
            (gerbil-ascent/core/positive-plan#index-term-value
             _%term8761%_
             _%environment8762%_))))
    (define gerbil-ascent/core/positive-plan#index-term-value
      (lambda (_%term8753%_ _%environment8754%_)
        (let ((_%$e8756%_ (car _%term8753%_)))
          (if (eq? 'literal _%$e8756%_)
              (cdr _%term8753%_)
              (if (eq? 'expression _%$e8756%_)
                  (let ((__tmp35059 (cdr _%term8753%_)))
                    (declare (not safe))
                    (gerbil-ascent/core/rule-bindings#gerbil-ascent-expression-value
                     __tmp35059
                     _%environment8754%_))
                  (let ((_%bound8759%_
                         (assq (cdr _%term8753%_) _%environment8754%_)))
                    (if _%bound8759%_
                        '#!void
                        (let ((__tmp35060 (cdr _%term8753%_)))
                          (declare (not safe))
                          (error '"unbound ASCENT index variable" __tmp35060)))
                    (cdr _%bound8759%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-emit-heads!
      (lambda (_%heads8743%_ _%environment8744%_ _%emit-row!8745%_)
        (let _%emit8747%_ ((_%remaining8749%_ _%heads8743%_))
          (if (null? _%remaining8749%_)
              '#!void
              (begin
                (let ((_%head8751%_ (car _%remaining8749%_)))
                  (_%emit-row!8745%_
                   _%head8751%_
                   (let ((__tmp35061 (vector-ref _%head8751%_ '1)))
                     (declare (not safe))
                     (gerbil-ascent/core/rule-bindings#gerbil-ascent-head-row
                      __tmp35061
                      _%environment8744%_))))
                (_%emit8747%_ (cdr _%remaining8749%_)))))))
    (define gerbil-ascent/core/positive-plan#gerbil-ascent-prepare-rule-activations
      (lambda (_%active8737%_)
        (vector-map
         (lambda (_%rules8739%_)
           (map (lambda (_%rule8741%_)
                  (vector (vector-ref _%rule8741%_ '0)
                          (vector-ref _%rule8741%_ '1)
                          (vector-ref _%rule8741%_ '2)
                          (vector-ref _%rule8741%_ '3)
                          (list->vector
                           (gerbil-ascent/core/positive-plan#active-prefix
                            (vector-ref _%rule8741%_ '1)))
                          (gerbil-ascent/core/positive-plan#gerbil-ascent-positive-plan
                           _%rule8741%_)))
                _%rules8739%_))
         _%active8737%_)))
    (define gerbil-ascent/core/positive-plan#active-prefix
      (lambda (_%body8731%_)
        (if (and (pair? _%body8731%_)
                 (eq? (vector-ref
                       (let () (declare (not safe)) (##car _%body8731%_))
                       '0)
                      'atom))
            (let ((_%atom8733%_ (vector-ref (car _%body8731%_) '1)))
              (cons (vector-ref _%atom8733%_ '0)
                    (if (and (null? (vector-ref _%atom8733%_ '2))
                             (let ((__tmp35063
                                    (lambda (_%term8735%_)
                                      (eq? (car _%term8735%_) 'variable)))
                                   (__tmp35062 (vector-ref _%atom8733%_ '1)))
                               (declare (not safe))
                               (andmap__0 __tmp35063 __tmp35062)))
                        (gerbil-ascent/core/positive-plan#active-prefix
                         (cdr _%body8731%_))
                        '())))
            '())))))
