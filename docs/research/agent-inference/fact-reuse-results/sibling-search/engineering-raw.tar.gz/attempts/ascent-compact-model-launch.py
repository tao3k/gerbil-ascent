import os,sys,subprocess
from pathlib import Path
origin=Path('/Users/guangtao/ghq/github.com/tao3k/gerbil-ascent');sys.path.insert(0,str(origin/'python/src'))
from ascent_test_support.movie_study import provider_key
root=Path('/private/var/folders/pj/n33bqzy94yn9wxggj3rny0d00000gn/T/ascent-clean-rebuild.lsy7lb/source');build=root.parent;env=os.environ.copy();env['DEEPSEEK_API_KEY']=provider_key()
env['PYTHONPATH']=str(root/'python/src')+':'+str(build/'api');env['GERBIL_PATH']=str(build/'gerbil')
mode=sys.argv[1];assert mode in ('branch-live','shared-label','branch-report','shared-check')
cmd=[str(root/'python/.venv/bin/python'),'-m','ascent_test_support.evidence_chain_study',mode,str(build/'frozen'),str(build/'run')]
raise SystemExit(subprocess.call(cmd,env=env,cwd=root))
