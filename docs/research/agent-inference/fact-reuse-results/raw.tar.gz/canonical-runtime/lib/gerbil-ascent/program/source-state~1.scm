(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/source-state[1]#_g37327_|
    (##structure
     gx#syntax-quote::t
     'source-state::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37329_|
    (##structure
     gx#syntax-quote::t
     'make-source-state
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37331_|
    (##structure
     gx#syntax-quote::t
     'source-state?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37333_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37334_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37335_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37336_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37338_|
    (##structure
     gx#syntax-quote::t
     'source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37339_|
    (##structure
     gx#syntax-quote::t
     'source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37340_|
    (##structure
     gx#syntax-quote::t
     'source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37341_|
    (##structure
     gx#syntax-quote::t
     'source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37343_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37344_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37345_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37346_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37348_|
    (##structure
     gx#syntax-quote::t
     '&source-state-originals-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37349_|
    (##structure
     gx#syntax-quote::t
     '&source-state-additions-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37350_|
    (##structure
     gx#syntax-quote::t
     '&source-state-overrides-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37351_|
    (##structure
     gx#syntax-quote::t
     '&source-state-snapshot-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/source-state[1]#_g37353_|
    (gx#core-deserialize-mark
     '(0
       ($%arg16929 . _%$%arg1692916987%_)
       ($%arg16930 . _%$%arg1693017001%_)
       (id . _%id16954%_)
       (arg . _%arg17017%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g37354_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37353_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37357_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g37358_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37357_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37360_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37357_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37362_|
    (gx#core-deserialize-mark
     '(0
       ($%arg17050 . _%$%arg1705017107%_)
       ($%arg17051 . _%$%arg1705117121%_)
       (id . _%id17074%_)
       (arg . _%arg17137%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g37363_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37362_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37366_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g37367_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37366_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37369_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37366_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37371_|
    (gx#core-deserialize-mark
     '(0
       ($%arg17170 . _%$%arg1717017227%_)
       (id . _%id17194%_)
       ($%arg17171 . _%$%arg1717117241%_)
       (arg . _%arg17257%_))
     (gx#import-module '(:gerbil/core/contract Interface))))
  (define |gerbil-ascent/program/source-state[1]#_g37372_|
    (##structure
     gx#syntax-quote::t
     'with-dispatch-arguments
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37371_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37375_|
    (gx#core-deserialize-mark
     '(0)
     (gx#import-module '(:gerbil/core/contract TypedDefinitions))))
  (define |gerbil-ascent/program/source-state[1]#_g37376_|
    (##structure
     gx#syntax-quote::t
     'using
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37375_|)))
  (define |gerbil-ascent/program/source-state[1]#_g37378_|
    (##structure
     gx#syntax-quote::t
     ':-
     #f
     (gx#current-expander-context)
     (list |gerbil-ascent/program/source-state[1]#_g37375_|)))
  (begin
    (define |gerbil-ascent/program/source-state[:0:]#source-state|
      (let ((__obj37315
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37315
           'gerbil-ascent/program/source-state#source-state::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 'source-state '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37315
           '(originals additions overrides snapshot)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37315
           '(originals additions overrides snapshot)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '#f '13 '#f '#f))
        (let ((__tmp37326 |gerbil-ascent/program/source-state[1]#_g37327_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37326 '4 '#f '#f))
        (let ((__tmp37328 |gerbil-ascent/program/source-state[1]#_g37329_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37328 '14 '#f '#f))
        (let ((__tmp37330 |gerbil-ascent/program/source-state[1]#_g37331_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37330 '15 '#f '#f))
        (let ((__tmp37332
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g37333_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g37334_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g37335_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g37336_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37332 '16 '#f '#f))
        (let ((__tmp37337
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g37338_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g37339_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g37340_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g37341_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37337 '17 '#f '#f))
        (let ((__tmp37342
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g37343_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g37344_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g37345_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g37346_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37342 '18 '#f '#f))
        (let ((__tmp37347
               (cons (cons 'originals
                           |gerbil-ascent/program/source-state[1]#_g37348_|)
                     (cons (cons 'additions
                                 |gerbil-ascent/program/source-state[1]#_g37349_|)
                           (cons (cons 'overrides
                                       |gerbil-ascent/program/source-state[1]#_g37350_|)
                                 (cons (cons 'snapshot
                                             |gerbil-ascent/program/source-state[1]#_g37351_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 __tmp37347 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37315 '() '21 '#f '#f))
        __obj37315))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-source-state-rows|
      (lambda (_%$stx16911%_)
        (let* ((_%__stx3723837239%_ _%$stx16911%_)
               (_%$%g1691616937%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3723837239%_)))))
          (let ((_%__kont3724137242%_
                 (lambda (_%$%g1691817003%_)
                   (cons (let ((__tmp37352
                                |gerbil-ascent/program/source-state[1]#_g37354_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37352
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 '()))
                                     (cons (let ((__tmp37355
                                                  (lambda (_%$%g1701817021%_
                                                           _%$%g1701917024%_)
                                                    (cons _%$%g1701817021%_
                                                          _%$%g1701917024%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37355
                                              '()
                                              _%$%g1691817003%_))
                                           '()))
                               (cons (cons (let ((__tmp37356
                                                  |gerbil-ascent/program/source-state[1]#_g37358_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37356
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp37359
                                  |gerbil-ascent/program/source-state[1]#_g37360_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37359 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-source-state-rows))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 '())))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3724537246%_
                 (lambda (_%$%g1693116944%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-source-state-rows)))))
            (let* ((_%$%g1691516956%_
                    (lambda ()
                      (let ((_%$%g1693116944%_ _%__stx3723837239%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1693116944%_))
                            (_%__kont3724537246%_ _%$%g1693116944%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1691616937%_))))))
                   (_%__match3726137262%_
                    (lambda (_%$%e1691916963%_
                             _%$%hd1692016967%_
                             _%$%tl1692116970%_
                             _%__splice3724337244%_
                             _%$%target1692216973%_
                             _%$%tl1692416976%_)
                      (letrec ((_%$%loop1692516979%_
                                (lambda (_%$%hd1692316983%_
                                         _%$%arg1692916986%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1692316983%_))
                                      (let ((_%$%e1692616989%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1692316983%_))))
                                        (let ((_%$%lp-tl1692816996%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1692616989%_)))
                                              (_%$%lp-hd1692716993%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1692616989%_))))
                                          (_%$%loop1692516979%_
                                           _%$%lp-tl1692816996%_
                                           (cons _%$%lp-hd1692716993%_
                                                 _%$%arg1692916986%_))))
                                      (let ((_%$%arg1693016999%_
                                             (reverse _%$%arg1692916986%_)))
                                        (_%__kont3724137242%_
                                         _%$%arg1693016999%_))))))
                        (_%$%loop1692516979%_ _%$%target1692216973%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3723837239%_))
                  (let ((_%$%e1691916963%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3723837239%_))))
                    (let ((_%$%tl1692116970%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1691916963%_)))
                          (_%$%hd1692016967%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1691916963%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1692116970%_))
                          (let ((_%__splice3724337244%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1692116970%_
                                    '0))))
                            (let ((_%$%tl1692416976%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3724337244%_ '1)))
                                  (_%$%target1692216973%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3724337244%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1692416976%_))
                                  (_%__match3726137262%_
                                   _%$%e1691916963%_
                                   _%$%hd1692016967%_
                                   _%$%tl1692116970%_
                                   _%__splice3724337244%_
                                   _%$%target1692216973%_
                                   _%$%tl1692416976%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1691516956%_)))))
                          (let () (declare (not safe)) (_%$%g1691516956%_)))))
                  (let () (declare (not safe)) (_%$%g1691516956%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-prepare-source-replacement|
      (lambda (_%$stx17032%_)
        (let* ((_%__stx3726437265%_ _%$stx17032%_)
               (_%$%g1703717058%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3726437265%_)))))
          (let ((_%__kont3726737268%_
                 (lambda (_%$%g1703917123%_)
                   (cons (let ((__tmp37361
                                |gerbil-ascent/program/source-state[1]#_g37363_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37361
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       '())))
                                     (cons (let ((__tmp37364
                                                  (lambda (_%$%g1713817141%_
                                                           _%$%g1713917144%_)
                                                    (cons _%$%g1713817141%_
                                                          _%$%g1713917144%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37364
                                              '()
                                              _%$%g1703917123%_))
                                           '()))
                               (cons (cons (let ((__tmp37365
                                                  |gerbil-ascent/program/source-state[1]#_g37367_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37365
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp37368
                                  |gerbil-ascent/program/source-state[1]#_g37369_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37368 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-prepare-source-replacement))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       '()))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3727137272%_
                 (lambda (_%$%g1705217065%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-prepare-source-replacement)))))
            (let* ((_%$%g1703617076%_
                    (lambda ()
                      (let ((_%$%g1705217065%_ _%__stx3726437265%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1705217065%_))
                            (_%__kont3727137272%_ _%$%g1705217065%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1703717058%_))))))
                   (_%__match3728737288%_
                    (lambda (_%$%e1704017083%_
                             _%$%hd1704117087%_
                             _%$%tl1704217090%_
                             _%__splice3726937270%_
                             _%$%target1704317093%_
                             _%$%tl1704517096%_)
                      (letrec ((_%$%loop1704617099%_
                                (lambda (_%$%hd1704417103%_
                                         _%$%arg1705017106%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1704417103%_))
                                      (let ((_%$%e1704717109%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1704417103%_))))
                                        (let ((_%$%lp-tl1704917116%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1704717109%_)))
                                              (_%$%lp-hd1704817113%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1704717109%_))))
                                          (_%$%loop1704617099%_
                                           _%$%lp-tl1704917116%_
                                           (cons _%$%lp-hd1704817113%_
                                                 _%$%arg1705017106%_))))
                                      (let ((_%$%arg1705117119%_
                                             (reverse _%$%arg1705017106%_)))
                                        (_%__kont3726737268%_
                                         _%$%arg1705117119%_))))))
                        (_%$%loop1704617099%_ _%$%target1704317093%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3726437265%_))
                  (let ((_%$%e1704017083%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3726437265%_))))
                    (let ((_%$%tl1704217090%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1704017083%_)))
                          (_%$%hd1704117087%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1704017083%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1704217090%_))
                          (let ((_%__splice3726937270%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1704217090%_
                                    '0))))
                            (let ((_%$%tl1704517096%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3726937270%_ '1)))
                                  (_%$%target1704317093%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3726937270%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1704517096%_))
                                  (_%__match3728737288%_
                                   _%$%e1704017083%_
                                   _%$%hd1704117087%_
                                   _%$%tl1704217090%_
                                   _%__splice3726937270%_
                                   _%$%target1704317093%_
                                   _%$%tl1704517096%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1703617076%_)))))
                          (let () (declare (not safe)) (_%$%g1703617076%_)))))
                  (let () (declare (not safe)) (_%$%g1703617076%_))))))))
    (define |gerbil-ascent/program/source-state[:0:]#@gerbil-ascent-commit-source-replacement!|
      (lambda (_%$stx17152%_)
        (let* ((_%__stx3729037291%_ _%$stx17152%_)
               (_%$%g1715717178%_
                (lambda ()
                  (let ()
                    (declare (not safe))
                    (gx#raise-syntax-error
                     '#f
                     '"Bad syntax; invalid match target"
                     _%__stx3729037291%_)))))
          (let ((_%__kont3729337294%_
                 (lambda (_%$%g1715917243%_)
                   (cons (let ((__tmp37370
                                |gerbil-ascent/program/source-state[1]#_g37372_|))
                           (declare (not safe))
                           (gx#datum->syntax__%
                            __tmp37370
                            'with-dispatch-arguments
                            '#f
                            '#f))
                         (cons (cons (cons (let ()
                                             (declare (not safe))
                                             (gx#datum->syntax__0 '#f 'state))
                                           (cons (let ()
                                                   (declare (not safe))
                                                   (gx#datum->syntax__0
                                                    '#f
                                                    'index))
                                                 (cons (let ()
                                                         (declare (not safe))
                                                         (gx#datum->syntax__0
                                                          '#f
                                                          'rows))
                                                       (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'cut))
                     '()))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     (cons (let ((__tmp37373
                                                  (lambda (_%$%g1725817261%_
                                                           _%$%g1725917264%_)
                                                    (cons _%$%g1725817261%_
                                                          _%$%g1725917264%_))))
                                             (declare (not safe))
                                             (foldr__0
                                              __tmp37373
                                              '()
                                              _%$%g1715917243%_))
                                           '()))
                               (cons (cons (let ((__tmp37374
                                                  |gerbil-ascent/program/source-state[1]#_g37376_|))
                                             (declare (not safe))
                                             (gx#datum->syntax__%
                                              __tmp37374
                                              'using
                                              '#f
                                              '#f))
                                           (cons (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0 '#f 'state))
                     (cons (let ((__tmp37377
                                  |gerbil-ascent/program/source-state[1]#_g37378_|))
                             (declare (not safe))
                             (gx#datum->syntax__% __tmp37377 ':- '#f '#f))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'source-state))
                                 '())))
               '())
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (cons (cons (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (gx#datum->syntax__0
                        '#f
                        '__gerbil-ascent-commit-source-replacement!))
                     (cons (let ()
                             (declare (not safe))
                             (gx#datum->syntax__0 '#f 'state))
                           (cons (let ()
                                   (declare (not safe))
                                   (gx#datum->syntax__0 '#f 'index))
                                 (cons (let ()
                                         (declare (not safe))
                                         (gx#datum->syntax__0 '#f 'rows))
                                       (cons (let ()
                                               (declare (not safe))
                                               (gx#datum->syntax__0 '#f 'cut))
                                             '())))))
               '())))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                     '())))))
                (_%__kont3729737298%_
                 (lambda (_%$%g1717217185%_)
                   (let ()
                     (declare (not safe))
                     (gx#datum->syntax__0
                      '#f
                      'gerbil-ascent-commit-source-replacement!)))))
            (let* ((_%$%g1715617196%_
                    (lambda ()
                      (let ((_%$%g1717217185%_ _%__stx3729037291%_))
                        (if (let ()
                              (declare (not safe))
                              (gx#identifier? _%$%g1717217185%_))
                            (_%__kont3729737298%_ _%$%g1717217185%_)
                            (let ()
                              (declare (not safe))
                              (_%$%g1715717178%_))))))
                   (_%__match3731337314%_
                    (lambda (_%$%e1716017203%_
                             _%$%hd1716117207%_
                             _%$%tl1716217210%_
                             _%__splice3729537296%_
                             _%$%target1716317213%_
                             _%$%tl1716517216%_)
                      (letrec ((_%$%loop1716617219%_
                                (lambda (_%$%hd1716417223%_
                                         _%$%arg1717017226%_)
                                  (if (let ()
                                        (declare (not safe))
                                        (gx#stx-pair? _%$%hd1716417223%_))
                                      (let ((_%$%e1716717229%_
                                             (let ()
                                               (declare (not safe))
                                               (gx#syntax-e
                                                _%$%hd1716417223%_))))
                                        (let ((_%$%lp-tl1716917236%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##cdr _%$%e1716717229%_)))
                                              (_%$%lp-hd1716817233%_
                                               (let ()
                                                 (declare (not safe))
                                                 (##car _%$%e1716717229%_))))
                                          (_%$%loop1716617219%_
                                           _%$%lp-tl1716917236%_
                                           (cons _%$%lp-hd1716817233%_
                                                 _%$%arg1717017226%_))))
                                      (let ((_%$%arg1717117239%_
                                             (reverse _%$%arg1717017226%_)))
                                        (_%__kont3729337294%_
                                         _%$%arg1717117239%_))))))
                        (_%$%loop1716617219%_ _%$%target1716317213%_ '())))))
              (if (let ()
                    (declare (not safe))
                    (gx#stx-pair? _%__stx3729037291%_))
                  (let ((_%$%e1716017203%_
                         (let ()
                           (declare (not safe))
                           (gx#syntax-e _%__stx3729037291%_))))
                    (let ((_%$%tl1716217210%_
                           (let ()
                             (declare (not safe))
                             (##cdr _%$%e1716017203%_)))
                          (_%$%hd1716117207%_
                           (let ()
                             (declare (not safe))
                             (##car _%$%e1716017203%_))))
                      (if (let ()
                            (declare (not safe))
                            (gx#stx-pair/null? _%$%tl1716217210%_))
                          (let ((_%__splice3729537296%_
                                 (let ()
                                   (declare (not safe))
                                   (gx#syntax-split-splice->vector
                                    _%$%tl1716217210%_
                                    '0))))
                            (let ((_%$%tl1716517216%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref _%__splice3729537296%_ '1)))
                                  (_%$%target1716317213%_
                                   (let ()
                                     (declare (not safe))
                                     (##vector-ref
                                      _%__splice3729537296%_
                                      '0))))
                              (if (let ()
                                    (declare (not safe))
                                    (gx#stx-null? _%$%tl1716517216%_))
                                  (_%__match3731337314%_
                                   _%$%e1716017203%_
                                   _%$%hd1716117207%_
                                   _%$%tl1716217210%_
                                   _%__splice3729537296%_
                                   _%$%target1716317213%_
                                   _%$%tl1716517216%_)
                                  (let ()
                                    (declare (not safe))
                                    (_%$%g1715617196%_)))))
                          (let () (declare (not safe)) (_%$%g1715617196%_)))))
                  (let () (declare (not safe)) (_%$%g1715617196%_))))))))))
