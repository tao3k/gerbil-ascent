(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-session[1]#_g37965_|
    (##structure
     gx#syntax-quote::t
     'relational-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37967_|
    (##structure
     gx#syntax-quote::t
     'make-relational-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37969_|
    (##structure
     gx#syntax-quote::t
     'relational-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37971_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37972_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37974_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37975_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37977_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37978_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37980_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37981_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37983_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37985_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37987_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37989_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37990_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37992_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37993_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37995_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37996_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37998_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g37999_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-session|
      (let ((__obj37941
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37941
           'gerbil-ascent/program/scheme-session#relational-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37941
           'relational-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37941
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37941
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '#f '13 '#f '#f))
        (let ((__tmp37964 |gerbil-ascent/program/scheme-session[1]#_g37965_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37964 '4 '#f '#f))
        (let ((__tmp37966 |gerbil-ascent/program/scheme-session[1]#_g37967_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37966 '14 '#f '#f))
        (let ((__tmp37968 |gerbil-ascent/program/scheme-session[1]#_g37969_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37968 '15 '#f '#f))
        (let ((__tmp37970
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37971_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37972_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37970 '16 '#f '#f))
        (let ((__tmp37973
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37974_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37975_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37973 '17 '#f '#f))
        (let ((__tmp37976
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37977_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37978_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37976 '18 '#f '#f))
        (let ((__tmp37979
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37980_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37981_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 __tmp37979 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37941 '() '21 '#f '#f))
        __obj37941))
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-program-session|
      (let ((__obj37942
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37942
           'gerbil-ascent/program/scheme-session#relational-program-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37942
           'relational-program-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37942
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj37942
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '#f '13 '#f '#f))
        (let ((__tmp37982 |gerbil-ascent/program/scheme-session[1]#_g37983_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37982 '4 '#f '#f))
        (let ((__tmp37984 |gerbil-ascent/program/scheme-session[1]#_g37985_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37984 '14 '#f '#f))
        (let ((__tmp37986 |gerbil-ascent/program/scheme-session[1]#_g37987_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37986 '15 '#f '#f))
        (let ((__tmp37988
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37989_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37990_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37988 '16 '#f '#f))
        (let ((__tmp37991
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37992_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37993_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37991 '17 '#f '#f))
        (let ((__tmp37994
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37995_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37996_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37994 '18 '#f '#f))
        (let ((__tmp37997
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g37998_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g37999_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 __tmp37997 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj37942 '() '21 '#f '#f))
        __obj37942))))
