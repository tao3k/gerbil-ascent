(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/component-plan[1]#_g35648_|
    (##structure
     gx#syntax-quote::t
     'positive-component::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35650_|
    (##structure
     gx#syntax-quote::t
     'make-positive-component
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35652_|
    (##structure
     gx#syntax-quote::t
     'positive-component?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35654_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35655_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35656_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35657_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35659_|
    (##structure
     gx#syntax-quote::t
     'positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35660_|
    (##structure
     gx#syntax-quote::t
     'positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35661_|
    (##structure
     gx#syntax-quote::t
     'positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35662_|
    (##structure
     gx#syntax-quote::t
     'positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35664_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35665_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35666_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35667_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35669_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-id-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35670_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35671_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-rules-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[1]#_g35672_|
    (##structure
     gx#syntax-quote::t
     '&positive-component-predecessors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/component-plan[:0:]#positive-component|
    (let ((__obj35469
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35469
         'gerbil-ascent/program/component-plan#positive-component::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 'positive-component '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35469
         '(id members rules predecessors)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj35469
         '(id members rules predecessors)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '#f '13 '#f '#f))
      (let ((__tmp35647 |gerbil-ascent/program/component-plan[1]#_g35648_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35647 '4 '#f '#f))
      (let ((__tmp35649 |gerbil-ascent/program/component-plan[1]#_g35650_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35649 '14 '#f '#f))
      (let ((__tmp35651 |gerbil-ascent/program/component-plan[1]#_g35652_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35651 '15 '#f '#f))
      (let ((__tmp35653
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35654_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35655_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35656_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35657_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35653 '16 '#f '#f))
      (let ((__tmp35658
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35659_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35660_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35661_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35662_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35658 '17 '#f '#f))
      (let ((__tmp35663
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35664_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35665_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35666_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35667_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35663 '18 '#f '#f))
      (let ((__tmp35668
             (cons (cons 'id
                         |gerbil-ascent/program/component-plan[1]#_g35669_|)
                   (cons (cons 'members
                               |gerbil-ascent/program/component-plan[1]#_g35670_|)
                         (cons (cons 'rules
                                     |gerbil-ascent/program/component-plan[1]#_g35671_|)
                               (cons (cons 'predecessors
                                           |gerbil-ascent/program/component-plan[1]#_g35672_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 __tmp35668 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj35469 '() '21 '#f '#f))
      __obj35469)))
