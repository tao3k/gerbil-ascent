(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/tools/research/candidate-interaction::timestamp
    1791688130)
  (begin
    (define gerbil-ascent/tools/research/candidate-interaction#edges
      '((0 1) (0 2) (1 0) (1 2) (2 0) (2 1)))
    (define gerbil-ascent/tools/research/candidate-interaction#ordinals
      (lambda (_%n2291%_)
        (let _%loop2293%_ ((_%i2295%_ '0))
          (if (= _%i2295%_ _%n2291%_)
              '()
              (cons _%i2295%_ (_%loop2293%_ (+ _%i2295%_ '1)))))))
    (define gerbil-ascent/tools/research/candidate-interaction#graph
      (lambda (_%mask2286%_)
        (let ((__tmp5119
               (lambda (_%edge2288%_ _%index2289%_)
                 (if (zero? (bitwise-and
                             _%mask2286%_
                             (arithmetic-shift '1 _%index2289%_)))
                     '#f
                     _%edge2288%_)))
              (__tmp5118
               (gerbil-ascent/tools/research/candidate-interaction#ordinals
                '6)))
          (declare (not safe))
          (filter-map__1
           __tmp5119
           gerbil-ascent/tools/research/candidate-interaction#edges
           __tmp5118))))
    (define gerbil-ascent/tools/research/candidate-interaction#walk
      (lambda (_%pairs2260%_ _%origin2261%_ _%even?2262%_)
        (let _%loop2264%_ ((_%pending2266%_
                            (let ((__tmp5127
                                   (lambda (_%e2282%_)
                                     (list (cadr _%e2282%_) '1)))
                                  (__tmp5126
                                   (filter (lambda (_%e2284%_)
                                             (= _%origin2261%_
                                                (car _%e2284%_)))
                                           _%pairs2260%_)))
                              (declare (not safe))
                              (##map __tmp5127 __tmp5126)))
                           (_%seen2267%_ '()))
          (if (null? _%pending2266%_)
              (let ((__tmp5120
                     (lambda (_%v2269%_)
                       (if (let ((__tmp5121
                                  (lambda (_%s2271%_)
                                    (and (= _%v2269%_ (car _%s2271%_))
                                         (or (not _%even?2262%_)
                                             (= '0 (cadr _%s2271%_)))))))
                             (declare (not safe))
                             (ormap__0 __tmp5121 _%seen2267%_))
                           _%v2269%_
                           '#f))))
                (declare (not safe))
                (filter-map__0 __tmp5120 '(0 1 2)))
              (let ((_%s2276%_ (car _%pending2266%_)))
                (if (member _%s2276%_ _%seen2267%_)
                    (_%loop2264%_ (cdr _%pending2266%_) _%seen2267%_)
                    (_%loop2264%_
                     (let ((__tmp5125 (cdr _%pending2266%_))
                           (__tmp5122
                            (let ((__tmp5124
                                   (lambda (_%e2278%_)
                                     (list (cadr _%e2278%_)
                                           (- '1 (cadr _%s2276%_)))))
                                  (__tmp5123
                                   (filter (lambda (_%e2280%_)
                                             (= (car _%s2276%_)
                                                (car _%e2280%_)))
                                           _%pairs2260%_)))
                              (declare (not safe))
                              (##map __tmp5124 __tmp5123))))
                       (declare (not safe))
                       (##append __tmp5125 __tmp5122))
                     (cons _%s2276%_ _%seen2267%_))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#expected
      (lambda (_%case-id2251%_ _%pairs2252%_)
        (if (= _%case-id2251%_ '2)
            (let ((__tmp5128
                   (filter (lambda (_%v2254%_)
                             (member _%v2254%_
                                     (gerbil-ascent/tools/research/candidate-interaction#walk
                                      _%pairs2252%_
                                      '1
                                      '#f)))
                           (gerbil-ascent/tools/research/candidate-interaction#walk
                            _%pairs2252%_
                            '0
                            '#f))))
              (declare (not safe))
              (##map list __tmp5128))
            (let ((__tmp5129
                   (let ((__tmp5130
                          (lambda (_%u2256%_)
                            (map (lambda (_%v2258%_)
                                   (list _%u2256%_ _%v2258%_))
                                 (gerbil-ascent/tools/research/candidate-interaction#walk
                                  _%pairs2252%_
                                  _%u2256%_
                                  (= _%case-id2251%_ '1))))))
                     (declare (not safe))
                     (##map __tmp5130 '(0 1 2)))))
              (declare (not safe))
              (##apply append __tmp5129)))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__%
      (lambda (_%case-id2233%_ _%rules2234%_ _%row-budget2235%_)
        (let ((__tmp5133 (if (= _%case-id2233%_ '2) '((relation both 1)) '()))
              (__tmp5132
               (map (lambda (_%r2237%_) (cons 'rule _%r2237%_)) _%rules2234%_))
              (__tmp5131
               (list (if (= _%case-id2233%_ '2)
                         '(query both ?z)
                         '(query path ?x ?y))
                     (list 'limits '16 _%row-budget2235%_ '128))))
          (declare (not safe))
          (##append
           '(candidate (relation path 2))
           __tmp5133
           __tmp5132
           __tmp5131))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal__0
      (lambda (_%case-id2242%_ _%rules2243%_)
        (let ((_%row-budget2245%_ '64))
          (gerbil-ascent/tools/research/candidate-interaction#proposal__%
           _%case-id2242%_
           _%rules2243%_
           _%row-budget2245%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#proposal
      (lambda _g5134_
        (let ((_g5135_ (let () (declare (not safe)) (##length _g5134_))))
          (cond ((let () (declare (not safe)) (##fx= _g5135_ 2))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__0
                        _g5134_))
                ((let () (declare (not safe)) (##fx= _g5135_ 3))
                 (apply gerbil-ascent/tools/research/candidate-interaction#proposal__%
                        _g5134_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/tools/research/candidate-interaction#proposal
                  _g5134_))))))
    (define gerbil-ascent/tools/research/candidate-interaction#source
      (lambda (_%case-id2228%_ _%generation2229%_ _%pairs2230%_)
        (let ((__tmp5139
               (let ((__tmp5140 (number->string _%case-id2228%_)))
                 (declare (not safe))
                 (##string-append '"library-candidate-" __tmp5140)))
              (__tmp5136
               (let ((__tmp5138 (list (list 'edge '2 _%pairs2230%_)))
                     (__tmp5137
                      (if (= _%case-id2228%_ '2)
                          '((left 1 ((0))) (right 1 ((1))))
                          '())))
                 (declare (not safe))
                 (##append __tmp5138 __tmp5137))))
          (declare (not safe))
          (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
           __tmp5139
           _%generation2229%_
           __tmp5136))))
    (define gerbil-ascent/tools/research/candidate-interaction#wire
      (lambda (_%x2223%_)
        (if (symbol? _%x2223%_)
            (let () (declare (not safe)) (##symbol->string _%x2223%_))
            (if (pair? _%x2223%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#wire
                         _%x2223%_))
                _%x2223%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#symbols
      (lambda (_%x2217%_)
        (if (string? _%x2217%_)
            (let () (declare (not safe)) (##string->symbol _%x2217%_))
            (if (list? _%x2217%_)
                (let ()
                  (declare (not safe))
                  (##map gerbil-ascent/tools/research/candidate-interaction#symbols
                         _%x2217%_))
                (if (and (integer? _%x2217%_) (exact? _%x2217%_))
                    _%x2217%_
                    (let ()
                      (declare (not safe))
                      (error '"invalid rule datum")))))))
    (define gerbil-ascent/tools/research/candidate-interaction#observe
      (lambda (_%case-id2193%_ _%generation2194%_ _%pairs2195%_ _%rules2196%_)
        (let* ((_%s2198%_
                (gerbil-ascent/tools/research/candidate-interaction#source
                 _%case-id2193%_
                 _%generation2194%_
                 _%pairs2195%_))
               (_%p2200%_
                (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                 _%case-id2193%_
                 _%rules2196%_))
               (_%r2202%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                   _%s2198%_
                   _%p2200%_
                   '#f)))
               (_%wanted2204%_
                (gerbil-ascent/tools/research/candidate-interaction#expected
                 _%case-id2193%_
                 _%pairs2195%_))
               (_%f2206%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                   _%s2198%_
                   _%p2200%_
                   _%r2202%_
                   _%wanted2204%_)))
               (_%ht2209%_
                (let ()
                  (declare (not safe))
                  (make-hash-table__%
                   '#f
                   '10
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value
                   absent-value))))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"generation" _%generation2194%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"edges" _%pairs2195%_))
          (let ()
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"expected" _%wanted2204%_))
          (let ((__tmp5141
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%r2202%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"nativeStatus" __tmp5141))
          (let ((__tmp5142
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%r2202%_ '7 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"actual" __tmp5142))
          (let ((__tmp5143
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2206%_ '1 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"status" __tmp5143))
          (let ((__tmp5144
                 (map (lambda (_%d2212%_)
                        (let ((_%ht2214%_
                               (let ()
                                 (declare (not safe))
                                 (make-hash-table__%
                                  '#f
                                  '2
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value
                                  absent-value))))
                          (let ((__tmp5145
                                 (gerbil-ascent/tools/research/candidate-interaction#wire
                                  (##structure-ref
                                   _%d2212%_
                                   '1
                                   gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                   '#f))))
                            (declare (not safe))
                            (__hash-put! _%ht2214%_ '"code" __tmp5145))
                          (let ((__tmp5146
                                 (##structure-ref
                                  _%d2212%_
                                  '3
                                  gerbil-ascent/candidate/types#reasoning-diagnostic::t
                                  '#f)))
                            (declare (not safe))
                            (__hash-put! _%ht2214%_ '"detail" __tmp5146))
                          _%ht2214%_))
                      (let ()
                        (declare (not safe))
                        (##unchecked-structure-ref _%r2202%_ '8 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"diagnostics" __tmp5144))
          (let ((__tmp5147
                 (gerbil-ascent/tools/research/candidate-interaction#wire
                  (let ()
                    (declare (not safe))
                    (##unchecked-structure-ref _%f2206%_ '2 '#f '#f)))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"reason" __tmp5147))
          (let ((__tmp5148
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2206%_ '3 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"missing" __tmp5148))
          (let ((__tmp5149
                 (let ()
                   (declare (not safe))
                   (##unchecked-structure-ref _%f2206%_ '4 '#f '#f))))
            (declare (not safe))
            (__hash-put! _%ht2209%_ '"extra" __tmp5149))
          _%ht2209%_)))
    (define gerbil-ascent/tools/research/candidate-interaction#correct
      '(((path ?x ?y) (edge ?x ?y)) ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))
    (define gerbil-ascent/tools/research/candidate-interaction#even-rules
      '(((path ?x ?z) (edge ?x ?y) (edge ?y ?z))
        ((path ?x ?w) (path ?x ?y) (edge ?y ?z) (edge ?z ?w))))
    (define gerbil-ascent/tools/research/candidate-interaction#both-rules
      (let ()
        (declare (not safe))
        (##append
         gerbil-ascent/tools/research/candidate-interaction#correct
         '(((both ?z) (left ?x) (right ?y) (path ?x ?z) (path ?y ?z))))))
    (define gerbil-ascent/tools/research/candidate-interaction#grade
      (lambda (_%case-id2186%_ _%rules2187%_)
        (let ((__tmp5153
               (lambda (_%mask2189%_)
                 (gerbil-ascent/tools/research/candidate-interaction#observe
                  _%case-id2186%_
                  _%mask2189%_
                  (gerbil-ascent/tools/research/candidate-interaction#graph
                   _%mask2189%_)
                  _%rules2187%_)))
              (__tmp5150
               (let ((__tmp5152
                      (lambda (_%mask2191%_)
                        (not (let ()
                               (declare (not safe))
                               (##member _%mask2191%_ '(0 1 3 9))))))
                     (__tmp5151
                      (gerbil-ascent/tools/research/candidate-interaction#ordinals
                       '64)))
                 (declare (not safe))
                 (##filter __tmp5152 __tmp5151))))
          (declare (not safe))
          (##map __tmp5153 __tmp5150))))
    (define gerbil-ascent/tools/research/candidate-interaction#qualification
      (lambda (_%group2068%_)
        (let ((_%checks2070%_ '0)
              (_%mutants2071%_
               (list gerbil-ascent/tools/research/candidate-interaction#correct
                     (let ()
                       (declare (not safe))
                       (##cdr gerbil-ascent/tools/research/candidate-interaction#correct))
                     (list (let ()
                             (declare (not safe))
                             (##car gerbil-ascent/tools/research/candidate-interaction#correct)))
                     '(((path ?x ?y) (edge ?x ?y))
                       ((path ?x ?z) (path ?x ?y) (edge ?x ?z)))
                     '(((path ?x ?y) (edge ?y ?x))
                       ((path ?x ?z) (path ?x ?y) (edge ?y ?z))))))
          (let ((__tmp5155
                 (lambda (_%rules2073%_ _%index2074%_)
                   (if (= _%group2068%_ _%index2074%_)
                       (let ((_%mismatches2076%_ '0))
                         (let ((__tmp5157
                                (lambda (_%mask2078%_)
                                  (let ((_%r2080%_
                                         (gerbil-ascent/tools/research/candidate-interaction#observe
                                          '0
                                          _%mask2078%_
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           _%mask2078%_)
                                          _%rules2073%_)))
                                    (if (string=?
                                         (let* ((_%h2082%_ _%r2080%_)
                                                (_%key2085%_ '"nativeStatus")
                                                (_%default2088%_ absent-obj)
                                                (_%h2092%_ _%h2082%_)
                                                (_%h2094%_ _%h2092%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2094%_
                                            _%key2085%_
                                            _%default2088%_))
                                         '"complete")
                                        '#!void
                                        (let ()
                                          (declare (not safe))
                                          (error '"incomplete control"
                                                 _%r2080%_)))
                                    (if (string=?
                                         (let* ((_%h2112%_ _%r2080%_)
                                                (_%key2115%_ '"status")
                                                (_%default2118%_ absent-obj)
                                                (_%h2122%_ _%h2112%_)
                                                (_%h2124%_ _%h2122%_))
                                           (declare (not safe))
                                           (__hash-ref__%
                                            _%h2124%_
                                            _%key2115%_
                                            _%default2118%_))
                                         '"match")
                                        '#!void
                                        (set! _%mismatches2076%_
                                              (+ _%mismatches2076%_ '1)))
                                    (set! _%checks2070%_
                                          (+ _%checks2070%_ '1)))))
                               (__tmp5156
                                (gerbil-ascent/tools/research/candidate-interaction#ordinals
                                 '64)))
                           (declare (not safe))
                           (##for-each __tmp5157 __tmp5156))
                         (if (if (= _%index2074%_ '0)
                                 (= _%mismatches2076%_ '0)
                                 (> _%mismatches2076%_ '0))
                             '#!void
                             (let ()
                               (declare (not safe))
                               (error '"mutant control failed"))))
                       '#!void)))
                (__tmp5154
                 (gerbil-ascent/tools/research/candidate-interaction#ordinals
                  '5)))
            (declare (not safe))
            (##for-each __tmp5155 _%mutants2071%_ __tmp5154))
          (let ((__tmp5159
                 (lambda (_%id2136%_ _%rules2137%_)
                   (if (= _%group2068%_ (+ _%id2136%_ '4))
                       (let ((__tmp5161
                              (lambda (_%mask2139%_)
                                (if (string=?
                                     (let* ((_%h2141%_
                                             (gerbil-ascent/tools/research/candidate-interaction#observe
                                              _%id2136%_
                                              _%mask2139%_
                                              (gerbil-ascent/tools/research/candidate-interaction#graph
                                               _%mask2139%_)
                                              _%rules2137%_))
                                            (_%key2144%_ '"status")
                                            (_%default2147%_ absent-obj)
                                            (_%h2151%_ _%h2141%_)
                                            (_%h2153%_ _%h2151%_))
                                       (declare (not safe))
                                       (__hash-ref__%
                                        _%h2153%_
                                        _%key2144%_
                                        _%default2147%_))
                                     '"match")
                                    '#!void
                                    (let ()
                                      (declare (not safe))
                                      (error '"independent walk disagrees")))
                                (set! _%checks2070%_ (+ _%checks2070%_ '1))))
                             (__tmp5160
                              (gerbil-ascent/tools/research/candidate-interaction#ordinals
                               '64)))
                         (declare (not safe))
                         (##for-each __tmp5161 __tmp5160))
                       '#!void)))
                (__tmp5158
                 (list gerbil-ascent/tools/research/candidate-interaction#even-rules
                       gerbil-ascent/tools/research/candidate-interaction#both-rules)))
            (declare (not safe))
            (##for-each __tmp5159 '(1 2) __tmp5158))
          (if (= _%group2068%_ '7)
              (begin
                (let* ((_%s2167%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '8)))
                       (_%p2169%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__0
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct))
                       (_%r2171%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2167%_
                           _%p2169%_
                           '#f))))
                  (if (eq? (let ((__tmp5162
                                  (let ((__tmp5164
                                         (gerbil-ascent/tools/research/candidate-interaction#source
                                          '0
                                          '1
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8)))
                                        (__tmp5163
                                         (gerbil-ascent/tools/research/candidate-interaction#expected
                                          '0
                                          (gerbil-ascent/tools/research/candidate-interaction#graph
                                           '8))))
                                    (declare (not safe))
                                    (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                                     __tmp5164
                                     _%p2169%_
                                     _%r2171%_
                                     __tmp5163))))
                             (declare (not safe))
                             (##unchecked-structure-ref __tmp5162 '2 '#f '#f))
                           'unbound)
                      '#!void
                      (let ()
                        (declare (not safe))
                        (error '"stale receipt accepted"))))
                (let* ((_%s2174%_
                        (gerbil-ascent/tools/research/candidate-interaction#source
                         '0
                         '0
                         (gerbil-ascent/tools/research/candidate-interaction#graph
                          '9)))
                       (_%p2176%_
                        (gerbil-ascent/tools/research/candidate-interaction#proposal__%
                         '0
                         gerbil-ascent/tools/research/candidate-interaction#correct
                         '1))
                       (_%r2178%_
                        (let ()
                          (declare (not safe))
                          (gerbil-ascent/candidate/reasoning#reasoning-attempt__1
                           _%s2174%_
                           _%p2176%_
                           '#f)))
                       (_%f2180%_
                        (let ((__tmp5165
                               (gerbil-ascent/tools/research/candidate-interaction#expected
                                '0
                                (gerbil-ascent/tools/research/candidate-interaction#graph
                                 '9))))
                          (declare (not safe))
                          (gerbil-ascent/candidate/feedback#reasoning-compare-rows
                           _%s2174%_
                           _%p2176%_
                           _%r2178%_
                           __tmp5165))))
                  (if (eq? (let ()
                             (declare (not safe))
                             (##unchecked-structure-ref _%f2180%_ '1 '#f '#f))
                           'match)
                      (let ()
                        (declare (not safe))
                        (error '"bounded failure became match"))
                      '#!void)))
              '#!void)
          (let ((_%ht2183%_
                 (let ()
                   (declare (not safe))
                   (make-hash-table__%
                    '#f
                    '3
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value
                    absent-value))))
            (let ()
              (declare (not safe))
              (__hash-put! _%ht2183%_ '"checks" _%checks2070%_))
            (let ((__tmp5166 (= _%group2068%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2183%_ '"staleRejected" __tmp5166))
            (let ((__tmp5167 (= _%group2068%_ '7)))
              (declare (not safe))
              (__hash-put! _%ht2183%_ '"boundedNotMatch" __tmp5167))
            _%ht2183%_))))
    (define gerbil-ascent/tools/research/candidate-interaction#dispatch
      (lambda (_%request1955%_)
        (let ((_%op1982%_
               (let* ((_%h1957%_ _%request1955%_)
                      (_%key1960%_ '"op")
                      (_%default1963%_ absent-obj)
                      (_%h1967%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h1957%_)))
                      (_%h1969%_ _%h1967%_))
                 (declare (not safe))
                 (__hash-ref__% _%h1969%_ _%key1960%_ _%default1963%_))))
          (if (string=? _%op1982%_ '"qualify")
              (gerbil-ascent/tools/research/candidate-interaction#qualification
               (let* ((_%h1984%_ _%request1955%_)
                      (_%key1987%_ '"group")
                      (_%default1990%_ absent-obj)
                      (_%h1994%_
                       (let ()
                         (declare (not safe))
                         (cast HashTable::interface _%h1984%_)))
                      (_%h1996%_ _%h1994%_))
                 (declare (not safe))
                 (__hash-ref__% _%h1996%_ _%key1987%_ _%default1990%_)))
              (let* ((_%id2033%_
                      (let* ((_%h2009%_ _%request1955%_)
                             (_%key2012%_ '"case")
                             (_%default2015%_ absent-obj)
                             (_%h2019%_
                              (let ()
                                (declare (not safe))
                                (cast HashTable::interface _%h2009%_)))
                             (_%h2021%_ _%h2019%_))
                        (declare (not safe))
                        (__hash-ref__% _%h2021%_ _%key2012%_ _%default2015%_)))
                     (_%rules2060%_
                      (gerbil-ascent/tools/research/candidate-interaction#symbols
                       (let* ((_%h2035%_ _%request1955%_)
                              (_%key2038%_ '"rules")
                              (_%default2041%_ absent-obj)
                              (_%h2045%_
                               (let ()
                                 (declare (not safe))
                                 (cast HashTable::interface _%h2035%_)))
                              (_%h2047%_ _%h2045%_))
                         (declare (not safe))
                         (__hash-ref__%
                          _%h2047%_
                          _%key2038%_
                          _%default2041%_)))))
                (if (let ()
                      (declare (not safe))
                      (##member _%id2033%_ '(0 1 2)))
                    '#!void
                    (let () (declare (not safe)) (error '"invalid case")))
                (if (string=? _%op1982%_ '"grade")
                    (gerbil-ascent/tools/research/candidate-interaction#grade
                     _%id2033%_
                     _%rules2060%_)
                    (if (string=? _%op1982%_ '"feedback")
                        (let ((__tmp5168
                               (lambda (_%mask2065%_)
                                 (gerbil-ascent/tools/research/candidate-interaction#observe
                                  _%id2033%_
                                  _%mask2065%_
                                  (gerbil-ascent/tools/research/candidate-interaction#graph
                                   _%mask2065%_)
                                  _%rules2060%_))))
                          (declare (not safe))
                          (##map __tmp5168 '(0 1 3 9)))
                        (let ()
                          (declare (not safe))
                          (error '"invalid operation")))))))))
    (define gerbil-ascent/tools/research/candidate-interaction#main
      (lambda _%args1886%_
        (let () (declare (not safe)) (displayln '"{\"ready\":true}"))
        (force-output)
        (let _%loop1888%_ ()
          (let ((_%line1891%_ (read-line)))
            (if (eof-object? _%line1891%_)
                '#!void
                (begin
                  (let ((__tmp5169
                         (let ((__tmp5170
                                (let ((__tmp5174
                                       (lambda (_%$%g18921894%_)
                                         (let* ((_%e1898%_ _%$%g18921894%_)
                                                (_%ht1900%_
                                                 (let ()
                                                   (declare (not safe))
                                                   (make-hash-table__%
                                                    '#f
                                                    '1
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value
                                                    absent-value))))
                                           (let ((__tmp5175
                                                  (let ()
                                                    (declare (not safe))
                                                    (std/error#exception->string
                                                     _%e1898%_))))
                                             (declare (not safe))
                                             (__hash-put!
                                              _%ht1900%_
                                              '"error"
                                              __tmp5175))
                                           _%ht1900%_)))
                                      (__tmp5171
                                       (lambda ()
                                         (gerbil-ascent/tools/research/candidate-interaction#dispatch
                                          (let ((__tmp5173
                                                 (lambda ()
                                                   (call-with-input-string
                                                    _%line1891%_
                                                    std/encoding/json/util#read-json)))
                                                (__tmp5172
                                                 (let* ((_%object-as-hash1906%_
                                                         '#t)
                                                        (_%key-as-symbol1909%_
                                                         '#f)
                                                        (_%array-as-vector1912%_
                                                         '#f)
                                                        (_%key-as-symbol1917%_
                                                         _%key-as-symbol1909%_)
                                                        (_%array-as-vector1935%_
                                                         _%array-as-vector1912%_)
                                                        (_%object-as-hash1945%_
                                                         _%object-as-hash1906%_))
                                                   (declare (not safe))
                                                   (std/encoding/json/env#__make-JSONReadOptions__%
                                                    '#f
                                                    _%key-as-symbol1917%_
                                                    _%array-as-vector1935%_
                                                    _%object-as-hash1945%_))))
                                            (declare (not safe))
                                            (call-with-parameters__1
                                             __tmp5173
                                             std/encoding/json/env#current-json-read-options
                                             __tmp5172))))))
                                  (declare (not safe))
                                  (__with-catch __tmp5174 __tmp5171))))
                           (declare (not safe))
                           (std/encoding/json/util#json->string __tmp5170))))
                    (declare (not safe))
                    (displayln __tmp5169))
                  (force-output)
                  (_%loop1888%_)))))))))
