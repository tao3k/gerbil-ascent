prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/program

(begin
  (declare-type
   gerbil-ascent/program/planning#gerbil-ascent-prepare-program
   (@lambda 4
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/planning)))
  (declare-type
   gerbil-ascent/program/planning#active-rules
   (@lambda 2
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/planning)))
  (declare-type
   gerbil-ascent/program/planning#plan-failure
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/planning)))
  (declare-type
   gerbil-ascent/program/planning#head-plan
   (@lambda 3
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/planning)))
  (declare-type
   gerbil-ascent/program/planning#gerbil-ascent-prepare-rule
   (@lambda 4
            #f
            signature:
            (return:
             vector::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/program/planning))))
