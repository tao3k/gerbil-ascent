(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/feedback::timestamp 1791687903)
  (begin
    (define gerbil-ascent/candidate/feedback#reasoning-feedback::t
      (let ((__tmp39397 (list))
            (__tmp39396
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reasoning-feedback
         __tmp39397
         '(status reason missing extra)
         __tmp39396
         '#f)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/feedback#reasoning-feedback::t)))
    (define gerbil-ascent/candidate/feedback#make-reasoning-feedback
      (lambda _%$args30270%_
        (apply make-instance
               gerbil-ascent/candidate/feedback#reasoning-feedback::t
               _%$args30270%_)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-status-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'status)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-reason-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'reason)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-missing-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'missing)))
    (define gerbil-ascent/candidate/feedback#&reasoning-feedback-extra-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/feedback#reasoning-feedback::t
         'extra)))
    (define gerbil-ascent/candidate/feedback#refuse-feedback
      (lambda (_%reason30268%_)
        (let ()
          (declare (not safe))
          (##structure
           gerbil-ascent/candidate/feedback#reasoning-feedback::t
           'inconclusive
           _%reason30268%_
           '()
           '()))))
    (define gerbil-ascent/candidate/feedback#receipt-feedback-reason
      (lambda (_%snapshot30261%_ _%candidate30262%_ _%receipt30263%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
               _%receipt30263%_
               _%snapshot30261%_
               _%candidate30262%_))
            (if (eq? (##structure-ref
                      _%receipt30263%_
                      '1
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f)
                     'complete)
                '#f
                (##structure-ref
                 _%receipt30263%_
                 '1
                 gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                 '#f))
            'unbound)))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-rows
      (lambda (_%snapshot30254%_
               _%candidate30255%_
               _%receipt30256%_
               _%expected30257%_)
        (let ((_%reason30259%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30254%_
                _%candidate30255%_
                _%receipt30256%_)))
          (if _%reason30259%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30259%_)
              (gerbil-ascent/candidate/feedback#compare-qualified-rows
               _%receipt30256%_
               _%expected30257%_)))))
    (define gerbil-ascent/candidate/feedback#reasoning-compare-attempts
      (lambda (_%snapshot30241%_
               _%candidate30242%_
               _%receipt30243%_
               _%reference-candidate30244%_
               _%reference-receipt30245%_)
        (let ((_%reason30247%_
               (gerbil-ascent/candidate/feedback#receipt-feedback-reason
                _%snapshot30241%_
                _%candidate30242%_
                _%receipt30243%_)))
          (if _%reason30247%_
              (gerbil-ascent/candidate/feedback#refuse-feedback
               _%reason30247%_)
              (if (let ()
                    (declare (not safe))
                    (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                     _%reference-receipt30245%_
                     _%snapshot30241%_
                     _%reference-candidate30244%_))
                  (if (eq? (##structure-ref
                            _%reference-receipt30245%_
                            '1
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f)
                           'complete)
                      (if (equal? (##structure-ref
                                   _%receipt30243%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f)
                                  (##structure-ref
                                   _%reference-receipt30245%_
                                   '6
                                   gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                   '#f))
                          (gerbil-ascent/candidate/feedback#compare-qualified-rows
                           _%receipt30243%_
                           (##structure-ref
                            _%reference-receipt30245%_
                            '7
                            gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                            '#f))
                          (gerbil-ascent/candidate/feedback#refuse-feedback
                           'query-mismatch))
                      (gerbil-ascent/candidate/feedback#refuse-feedback
                       'reference-incomplete))
                  (gerbil-ascent/candidate/feedback#refuse-feedback
                   'reference-unbound))))))
    (define gerbil-ascent/candidate/feedback#compare-qualified-rows
      (lambda (_%receipt30211%_ _%expected30212%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%expected30212%_
                    '16384
                    '128))
                 (list? _%expected30212%_)
                 (let* ((_%arity30214%_
                         (length (cdr (##structure-ref
                                       _%receipt30211%_
                                       '6
                                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                       '#f))))
                        (__tmp39398
                         (lambda (_%row30216%_)
                           (and (list? _%row30216%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%row30216%_))
                                   _%arity30214%_)
                                (let ()
                                  (declare (not safe))
                                  (andmap__0
                                   gerbil-ascent/candidate/program#scalar?
                                   _%row30216%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp39398 _%expected30212%_)))
            (let ((_%actual-set30220%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%expected-set30221%_
                   (let ()
                     (declare (not safe))
                     (make-hash-table__%
                      '#f
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value
                      absent-value)))
                  (_%actual30222%_ '())
                  (_%wanted30223%_ '()))
              (letrec ((_%insert30225%_
                        (lambda (_%rows30234%_ _%table30235%_)
                          (let ((_%unique30237%_ '()))
                            (for-each
                             (lambda (_%row30239%_)
                               (if (let ()
                                     (declare (not safe))
                                     (hash-get _%table30235%_ _%row30239%_))
                                   '#!void
                                   (begin
                                     (let ()
                                       (declare (not safe))
                                       (hash-put!
                                        _%table30235%_
                                        _%row30239%_
                                        '#t))
                                     (set! _%unique30237%_
                                           (cons _%row30239%_
                                                 _%unique30237%_)))))
                             _%rows30234%_)
                            (let ()
                              (declare (not safe))
                              (##reverse _%unique30237%_))))))
                (set! _%actual30222%_
                      (_%insert30225%_
                       (##structure-ref
                        _%receipt30211%_
                        '7
                        gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                        '#f)
                       _%actual-set30220%_))
                (set! _%wanted30223%_
                      (_%insert30225%_
                       _%expected30212%_
                       _%expected-set30221%_))
                (let ((_%missing30231%_
                       (let ((__tmp39399
                              (lambda (_%row30227%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%actual-set30220%_
                                        _%row30227%_))))))
                         (declare (not safe))
                         (##filter __tmp39399 _%wanted30223%_)))
                      (_%extra30232%_
                       (let ((__tmp39400
                              (lambda (_%row30229%_)
                                (not (let ()
                                       (declare (not safe))
                                       (__hash-get
                                        _%expected-set30221%_
                                        _%row30229%_))))))
                         (declare (not safe))
                         (##filter __tmp39400 _%actual30222%_))))
                  (let ((__tmp39403
                         (if (and (null? _%missing30231%_)
                                  (null? _%extra30232%_))
                             'match
                             'mismatch))
                        (__tmp39402
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%missing30231%_)))
                        (__tmp39401
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/datum#candidate-copy-pairs
                            _%extra30232%_))))
                    (declare (not safe))
                    (##structure
                     gerbil-ascent/candidate/feedback#reasoning-feedback::t
                     __tmp39403
                     '#f
                     __tmp39402
                     __tmp39401)))))
            (gerbil-ascent/candidate/feedback#refuse-feedback
             'invalid-reference))))))
