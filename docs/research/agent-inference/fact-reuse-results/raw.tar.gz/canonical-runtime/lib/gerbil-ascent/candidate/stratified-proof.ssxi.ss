prelude: :gerbil/compiler/ssxi
package: gerbil-ascent/candidate

(begin
  (declare-type
   gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+
   (optimizer-resolve-class
    '(typedecl gerbil-ascent/candidate/stratified-proof#+max-proof-nodes+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+
   (optimizer-resolve-class
    '(typedecl
      gerbil-ascent/candidate/stratified-proof#+max-proof-datum-nodes+)
    'fixnum::t))
  (declare-type
   gerbil-ascent/candidate/stratified-proof#ground-row?
   (@lambda 2
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/stratified-proof)))
  (declare-type
   gerbil-ascent/candidate/stratified-proof#same-distinct-rows?
   (@lambda 3
            #f
            signature:
            (return:
             boolean::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/stratified-proof)))
  (declare-type
   gerbil-ascent/candidate/stratified-proof#candidate-verify-stratified-proof
   (@lambda 9
            #f
            signature:
            (return:
             t::t
             effect:
             #f
             arguments:
             #f
             unchecked:
             #f
             origin:
             gerbil-ascent/candidate/stratified-proof))))
