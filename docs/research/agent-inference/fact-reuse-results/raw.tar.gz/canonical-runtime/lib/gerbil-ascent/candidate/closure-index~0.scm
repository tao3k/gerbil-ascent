(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/closure-index::timestamp 1791690988)
  (begin
    (define gerbil-ascent/candidate/closure-index#closure-relation::t
      (let ((__tmp34477 (list)) (__tmp34476 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/closure-index#closure-relation::t
         'closure-relation
         __tmp34477
         '(rows members source)
         __tmp34476
         '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-relation?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/closure-index#closure-relation::t)))
    (define gerbil-ascent/candidate/closure-index#make-closure-relation
      (lambda _%$args28614%_
        (apply make-instance
               gerbil-ascent/candidate/closure-index#closure-relation::t
               _%$args28614%_)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-source
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#closure-relation-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-members
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-source
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'rows)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-members-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'members)))
    (define gerbil-ascent/candidate/closure-index#&closure-relation-source-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/closure-index#closure-relation::t
         'source)))
    (define gerbil-ascent/candidate/closure-index#make-closure-index__%
      (lambda (_%closure28588%_ _%sources28589%_)
        (let ((_%index28591%_
               (let ((__tmp34478 (length _%closure28588%_)))
                 (declare (not safe))
                 (make-hash-table-eq 'size: __tmp34478))))
          (for-each
           (lambda (_%entry28593%_)
             (let* ((_%rows28595%_ (caddr _%entry28593%_))
                    (_%members28597%_
                     (let ((__tmp34479 (length _%rows28595%_)))
                       (declare (not safe))
                       (make-hash-table__%
                        '#f
                        __tmp34479
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value
                        absent-value))))
               (for-each
                (lambda (_%row28600%_)
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%members28597%_ _%row28600%_ '#t)))
                _%rows28595%_)
               (let ((__tmp34481 (car _%entry28593%_))
                     (__tmp34480
                      (let ()
                        (declare (not safe))
                        (##structure
                         gerbil-ascent/candidate/closure-index#closure-relation::t
                         _%rows28595%_
                         _%members28597%_
                         '#f))))
                 (declare (not safe))
                 (__hash-put! _%index28591%_ __tmp34481 __tmp34480))))
           _%closure28588%_)
          (for-each
           (lambda (_%entry28602%_)
             (##structure-set!
              (gerbil-ascent/candidate/closure-index#closure-entry
               _%index28591%_
               (car _%entry28602%_))
              (list->vector (caddr _%entry28602%_))
              '3
              gerbil-ascent/candidate/closure-index#closure-relation::t
              '#f))
           _%sources28589%_)
          _%index28591%_)))
    (define gerbil-ascent/candidate/closure-index#make-closure-index__0
      (lambda (_%closure28607%_)
        (let ((_%sources28609%_ '()))
          (gerbil-ascent/candidate/closure-index#make-closure-index__%
           _%closure28607%_
           _%sources28609%_))))
    (define gerbil-ascent/candidate/closure-index#make-closure-index
      (lambda _g34482_
        (let ((_g34483_ (let () (declare (not safe)) (##length _g34482_))))
          (cond ((let () (declare (not safe)) (##fx= _g34483_ 1))
                 (apply gerbil-ascent/candidate/closure-index#make-closure-index__0
                        _g34482_))
                ((let () (declare (not safe)) (##fx= _g34483_ 2))
                 (apply gerbil-ascent/candidate/closure-index#make-closure-index__%
                        _g34482_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/closure-index#make-closure-index
                  _g34482_))))))
    (define gerbil-ascent/candidate/closure-index#closure-entry
      (lambda (_%index28581%_ _%name28582%_)
        (let ((_%$e28584%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index28581%_ _%name28582%_))))
          (if _%$e28584%_
              _%$e28584%_
              (let ()
                (declare (not safe))
                (error '"candidate is missing inspected entry"
                       _%name28582%_))))))
    (define gerbil-ascent/candidate/closure-index#closure-index-rows
      (lambda (_%index28578%_ _%name28579%_)
        (##structure-ref
         (gerbil-ascent/candidate/closure-index#closure-entry
          _%index28578%_
          _%name28579%_)
         '1
         gerbil-ascent/candidate/closure-index#closure-relation::t
         '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-index-member?
      (lambda (_%index28574%_ _%name28575%_ _%row28576%_)
        (if (let ((__tmp34484
                   (##structure-ref
                    (gerbil-ascent/candidate/closure-index#closure-entry
                     _%index28574%_
                     _%name28575%_)
                    '2
                    gerbil-ascent/candidate/closure-index#closure-relation::t
                    '#f)))
              (declare (not safe))
              (hash-get __tmp34484 _%row28576%_))
            '#t
            '#f)))
    (define gerbil-ascent/candidate/closure-index#closure-index-source
      (lambda (_%index28569%_ _%name28570%_)
        (let ((_%entry28572%_
               (let ()
                 (declare (not safe))
                 (hash-get _%index28569%_ _%name28570%_))))
          (if _%entry28572%_
              (##structure-ref
               _%entry28572%_
               '3
               gerbil-ascent/candidate/closure-index#closure-relation::t
               '#f)
              '#f))))))
