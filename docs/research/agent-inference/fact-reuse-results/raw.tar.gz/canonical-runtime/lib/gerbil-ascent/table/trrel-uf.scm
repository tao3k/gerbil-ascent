(declare (block) (standard-bindings) (extended-bindings))
(begin
  (load-module "gerbil-ascent/core/relation-view")
  (load-module "gerbil-ascent/table/trrel-uf~0"))
