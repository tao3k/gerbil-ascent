(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/scheme-session::timestamp 1791687893)
  (begin
    (define gerbil-ascent/program/scheme-session#relational-session::t
      (let ((__tmp37944 (list)) (__tmp37943 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-session#relational-session::t
         'relational-session
         __tmp37944
         '(engine source-arities)
         __tmp37943
         '#f)))
    (define gerbil-ascent/program/scheme-session#relational-session?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-session#relational-session::t)))
    (define gerbil-ascent/program/scheme-session#make-relational-session
      (lambda _%$args20387%_
        (apply make-instance
               gerbil-ascent/program/scheme-session#relational-session::t
               _%$args20387%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-program-session::t
      (let ((__tmp37946 (list)) (__tmp37945 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/scheme-session#relational-program-session::t
         'relational-program-session
         __tmp37946
         '(engine source-arities)
         __tmp37945
         '#f)))
    (define gerbil-ascent/program/scheme-session#relational-program-session?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/scheme-session#relational-program-session::t)))
    (define gerbil-ascent/program/scheme-session#make-relational-program-session
      (lambda _%$args20384%_
        (apply make-instance
               gerbil-ascent/program/scheme-session#relational-program-session::t
               _%$args20384%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#relational-program-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-engine
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-source-arities
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-engine-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'engine)))
    (define gerbil-ascent/program/scheme-session#&relational-program-session-source-arities-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/scheme-session#relational-program-session::t
         'source-arities)))
    (define gerbil-ascent/program/scheme-session#relational-source-arities
      (lambda (_%snapshot20374%_)
        (let ((_%sources20376%_
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%snapshot20374%_ 'source-handles))))
          (map (lambda (_%name20378%_)
                 (let ((_%relation20382%_
                        (let ((__tmp37948
                               (lambda (_%candidate20380%_)
                                 (eq? (let ()
                                        (declare (not safe))
                                        (clan/poo/object#.ref
                                         _%candidate20380%_
                                         'name))
                                      _%name20378%_)))
                              (__tmp37947
                               (let ()
                                 (declare (not safe))
                                 (clan/poo/object#.ref
                                  _%snapshot20374%_
                                  'relations))))
                          (declare (not safe))
                          (__find __tmp37948 __tmp37947))))
                   (if _%relation20382%_
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"relational source has no declaration"
                                _%name20378%_)))
                   (cons _%name20378%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref _%relation20382%_ 'arity)))))
               _%sources20376%_))))
    (define gerbil-ascent/program/scheme-session#relational-open-session
      (lambda (_%program20367%_)
        (let* ((_%snapshot20369%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                   _%program20367%_)))
               (_%arities20371%_
                (gerbil-ascent/program/scheme-session#relational-source-arities
                 _%snapshot20369%_))
               (__tmp37949
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/session#gerbil-ascent-open-session__%
                   '#f
                   absent-value
                   _%snapshot20369%_))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-session#relational-session::t
           __tmp37949
           _%arities20371%_))))
    (define gerbil-ascent/program/scheme-session#relational-open-program-session
      (lambda (_%program20360%_)
        (let* ((_%snapshot20362%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-snapshot#relational-snapshot-program
                   _%program20360%_)))
               (_%arities20364%_
                (gerbil-ascent/program/scheme-session#relational-source-arities
                 _%snapshot20362%_))
               (__tmp37950
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/session#gerbil-ascent-open-session__%
                   '#f
                   absent-value
                   _%snapshot20362%_))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-session#relational-program-session::t
           __tmp37950
           _%arities20364%_))))
    (define gerbil-ascent/program/scheme-session#relational-replace-source/checked!
      (lambda (_%engine20351%_ _%arities20352%_ _%name20353%_ _%rows20354%_)
        (let ((_%arity20356%_
               (if (symbol? _%name20353%_)
                   (assq _%name20353%_ _%arities20352%_)
                   '#f)))
          (if _%arity20356%_
              '#!void
              (let ()
                (declare (not safe))
                (error '"relation is not a source in this session"
                       _%name20353%_)))
          (let ((_%copied20358%_
                 (let ((__tmp37951 (cdr _%arity20356%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/scheme-checked#relational-copy-rows
                    _%rows20354%_
                    __tmp37951))))
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/session#gerbil-ascent-session-replace-source!
               _%engine20351%_
               _%name20353%_
               _%copied20358%_))
            '#!void))))
    (define gerbil-ascent/program/scheme-session#relational-append-source/checked!
      (lambda (_%engine20342%_ _%arities20343%_ _%name20344%_ _%row20345%_)
        (let ((_%arity20347%_
               (if (symbol? _%name20344%_)
                   (assq _%name20344%_ _%arities20343%_)
                   '#f)))
          (if _%arity20347%_
              '#!void
              (let ()
                (declare (not safe))
                (error '"relation is not a source in this session"
                       _%name20344%_)))
          (let ((_%copied20349%_
                 (let ((__tmp37952 (cdr _%arity20347%_)))
                   (declare (not safe))
                   (gerbil-ascent/program/scheme-checked#relational-copy-row
                    _%row20345%_
                    __tmp37952))))
            (let ()
              (declare (not safe))
              (gerbil-ascent/program/session#gerbil-ascent-session-append-source!
               _%engine20342%_
               _%name20344%_
               _%copied20349%_))
            '#!void))))
    (define gerbil-ascent/program/scheme-session#relational-session-append-source!
      (lambda (_%session20332%_ _%fragment20333%_ _%label20334%_ _%row20335%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20332%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational source append requires a session"
                     _%session20332%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20333%_))
        (let* ((_%name20337%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-query#relational-export
                   _%fragment20333%_
                   _%label20334%_)))
               (_%arity20339%_
                (assq _%name20337%_
                      (##structure-ref
                       _%session20332%_
                       '2
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))))
          (if (and (memq _%name20337%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20333%_
                            'source-handles)))
                   _%arity20339%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20334%_)))
          (gerbil-ascent/program/scheme-session#relational-append-source/checked!
           (##structure-ref
            _%session20332%_
            '1
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           (##structure-ref
            _%session20332%_
            '2
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           _%name20337%_
           _%row20335%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-replace-source!
      (lambda (_%session20322%_ _%fragment20323%_ _%label20324%_ _%rows20325%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20322%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational source replacement requires a session"
                     _%session20322%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20323%_))
        (let* ((_%name20327%_
                (let ()
                  (declare (not safe))
                  (gerbil-ascent/program/scheme-query#relational-export
                   _%fragment20323%_
                   _%label20324%_)))
               (_%arity20329%_
                (assq _%name20327%_
                      (##structure-ref
                       _%session20322%_
                       '2
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))))
          (if (and (memq _%name20327%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20323%_
                            'source-handles)))
                   _%arity20329%_)
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20324%_)))
          (gerbil-ascent/program/scheme-session#relational-replace-source/checked!
           (##structure-ref
            _%session20322%_
            '1
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           (##structure-ref
            _%session20322%_
            '2
            gerbil-ascent/program/scheme-session#relational-session::t
            '#f)
           _%name20327%_
           _%rows20325%_))))
    (define gerbil-ascent/program/scheme-session#relational-checked-replacements
      (lambda (_%arities20308%_ _%entries20309%_)
        (if (and (list? _%entries20309%_) (pair? _%entries20309%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires source updates"
                     _%entries20309%_)))
        (let ((_%seen20311%_
               (let () (declare (not safe)) (make-hash-table-eq))))
          (map (lambda (_%entry20313%_)
                 (if (and (pair? _%entry20313%_)
                          (symbol? (let ()
                                     (declare (not safe))
                                     (##car _%entry20313%_))))
                     '#!void
                     (let ()
                       (declare (not safe))
                       (error '"invalid relational source update"
                              _%entry20313%_)))
                 (let* ((_%name20315%_ (car _%entry20313%_))
                        (_%arity20317%_ (assq _%name20315%_ _%arities20308%_)))
                   (if _%arity20317%_
                       '#!void
                       (let ()
                         (declare (not safe))
                         (error '"relation is not a source in this session"
                                _%name20315%_)))
                   (if (let ()
                         (declare (not safe))
                         (__hash-get _%seen20311%_ _%name20315%_))
                       (let ()
                         (declare (not safe))
                         (error '"duplicate relational transaction source"
                                _%name20315%_))
                       '#!void)
                   (let ()
                     (declare (not safe))
                     (__hash-put! _%seen20311%_ _%name20315%_ '#t))
                   (let ((_%rows20320%_
                          (let ((__tmp37954 (cdr _%entry20313%_))
                                (__tmp37953 (cdr _%arity20317%_)))
                            (declare (not safe))
                            (gerbil-ascent/program/scheme-checked#relational-copy-rows
                             __tmp37954
                             __tmp37953))))
                     (cons _%name20315%_ _%rows20320%_))))
               _%entries20309%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-source-name
      (lambda (_%session20302%_ _%fragment20303%_ _%label20304%_)
        (let ((_%name20306%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/scheme-query#relational-export
                  _%fragment20303%_
                  _%label20304%_))))
          (if (and (memq _%name20306%_
                         (let ()
                           (declare (not safe))
                           (clan/poo/object#.ref
                            _%fragment20303%_
                            'source-handles)))
                   (assq _%name20306%_
                         (##structure-ref
                          _%session20302%_
                          '2
                          gerbil-ascent/program/scheme-session#relational-session::t
                          '#f)))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational export is not a source in this session"
                       _%label20304%_)))
          _%name20306%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-transaction!
      (lambda (_%session20295%_ _%updates20296%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20295%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20295%_)))
        (if (and (list? _%updates20296%_) (pair? _%updates20296%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires source updates"
                     _%updates20296%_)))
        (let ((_%entries20300%_
               (map (lambda (_%update20298%_)
                      (if (and (list? _%update20298%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%update20298%_))
                                  '3)
                               (symbol? (cadr _%update20298%_)))
                          '#!void
                          (let ()
                            (declare (not safe))
                            (error '"invalid relational transaction update"
                                   _%update20298%_)))
                      (cons (gerbil-ascent/program/scheme-session#relational-session-source-name
                             _%session20295%_
                             (car _%update20298%_)
                             (cadr _%update20298%_))
                            (caddr _%update20298%_)))
                    _%updates20296%_)))
          (gerbil-ascent/program/scheme-session#relational-session-commit-entries!
           _%session20295%_
           _%entries20300%_))))
    (define gerbil-ascent/program/scheme-session#relational-session-commit-entries!
      (lambda (_%session20292%_ _%entries20293%_)
        (let ((__tmp37955
               (let ((__tmp37957
                      (##structure-ref
                       _%session20292%_
                       '1
                       gerbil-ascent/program/scheme-session#relational-session::t
                       '#f))
                     (__tmp37956
                      (gerbil-ascent/program/scheme-session#relational-checked-replacements
                       (##structure-ref
                        _%session20292%_
                        '2
                        gerbil-ascent/program/scheme-session#relational-session::t
                        '#f)
                       _%entries20293%_)))
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                  __tmp37957
                  __tmp37956))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37955))))
    (define gerbil-ascent/program/scheme-session#relational-session-prepare-transaction
      (lambda (_%session20276%_ _%sources20277%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20276%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20276%_)))
        (if (and (list? _%sources20277%_) (pair? _%sources20277%_))
            '#!void
            (let ()
              (declare (not safe))
              (error '"prepared transaction requires source selections"
                     _%sources20277%_)))
        (let* ((_%seen20279%_
                (let () (declare (not safe)) (make-hash-table-eq)))
               (_%names20285%_
                (map (lambda (_%source20281%_)
                       (if (and (list? _%source20281%_)
                                (= (let ()
                                     (declare (not safe))
                                     (##length _%source20281%_))
                                   '2)
                                (symbol? (cadr _%source20281%_)))
                           '#!void
                           (let ()
                             (declare (not safe))
                             (error '"invalid prepared transaction source"
                                    _%source20281%_)))
                       (let ((_%name20283%_
                              (gerbil-ascent/program/scheme-session#relational-session-source-name
                               _%session20276%_
                               (car _%source20281%_)
                               (cadr _%source20281%_))))
                         (if (let ()
                               (declare (not safe))
                               (__hash-get _%seen20279%_ _%name20283%_))
                             (let ()
                               (declare (not safe))
                               (error '"duplicate relational transaction source"
                                      _%name20283%_))
                             '#!void)
                         (let ()
                           (declare (not safe))
                           (__hash-put! _%seen20279%_ _%name20283%_ '#t))
                         _%name20283%_))
                     _%sources20277%_))
               (_%count20287%_
                (let () (declare (not safe)) (##length _%names20285%_))))
          (lambda (_%batches20290%_)
            (if (and (list? _%batches20290%_)
                     (= (let ()
                          (declare (not safe))
                          (##length _%batches20290%_))
                        _%count20287%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"prepared transaction requires one row batch per source"
                         _%batches20290%_)))
            (gerbil-ascent/program/scheme-session#relational-session-commit-entries!
             _%session20276%_
             (let ()
               (declare (not safe))
               (##map cons _%names20285%_ _%batches20290%_)))))))
    (define gerbil-ascent/program/scheme-session#relational-session-prepare-replacements
      (lambda (_%session20256%_ _%fragment20257%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20256%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational transaction requires a session"
                     _%session20256%_)))
        (let ()
          (declare (not safe))
          (clan/poo/mop#validate
           gerbil-ascent/program/types#GerbilAscentFragmentContract
           _%fragment20257%_))
        (let ((_%last-preparation20259%_ '#f))
          (lambda (_%replacements20261%_)
            (if (and (list? _%replacements20261%_)
                     (pair? _%replacements20261%_))
                '#!void
                (let ()
                  (declare (not safe))
                  (error '"relational transaction requires source updates"
                         _%replacements20261%_)))
            (let* ((_%labels20265%_
                    (map (lambda (_%replacement20263%_)
                           (if (and (pair? _%replacement20263%_)
                                    (symbol? (let ()
                                               (declare (not safe))
                                               (##car _%replacement20263%_))))
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid relational source replacement"
                                        _%replacement20263%_)))
                           (car _%replacement20263%_))
                         _%replacements20261%_))
                   (_%previous20267%_ _%last-preparation20259%_)
                   (_%transaction20273%_
                    (if (and _%previous20267%_
                             (equal? _%labels20265%_
                                     (let ()
                                       (declare (not safe))
                                       (##car _%previous20267%_))))
                        (cdr _%previous20267%_)
                        (let ((_%prepared20271%_
                               (gerbil-ascent/program/scheme-session#relational-session-prepare-transaction
                                _%session20256%_
                                (let ((__tmp37958
                                       (lambda (_%label20269%_)
                                         (list _%fragment20257%_
                                               _%label20269%_))))
                                  (declare (not safe))
                                  (##map __tmp37958 _%labels20265%_)))))
                          (set! _%last-preparation20259%_
                                (cons _%labels20265%_ _%prepared20271%_))
                          _%prepared20271%_))))
              (_%transaction20273%_ (map cdr _%replacements20261%_)))))))
    (define gerbil-ascent/program/scheme-session#relational-session-replace-sources!
      (lambda (_%session20250%_ _%fragment20251%_ _%replacements20252%_)
        (if (list? _%replacements20252%_)
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational batch replacements must be a list"
                     _%replacements20252%_)))
        (gerbil-ascent/program/scheme-session#relational-session-transaction!
         _%session20250%_
         (map (lambda (_%replacement20254%_)
                (if (and (pair? _%replacement20254%_)
                         (symbol? (let ()
                                    (declare (not safe))
                                    (##car _%replacement20254%_))))
                    '#!void
                    (let ()
                      (declare (not safe))
                      (error '"invalid relational source replacement"
                             _%replacement20254%_)))
                (list _%fragment20251%_
                      (car _%replacement20254%_)
                      (cdr _%replacement20254%_)))
              _%replacements20252%_))))
    (define gerbil-ascent/program/scheme-session#relational-program-replace-source!
      (lambda (_%session20246%_ _%name20247%_ _%rows20248%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20246%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named source replacement requires a program session"
                     _%session20246%_)))
        (gerbil-ascent/program/scheme-session#relational-replace-source/checked!
         (##structure-ref
          _%session20246%_
          '1
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         (##structure-ref
          _%session20246%_
          '2
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         _%name20247%_
         _%rows20248%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-append-source!
      (lambda (_%session20242%_ _%name20243%_ _%row20244%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20242%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named source append requires a program session"
                     _%session20242%_)))
        (gerbil-ascent/program/scheme-session#relational-append-source/checked!
         (##structure-ref
          _%session20242%_
          '1
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         (##structure-ref
          _%session20242%_
          '2
          gerbil-ascent/program/scheme-session#relational-program-session::t
          '#f)
         _%name20243%_
         _%row20244%_)))
    (define gerbil-ascent/program/scheme-session#relational-program-transaction!
      (lambda (_%session20239%_ _%replacements20240%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20239%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named transaction requires a program session"
                     _%session20239%_)))
        (let ((__tmp37959
               (let ((__tmp37961
                      (##structure-ref
                       _%session20239%_
                       '1
                       gerbil-ascent/program/scheme-session#relational-program-session::t
                       '#f))
                     (__tmp37960
                      (gerbil-ascent/program/scheme-session#relational-checked-replacements
                       (##structure-ref
                        _%session20239%_
                        '2
                        gerbil-ascent/program/scheme-session#relational-program-session::t
                        '#f)
                       _%replacements20240%_)))
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-replace-sources!__0
                  __tmp37961
                  __tmp37960))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-program-solution::t
           __tmp37959))))
    (define gerbil-ascent/program/scheme-session#relational-session-result
      (lambda (_%engine20235%_)
        (let ((_%result20237%_
               (let ()
                 (declare (not safe))
                 (gerbil-ascent/program/session#gerbil-ascent-session-run
                  _%engine20235%_))))
          (if (let ()
                (declare (not safe))
                (clan/poo/object#.ref _%result20237%_ 'finished))
              '#!void
              (let ()
                (declare (not safe))
                (error '"relational session did not complete")))
          _%result20237%_)))
    (define gerbil-ascent/program/scheme-session#relational-session-run
      (lambda (_%session20233%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20233%_
               'gerbil-ascent/program/scheme-session#relational-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"relational run requires a session" _%session20233%_)))
        (let ((__tmp37962
               (gerbil-ascent/program/scheme-session#relational-session-result
                (##structure-ref
                 _%session20233%_
                 '1
                 gerbil-ascent/program/scheme-session#relational-session::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-solution::t
           __tmp37962))))
    (define gerbil-ascent/program/scheme-session#relational-program-session-run
      (lambda (_%session20231%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%session20231%_
               'gerbil-ascent/program/scheme-session#relational-program-session::t))
            '#!void
            (let ()
              (declare (not safe))
              (error '"named run requires a program session"
                     _%session20231%_)))
        (let ((__tmp37963
               (gerbil-ascent/program/scheme-session#relational-session-result
                (##structure-ref
                 _%session20231%_
                 '1
                 gerbil-ascent/program/scheme-session#relational-program-session::t
                 '#f))))
          (declare (not safe))
          (##structure
           gerbil-ascent/program/scheme-query#relational-program-solution::t
           __tmp37963))))))
