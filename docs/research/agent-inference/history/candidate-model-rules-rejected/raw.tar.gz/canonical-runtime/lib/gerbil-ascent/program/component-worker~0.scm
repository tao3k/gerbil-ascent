(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/component-worker::timestamp 1791687882)
  (begin
    (define gerbil-ascent/program/component-worker#component-snapshot::t
      (let ((__tmp36222 (list)) (__tmp36221 (cons (cons 'struct: '#t) '())))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/program/component-worker#component-snapshot::t
         'component-snapshot
         __tmp36222
         '(rows sizes)
         __tmp36221
         '#f)))
    (define gerbil-ascent/program/component-worker#component-snapshot?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/program/component-worker#component-snapshot::t)))
    (define gerbil-ascent/program/component-worker#make-component-snapshot
      (lambda _%$args18016%_
        (apply make-instance
               gerbil-ascent/program/component-worker#component-snapshot::t
               _%$args18016%_)))
    (define gerbil-ascent/program/component-worker#component-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#component-snapshot-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#component-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#component-snapshot-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-rows
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-sizes
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-rows-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'rows)))
    (define gerbil-ascent/program/component-worker#&component-snapshot-sizes-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/program/component-worker#component-snapshot::t
         'sizes)))
    (define gerbil-ascent/program/component-worker#gerbil-ascent-run-positive-component!
      (lambda (_%component17942%_
               _%schema17943%_
               _%snapshot17944%_
               _%emit!17945%_
               _%checkpoint!17946%_)
        (let* ((_%all17948%_
                (##structure-ref
                 _%snapshot17944%_
                 '1
                 gerbil-ascent/program/component-worker#component-snapshot::t
                 '#f))
               (_%all-size17950%_
                (##structure-ref
                 _%snapshot17944%_
                 '2
                 gerbil-ascent/program/component-worker#component-snapshot::t
                 '#f))
               (_%count17952%_ (vector-length _%all17948%_))
               (_%delta17954%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '())))
               (_%delta-size17956%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '0)))
               (_%all-version17958%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '0)))
               (_%delta-version17960%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '0)))
               (_%indexes17962%_
                (let ((__tmp36223 (vector-ref _%schema17943%_ '5)))
                  (declare (not safe))
                  (gerbil-ascent/program/index#gerbil-ascent-make-row-indexes__0
                   _%all17948%_
                   _%delta17954%_
                   _%all-size17950%_
                   _%delta-size17956%_
                   _%all-version17958%_
                   _%delta-version17960%_
                   __tmp36223)))
               (_%rows-access17964%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%indexes17962%_ '1 '#f '#f)))
               (_%advance!17966%_
                (let ()
                  (declare (not safe))
                  (##unchecked-structure-ref _%indexes17962%_ '2 '#f '#f)))
               (_%seen17968%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '#f)))
               (_%pending17970%_
                (let ()
                  (declare (not safe))
                  (##make-vector _%count17952%_ '())))
               (_%members17972%_
                (##structure-ref
                 _%component17942%_
                 '2
                 gerbil-ascent/program/component-plan#positive-component::t
                 '#f))
               (_%rules17976%_
                (map (lambda (_%rule17974%_)
                       (vector (vector-ref _%rule17974%_ '0)
                               (vector-ref _%rule17974%_ '1)
                               (make-vector
                                (vector-ref (vector-ref _%rule17974%_ '0) '2)
                                '#f)))
                     (##structure-ref
                      _%component17942%_
                      '3
                      gerbil-ascent/program/component-plan#positive-component::t
                      '#f))))
          (let ()
            (declare (not safe))
            (gerbil-ascent/program/index#row-indexes-plan-positive-rules!
             _%indexes17962%_
             _%rules17976%_))
          (for-each
           (lambda (_%index17979%_)
             (let ((_%table17981%_
                    (let ()
                      (declare (not safe))
                      (make-hash-table__%
                       '#f
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value
                       absent-value))))
               (for-each
                (lambda (_%row17983%_)
                  (let ()
                    (declare (not safe))
                    (__hash-put! _%table17981%_ _%row17983%_ '#t)))
                (vector-ref _%all17948%_ _%index17979%_))
               (vector-set! _%seen17968%_ _%index17979%_ _%table17981%_)))
           _%members17972%_)
          (let _%rounds17985%_ ((_%first?17987%_ '#t))
            (let ((_%new?17989%_ '#f))
              (letrec ((_%candidate!17991%_
                        (lambda (_%atom18008%_ _%row18009%_)
                          (let* ((_%index18011%_ (vector-ref _%atom18008%_ '0))
                                 (_%table18013%_
                                  (vector-ref _%seen17968%_ _%index18011%_)))
                            (if (let ()
                                  (declare (not safe))
                                  (hash-get _%table18013%_ _%row18009%_))
                                '#!void
                                (begin
                                  (let ()
                                    (declare (not safe))
                                    (hash-put!
                                     _%table18013%_
                                     _%row18009%_
                                     '#t))
                                  (vector-set!
                                   _%pending17970%_
                                   _%index18011%_
                                   (cons _%row18009%_
                                         (vector-ref
                                          _%pending17970%_
                                          _%index18011%_)))
                                  (set! _%new?17989%_ '#t)
                                  (_%emit!17945%_
                                   _%atom18008%_
                                   _%row18009%_)))))))
                (let ((__tmp36224
                       (lambda (_%rule17993%_)
                         (let ((_%plan17995%_ (vector-ref _%rule17993%_ '0))
                               (_%pivots17996%_ (vector-ref _%rule17993%_ '1))
                               (_%frame17997%_ (vector-ref _%rule17993%_ '2)))
                           (if _%first?17987%_
                               (let ()
                                 (declare (not safe))
                                 (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                                  _%plan17995%_
                                  _%frame17997%_
                                  '-1
                                  _%rows-access17964%_
                                  _%candidate!17991%_
                                  _%checkpoint!17946%_))
                               (for-each
                                (lambda (_%pivot17999%_)
                                  (let ()
                                    (declare (not safe))
                                    (gerbil-ascent/core/positive-plan#gerbil-ascent-run-positive-plan!__1
                                     _%plan17995%_
                                     _%frame17997%_
                                     _%pivot17999%_
                                     _%rows-access17964%_
                                     _%candidate!17991%_
                                     _%checkpoint!17946%_)))
                                _%pivots17996%_))))))
                  (declare (not safe))
                  (##for-each __tmp36224 _%rules17976%_))
                (for-each
                 (lambda (_%index18001%_)
                   (let* ((_%batch18003%_
                           (vector-ref _%pending17970%_ _%index18001%_))
                          (_%size18005%_ (length _%batch18003%_)))
                     (if (null? _%batch18003%_)
                         '#!void
                         (begin
                           (_%advance!17966%_
                            _%index18001%_
                            _%batch18003%_
                            '#t)
                           (vector-set!
                            _%all17948%_
                            _%index18001%_
                            (append _%batch18003%_
                                    (vector-ref _%all17948%_ _%index18001%_)))
                           (vector-set!
                            _%all-size17950%_
                            _%index18001%_
                            (+ (vector-ref _%all-size17950%_ _%index18001%_)
                               _%size18005%_))
                           (vector-set!
                            _%all-version17958%_
                            _%index18001%_
                            (+ '1
                               (vector-ref
                                _%all-version17958%_
                                _%index18001%_)))))
                     (vector-set! _%delta17954%_ _%index18001%_ _%batch18003%_)
                     (vector-set! _%pending17970%_ _%index18001%_ '())
                     (vector-set!
                      _%delta-size17956%_
                      _%index18001%_
                      _%size18005%_)
                     (vector-set!
                      _%delta-version17960%_
                      _%index18001%_
                      (+ '1
                         (vector-ref _%delta-version17960%_ _%index18001%_)))))
                 _%members17972%_)
                (if _%new?17989%_ (_%rounds17985%_ '#f) '#!void)))))))))
