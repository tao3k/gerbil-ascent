(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/feedback[1]#_g39931_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39933_|
    (##structure
     gx#syntax-quote::t
     'make-reasoning-feedback
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39935_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39937_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39938_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39939_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39940_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39942_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39943_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39944_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39945_|
    (##structure
     gx#syntax-quote::t
     'reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39947_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39948_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39949_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39950_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39952_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39953_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-reason-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39954_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-missing-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[1]#_g39955_|
    (##structure
     gx#syntax-quote::t
     '&reasoning-feedback-extra-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/feedback[:0:]#reasoning-feedback|
    (let ((__obj39859
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39859
         'gerbil-ascent/candidate/feedback#reasoning-feedback::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 'reasoning-feedback '3 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39859
         '(status reason missing extra)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj39859
         '(status reason missing extra)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '#t '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '#f '13 '#f '#f))
      (let ((__tmp39930 |gerbil-ascent/candidate/feedback[1]#_g39931_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39930 '4 '#f '#f))
      (let ((__tmp39932 |gerbil-ascent/candidate/feedback[1]#_g39933_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39932 '14 '#f '#f))
      (let ((__tmp39934 |gerbil-ascent/candidate/feedback[1]#_g39935_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39934 '15 '#f '#f))
      (let ((__tmp39936
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39937_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39938_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39939_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39940_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39936 '16 '#f '#f))
      (let ((__tmp39941
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39942_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39943_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39944_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39945_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39941 '17 '#f '#f))
      (let ((__tmp39946
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39947_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39948_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39949_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39950_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39946 '18 '#f '#f))
      (let ((__tmp39951
             (cons (cons 'status
                         |gerbil-ascent/candidate/feedback[1]#_g39952_|)
                   (cons (cons 'reason
                               |gerbil-ascent/candidate/feedback[1]#_g39953_|)
                         (cons (cons 'missing
                                     |gerbil-ascent/candidate/feedback[1]#_g39954_|)
                               (cons (cons 'extra
                                           |gerbil-ascent/candidate/feedback[1]#_g39955_|)
                                     '()))))))
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 __tmp39951 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj39859 '() '21 '#f '#f))
      __obj39859)))
