(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/table/index-sharing[1]#_g33594_|
    (##structure
     gx#syntax-quote::t
     'column-order::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33596_|
    (##structure
     gx#syntax-quote::t
     'make-column-order
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33598_|
    (##structure
     gx#syntax-quote::t
     'column-order?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33600_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33601_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33603_|
    (##structure
     gx#syntax-quote::t
     'column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33604_|
    (##structure
     gx#syntax-quote::t
     'column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33606_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33607_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33609_|
    (##structure
     gx#syntax-quote::t
     '&column-order-sets-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33610_|
    (##structure
     gx#syntax-quote::t
     '&column-order-successors-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33612_|
    (##structure
     gx#syntax-quote::t
     'shared-index::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33614_|
    (##structure
     gx#syntax-quote::t
     'make-shared-index
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33616_|
    (##structure
     gx#syntax-quote::t
     'shared-index?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33618_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33619_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33620_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33621_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33622_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33623_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33625_|
    (##structure
     gx#syntax-quote::t
     'shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33626_|
    (##structure
     gx#syntax-quote::t
     'shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33627_|
    (##structure
     gx#syntax-quote::t
     'shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33628_|
    (##structure
     gx#syntax-quote::t
     'shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33629_|
    (##structure
     gx#syntax-quote::t
     'shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33630_|
    (##structure
     gx#syntax-quote::t
     'shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33632_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33633_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33634_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33635_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33636_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33637_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33639_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33640_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-root-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33641_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33642_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-views-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33643_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-projection-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33644_|
    (##structure
     gx#syntax-quote::t
     '&shared-index-key-plans-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33646_|
    (##structure
     gx#syntax-quote::t
     'column-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33648_|
    (##structure
     gx#syntax-quote::t
     'make-column-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33650_|
    (##structure
     gx#syntax-quote::t
     'column-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33652_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33653_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33654_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33656_|
    (##structure
     gx#syntax-quote::t
     'column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33657_|
    (##structure
     gx#syntax-quote::t
     'column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33658_|
    (##structure
     gx#syntax-quote::t
     'column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33660_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33661_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33662_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33664_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-columns-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33665_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33666_|
    (##structure
     gx#syntax-quote::t
     '&column-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33668_|
    (##structure
     gx#syntax-quote::t
     'key-projection::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33670_|
    (##structure
     gx#syntax-quote::t
     'make-key-projection
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33672_|
    (##structure
     gx#syntax-quote::t
     'key-projection?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33674_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33675_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33676_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33678_|
    (##structure
     gx#syntax-quote::t
     'key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33679_|
    (##structure
     gx#syntax-quote::t
     'key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33680_|
    (##structure
     gx#syntax-quote::t
     'key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33682_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33683_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33684_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33686_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-physical-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33687_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-writes-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/table/index-sharing[1]#_g33688_|
    (##structure
     gx#syntax-quote::t
     '&key-projection-frame-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/table/index-sharing[:0:]#column-order|
      (let ((__obj33530
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33530
           'gerbil-ascent/table/index-sharing#column-order::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 'column-order '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33530
           '(sets successors)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33530
           '(sets successors)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '#f '13 '#f '#f))
        (let ((__tmp33593 |gerbil-ascent/table/index-sharing[1]#_g33594_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33593 '4 '#f '#f))
        (let ((__tmp33595 |gerbil-ascent/table/index-sharing[1]#_g33596_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33595 '14 '#f '#f))
        (let ((__tmp33597 |gerbil-ascent/table/index-sharing[1]#_g33598_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33597 '15 '#f '#f))
        (let ((__tmp33599
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33600_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33601_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33599 '16 '#f '#f))
        (let ((__tmp33602
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33603_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33604_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33602 '17 '#f '#f))
        (let ((__tmp33605
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33606_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33607_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33605 '18 '#f '#f))
        (let ((__tmp33608
               (cons (cons 'sets
                           |gerbil-ascent/table/index-sharing[1]#_g33609_|)
                     (cons (cons 'successors
                                 |gerbil-ascent/table/index-sharing[1]#_g33610_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 __tmp33608 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33530 '() '21 '#f '#f))
        __obj33530))
    (define |gerbil-ascent/table/index-sharing[:0:]#shared-index|
      (let ((__obj33531
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33531
           'gerbil-ascent/table/index-sharing#shared-index::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 'shared-index '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33531
           '(columns root ordinal views projection key-plans)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33531
           '(columns root ordinal views projection key-plans)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '#f '13 '#f '#f))
        (let ((__tmp33611 |gerbil-ascent/table/index-sharing[1]#_g33612_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33611 '4 '#f '#f))
        (let ((__tmp33613 |gerbil-ascent/table/index-sharing[1]#_g33614_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33613 '14 '#f '#f))
        (let ((__tmp33615 |gerbil-ascent/table/index-sharing[1]#_g33616_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33615 '15 '#f '#f))
        (let ((__tmp33617
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33618_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33619_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33620_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33621_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33622_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33623_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33617 '16 '#f '#f))
        (let ((__tmp33624
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33625_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33626_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33627_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33628_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33629_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33630_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33624 '17 '#f '#f))
        (let ((__tmp33631
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33632_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33633_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33634_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33635_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33636_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33637_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33631 '18 '#f '#f))
        (let ((__tmp33638
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33639_|)
                     (cons (cons 'root
                                 |gerbil-ascent/table/index-sharing[1]#_g33640_|)
                           (cons (cons 'ordinal
                                       |gerbil-ascent/table/index-sharing[1]#_g33641_|)
                                 (cons (cons 'views
                                             |gerbil-ascent/table/index-sharing[1]#_g33642_|)
                                       (cons (cons 'projection
                                                   |gerbil-ascent/table/index-sharing[1]#_g33643_|)
                                             (cons (cons 'key-plans
                                                         |gerbil-ascent/table/index-sharing[1]#_g33644_|)
                                                   '()))))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 __tmp33638 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33531 '() '21 '#f '#f))
        __obj33531))
    (define |gerbil-ascent/table/index-sharing[:0:]#column-projection|
      (let ((__obj33532
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33532
           'gerbil-ascent/table/index-sharing#column-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33532
           'column-projection
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33532
           '(columns writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33532
           '(columns writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '#f '13 '#f '#f))
        (let ((__tmp33645 |gerbil-ascent/table/index-sharing[1]#_g33646_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33645 '4 '#f '#f))
        (let ((__tmp33647 |gerbil-ascent/table/index-sharing[1]#_g33648_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33647 '14 '#f '#f))
        (let ((__tmp33649 |gerbil-ascent/table/index-sharing[1]#_g33650_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33649 '15 '#f '#f))
        (let ((__tmp33651
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33652_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33653_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33654_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33651 '16 '#f '#f))
        (let ((__tmp33655
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33656_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33657_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33658_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33655 '17 '#f '#f))
        (let ((__tmp33659
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33660_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33661_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33662_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33659 '18 '#f '#f))
        (let ((__tmp33663
               (cons (cons 'columns
                           |gerbil-ascent/table/index-sharing[1]#_g33664_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33665_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33666_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 __tmp33663 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33532 '() '21 '#f '#f))
        __obj33532))
    (define |gerbil-ascent/table/index-sharing[:0:]#key-projection|
      (let ((__obj33533
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33533
           'gerbil-ascent/table/index-sharing#key-projection::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 'key-projection '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33533
           '(physical writes frame)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj33533
           '(physical writes frame)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '#t '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '#f '13 '#f '#f))
        (let ((__tmp33667 |gerbil-ascent/table/index-sharing[1]#_g33668_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33667 '4 '#f '#f))
        (let ((__tmp33669 |gerbil-ascent/table/index-sharing[1]#_g33670_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33669 '14 '#f '#f))
        (let ((__tmp33671 |gerbil-ascent/table/index-sharing[1]#_g33672_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33671 '15 '#f '#f))
        (let ((__tmp33673
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33674_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33675_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33676_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33673 '16 '#f '#f))
        (let ((__tmp33677
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33678_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33679_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33680_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33677 '17 '#f '#f))
        (let ((__tmp33681
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33682_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33683_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33684_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33681 '18 '#f '#f))
        (let ((__tmp33685
               (cons (cons 'physical
                           |gerbil-ascent/table/index-sharing[1]#_g33686_|)
                     (cons (cons 'writes
                                 |gerbil-ascent/table/index-sharing[1]#_g33687_|)
                           (cons (cons 'frame
                                       |gerbil-ascent/table/index-sharing[1]#_g33688_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 __tmp33685 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj33533 '() '21 '#f '#f))
        __obj33533))))
