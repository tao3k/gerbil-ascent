(declare (block) (standard-bindings) (extended-bindings))
(begin
  (begin
    (load-module "clan/poo/object")
    (load-module "clan/poo/mop")
    (load-module "gerbil-ascent/program/types"))
  (load-module "gerbil-ascent/program/scheme-query~0"))
