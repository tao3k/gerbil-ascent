(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/index[1]#_g36124_|
    (##structure
     gx#syntax-quote::t
     'row-indexes::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36126_|
    (##structure
     gx#syntax-quote::t
     'make-row-indexes
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36128_|
    (##structure
     gx#syntax-quote::t
     'row-indexes?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36130_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36131_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36132_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36133_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36135_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36136_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36137_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36138_|
    (##structure
     gx#syntax-quote::t
     'row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36140_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36141_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36142_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36143_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36145_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-rows-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36146_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-advance!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36147_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-plan!-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36148_|
    (##structure
     gx#syntax-quote::t
     '&row-indexes-visit-parts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36150_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36152_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-member
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36154_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36156_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36157_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36158_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36160_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36161_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36162_|
    (##structure
     gx#syntax-quote::t
     'provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36164_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36165_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36166_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36168_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-ordinal-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36169_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-key-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36170_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-member-occurrences-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36172_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36174_|
    (##structure
     gx#syntax-quote::t
     'make-provider-row-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36176_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36178_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36179_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36181_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36182_|
    (##structure
     gx#syntax-quote::t
     'provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36184_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36185_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36187_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-members-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36188_|
    (##structure
     gx#syntax-quote::t
     '&provider-row-witness-counts-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36190_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36192_|
    (##structure
     gx#syntax-quote::t
     'make-physical-index-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36194_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36196_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36197_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36198_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36199_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36201_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36202_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36203_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36204_|
    (##structure
     gx#syntax-quote::t
     'physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36206_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36207_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36208_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36209_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36211_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-version-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36212_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-lookup-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36213_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-shared?-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36214_|
    (##structure
     gx#syntax-quote::t
     '&physical-index-entry-witness-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36216_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36218_|
    (##structure
     gx#syntax-quote::t
     'make-atom-index-view
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36220_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36222_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36223_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36225_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36226_|
    (##structure
     gx#syntax-quote::t
     'atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36228_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36229_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36231_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-entry-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/index[1]#_g36232_|
    (##structure
     gx#syntax-quote::t
     '&atom-index-view-permutation-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/index[:0:]#row-indexes|
      (let ((__obj35815
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35815
           'gerbil-ascent/program/index#row-indexes::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 'row-indexes '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35815
           '(rows advance! plan! visit-parts)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35815
           '(rows advance! plan! visit-parts)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '#f '13 '#f '#f))
        (let ((__tmp36123 |gerbil-ascent/program/index[1]#_g36124_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36123 '4 '#f '#f))
        (let ((__tmp36125 |gerbil-ascent/program/index[1]#_g36126_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36125 '14 '#f '#f))
        (let ((__tmp36127 |gerbil-ascent/program/index[1]#_g36128_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36127 '15 '#f '#f))
        (let ((__tmp36129
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36130_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36131_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36132_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36133_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36129 '16 '#f '#f))
        (let ((__tmp36134
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36135_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36136_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36137_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36138_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36134 '17 '#f '#f))
        (let ((__tmp36139
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36140_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36141_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36142_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36143_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36139 '18 '#f '#f))
        (let ((__tmp36144
               (cons (cons 'rows |gerbil-ascent/program/index[1]#_g36145_|)
                     (cons (cons 'advance!
                                 |gerbil-ascent/program/index[1]#_g36146_|)
                           (cons (cons 'plan!
                                       |gerbil-ascent/program/index[1]#_g36147_|)
                                 (cons (cons 'visit-parts
                                             |gerbil-ascent/program/index[1]#_g36148_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 __tmp36144 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35815 '() '21 '#f '#f))
        __obj35815))
    (define |gerbil-ascent/program/index[:0:]#provider-row-member|
      (let ((__obj35816
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35816
           'gerbil-ascent/program/index#provider-row-member::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35816
           'provider-row-member
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35816
           '(ordinal key occurrences)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35816
           '(ordinal key occurrences)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '#f '13 '#f '#f))
        (let ((__tmp36149 |gerbil-ascent/program/index[1]#_g36150_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36149 '4 '#f '#f))
        (let ((__tmp36151 |gerbil-ascent/program/index[1]#_g36152_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36151 '14 '#f '#f))
        (let ((__tmp36153 |gerbil-ascent/program/index[1]#_g36154_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36153 '15 '#f '#f))
        (let ((__tmp36155
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36156_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36157_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36158_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36155 '16 '#f '#f))
        (let ((__tmp36159
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36160_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36161_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36162_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36159 '17 '#f '#f))
        (let ((__tmp36163
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36164_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36165_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36166_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36163 '18 '#f '#f))
        (let ((__tmp36167
               (cons (cons 'ordinal |gerbil-ascent/program/index[1]#_g36168_|)
                     (cons (cons 'key
                                 |gerbil-ascent/program/index[1]#_g36169_|)
                           (cons (cons 'occurrences
                                       |gerbil-ascent/program/index[1]#_g36170_|)
                                 '())))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 __tmp36167 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35816 '() '21 '#f '#f))
        __obj35816))
    (define |gerbil-ascent/program/index[:0:]#provider-row-witness|
      (let ((__obj35817
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35817
           'gerbil-ascent/program/index#provider-row-witness::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35817
           'provider-row-witness
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '(members counts) '6 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '(members counts) '8 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '#f '13 '#f '#f))
        (let ((__tmp36171 |gerbil-ascent/program/index[1]#_g36172_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36171 '4 '#f '#f))
        (let ((__tmp36173 |gerbil-ascent/program/index[1]#_g36174_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36173 '14 '#f '#f))
        (let ((__tmp36175 |gerbil-ascent/program/index[1]#_g36176_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36175 '15 '#f '#f))
        (let ((__tmp36177
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36178_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36179_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36177 '16 '#f '#f))
        (let ((__tmp36180
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36181_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36182_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36180 '17 '#f '#f))
        (let ((__tmp36183
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36184_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36185_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36183 '18 '#f '#f))
        (let ((__tmp36186
               (cons (cons 'members |gerbil-ascent/program/index[1]#_g36187_|)
                     (cons (cons 'counts
                                 |gerbil-ascent/program/index[1]#_g36188_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 __tmp36186 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35817 '() '21 '#f '#f))
        __obj35817))
    (define |gerbil-ascent/program/index[:0:]#physical-index-entry|
      (let ((__obj35818
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35818
           'gerbil-ascent/program/index#physical-index-entry::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35818
           'physical-index-entry
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35818
           '(version lookup shared? witness)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35818
           '(version lookup shared? witness)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '#f '13 '#f '#f))
        (let ((__tmp36189 |gerbil-ascent/program/index[1]#_g36190_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36189 '4 '#f '#f))
        (let ((__tmp36191 |gerbil-ascent/program/index[1]#_g36192_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36191 '14 '#f '#f))
        (let ((__tmp36193 |gerbil-ascent/program/index[1]#_g36194_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36193 '15 '#f '#f))
        (let ((__tmp36195
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36196_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36197_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36198_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36199_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36195 '16 '#f '#f))
        (let ((__tmp36200
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36201_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36202_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36203_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36204_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36200 '17 '#f '#f))
        (let ((__tmp36205
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36206_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36207_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36208_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36209_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36205 '18 '#f '#f))
        (let ((__tmp36210
               (cons (cons 'version |gerbil-ascent/program/index[1]#_g36211_|)
                     (cons (cons 'lookup
                                 |gerbil-ascent/program/index[1]#_g36212_|)
                           (cons (cons 'shared?
                                       |gerbil-ascent/program/index[1]#_g36213_|)
                                 (cons (cons 'witness
                                             |gerbil-ascent/program/index[1]#_g36214_|)
                                       '()))))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 __tmp36210 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35818 '() '21 '#f '#f))
        __obj35818))
    (define |gerbil-ascent/program/index[:0:]#atom-index-view|
      (let ((__obj35819
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35819
           'gerbil-ascent/program/index#atom-index-view::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 'atom-index-view '3 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35819
           '(entry permutation)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj35819
           '(entry permutation)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '#f '13 '#f '#f))
        (let ((__tmp36215 |gerbil-ascent/program/index[1]#_g36216_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36215 '4 '#f '#f))
        (let ((__tmp36217 |gerbil-ascent/program/index[1]#_g36218_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36217 '14 '#f '#f))
        (let ((__tmp36219 |gerbil-ascent/program/index[1]#_g36220_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36219 '15 '#f '#f))
        (let ((__tmp36221
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36222_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36223_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36221 '16 '#f '#f))
        (let ((__tmp36224
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36225_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36226_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36224 '17 '#f '#f))
        (let ((__tmp36227
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36228_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36229_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36227 '18 '#f '#f))
        (let ((__tmp36230
               (cons (cons 'entry |gerbil-ascent/program/index[1]#_g36231_|)
                     (cons (cons 'permutation
                                 |gerbil-ascent/program/index[1]#_g36232_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 __tmp36230 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj35819 '() '21 '#f '#f))
        __obj35819))))
