(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37738_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37740_|
    (##structure
     gx#syntax-quote::t
     'make-positive-nonmembership
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37742_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37744_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37745_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37746_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37747_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37748_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37749_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37750_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37751_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37752_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37754_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37755_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37756_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37757_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37758_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37759_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37760_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37761_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37762_|
    (##structure
     gx#syntax-quote::t
     'positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37764_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37765_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37766_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37767_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37768_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37769_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37770_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37771_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37772_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37774_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-status-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37775_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-identity-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37776_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-generation-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37777_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-snapshot-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37778_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-candidate-digest-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37779_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-program-fingerprint-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37780_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-query-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37781_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-work-budget-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[1]#_g37782_|
    (##structure
     gx#syntax-quote::t
     '&positive-nonmembership-closure-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/candidate/nonmembership[:0:]#positive-nonmembership|
    (let ((__obj37616
           (let ()
             (declare (not safe))
             (##structure
              gerbil/core/mop~MOP-2#class-type-info::t
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f
              '#f))))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37616
         'gerbil-ascent/candidate/nonmembership#positive-nonmembership::t
         '2
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37616
         'positive-nonmembership
         '3
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37616
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '6
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set!
         __obj37616
         '(status snapshot-identity
                  snapshot-generation
                  snapshot-digest
                  candidate-digest
                  program-fingerprint
                  query
                  work-budget
                  closure)
         '8
         '#f
         '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '() '5 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '#t '9 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '#f '10 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '#f '12 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '#f '13 '#f '#f))
      (let ((__tmp37737 |gerbil-ascent/candidate/nonmembership[1]#_g37738_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37737 '4 '#f '#f))
      (let ((__tmp37739 |gerbil-ascent/candidate/nonmembership[1]#_g37740_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37739 '14 '#f '#f))
      (let ((__tmp37741 |gerbil-ascent/candidate/nonmembership[1]#_g37742_|))
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37741 '15 '#f '#f))
      (let ((__tmp37743
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37744_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37745_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37746_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37747_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37748_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37749_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37750_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37751_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37752_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37743 '16 '#f '#f))
      (let ((__tmp37753
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37754_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37755_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37756_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37757_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37758_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37759_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37760_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37761_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37762_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37753 '17 '#f '#f))
      (let ((__tmp37763
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37764_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37765_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37766_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37767_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37768_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37769_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37770_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37771_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37772_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37763 '18 '#f '#f))
      (let ((__tmp37773
             (cons (cons 'status
                         |gerbil-ascent/candidate/nonmembership[1]#_g37774_|)
                   (cons (cons 'snapshot-identity
                               |gerbil-ascent/candidate/nonmembership[1]#_g37775_|)
                         (cons (cons 'snapshot-generation
                                     |gerbil-ascent/candidate/nonmembership[1]#_g37776_|)
                               (cons (cons 'snapshot-digest
                                           |gerbil-ascent/candidate/nonmembership[1]#_g37777_|)
                                     (cons (cons 'candidate-digest
                                                 |gerbil-ascent/candidate/nonmembership[1]#_g37778_|)
                                           (cons (cons 'program-fingerprint
                                                       |gerbil-ascent/candidate/nonmembership[1]#_g37779_|)
                                                 (cons (cons 'query
                                                             |gerbil-ascent/candidate/nonmembership[1]#_g37780_|)
                                                       (cons (cons 'work-budget
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                           |gerbil-ascent/candidate/nonmembership[1]#_g37781_|)
                     (cons (cons 'closure
                                 |gerbil-ascent/candidate/nonmembership[1]#_g37782_|)
                           '())))))))))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 __tmp37773 '19 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '() '20 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '() '22 '#f '#f))
      (let ()
        (declare (not safe))
        (##unchecked-structure-set! __obj37616 '() '21 '#f '#f))
      __obj37616)))
