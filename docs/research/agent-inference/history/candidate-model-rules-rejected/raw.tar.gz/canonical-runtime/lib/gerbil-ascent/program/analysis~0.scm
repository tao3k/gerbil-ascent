(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/program/analysis::timestamp 1791687878)
  (begin
    (define gerbil-ascent/program/analysis#+program-analysis-cache+
      (let ((__tmp35513 (make-mutex 'ascent-program-analysis)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35513)))
    (define gerbil-ascent/program/analysis#+program-schema-cache+
      (let ((__tmp35514 (make-mutex 'ascent-program-schema)))
        (declare (not safe))
        (make-hash-table-eq 'weak-keys: '#t 'lock: __tmp35514)))
    (define gerbil-ascent/program/analysis#gerbil-ascent-program-analysis
      (lambda (_%program8086%_ _%relations8087%_ _%rules8088%_ _%build8089%_)
        (let ((_%cached8091%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/analysis#+program-analysis-cache+
                  _%program8086%_))))
          (if (and _%cached8091%_
                   (eq? _%relations8087%_ (vector-ref _%cached8091%_ '0))
                   (eq? _%rules8088%_ (vector-ref _%cached8091%_ '1)))
              _%cached8091%_
              (let ((_%fresh8093%_ (_%build8089%_)))
                (let ()
                  (declare (not safe))
                  (__hash-put!
                   gerbil-ascent/program/analysis#+program-analysis-cache+
                   _%program8086%_
                   _%fresh8093%_))
                _%fresh8093%_)))))
    (define gerbil-ascent/program/analysis#gerbil-ascent-program-schema
      (lambda (_%program8031%_ _%relations8032%_)
        (let ((_%cached8034%_
               (let ()
                 (declare (not safe))
                 (__hash-get
                  gerbil-ascent/program/analysis#+program-schema-cache+
                  _%program8031%_))))
          (if (and _%cached8034%_
                   (eq? _%relations8032%_ (vector-ref _%cached8034%_ '0)))
              _%cached8034%_
              (let* ((_%count8036%_ (length _%relations8032%_))
                     (_%names8038%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%arity8040%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%field-checkers8042%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%positions8044%_
                      (let () (declare (not safe)) (make-hash-table-eq)))
                     (_%index-providers8046%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%storage-extensions8048%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%lattice-joins8050%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%kinds8052%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f)))
                     (_%storage-providers8054%_
                      (let ()
                        (declare (not safe))
                        (##make-vector _%count8036%_ '#f))))
                (for-each
                 (lambda (_%relation8057%_ _%index8058%_)
                   (let* ((_%name8060%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation8057%_ 'name)))
                          (_%width8062%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref _%relation8057%_ 'arity)))
                          (_%kind8064%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation8057%_
                              'storage-kind)))
                          (_%predicates8066%_
                           (let ()
                             (declare (not safe))
                             (clan/poo/object#.ref
                              _%relation8057%_
                              'field-predicates))))
                     (if (and (symbol? _%name8060%_)
                              (if (let ()
                                    (declare (not safe))
                                    (__hash-get
                                     _%positions8044%_
                                     _%name8060%_))
                                  '#f
                                  (and (exact-integer? _%width8062%_)
                                       (<= '0 _%width8062%_)
                                       (let ()
                                         (declare (not safe))
                                         (##memq _%kind8064%_
                                                 '(relation lattice)))
                                       (or (eq? _%kind8064%_ 'relation)
                                           (> _%width8062%_ '0))
                                       (list? _%predicates8066%_)
                                       (or (null? _%predicates8066%_)
                                           (= (let ()
                                                (declare (not safe))
                                                (##length _%predicates8066%_))
                                              _%width8062%_))
                                       (let ()
                                         (declare (not safe))
                                         (andmap__0
                                          procedure?
                                          _%predicates8066%_)))))
                         '#!void
                         (let ()
                           (declare (not safe))
                           (error '"invalid or duplicate ASCENT relation"
                                  _%name8060%_)))
                     (vector-set! _%names8038%_ _%index8058%_ _%name8060%_)
                     (vector-set! _%arity8040%_ _%index8058%_ _%width8062%_)
                     (vector-set! _%kinds8052%_ _%index8058%_ _%kind8064%_)
                     (let ((__tmp35515 (+ _%index8058%_ '1)))
                       (declare (not safe))
                       (__hash-put! _%positions8044%_ _%name8060%_ __tmp35515))
                     (if (pair? _%predicates8066%_)
                         (vector-set!
                          _%field-checkers8042%_
                          _%index8058%_
                          (lambda (_%row8075%_)
                            (let ((__tmp35516
                                   (lambda (_%predicate8077%_ _%value8078%_)
                                     (if (_%predicate8077%_ _%value8078%_)
                                         '#!void
                                         (let ()
                                           (declare (not safe))
                                           (error '"ASCENT relation field type mismatch"
                                                  _%name8060%_
                                                  _%row8075%_))))))
                              (declare (not safe))
                              (##for-each
                               __tmp35516
                               _%predicates8066%_
                               _%row8075%_))))
                         '#!void)
                     (vector-set!
                      _%index-providers8046%_
                      _%index8058%_
                      (let ()
                        (declare (not safe))
                        (clan/poo/object#.ref
                         _%relation8057%_
                         'index-provider)))
                     (if (eq? _%kind8064%_ 'lattice)
                         (let ((_%join8080%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%relation8057%_
                                   'join))))
                           (if (procedure? _%join8080%_)
                               '#!void
                               (let ()
                                 (declare (not safe))
                                 (error '"invalid ASCENT lattice join"
                                        _%name8060%_)))
                           (vector-set!
                            _%lattice-joins8050%_
                            _%index8058%_
                            _%join8080%_))
                         (let ((_%provider8082%_
                                (let ()
                                  (declare (not safe))
                                  (clan/poo/object#.ref
                                   _%relation8057%_
                                   'storage-provider))))
                           (vector-set!
                            _%storage-providers8054%_
                            _%index8058%_
                            _%provider8082%_)
                           (vector-set!
                            _%storage-extensions8048%_
                            _%index8058%_
                            (let ()
                              (declare (not safe))
                              (gerbil-ascent/table/storage#gerbil-ascent-storage-engine-extension
                               _%provider8082%_
                               _%width8062%_)))))))
                 _%relations8032%_
                 (let () (declare (not safe)) (##iota _%count8036%_)))
                (let ((_%fresh8084%_
                       (vector _%relations8032%_
                               _%names8038%_
                               _%arity8040%_
                               _%field-checkers8042%_
                               _%positions8044%_
                               _%index-providers8046%_
                               _%storage-extensions8048%_
                               _%lattice-joins8050%_
                               _%kinds8052%_
                               _%storage-providers8054%_)))
                  (let ()
                    (declare (not safe))
                    (__hash-put!
                     gerbil-ascent/program/analysis#+program-schema-cache+
                     _%program8031%_
                     _%fresh8084%_))
                  _%fresh8084%_))))))))
