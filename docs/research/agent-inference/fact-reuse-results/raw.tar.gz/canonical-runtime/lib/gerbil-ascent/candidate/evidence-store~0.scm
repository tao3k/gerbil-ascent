(declare (block) (standard-bindings) (extended-bindings))
(begin
  (define gerbil-ascent/candidate/evidence-store::timestamp 1791691041)
  (begin
    (define gerbil-ascent/candidate/evidence-store#evidence-entry::t
      (let ((__tmp39875 (list))
            (__tmp39874
             (cons (cons 'struct: '#t) (cons (cons 'final: '#t) '()))))
        (declare (not safe))
        (make-class-type
         'gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'evidence-entry
         __tmp39875
         '(snapshot candidate receipt handle)
         __tmp39874
         '#f)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry?
      (let ()
        (declare (not safe))
        (__make-class-predicate
         gerbil-ascent/candidate/evidence-store#evidence-entry::t)))
    (define gerbil-ascent/candidate/evidence-store#make-evidence-entry
      (lambda _%$args30731%_
        (apply make-instance
               gerbil-ascent/candidate/evidence-store#evidence-entry::t
               _%$args30731%_)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-accessor
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-snapshot-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'snapshot)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-candidate-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'candidate)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-receipt-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'receipt)))
    (define gerbil-ascent/candidate/evidence-store#&evidence-entry-handle-set!
      (let ()
        (declare (not safe))
        (__make-class-slot-unchecked-mutator
         gerbil-ascent/candidate/evidence-store#evidence-entry::t
         'handle)))
    (define gerbil-ascent/candidate/evidence-store#evidence-operations?
      (lambda (_%owner30727%_)
        (if (let ()
              (declare (not safe))
              (##structure-instance-of?
               _%owner30727%_
               'clan/poo/object#object::t))
            (let ((__tmp39876
                   (lambda (_%slot30729%_)
                     (if (let ()
                           (declare (not safe))
                           (clan/poo/object#.slot?
                            _%owner30727%_
                            _%slot30729%_))
                         (procedure?
                          (let ()
                            (declare (not safe))
                            (clan/poo/object#.ref
                             _%owner30727%_
                             _%slot30729%_)))
                         '#f))))
              (declare (not safe))
              (andmap__0
               __tmp39876
               '(.resolve
                 .claim
                 .fact
                 .fragment
                 .certificate
                 .partition
                 .stats
                 .clear)))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
      (let ((__obj39871
             (let ()
               (declare (not safe))
               (##structure
                clan/poo/object#object::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ((__tmp39878
               (list (cons 'sexp
                           (let ((__tmp39879
                                  (lambda (_%@30676%_)
                                    'GerbilAscentEvidenceStoreContract)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp39879)))
                     (cons 'identity
                           (let ((__tmp39880
                                  (lambda (_%@30682%_)
                                    'ascent/computational-evidence-store)))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp39880)))
                     (cons 'proto
                           (let ((__tmp39881
                                  (lambda (_%@30687%_)
                                    (let ((__obj39869
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp39883 (list))
                                            (__tmp39882 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp39883
                                         __tmp39882
                                         __obj39869))
                                      __obj39869))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp39881)))
                     (cons 'responsibilities
                           (let ((__tmp39884
                                  (lambda (_%@30701%_)
                                    (let ((__obj39870
                                           (let ()
                                             (declare (not safe))
                                             (##structure
                                              clan/poo/object#object::t
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f
                                              '#f))))
                                      (let ((__tmp39886
                                             (list (cons '.operations
                                                         (let ((__tmp39887
                                                                (lambda (_%self30717%_)
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (let ((__tmp39888
                                 (lambda (_%_v30724%_ _%_c30725%_) '())))
                            (declare (not safe))
                            (core/types#poo-flow-predicate-contract
                             'ascent/evidence-operations
                             gerbil-ascent/candidate/evidence-store#evidence-operations?
                             __tmp39888)))))
                   (declare (not safe))
                   (##structure
                    clan/poo/object#$self-slot-spec::t
                    __tmp39887)))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            (__tmp39885 (list)))
                                        (declare (not safe))
                                        (clan/poo/object#object:::init!__%
                                         '#f
                                         '()
                                         __tmp39886
                                         __tmp39885
                                         __obj39870))
                                      __obj39870))))
                             (declare (not safe))
                             (##structure
                              clan/poo/object#$self-slot-spec::t
                              __tmp39884)))))
              (__tmp39877 (list)))
          (declare (not safe))
          (clan/poo/object#object:::init!__%
           '#f
           core/types#PooFlowNativeObjectContract.
           __tmp39878
           __tmp39877
           __obj39871))
        __obj39871))
    (define gerbil-ascent/candidate/evidence-store#detached
      (lambda (_%value30658%_)
        (if (pair? _%value30658%_)
            (cons (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##car _%value30658%_)))
                  (gerbil-ascent/candidate/evidence-store#detached
                   (let () (declare (not safe)) (##cdr _%value30658%_))))
            (if (string? _%value30658%_)
                (let () (declare (not safe)) (##string-copy _%value30658%_))
                _%value30658%_))))
    (define gerbil-ascent/candidate/evidence-store#scope-key
      (lambda (_%snapshot30653%_ _%candidate30654%_)
        (if (let ()
              (declare (not safe))
              (gerbil-ascent/candidate/types#reasoning-snapshot-valid?
               _%snapshot30653%_))
            (let ((_%digest30656%_
                   (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#candidate-content-digest
                      _%candidate30654%_))))
              (if _%digest30656%_
                  (list (##structure-ref
                         _%snapshot30653%_
                         '1
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30653%_
                         '2
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        (##structure-ref
                         _%snapshot30653%_
                         '3
                         gerbil-ascent/candidate/types#reasoning-snapshot::t
                         '#f)
                        _%digest30656%_)
                  '#f))
            '#f)))
    (define gerbil-ascent/candidate/evidence-store#scope-description
      (lambda (_%entry30648%_)
        (let ((_%snapshot30650%_
               (##direct-structure-ref
                _%entry30648%_
                '1
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f))
              (_%receipt30651%_
               (##direct-structure-ref
                _%entry30648%_
                '3
                gerbil-ascent/candidate/evidence-store#evidence-entry::t
                '#f)))
          (list (list 'source-identity
                      (##structure-ref
                       _%snapshot30650%_
                       '1
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'generation
                      (##structure-ref
                       _%snapshot30650%_
                       '2
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'source-digest
                      (##structure-ref
                       _%snapshot30650%_
                       '3
                       gerbil-ascent/candidate/types#reasoning-snapshot::t
                       '#f))
                (list 'candidate-digest
                      (##structure-ref
                       _%receipt30651%_
                       '5
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))
                (list 'query
                      (##structure-ref
                       _%receipt30651%_
                       '6
                       gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                       '#f))))))
    (define gerbil-ascent/candidate/evidence-store#describe-entry
      (lambda (_%entry30645%_ _%reused?30646%_)
        (gerbil-ascent/candidate/evidence-store#detached
         (list (list 'status 'verified)
               (list 'finite-complete '#t)
               (list 'handle
                     (##direct-structure-ref
                      _%entry30645%_
                      '4
                      gerbil-ascent/candidate/evidence-store#evidence-entry::t
                      '#f))
               (list 'reused _%reused?30646%_)
               (list 'scope
                     (gerbil-ascent/candidate/evidence-store#scope-description
                      _%entry30645%_))
               (list 'rows
                     (##structure-ref
                      (##direct-structure-ref
                       _%entry30645%_
                       '3
                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                       '#f)
                      '7
                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                      '#f))))))
    (define gerbil-ascent/candidate/evidence-store#unknown
      (lambda (_%reason30643%_)
        (list (list 'status 'unknown) (list 'reason _%reason30643%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
      (lambda (_%max-entries30359%_ _%proof-steps30360%_ _%work-steps30361%_)
        (if (let ((__tmp39890
                   (lambda (_%v30363%_)
                     (and (exact-integer? _%v30363%_) (> _%v30363%_ '0))))
                  (__tmp39889
                   (list _%max-entries30359%_
                         _%proof-steps30360%_
                         _%work-steps30361%_)))
              (declare (not safe))
              (andmap__0 __tmp39890 __tmp39889))
            '#!void
            (let ()
              (declare (not safe))
              (error '"evidence store requires positive bounds")))
        (let ((_%entries30365%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%handles30366%_
               (let ()
                 (declare (not safe))
                 (make-hash-table__%
                  '#f
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value
                  absent-value)))
              (_%order30367%_ '())
              (_%serial30368%_ '0)
              (_%builds30369%_ '0)
              (_%hits30370%_ '0)
              (_%attempts30371%_ '0)
              (_%evictions30372%_ '0)
              (_%gate30373%_ (make-mutex 'ascent-evidence-owner)))
          (letrec ((_%serialized30375%_
                    (lambda (_%call30616%_)
                      (if (eq? (mutex-state _%gate30373%_) (current-thread))
                          (let ()
                            (declare (not safe))
                            (error '"reentrant evidence owner call"))
                          '#!void)
                      (let ()
                        (declare (not safe))
                        (with-dynamic-lock _%gate30373%_ _%call30616%_))))
                   (_%bound-entry30376%_
                    (lambda (_%snapshot30610%_
                             _%candidate30611%_
                             _%handle30612%_)
                      (let ((_%entry30614%_
                             (if (exact-integer? _%handle30612%_)
                                 (let ()
                                   (declare (not safe))
                                   (__hash-get
                                    _%handles30366%_
                                    _%handle30612%_))
                                 '#f)))
                        (if _%entry30614%_
                            (if (let ((__tmp39891
                                       (##direct-structure-ref
                                        _%entry30614%_
                                        '3
                                        gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                        '#f)))
                                  (declare (not safe))
                                  (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                   __tmp39891
                                   _%snapshot30610%_
                                   _%candidate30611%_))
                                _%entry30614%_
                                '#f)
                            '#f))))
                   (_%resolve30377%_
                    (lambda (_%snapshot30574%_ _%candidate30575%_)
                      (let* ((_%key30577%_
                              (gerbil-ascent/candidate/evidence-store#scope-key
                               _%snapshot30574%_
                               _%candidate30575%_))
                             (_%entry30579%_
                              (if _%key30577%_
                                  (let ()
                                    (declare (not safe))
                                    (__hash-get _%entries30365%_ _%key30577%_))
                                  '#f)))
                        (if _%key30577%_
                            (if (and _%entry30579%_
                                     (let ((__tmp39892
                                            (##direct-structure-ref
                                             _%entry30579%_
                                             '3
                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                        __tmp39892
                                        _%snapshot30574%_
                                        _%candidate30575%_)))
                                (let ()
                                  (set! _%hits30370%_ (+ _%hits30370%_ '1))
                                  (gerbil-ascent/candidate/evidence-store#describe-entry
                                   _%entry30579%_
                                   '#t))
                                (let ()
                                  (set! _%attempts30371%_
                                        (+ _%attempts30371%_ '1))
                                  (let ((__tmp39906
                                         (lambda (_%$%g3058430586%_)
                                           (let ((_%e30590%_
                                                  _%$%g3058430586%_))
                                             (gerbil-ascent/candidate/evidence-store#unknown
                                              (let ()
                                                (declare (not safe))
                                                (std/error#exception->string
                                                 _%e30590%_))))))
                                        (__tmp39893
                                         (lambda ()
                                           (let* ((_%owned-source30594%_
                                                   (let ((__tmp39896
                                                          (gerbil-ascent/candidate/evidence-store#detached
                                                           (##structure-ref
                                                            _%snapshot30574%_
                                                            '1
                                                            gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                            '#f)))
                                                         (__tmp39895
                                                          (##structure-ref
                                                           _%snapshot30574%_
                                                           '2
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f))
                                                         (__tmp39894
                                                          (##structure-ref
                                                           _%snapshot30574%_
                                                           '4
                                                           gerbil-ascent/candidate/types#reasoning-snapshot::t
                                                           '#f)))
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-source-snapshot
                                                      __tmp39896
                                                      __tmp39895
                                                      __tmp39894)))
                                                  (_%owned-candidate30596%_
                                                   (gerbil-ascent/candidate/evidence-store#detached
                                                    _%candidate30575%_))
                                                  (_%receipt30598%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (gerbil-ascent/candidate/reasoning#reasoning-attempt__%
                                                      _%owned-source30594%_
                                                      _%owned-candidate30596%_
                                                      _%proof-steps30360%_
                                                      _%work-steps30361%_)))
                                                  (_%rows30600%_
                                                   (let ()
                                                     (declare (not safe))
                                                     (##unchecked-structure-ref
                                                      _%receipt30598%_
                                                      '7
                                                      '#f
                                                      '#f))))
                                             (if (and (let ()
                                                        (declare (not safe))
                                                        (gerbil-ascent/candidate/reasoning#reasoning-receipt-bound?
                                                         _%receipt30598%_
                                                         _%snapshot30574%_
                                                         _%candidate30575%_))
                                                      (eq? (let ()
                                                             (declare
                                                               (not safe))
                                                             (##unchecked-structure-ref
                                                              _%receipt30598%_
                                                              '1
                                                              '#f
                                                              '#f))
                                                           'complete)
                                                      (let ((__tmp39897
                                                             (let ()
                                                               (declare
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                         (not safe))
                       (##unchecked-structure-ref
                        _%receipt30598%_
                        '10
                        '#f
                        '#f))))
                (declare (not safe))
                (##structure-instance-of?
                 __tmp39897
                 'gerbil-ascent/candidate/provenance#positive-proof::t))
              (or (null? _%rows30600%_)
                  (let ((__tmp39900
                         (let ()
                           (declare (not safe))
                           (gerbil-ascent/candidate/program#candidate-inspect
                            _%owned-source30594%_
                            _%owned-candidate30596%_)))
                        (__tmp39899
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30598%_
                            '5
                            '#f
                            '#f)))
                        (__tmp39898
                         (let ()
                           (declare (not safe))
                           (##unchecked-structure-ref
                            _%receipt30598%_
                            '10
                            '#f
                            '#f))))
                    (declare (not safe))
                    (gerbil-ascent/candidate/provenance#candidate-verify-positive-proof
                     _%owned-source30594%_
                     __tmp39900
                     __tmp39899
                     'complete
                     _%rows30600%_
                     __tmp39898
                     _%proof-steps30360%_)))
              (eq? (let ()
                     (declare (not safe))
                     (gerbil-ascent/candidate/reasoning#reasoning-verify-finite-receipt
                      _%receipt30598%_
                      _%owned-source30594%_
                      _%owned-candidate30596%_
                      _%work-steps30361%_))
                   'valid))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                 (begin
                                                   (if (>= (let ()
                                                             (declare
                                                               (not safe))
                                                             (__hash-length
                                                              _%entries30365%_))
                                                           _%max-entries30359%_)
                                                       (begin
                                                         (let ((_%old30606%_
                                                                (let ((__tmp39901
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                               (car _%order30367%_)))
                          (declare (not safe))
                          (hash-ref__0 _%entries30365%_ __tmp39901))))
                   (let ((__tmp39902
                          (##direct-structure-ref
                           _%old30606%_
                           '4
                           gerbil-ascent/candidate/evidence-store#evidence-entry::t
                           '#f)))
                     (declare (not safe))
                     (__hash-remove! _%handles30366%_ __tmp39902))
                   (let ((__tmp39903 (car _%order30367%_)))
                     (declare (not safe))
                     (__hash-remove! _%entries30365%_ __tmp39903)))
                 (set! _%order30367%_ (cdr _%order30367%_))
                 (set! _%evictions30372%_ (+ _%evictions30372%_ '1)))
               '#!void)
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                   (set! _%serial30368%_
                                                         (+ _%serial30368%_
                                                            '1))
                                                   (set! _%builds30369%_
                                                         (+ _%builds30369%_
                                                            '1))
                                                   (let ((_%admitted30608%_
                                                          (let ()
                                                            (declare
                                                              (not safe))
                                                            (##structure
                                                             gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                             _%owned-source30594%_
                                                             _%owned-candidate30596%_
                                                             _%receipt30598%_
                                                             _%serial30368%_))))
                                                     (let ((__tmp39904
                                                            (gerbil-ascent/candidate/evidence-store#detached
                                                             _%key30577%_)))
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%entries30365%_
                                                        __tmp39904
                                                        _%admitted30608%_))
                                                     (let ()
                                                       (declare (not safe))
                                                       (__hash-put!
                                                        _%handles30366%_
                                                        _%serial30368%_
                                                        _%admitted30608%_))
                                                     (set! _%order30367%_
                                                           (let ((__tmp39905
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          (list (gerbil-ascent/candidate/evidence-store#detached
                                 _%key30577%_))))
                     (declare (not safe))
                     (##append _%order30367%_ __tmp39905)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (gerbil-ascent/candidate/evidence-store#describe-entry
                                                      _%admitted30608%_
                                                      '#f)))
                                                 (gerbil-ascent/candidate/evidence-store#unknown
                                                  'unverified-receipt))))))
                                    (declare (not safe))
                                    (__with-catch __tmp39906 __tmp39893))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'invalid-scope)))))
                   (_%claim30378%_
                    (lambda (_%snapshot30562%_
                             _%candidate30563%_
                             _%handle30564%_
                             _%row30565%_)
                      (let ((_%entry30567%_
                             (_%bound-entry30376%_
                              _%snapshot30562%_
                              _%candidate30563%_
                              _%handle30564%_)))
                        (if _%entry30567%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%row30565%_
                                        '16384
                                        '128))
                                     (list? _%row30565%_)
                                     (= (let ()
                                          (declare (not safe))
                                          (##length _%row30565%_))
                                        (length (cdr (##structure-ref
                                                      (##direct-structure-ref
                                                       _%entry30567%_
                                                       '3
                                                       gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                       '#f)
                                                      '6
                                                      gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                      '#f))))
                                     (let ()
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        _%row30565%_))
                                     (let ((__tmp39907
                                            (##structure-ref
                                             (##direct-structure-ref
                                              _%entry30567%_
                                              '3
                                              gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                              '#f)
                                             '6
                                             gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                             '#f)))
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/funs#candidate-bind-atom
                                        __tmp39907
                                        _%row30565%_
                                        '())))
                                (let ((_%present30572%_
                                       (if (member _%row30565%_
                                                   (##structure-ref
                                                    (##direct-structure-ref
                                                     _%entry30567%_
                                                     '3
                                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                                     '#f)
                                                    '7
                                                    gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                                    '#f))
                                           '#t
                                           '#f)))
                                  (gerbil-ascent/candidate/evidence-store#detached
                                   (list (list 'status
                                               (if _%present30572%_
                                                   'verified
                                                   'finite-absent))
                                         (list 'present _%present30572%_)
                                         (list 'row _%row30565%_)
                                         (list 'handle _%handle30564%_)
                                         (list 'scope
                                               (gerbil-ascent/candidate/evidence-store#scope-description
                                                _%entry30567%_)))))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-query-row))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%certificate30379%_
                    (lambda (_%snapshot30549%_
                             _%candidate30550%_
                             _%handle30551%_)
                      (let ((_%entry30553%_
                             (_%bound-entry30376%_
                              _%snapshot30549%_
                              _%candidate30550%_
                              _%handle30551%_)))
                        (if _%entry30553%_
                            (let* ((_%receipt30555%_
                                    (##direct-structure-ref
                                     _%entry30553%_
                                     '3
                                     gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                     '#f))
                                   (_%proof30557%_
                                    (##structure-ref
                                     _%receipt30555%_
                                     '10
                                     gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                     '#f)))
                              (gerbil-ascent/candidate/evidence-store#detached
                               (list (list 'status 'verified)
                                     (list 'handle _%handle30551%_)
                                     (list 'scope
                                           (gerbil-ascent/candidate/evidence-store#scope-description
                                            _%entry30553%_))
                                     (list 'finite-closure
                                           (##structure-ref
                                            (##structure-ref
                                             (##structure-ref
                                              _%receipt30555%_
                                              '12
                                              gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                              '#f)
                                             '2
                                             gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                             '#f)
                                            '9
                                            gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                            '#f))
                                     (list 'positive-proof-status
                                           (##structure-ref
                                            _%proof30557%_
                                            '1
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'roots
                                           (##structure-ref
                                            _%proof30557%_
                                            '9
                                            gerbil-ascent/candidate/provenance#positive-proof::t
                                            '#f))
                                     (list 'nodes
                                           (map (lambda (_%n30560%_)
                                                  (list (##structure-ref
                                                         _%n30560%_
                                                         '1
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30560%_
                                                         '2
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30560%_
                                                         '3
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30560%_
                                                         '4
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30560%_
                                                         '5
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)
                                                        (##structure-ref
                                                         _%n30560%_
                                                         '6
                                                         gerbil-ascent/candidate/provenance#proof-node::t
                                                         '#f)))
                                                (##structure-ref
                                                 _%proof30557%_
                                                 '8
                                                 gerbil-ascent/candidate/provenance#positive-proof::t
                                                 '#f))))))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fact30380%_
                    (lambda (_%snapshot30525%_
                             _%candidate30526%_
                             _%handle30527%_
                             _%atom30528%_)
                      (let ((_%entry30530%_
                             (_%bound-entry30376%_
                              _%snapshot30525%_
                              _%candidate30526%_
                              _%handle30527%_)))
                        (if _%entry30530%_
                            (if (and (let ()
                                       (declare (not safe))
                                       (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                                        _%atom30528%_
                                        '16384
                                        '128))
                                     (list? _%atom30528%_)
                                     (pair? _%atom30528%_)
                                     (symbol? (let ()
                                                (declare (not safe))
                                                (##car _%atom30528%_)))
                                     (let ((__tmp39908
                                            (let ()
                                              (declare (not safe))
                                              (##cdr _%atom30528%_))))
                                       (declare (not safe))
                                       (andmap__0
                                        gerbil-ascent/candidate/program#scalar?
                                        __tmp39908)))
                                (let* ((_%receipt30535%_
                                        (##direct-structure-ref
                                         _%entry30530%_
                                         '3
                                         gerbil-ascent/candidate/evidence-store#evidence-entry::t
                                         '#f))
                                       (_%closure30537%_
                                        (##structure-ref
                                         (##structure-ref
                                          (##structure-ref
                                           _%receipt30535%_
                                           '12
                                           gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                                           '#f)
                                          '2
                                          gerbil-ascent/candidate/reasoning#reasoning-stratified-evidence::t
                                          '#f)
                                         '9
                                         gerbil-ascent/candidate/finite-evidence#finite-evidence::t
                                         '#f))
                                       (_%relation30539%_
                                        (assq (car _%atom30528%_)
                                              _%closure30537%_)))
                                  (if (and _%relation30539%_
                                           (= (length (cdr _%atom30528%_))
                                              (cadr _%relation30539%_)))
                                      (let* ((_%present30542%_
                                              (if (member (cdr _%atom30528%_)
                                                          (caddr _%relation30539%_))
                                                  '#t
                                                  '#f))
                                             (_%support30546%_
                                              (filter (lambda (_%node30544%_)
                                                        (if (eq? (##structure-ref
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                          _%node30544%_
                          '3
                          gerbil-ascent/candidate/provenance#proof-node::t
                          '#f)
                         (car _%atom30528%_))
                    (equal? (##structure-ref
                             _%node30544%_
                             '4
                             gerbil-ascent/candidate/provenance#proof-node::t
                             '#f)
                            (cdr _%atom30528%_))
                    '#f))
              (##structure-ref
               (##structure-ref
                _%receipt30535%_
                '10
                gerbil-ascent/candidate/reasoning#reasoning-receipt::t
                '#f)
               '8
               gerbil-ascent/candidate/provenance#positive-proof::t
               '#f))))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                        (gerbil-ascent/candidate/evidence-store#detached
                                         (list (list 'status
                                                     (if _%present30542%_
                                                         'verified
                                                         'finite-absent))
                                               (list 'present _%present30542%_)
                                               (list 'atom _%atom30528%_)
                                               (list 'handle _%handle30527%_)
                                               (list 'basis
                                                     'verified-finite-closure)
                                               (list 'support-nodes
                                                     (let ()
                                                       (declare (not safe))
                                                       (##map gerbil-ascent/candidate/provenance#proof-node-id
                                                              _%support30546%_)))
                                               (list 'scope
                                                     (gerbil-ascent/candidate/evidence-store#scope-description
                                                      _%entry30530%_)))))
                                      (gerbil-ascent/candidate/evidence-store#unknown
                                       'unknown-relation-or-arity)))
                                (gerbil-ascent/candidate/evidence-store#unknown
                                 'invalid-atom))
                            (gerbil-ascent/candidate/evidence-store#unknown
                             'stale-or-unknown-handle)))))
                   (_%fragment30381%_
                    (lambda (_%snapshot30501%_
                             _%candidate30502%_
                             _%handle30503%_
                             _%atom30504%_)
                      (let ((_%answer30506%_
                             (_%fact30380%_
                              _%snapshot30501%_
                              _%candidate30502%_
                              _%handle30503%_
                              _%atom30504%_)))
                        (if (eq? (cadr (assq 'status _%answer30506%_))
                                 'verified)
                            (let* ((_%proof30508%_
                                    (_%certificate30379%_
                                     _%snapshot30501%_
                                     _%candidate30502%_
                                     _%handle30503%_))
                                   (_%nodes30510%_
                                    (cadr (assq 'nodes _%proof30508%_)))
                                   (_%roots30512%_
                                    (cadr (assq 'support-nodes
                                                _%answer30506%_)))
                                   (_%seen30514%_ '())
                                   (_%selected30516%_ '()))
                              (letrec ((_%visit30519%_
                                        (lambda (_%id30521%_)
                                          (if (let ()
                                                (declare (not safe))
                                                (##member
                                                 _%id30521%_
                                                 _%seen30514%_))
                                              '#!void
                                              (let ((_%node30523%_
                                                     (assoc _%id30521%_
                                                            _%nodes30510%_)))
                                                (if _%node30523%_
                                                    '#!void
                                                    (let ()
                                                      (declare (not safe))
                                                      (error '"verified proof has missing support"
                                                             _%id30521%_)))
                                                (set! _%seen30514%_
                                                      (cons _%id30521%_
                                                            _%seen30514%_))
                                                (for-each
                                                 _%visit30519%_
                                                 (list-ref _%node30523%_ '5))
                                                (set! _%selected30516%_
                                                      (cons _%node30523%_
                                                            _%selected30516%_)))))))
                                (for-each _%visit30519%_ _%roots30512%_)
                                (gerbil-ascent/candidate/evidence-store#detached
                                 (list (list 'status 'verified)
                                       (list 'fact _%answer30506%_)
                                       (list 'roots _%roots30512%_)
                                       (list 'nodes
                                             (let ()
                                               (declare (not safe))
                                               (##reverse
                                                _%selected30516%_)))))))
                            _%answer30506%_)))))
            (let ((__tmp39909
                   (let ((__obj39873
                          (let ()
                            (declare (not safe))
                            (##structure
                             clan/poo/object#object::t
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f
                             '#f))))
                     (let ((__tmp39923
                            (let ()
                              (declare (not safe))
                              (clan/poo/object#.ref
                               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
                               'proto)))
                           (__tmp39911
                            (list (cons '.operations
                                        (let ((__tmp39912
                                               (lambda (_%@30396%_)
                                                 (let ((__obj39872
                                                        (let ()
                                                          (declare (not safe))
                                                          (##structure
                                                           clan/poo/object#object::t
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f
                                                           '#f))))
                                                   (let ((__tmp39914
                                                          (list (cons '.resolve
;;<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                              (let ((__tmp39915
                                     (lambda (_%self30420%_)
                                       (lambda (_%snapshot30427%_
                                                _%candidate30428%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (_%resolve30377%_
                                             _%snapshot30427%_
                                             _%candidate30428%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39915)))
                        (cons '.claim
                              (let ((__tmp39916
                                     (lambda (_%self30431%_)
                                       (lambda (_%snapshot30436%_
                                                _%candidate30437%_
                                                _%handle30438%_
                                                _%row30439%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (_%claim30378%_
                                             _%snapshot30436%_
                                             _%candidate30437%_
                                             _%handle30438%_
                                             _%row30439%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39916)))
                        (cons '.fact
                              (let ((__tmp39917
                                     (lambda (_%self30442%_)
                                       (lambda (_%snapshot30447%_
                                                _%candidate30448%_
                                                _%handle30449%_
                                                _%atom30450%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (_%fact30380%_
                                             _%snapshot30447%_
                                             _%candidate30448%_
                                             _%handle30449%_
                                             _%atom30450%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39917)))
                        (cons '.fragment
                              (let ((__tmp39918
                                     (lambda (_%self30453%_)
                                       (lambda (_%snapshot30458%_
                                                _%candidate30459%_
                                                _%handle30460%_
                                                _%atom30461%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (_%fragment30381%_
                                             _%snapshot30458%_
                                             _%candidate30459%_
                                             _%handle30460%_
                                             _%atom30461%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39918)))
                        (cons '.certificate
                              (let ((__tmp39919
                                     (lambda (_%self30464%_)
                                       (lambda (_%snapshot30469%_
                                                _%candidate30470%_
                                                _%handle30471%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (_%certificate30379%_
                                             _%snapshot30469%_
                                             _%candidate30470%_
                                             _%handle30471%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39919)))
                        (cons '.partition
                              (let ((__tmp39920
                                     (lambda (_%self30474%_)
                                       (lambda (_%snapshot30479%_
                                                _%candidate30480%_
                                                _%handle30481%_
                                                _%alternatives30482%_)
                                         (_%serialized30375%_
                                          (lambda ()
                                            (gerbil-ascent/candidate/evidence-store#partition-obligations
                                             (lambda (_%atom30485%_)
                                               (_%fact30380%_
                                                _%snapshot30479%_
                                                _%candidate30480%_
                                                _%handle30481%_
                                                _%atom30485%_))
                                             _%alternatives30482%_)))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39920)))
                        (cons '.stats
                              (let ((__tmp39921
                                     (lambda (_%self30487%_)
                                       (lambda ()
                                         (_%serialized30375%_
                                          (lambda ()
                                            (list (list 'entries
                                                        (let ()
                                                          (declare (not safe))
                                                          (__hash-length
                                                           _%entries30365%_)))
                                                  (list 'attempts
                                                        _%attempts30371%_)
                                                  (list 'proof-builds
                                                        _%builds30369%_)
                                                  (list 'hits _%hits30370%_)
                                                  (list 'evictions
                                                        _%evictions30372%_))))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39921)))
                        (cons '.clear
                              (let ((__tmp39922
                                     (lambda (_%self30494%_)
                                       (lambda ()
                                         (_%serialized30375%_
                                          (lambda ()
                                            (set! _%entries30365%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%handles30366%_
                                                  (let ()
                                                    (declare (not safe))
                                                    (make-hash-table__%
                                                     '#f
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value
                                                     absent-value)))
                                            (set! _%order30367%_ '())
                                            '#t))))))
                                (declare (not safe))
                                (##structure
                                 clan/poo/object#$self-slot-spec::t
                                 __tmp39922)))))
                 (__tmp39913 (list)))
;;>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                                     (declare (not safe))
                                                     (clan/poo/object#object:::init!__%
                                                      '#f
                                                      '()
                                                      __tmp39914
                                                      __tmp39913
                                                      __obj39872))
                                                   __obj39872))))
                                          (declare (not safe))
                                          (##structure
                                           clan/poo/object#$self-slot-spec::t
                                           __tmp39912)))))
                           (__tmp39910 (list)))
                       (declare (not safe))
                       (clan/poo/object#object:::init!__%
                        '#f
                        __tmp39923
                        __tmp39911
                        __tmp39910
                        __obj39873))
                     __obj39873)))
              (declare (not safe))
              (clan/poo/mop#validate
               gerbil-ascent/candidate/evidence-store#GerbilAscentEvidenceStoreContract
               __tmp39909))))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
      (lambda ()
        (let* ((_%max-entries30622%_ '64)
               (_%proof-steps30624%_ '100000)
               (_%work-steps30626%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30622%_
           _%proof-steps30624%_
           _%work-steps30626%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
      (lambda (_%max-entries30628%_)
        (let* ((_%proof-steps30630%_ '100000) (_%work-steps30632%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30628%_
           _%proof-steps30630%_
           _%work-steps30632%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
      (lambda (_%max-entries30634%_ _%proof-steps30635%_)
        (let ((_%work-steps30637%_ '100000))
          (gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
           _%max-entries30634%_
           _%proof-steps30635%_
           _%work-steps30637%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
      (lambda _g39924_
        (let ((_g39925_ (let () (declare (not safe)) (##length _g39924_))))
          (cond ((let () (declare (not safe)) (##fx= _g39925_ 0))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__0
                        _g39924_))
                ((let () (declare (not safe)) (##fx= _g39925_ 1))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__1
                        _g39924_))
                ((let () (declare (not safe)) (##fx= _g39925_ 2))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__2
                        _g39924_))
                ((let () (declare (not safe)) (##fx= _g39925_ 3))
                 (apply gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store__%
                        _g39924_))
                (else
                 (##raise-wrong-number-of-arguments-exception
                  gerbil-ascent/candidate/evidence-store#reasoning-open-evidence-store
                  _g39924_))))))
    (define gerbil-ascent/candidate/evidence-store#operation
      (lambda (_%store30355%_ _%name30356%_)
        (let ((__tmp39926
               (let ()
                 (declare (not safe))
                 (clan/poo/object#.ref _%store30355%_ '.operations))))
          (declare (not safe))
          (clan/poo/object#.ref __tmp39926 _%name30356%_))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-resolve-evidence
      (lambda (_%store30351%_ _%snapshot30352%_ _%candidate30353%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30351%_
          '.resolve)
         _%snapshot30352%_
         _%candidate30353%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-claim
      (lambda (_%store30345%_
               _%snapshot30346%_
               _%candidate30347%_
               _%handle30348%_
               _%row30349%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30345%_
          '.claim)
         _%snapshot30346%_
         _%candidate30347%_
         _%handle30348%_
         _%row30349%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fact
      (lambda (_%store30339%_
               _%snapshot30340%_
               _%candidate30341%_
               _%handle30342%_
               _%atom30343%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30339%_
          '.fact)
         _%snapshot30340%_
         _%candidate30341%_
         _%handle30342%_
         _%atom30343%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-fragment
      (lambda (_%store30333%_
               _%snapshot30334%_
               _%candidate30335%_
               _%handle30336%_
               _%atom30337%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30333%_
          '.fragment)
         _%snapshot30334%_
         _%candidate30335%_
         _%handle30336%_
         _%atom30337%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-certificate
      (lambda (_%store30328%_
               _%snapshot30329%_
               _%candidate30330%_
               _%handle30331%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30328%_
          '.certificate)
         _%snapshot30329%_
         _%candidate30330%_
         _%handle30331%_)))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-stats
      (lambda (_%store30326%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30326%_
          '.stats))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-store-clear!
      (lambda (_%store30324%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30324%_
          '.clear))))
    (define gerbil-ascent/candidate/evidence-store#reasoning-evidence-partition
      (lambda (_%store30318%_
               _%snapshot30319%_
               _%candidate30320%_
               _%handle30321%_
               _%alternatives30322%_)
        ((gerbil-ascent/candidate/evidence-store#operation
          _%store30318%_
          '.partition)
         _%snapshot30319%_
         _%candidate30320%_
         _%handle30321%_
         _%alternatives30322%_)))
    (define gerbil-ascent/candidate/evidence-store#partition-obligations
      (lambda (_%fact30292%_ _%alternatives30293%_)
        (if (and (let ()
                   (declare (not safe))
                   (gerbil-ascent/candidate/datum#reasoning-bounded-data?
                    _%alternatives30293%_
                    '16384
                    '128))
                 (list? _%alternatives30293%_)
                 (let ((__tmp39927
                        (lambda (_%a30295%_)
                          (and (list? _%a30295%_)
                               (= (let ()
                                    (declare (not safe))
                                    (##length _%a30295%_))
                                  '2)
                               (let ((__tmp39928 (car _%a30295%_)))
                                 (declare (not safe))
                                 (gerbil-ascent/candidate/program#scalar?
                                  __tmp39928))
                               (list? (cadr _%a30295%_))))))
                   (declare (not safe))
                   (andmap__0 __tmp39927 _%alternatives30293%_)))
            '#!void
            (let ()
              (declare (not safe))
              (error '"invalid branch obligations")))
        (let ((_%seen30297%_ '())
              (_%eligible30298%_ '())
              (_%pruned30299%_ '())
              (_%unresolved30300%_ '())
              (_%allowed30301%_ '())
              (_%claims30302%_ '()))
          (for-each
           (lambda (_%alternative30304%_)
             (let* ((_%id30306%_ (car _%alternative30304%_))
                    (_%answers30308%_
                     (map _%fact30292%_ (cadr _%alternative30304%_)))
                    (_%statuses30312%_
                     (let ((__tmp39929
                            (lambda (_%answer30310%_)
                              (cadr (assq 'status _%answer30310%_)))))
                       (declare (not safe))
                       (##map __tmp39929 _%answers30308%_))))
               (if (let ()
                     (declare (not safe))
                     (##member _%id30306%_ _%seen30297%_))
                   (let ()
                     (declare (not safe))
                     (error '"duplicate branch ID" _%id30306%_))
                   '#!void)
               (set! _%seen30297%_ (cons _%id30306%_ _%seen30297%_))
               (set! _%claims30302%_
                     (cons (list _%id30306%_ _%answers30308%_)
                           _%claims30302%_))
               (if (let ()
                     (declare (not safe))
                     (##memq 'finite-absent _%statuses30312%_))
                   (set! _%pruned30299%_ (cons _%id30306%_ _%pruned30299%_))
                   (if (let ()
                         (declare (not safe))
                         (##memq 'unknown _%statuses30312%_))
                       (let ()
                         (set! _%unresolved30300%_
                               (cons _%id30306%_ _%unresolved30300%_))
                         (set! _%allowed30301%_
                               (cons _%id30306%_ _%allowed30301%_)))
                       (let ()
                         (set! _%eligible30298%_
                               (cons _%id30306%_ _%eligible30298%_))
                         (set! _%allowed30301%_
                               (cons _%id30306%_ _%allowed30301%_)))))))
           _%alternatives30293%_)
          (list (list 'eligible
                      (let ()
                        (declare (not safe))
                        (##reverse _%eligible30298%_)))
                (list 'pruned
                      (let ()
                        (declare (not safe))
                        (##reverse _%pruned30299%_)))
                (list 'unresolved
                      (let ()
                        (declare (not safe))
                        (##reverse _%unresolved30300%_)))
                (list 'allowed
                      (let ()
                        (declare (not safe))
                        (##reverse _%allowed30301%_)))
                (list 'claims
                      (let ()
                        (declare (not safe))
                        (##reverse _%claims30302%_)))))))))
