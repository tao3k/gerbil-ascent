(declare (block) (standard-bindings) (extended-bindings) (inlining-limit 200))
(begin
  (define |gerbil-ascent/program/scheme-session[1]#_g38358_|
    (##structure
     gx#syntax-quote::t
     'relational-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38360_|
    (##structure
     gx#syntax-quote::t
     'make-relational-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38362_|
    (##structure
     gx#syntax-quote::t
     'relational-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38364_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38365_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38367_|
    (##structure
     gx#syntax-quote::t
     'relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38368_|
    (##structure
     gx#syntax-quote::t
     'relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38370_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38371_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38373_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38374_|
    (##structure
     gx#syntax-quote::t
     '&relational-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38376_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session::t
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38378_|
    (##structure
     gx#syntax-quote::t
     'make-relational-program-session
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38380_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session?
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38382_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38383_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38385_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38386_|
    (##structure
     gx#syntax-quote::t
     'relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38388_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38389_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38391_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-engine-set!
     #f
     (gx#current-expander-context)
     '()))
  (define |gerbil-ascent/program/scheme-session[1]#_g38392_|
    (##structure
     gx#syntax-quote::t
     '&relational-program-session-source-arities-set!
     #f
     (gx#current-expander-context)
     '()))
  (begin
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-session|
      (let ((__obj38334
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38334
           'gerbil-ascent/program/scheme-session#relational-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38334
           'relational-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38334
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38334
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '#f '13 '#f '#f))
        (let ((__tmp38357 |gerbil-ascent/program/scheme-session[1]#_g38358_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38357 '4 '#f '#f))
        (let ((__tmp38359 |gerbil-ascent/program/scheme-session[1]#_g38360_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38359 '14 '#f '#f))
        (let ((__tmp38361 |gerbil-ascent/program/scheme-session[1]#_g38362_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38361 '15 '#f '#f))
        (let ((__tmp38363
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38364_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38365_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38363 '16 '#f '#f))
        (let ((__tmp38366
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38367_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38368_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38366 '17 '#f '#f))
        (let ((__tmp38369
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38370_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38371_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38369 '18 '#f '#f))
        (let ((__tmp38372
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38373_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38374_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 __tmp38372 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38334 '() '21 '#f '#f))
        __obj38334))
    (define |gerbil-ascent/program/scheme-session[:0:]#relational-program-session|
      (let ((__obj38335
             (let ()
               (declare (not safe))
               (##structure
                gerbil/core/mop~MOP-2#class-type-info::t
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f
                '#f))))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38335
           'gerbil-ascent/program/scheme-session#relational-program-session::t
           '2
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38335
           'relational-program-session
           '3
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38335
           '(engine source-arities)
           '6
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set!
           __obj38335
           '(engine source-arities)
           '8
           '#f
           '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '() '5 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '#t '9 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '#f '10 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '#f '12 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '#f '13 '#f '#f))
        (let ((__tmp38375 |gerbil-ascent/program/scheme-session[1]#_g38376_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38375 '4 '#f '#f))
        (let ((__tmp38377 |gerbil-ascent/program/scheme-session[1]#_g38378_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38377 '14 '#f '#f))
        (let ((__tmp38379 |gerbil-ascent/program/scheme-session[1]#_g38380_|))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38379 '15 '#f '#f))
        (let ((__tmp38381
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38382_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38383_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38381 '16 '#f '#f))
        (let ((__tmp38384
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38385_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38386_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38384 '17 '#f '#f))
        (let ((__tmp38387
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38388_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38389_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38387 '18 '#f '#f))
        (let ((__tmp38390
               (cons (cons 'engine
                           |gerbil-ascent/program/scheme-session[1]#_g38391_|)
                     (cons (cons 'source-arities
                                 |gerbil-ascent/program/scheme-session[1]#_g38392_|)
                           '()))))
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 __tmp38390 '19 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '() '20 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '() '22 '#f '#f))
        (let ()
          (declare (not safe))
          (##unchecked-structure-set! __obj38335 '() '21 '#f '#f))
        __obj38335))))
